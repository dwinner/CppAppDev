#include "SpreadsheetCell.h"
#include <iostream>
using namespace std;

int main()
{
	SpreadsheetCell myCell(5);
	myCell.setColor(SpreadsheetCell::Colors::Blue);

	return 0;
}
