#ifndef FRAME_STREAM_H
#define FRAME_STREAM_H

#include "PayloadUnitSequenceRepeater.h"
#include "VideoStream.h"
#include "stdbool.h"
#include "stdint.h"

typedef struct
{
    size_t timestamp;
    size_t frameCount;
    size_t framePosition;

    bool frameStarted;
    bool frameAppended;

    /* When to send the next video frame */
    uint32_t frameTimer;
    /* How fast to send frames */
    uint32_t frameInterval;

    VIDEORTP_videoStream_t* stream;

    VIDEORTP_payloadUnit_t* payloadUnits;
    size_t payloadUnitCount;
} VIDEORTP_frameStream_t;

/**
 * @brief Initialize frame stream
 *
 * @param self Instance of VIDEORTP_frameStream_t that function work on
 * @param stream Stream for frame appending
 * @param frameInterval time beetwen frames
 */
void VIDEORTP_frStreamInit(VIDEORTP_frameStream_t* self, VIDEORTP_videoStream_t* stream, uint32_t frameInterval);

/**
 * @brief Set payload fot VIDEORTP_frameStream_t
 *
 * @param self Instance of VIDEORTP_frameStream_t that function work on
 * @param payloadUnits array of frames
 * @param payloadUnitCount frame count
 */
void VIDEORTP_frSetPayload(VIDEORTP_frameStream_t* self, VIDEORTP_payloadUnit_t* payloadUnits, size_t payloadUnitCount);

/**
 * @brief Cycle for adding one frame to ipc stream
 *
 * @param self Instance of VIDEORTP_frameStream_t that function work on
 * @param timeSinceLastCall time since last calling of this function
 */
void VIDEORTP_frStreamCyclic(VIDEORTP_frameStream_t* self, uint32_t timeSinceLastCall);

/**
 * @brief Cycle for adding as much frames to ipc stream as possible
 *
 * @param self Instance of VIDEORTP_frameStream_t that function work on
 * @param timeSinceLastCall time since last calling of this function
 */
void VIDEORTP_frStreamFullCyclic(VIDEORTP_frameStream_t* self, uint32_t timeSinceLastCall);

#endif /* FRAME_STREAM_H */
