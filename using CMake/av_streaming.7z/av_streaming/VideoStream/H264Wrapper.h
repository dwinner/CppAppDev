#ifndef H264__HH
#define H264__HH

#ifdef __cplusplus
extern "C"
{
#endif

#include "BufferWriter.h"
#include "PayloadProvider.h"

#include "PayloadUnitSequenceRepeater.h"

    typedef struct
    {
        void* m_private;
    } VIDEORTP_H264Wrapper_t;

    void VIDEORTP_frInitFileRead(VIDEORTP_H264Wrapper_t* self, const char* fileName);

    void VIDEORTP_frDeinitFileRead(VIDEORTP_H264Wrapper_t* self);

    size_t VIDEORTP_frInitSequenceRepeator(VIDEORTP_H264Wrapper_t* self, VIDEORTP_payloadUnit_t** payload);

#ifdef __cplusplus
};
#endif

#endif
