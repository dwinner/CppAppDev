/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */
/* ===========================================================================
 *
 *   Description about this module
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "VideoTestStream.h"

/* ===========================================================================
 *
 *   Private Typedefs
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Defines
 *
 * ========================================================================= */

#define VIDEORTP_OUTPUT_PARAM "--output"

#define VIDEORTP_HOST_PARAM "--host"

#define VIDEORTP_PORT_PARAM "--port"

#define VIDEORTP_INPUT_PARAM "--input"

#define VIDEORTP_GENERATE_PARAM "--generate"

#define VIDEORTP_LOOP_PARAM "--loop"

#define VIDEORTP_TIME_PARAM "--time"

#define VIDEORTP_FPS_PARAM "--fps"

#define VIDEORTP_MPEGTS_PARAM "--mpegts"

#define VIDEORTP_MPEGTS_TABLES_PARAM "--mpegts-tables"

#define VIDEORTP_MPEGTS_PROGRAM_PARAM "--mpegts-program"

#define VIDEORTP_MPEGTS_PMT_PID_PARAM "--mpegts-pmt-pid"

#define VIDEORTP_MPEGTS_VIDEO_PID_PARAM "--mpegts-video-pid"

#define VIDEORTP_MPEGTS_STREAM_ID_PARAM "--mpegts-stream-id"

#define VIDEORTP_CLOCK_OFFSET_PARAM "--clock-offset"

#define VIDEORTP_RTP_PARAM "--rtp"

#define VIDEORTP_RTCP_PARAM "--rtcp"

#define VIDEORTP_RTP_SIZE_PARAM "--rtp-size"

#define VIDEORTP_REALTIME_PARAM "--realtime"

#define VIDEORTP_IP_AVT_PARAM "--ip-avt"

#define VIDEORTP_SQUENCE_NUMBER "--sequence"

#define VIDEORTP_TEST_STREAM "--test-stream"

#define VIDEORTP_ESTIMATE_STACK "--estimate-stack"

/* ===========================================================================
 *
 *   Private Constants
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Macros
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Data Declarations (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Function Prototypes
 *
 * ========================================================================= */

/**
 * @brief Parsing command line parameters
 *
 * @param paramName Parameter name
 * @param paramValue Parameter value
 * @param config Pointer to the structure of command line parameters
 */
void VIDEORTP_parserArgv(const char* paramName, const char* paramValue, VIDEORTP_initConfiguration_t* config);

/**
 * @brief Setting default parameters
 *
 * @param config Pointer to the structure of command line parameters
 */
void VIDEORTP_defaultArgv(VIDEORTP_initConfiguration_t* config);

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

int main(int argc, char** argv)
{
    /* VIDEORTP_PREGEN_MODE: -- input gen --host 127.0.0.1 --port 5500 */
    /* --input D:\test_noloop.h264 --host 127.0.0.1 --port 5500 --loop 1 */
    int result = 0;
    if (argc > 1)
    {
        VIDEORTP_initConfiguration_t config;
        VIDEORTP_defaultArgv(&config);

        for (int it = 1; it + 1 < argc; it += 2)
        {
            VIDEORTP_parserArgv(argv[it], argv[it + 1], &config);
        }
        VIDEORTP_mainVideoStream(&config);

        if (config.fileNamePCAP != NULL)
        {
            free(config.fileNamePCAP);
        }
        if (config.fileNameH264 != NULL)
        {
            free(config.fileNameH264);
        }
        if (config.address != NULL)
        {
            free(config.address);
        }
    }
    else
    {
        result = 1;
    }
    return result;
}

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

void VIDEORTP_parserArgv(const char* paramName, const char* paramValue, VIDEORTP_initConfiguration_t* config)
{
    if (strcmp(paramName, VIDEORTP_OUTPUT_PARAM) == 0)
    {
        free(config->fileNamePCAP);
        config->fileNamePCAP = strdup(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_HOST_PARAM) == 0)
    {
        free(config->address);
        config->address = strdup(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_PORT_PARAM) == 0)
    {
        config->port = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_INPUT_PARAM) == 0)
    {
        free(config->fileNameH264);
        config->fileNameH264 = strdup(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_GENERATE_PARAM) == 0)
    {
        config->generate = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_LOOP_PARAM) == 0)
    {
        config->loop = (atoi(paramValue) == 0) ? (false) : (true);
    }
    else if (strcmp(paramName, VIDEORTP_TIME_PARAM) == 0)
    {
        config->time = atof(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_FPS_PARAM) == 0)
    {
        config->fps = atof(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_PARAM) == 0)
    {
        config->mpegTS = (atoi(paramValue) == 0) ? (false) : (true);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_TABLES_PARAM) == 0)
    {
        config->mpegTSTables = atof(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_PROGRAM_PARAM) == 0)
    {
        config->mpegTSProgram = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_PMT_PID_PARAM) == 0)
    {
        config->mpegTSPmtPid = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_VIDEO_PID_PARAM) == 0)
    {
        config->mpegTSVideoPid = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_MPEGTS_STREAM_ID_PARAM) == 0)
    {
        config->mpegTSStreamId = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_CLOCK_OFFSET_PARAM) == 0)
    {
        config->clockOffset = atof(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_RTP_PARAM) == 0)
    {
        config->rtp = (atoi(paramValue) == 0) ? (false) : (true);
    }
    else if (strcmp(paramName, VIDEORTP_RTCP_PARAM) == 0)
    {
        config->rtcp = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_RTP_SIZE_PARAM) == 0)
    {
        config->rtpSize = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_REALTIME_PARAM) == 0)
    {
        config->realTime = (atoi(paramValue) == 0) ? (false) : (true);
    }
    else if (strcmp(paramName, VIDEORTP_IP_AVT_PARAM) == 0)
    {
        switch (atoi(paramValue))
        {
            case 1:
                config->IPAvt = VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS;
                break;
            case 2:
                config->IPAvt = VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS;
                break;
            case 0:
            default:
                config->IPAvt = VIDEORTP_rtpStreamingMode_RFC2250;
                break;
        }
    }
    else if (strcmp(paramName, VIDEORTP_SQUENCE_NUMBER) == 0)
    {
        config->sequenceNumber = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_TEST_STREAM) == 0)
    {
        config->testStream = atoi(paramValue);
    }
    else if (strcmp(paramName, VIDEORTP_ESTIMATE_STACK) == 0)
    {
        config->estimateStack = atoi(paramValue);
    }
}

void VIDEORTP_defaultArgv(VIDEORTP_initConfiguration_t* config)
{
    config->fileNamePCAP = VIDEORTP_DEFAULT_OUTPUT;
    config->fileNameH264 = VIDEORTP_DEFAULT_INPUT;
    config->address = VIDEORTP_DEFAULT_HOST;
    config->port = VIDEORTP_DEFAULT_PORT;
    config->generate = VIDEORTP_DEFAULT_GENERATE;
    config->loop = VIDEORTP_DEFAULT_LOOP;
    config->time = VIDEORTP_DEFAULT_TIME;
    config->fps = VIDEORTP_DEFAULT_FRAME_RATE;
    config->mpegTS = VIDEORTP_DEFAULT_MPEGTS;
    config->mpegTSTables = VIDEORTP_DEFAULT_MPEGTS_TABLES;
    config->mpegTSProgram = VIDEORTP_DEFAULT_MPEGTS_PROGRAM;
    config->mpegTSPmtPid = VIDEORTP_DEFAULT_MPEGTS_PMT_PID;
    config->mpegTSVideoPid = VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID;
    config->mpegTSStreamId = VIDEORTP_DEFAULT_MPEGTS_STREAM_ID;
    config->clockOffset = VIDEORTP_DEFAULT_CLOCK_OFFSET;
    config->rtp = VIDEORTP_DEFAULT_RTP;
    config->rtcp = VIDEORTP_DEFAULT_RTCP;
    config->rtpSize = VIDEORTP_DEFAULT_RTP_SIZE;
    config->realTime = VIDEORTP_DEFAULT_REALTIME;
    config->IPAvt = VIDEORTP_DEFAULT_IP_AVT;
    config->sequenceNumber = VIDEORTP_DEFAULT_SEQUENCE_NUMBER;
    config->testStream = VIDEORTP_DEFAULT_TEST_STREAM;
    config->estimateStack = VIDEORTP_DEFAULT_ESTIMATE_STACK;
}
