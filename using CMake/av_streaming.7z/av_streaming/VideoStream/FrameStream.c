#include "FrameStream.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frStreamInit
 *
 *   Function:   Initialize frame stream
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               VIDEORTP_videoStream_t* stream: Stream for frame appending
 *               uint32_t frameInterval: time beetwen frames
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frStreamInit(VIDEORTP_frameStream_t* self, VIDEORTP_videoStream_t* stream, uint32_t frameInterval)
{
    assert(self);

    self->frameTimer = frameInterval;
    self->frameInterval = frameInterval;

    self->timestamp = frameInterval;
    self->frameCount = 0;
    self->framePosition = 0;

    self->frameStarted = false;
    self->frameAppended = false;
    self->stream = stream;

    self->payloadUnits = NULL;
    self->payloadUnitCount = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frSetPayload
 *
 *   Function:   Set payload fot VIDEORTP_frameStream_t
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               VIDEORTP_payloadUnit_t* payloadUnits: array of frames
 *               size_t payloadUnitCount: frame count
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frSetPayload(VIDEORTP_frameStream_t* self, VIDEORTP_payloadUnit_t* payloadUnits, size_t payloadUnitCount)
{
    self->payloadUnits = payloadUnits;
    self->payloadUnitCount = payloadUnitCount;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frStreamCyclic
 *
 *   Function:   Cycle for adding one frame to ipc stream
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               uint32_t timeSinceLastCall: time since last calling of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frStreamCyclic(VIDEORTP_frameStream_t* self, uint32_t timeSinceLastCall)
{
    assert(self);
    if (VIDEORTP_timerTick(&self->frameTimer, timeSinceLastCall, self->frameInterval))
    {
        /* calculate new timestamp */
        self->timestamp += self->frameInterval;

        size_t frameSize = self->payloadUnits[self->frameCount].length;
        /* check that last appendFrame was success */
        if (self->framePosition == 0)
        {
            self->frameStarted = VIDEORTP_startFrameVideoStream(self->stream, frameSize, self->timestamp * 27000);
        }
        self->frameAppended = false;

        /* slice frame to chunks */
        while (self->frameStarted && (self->framePosition < frameSize))
        {
            size_t payloadSize = frameSize - self->framePosition < 512 ? frameSize - self->framePosition : 512;
            self->frameAppended = VIDEORTP_appendFrameVideoStream(
                self->stream, (const uint8_t*) self->payloadUnits[self->frameCount].buffer + self->framePosition, payloadSize,
                NULL);
            if (!self->frameAppended)
            {
                break;
            }
            self->framePosition += payloadSize;
        }

        /* check last chunk was added */
        if (self->framePosition == frameSize)
        {
            self->frameCount++;
            self->framePosition = 0;

            /* check last frame */
            if (self->frameCount >= self->payloadUnitCount)
            {
                self->frameCount = 0;
            }
        }
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frStreamFullCyclic
 *
 *   Function:   Cycle for adding as much frames to ipc stream as possible
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               uint32_t timeSinceLastCall: time since last calling of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frStreamFullCyclic(VIDEORTP_frameStream_t* self, uint32_t timeSinceLastCall)
{
    assert(self);
    if (VIDEORTP_timerTick(&self->frameTimer, timeSinceLastCall, self->frameInterval))
    {
        size_t frameSize = self->payloadUnits[self->frameCount].length;

        while (self->framePosition <= frameSize)
        {
            frameSize = self->payloadUnits[self->frameCount].length;

            if (!self->frameStarted && self->framePosition == 0)
            {
                self->timestamp += self->frameInterval;
                self->frameStarted = VIDEORTP_startFrameVideoStream(self->stream, frameSize, self->timestamp * 27000);
                if (!self->frameStarted)
                {
                    break;
                }
            }

            size_t payloadSize = frameSize - self->framePosition < 512 ? frameSize - self->framePosition : 512;
            self->frameAppended = VIDEORTP_appendFrameVideoStream(
                self->stream, (const uint8_t*) self->payloadUnits[self->frameCount].buffer + self->framePosition, payloadSize,
                NULL);
            if (self->frameAppended)
            {
                self->framePosition += payloadSize;
            }
            else
            {
                break;
            }

            /* check last chunk was added */
            if (self->framePosition == frameSize)
            {
                self->frameStarted = false;
                self->frameCount++;
                self->framePosition = 0;
                /* check last frame */
                if (self->frameCount >= self->payloadUnitCount)
                {
                    self->frameCount = 0;
                }
            }
        }
    }
}
