#include "FrameStream.h"
#include "VideoRtpUtil.h"
#include "sysdef.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frStreamInit
 *
 *   Function:   Initialize frame stream
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               VIDEORTP_videoStream_t* stream: Stream for frame appending
 *               uint32_t frameInterval: time beetwen frames
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frStreamInit(VIDEORTP_frameStream_t* self, VIDEORTP_videoStream_t* stream, uint32_t frameInterval)
{
    assert(self);

    self->frameTimer = frameInterval;
    self->frameInterval = frameInterval;

    self->timestamp = frameInterval;
    self->frameCount = 0;
    self->framePosition = 0;

    self->frameStarted = false;
    self->stream = stream;

    self->payloadUnits = NULL;
    self->payloadUnitCount = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frSetPayload
 *
 *   Function:   Set payload fot VIDEORTP_frameStream_t
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               VIDEORTP_payloadUnit_t* payloadUnits: array of frames
 *               size_t payloadUnitCount: frame count
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frSetPayload(VIDEORTP_frameStream_t* self, VIDEORTP_payloadUnit_t* payloadUnits, size_t payloadUnitCount)
{
    self->payloadUnits = payloadUnits;
    self->payloadUnitCount = payloadUnitCount;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frStreamCyclic
 *
 *   Function:   Cycle for adding one frame to ipc stream
 *
 *   Inputs:
 *               VIDEORTP_frameStream_t* self: Instance of VIDEORTP_frameStream_t that function work on
 *               uint32_t timeSinceLastCall: time since last calling of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-815
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frStreamCyclic(VIDEORTP_frameStream_t* self, uint32_t timeSinceLastCall)
{
    assert(self);

    const size_t frameSize = self->payloadUnits[self->frameCount].length;

    if (VIDEORTP_timerTick(&self->frameTimer, timeSinceLastCall, self->frameInterval))
    {
        /* calculate new timestamp */
        self->timestamp += self->frameInterval;

        /* the next frame will be delayed until the last frame was added completely */
        if (!self->frameStarted && self->framePosition == 0)
        {
            uint64_t pts = self->timestamp * UINT64_C(27000);
            uint32_t ieee = self->timestamp * 1000000;
            VIDEORTP_timestamp timestamp = { pts, pts, ieee, 55555 };
            self->frameStarted = VIDEORTP_startFrameVideoStream(self->stream, frameSize, &timestamp);
        }
    }

    if (self->frameStarted)
    {
        /* slice frame to chunks */
        while ((self->framePosition < frameSize))
        {
            size_t chunkSize = VIDEORTP_sysGetMin(frameSize - self->framePosition, VIDEORTP_sysGetMax(frameSize / 4, 512));
            bool frameAppended = VIDEORTP_appendFrameVideoStream(
                self->stream, (const uint8_t*) self->payloadUnits[self->frameCount].buffer + self->framePosition, chunkSize, NULL);
            if (!frameAppended)
            {
                break;
            }
            self->framePosition += chunkSize;
        }

        /* check last chunk was added */
        if (self->framePosition == frameSize)
        {
            self->frameStarted = false;
            self->frameCount++;
            self->framePosition = 0;

            /* check last frame */
            if (self->frameCount >= self->payloadUnitCount)
            {
                self->frameCount = 0;
            }
        }
    }
}
