#include "H264Wrapper.h"

#include "H264FileReader.h"
#include <memory>
#include <string>
#include <vector>

struct Private
{
    std::string m_fileName;

    size_t m_position;

    size_t m_nalUnit;

    std::unique_ptr<std::valarray<std::unique_ptr<Nalu>>> m_nalUnits;

    H264FileReader* m_fileReader;
};

extern "C" void VIDEORTP_frInitFileRead(VIDEORTP_H264Wrapper_t* self, const char* fileName)
{
    self->m_private = (void*) new Private();
    Private* _private = (Private*) self->m_private;
    _private->m_fileName = fileName;
    _private->m_fileReader = new H264FileReader(_private->m_fileName);
    _private->m_nalUnits = _private->m_fileReader->GetNalUnits();
    _private->m_position = 0;
    _private->m_nalUnit = 0;
}

extern "C" void VIDEORTP_frDeinitFileRead(VIDEORTP_H264Wrapper_t* self)
{
    Private* _private = (Private*) self->m_private;
    delete _private->m_fileReader;
    delete _private;
}

extern "C" size_t VIDEORTP_frInitSequenceRepeator(VIDEORTP_H264Wrapper_t* self, VIDEORTP_payloadUnit_t** payload)
{
    Private* _private = (Private*) self->m_private;
    size_t result = _private->m_nalUnits->size();
    *payload = new VIDEORTP_payloadUnit_t[result];
    for (size_t it = 0; it < _private->m_nalUnits->size(); it++)
    {
        std::unique_ptr<Nalu> item = std::move((*_private->m_nalUnits)[it]);
        std::valarray<uint8_t> content = item->GetContent();
        (*payload)[it].length = item->GetLength();
        uint8_t* buffer = new uint8_t[item->GetLength()];
        for (size_t itt = 0; itt < item->GetLength(); itt++)
        {
            buffer[itt] = content[itt];
        }
        (*payload)[it].buffer = buffer;
    }
    return result;
}
