#ifndef VIDEO_STREAM_H
#define VIDEO_STREAM_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <stdbool.h>
#include <stdint.h>

#include <AvbRtcpPacketBuilder.h>

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup VideoStream
     * @{
     */

    /* ===========================================================================
     *
     *  Extern Support
     *
     * ========================================================================= */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    typedef struct
    {
        /**
         * @brief Save stream to file
         *
         */
        char* fileNamePCAP;
        /**
         * @brief Read H264 input stream from file
         *
         */
        char* fileNameH264;
        /**
         * @brief Send stream to UDP address
         *
         */
        char* address;
        /**
         * @brief Send stream to UDP port
         *
         */
        uint16_t port;
        /**
         * @brief How many dummy packets to generate
         *
         */
        uint32_t generate;
        /**
         * @brief Repeat stream indefinitely
         *
         */
        bool loop;
        /**
         * @brief Starting timestamp (seconds)
         *
         */
        float time;
        /**
         * @brief Cycle time (milliseconds)
         *
         */
        float cycle;
        /**
         * @brief Frame rate of video
         *
         */
        float fps;
        /**
         * @brief Data rate of video
         *
         */
        uint32_t dataRate;
        /**
         * @brief Interval to resend program tables (milliseconds)
         *
         */
        float mpegTSTables;
        /**
         * @brief Program Number of the MPEG video stream
         *
         */
        uint32_t mpegTSProgram;
        /**
         * @brief PID of the MPEG Program Map Table
         *
         */
        uint32_t mpegTSPmtPid;
        /**
         * @brief PID of the MPEG video elementary stream
         *
         */
        uint32_t mpegTSVideoPid;
        /**
         * @brief MPEG Transport Stream ID in Program Association Table
         *
         */
        uint32_t mpegTSStreamId;
        /**
         * @brief Offset of MPEG clock (milliseconds)
         *
         */
        float clockOffset;
        /**
         * @brief Wrap data in RTP packets
         *
         */
        bool rtp;
        /**
         * @brief Send RTCP packets
         *
         */
        bool rtcp;
        /**
         * @brief Maximum size of RTP packets
         *
         */
        uint32_t rtpSize;
        /**
         * @brief Comply with VW LAH.DUM.035.F (IP Audio/Video Transport)
         *
         */
        VIDEORTP_rtpStreamingMode_t IPAvt;
        /**
         * @brief Sequence number
         *
         */
        uint16_t sequenceNumber;
        /**
         * @brief Whether to enable test stream (padding, etc.) and bypass IPC
         *
         */
        bool testStream;
        /**
         * @brief Whether to estimate the stack usage
         *
         */
        bool estimateStack;
    } VIDEORTP_initConfiguration_t;

    /* ===========================================================================
     *
     *  Public Defines
     *
     * ========================================================================= */

#define VIDEORTP_DEFAULT_OUTPUT NULL

#define VIDEORTP_DEFAULT_HOST NULL

#define VIDEORTP_DEFAULT_PORT 5004

#define VIDEORTP_DEFAULT_INPUT NULL

#define VIDEORTP_DEFAULT_GENERATE 1000

#define VIDEORTP_DEFAULT_LOOP 0

#define VIDEORTP_DEFAULT_TIME 5

#define VIDEORTP_DEFAULT_CYCLE 1

#define VIDEORTP_DEFAULT_FRAME_RATE 25

#define VIDEORTP_DEFAULT_DATA_RATE 6000000

#define VIDEORTP_DEFAULT_MPEGTS_TABLES 250

#define VIDEORTP_DEFAULT_MPEGTS_PROGRAM 1

#define VIDEORTP_DEFAULT_MPEGTS_PMT_PID 0x1000

#define VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID 0x0100

#define VIDEORTP_DEFAULT_MPEGTS_STREAM_ID 1

#define VIDEORTP_DEFAULT_CLOCK_OFFSET 50

#define VIDEORTP_DEFAULT_RTP 1

#define VIDEORTP_DEFAULT_RTCP 1

#define VIDEORTP_DEFAULT_RTP_SIZE 1232

#define VIDEORTP_DEFAULT_IP_AVT VIDEORTP_rtpStreamingMode_RFC2250

#define VIDEORTP_DEFAULT_SEQUENCE_NUMBER 1

#define VIDEORTP_DEFAULT_TEST_STREAM 0

#define VIDEORTP_DEFAULT_ESTIMATE_STACK 0

    /* ===========================================================================
     *
     *  Public Macros
     *
     * ========================================================================= */

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Main function
     *
     * @param config VIDEORTP_initConfiguration_t params line command
     */
    void VIDEORTP_mainVideoStream(const VIDEORTP_initConfiguration_t* config);

    /**@} VideoStream global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* VIDEO_STREAM_H */
