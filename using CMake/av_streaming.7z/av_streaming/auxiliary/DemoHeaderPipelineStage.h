#ifndef DEMOHEADERPIPELINESTAGE_H_INCLUDED
#define DEMOHEADERPIPELINESTAGE_H_INCLUDED

#include "PayloadProvider.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

    // Add some header to the payload of another pipeline stage
    typedef struct DemoHeaderPipelineStage
    {
        /** @privatesection @{ */
        VIDEORTP_payloadProvider_t vtable; /* "virtual methods" of this object */
        VIDEORTP_payloadProvider_t* predecessor; /* previous (filtered) pipeline stage */
        uint32_t magic; /* magic number to write into the header */
        /** @} */
    } DemoHeaderPipelineStage;

    void DemoHeaderPipelineStage_init(DemoHeaderPipelineStage* obj, VIDEORTP_payloadProvider_t* predecessor, uint32_t magic);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
