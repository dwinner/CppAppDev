/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */
/* ===========================================================================
 *
 *   Description about this module
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PCAPWriter.h"
#include "BufferWriter.h"
#include "sysdef.h"

#pragma comment(lib, "ws2_32")

/* ===========================================================================
 *
 *   Private Typedefs
 *
 * ========================================================================= */

/**
 *
 * @note This interface describes the file header parameters
 */
typedef struct
{
    /**
     * @brief Magic number
     *
     */
    uint32_t magicNumber;

    /**
     * @brief Major version number
     *
     */
    uint16_t versionMajor;

    /**
     * @brief Minor version number
     *
     */
    uint16_t versionMinor;

    /**
     * @brief GMT to local correction
     *
     */
    int32_t thisZone;

    /**
     * @brief Accuracy of timestamps
     *
     */
    uint32_t sigFigs;

    /**
     * @brief Max length of captured packets, in octets
     *
     */
    uint32_t snapLen;

    /**
     * @brief Data link type
     *
     */
    uint32_t network;
} VIDEORTP_pcapHdr_t;

/**
 *
 * @note This interface describes the packet header parameters
 */
typedef struct
{
    /**
     * @brief Timestamp seconds
     *
     */
    uint32_t tsSec;

    /**
     * @brief Timestamp microseconds
     *
     */
    uint32_t tsUsec;

    /**
     * @brief Number of octets of packet saved in file
     *
     */
    uint32_t inclLen;

    /**
     * @brief Actual length of packet
     *
     */
    uint32_t origLen;
} VIDEORTP_pcapRecHdr_t;

/**
 *
 * @note This interface describes the Inthernet frame
 */
typedef struct
{
    /**
     * @brief Source address
     *
     */
    uint8_t source[6];

    /**
     * @brief Destination address
     *
     */
    uint8_t destination[6];

    /**
     * @brief Type protocol
     *
     */
    uint16_t typeProtocol;
} VIDEORTP_EtherHeader_t;

/* ===========================================================================
 *
 *   Private Defines
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Constants
 *
 * ========================================================================= */

/** PCAP file header */
static const VIDEORTP_pcapHdr_t VIDEORTP_pcapHeadFile = {
    0xa1b2c3d4, /* magicNumber */
    2, /* versionMajor */
    4, /* versionMinor */
    0, /* thisZone */
    0, /* sigFigs */
    0xffff, /* snapLen */
    1 /* network */
};

/** Ethernet header */
static const VIDEORTP_EtherHeader_t VIDEORTP_pcapEtherHead = {
    { 0x33, 0x33, 0x00, 0x00, 0x00, 0xfb }, /* source */
    { 0xf4, 0xb5, 0x20, 0x0c, 0x8b, 0xf1 }, /* destination */
    0xdd86, /* type of protocol */
};

/* ===========================================================================
 *
 *   Private Macros
 *
 * ========================================================================= */

/* size of headers without pcap file header */
#define VIDEORTP_PCAP_FRAME_HEADER_SIZE 78
/* udp source port */
#define VIDEORTP_PCAP_UDP_PORT_SRC 5000
/* udp destination port */
#define VIDEORTP_PCAP_UDP_PORT_DST 55000
/* udp header size */
#define VIDEORTP_PCAP_UDP_HEADER_SIZE 8
/* type of udp */
#define VIDEORTP_PCAP_UDP_TYPE 0x0011

/* ===========================================================================
 *
 *   Private Data Declarations (static)
 *
 * ========================================================================= */

/* Source IP adress */
static uint8_t VIDEORTP_pcapIpSrcAddr[16]
    = { 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa8, 0x1c, 0xbb, 0x91, 0x6d, 0x05, 0x23, 0x9d };
/* Destination IP adress */
static uint8_t VIDEORTP_pcapIpDstAddr[16]
    = { 0xff, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xfb };
/* IP Version and trafic class */
static uint8_t VIDEORTP_pcapIphCls[4] = { 0x60, 0x0a, 0x17, 0x70 };

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_getChecksum
 *
 *   Function:   Calculate checksum for buffer
 *
 *   Inputs:
 *               uint16_t *buffer: buffer
 *               int32_t len: buffer size
 *
 *   Outputs:
 *               uint32_t: sum of buffer words
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static uint32_t VIDEORTP_getChecksum(uint16_t* buffer, int32_t len)
{
    /* RFC 1071 */
    uint16_t result;
    uint16_t* addr = buffer;
    uint32_t sum = 0;

    while (len > 1)
    {
        sum += *addr;
        addr++;
        len -= 2;
    }

    if (len == 1)
    {
        sum += *(unsigned char*) addr;
    }

    return sum;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_finalizeCheckSum
 *
 *   Function:   Finalize checksum calculating
 *
 *   Inputs:
 *               uint32_t checkSum: sum of all data words
 *
 *   Outputs:
 *               uint32_t: checksum
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static uint16_t VIDEORTP_finalizeCheckSum(uint32_t checkSum)
{
    /* RFC 1071 Section 4.1 */
    uint32_t sum = checkSum;

    sum = (sum & 0xffff) + (sum >> 16);
    sum = (sum & 0xffff) + (sum >> 16);

    sum = ~sum;

    return (uint16_t) sum;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_getPseudoHeaderCheckSum
 *
 *   Function:   Calculate checksum for pseudoheader
 *
 *   Inputs:
 *               uint16_t payloadSize: payload size into ip header and udp header
 *
 *   Outputs:
 *               uint32_t: sum of all pseudoheader words
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static uint32_t VIDEORTP_getPseudoHeaderCheckSum(uint16_t payloadSize)
{
    /* RFC 2460 Section 8.1 */
    typedef struct
    {
        uint8_t ipSource[16];
        uint8_t ipDestination[16];
        uint32_t ipPayloadLength;
        uint32_t ipProtocol;

        uint16_t udpSource;
        uint16_t udpDestination;
        uint16_t udpSize;
    } pseudoHeader_t;

    pseudoHeader_t head = { 0 };
    memcpy(&head.ipSource, VIDEORTP_pcapIpSrcAddr, sizeof(VIDEORTP_pcapIpSrcAddr));
    memcpy(&head.ipDestination, VIDEORTP_pcapIpDstAddr, sizeof(VIDEORTP_pcapIpDstAddr));

    head.ipProtocol = htonl(VIDEORTP_PCAP_UDP_TYPE);
    head.ipPayloadLength = htonl(payloadSize);

    head.udpSource = htons(VIDEORTP_PCAP_UDP_PORT_SRC);
    head.udpDestination = htons(VIDEORTP_PCAP_UDP_PORT_DST);
    head.udpSize = htons(payloadSize);

    return VIDEORTP_getChecksum((uint16_t*) &head, 46);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_getCompleteCheckSum
 *
 *   Function:   Checksum calculation
 *
 *   Inputs:
 *               uint6_t* buffer: buffers with recorded data
 *               int32_t len: data length
 *
 *   Outputs:
 *               uint16_t: result checksum
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static uint32_t VIDEORTP_getCompleteCheckSum(uint8_t* payload, size_t payloadSize)
{
    uint32_t _checksum = 0;
    _checksum = VIDEORTP_getPseudoHeaderCheckSum(payloadSize + VIDEORTP_PCAP_UDP_HEADER_SIZE);
    _checksum += VIDEORTP_getChecksum((uint16_t*) payload, payloadSize);
    _checksum = htons(VIDEORTP_finalizeCheckSum(_checksum));
    return _checksum;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapAddUDPHeader
 *
 *   Function:   Adds a UDP packet header
 *
 *   Inputs:
 *               uint8_t* buffer: buffers with recorded data
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapAddUDPHeader(VIDEORTP_bufferWriter_t* bw, uint8_t* payload, size_t payloadSize)
{
    assert(bw);
    uint32_t _checksum = VIDEORTP_getCompleteCheckSum(payload, payloadSize);

    /* Source port */
    VIDEORTP_bufWriteInteger(bw, VIDEORTP_PCAP_UDP_PORT_SRC, sizeof(uint16_t));
    /* Destination port */
    VIDEORTP_bufWriteInteger(bw, VIDEORTP_PCAP_UDP_PORT_DST, sizeof(uint16_t));
    /* Payload lenght */
    VIDEORTP_bufWriteInteger(bw, payloadSize + VIDEORTP_PCAP_UDP_HEADER_SIZE, sizeof(uint16_t));
    /* Checksum */
    VIDEORTP_bufWriteInteger(bw, _checksum, sizeof(uint16_t));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapAddIP6Header
 *
 *   Function:   Adds a IP6 packet header
 *
 *   Inputs:
 *               uint8_t* buffer: buffers with recorded data
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapAddIP6Header(VIDEORTP_bufferWriter_t* bw, uint16_t payloadLength)
{
    assert(bw);

    VIDEORTP_bufWriteData(bw, VIDEORTP_pcapIphCls, sizeof(VIDEORTP_pcapIphCls));
    VIDEORTP_bufWriteInteger(bw, payloadLength, sizeof(uint16_t)); /* lenght */
    VIDEORTP_bufWriteInteger(bw, 17, sizeof(uint8_t)); /* next header */
    VIDEORTP_bufWriteInteger(bw, 1, sizeof(uint8_t)); /* limit */
    VIDEORTP_bufWriteData(bw, VIDEORTP_pcapIpSrcAddr, sizeof(VIDEORTP_pcapIpSrcAddr)); /* source IP adress*/
    VIDEORTP_bufWriteData(bw, VIDEORTP_pcapIpDstAddr, sizeof(VIDEORTP_pcapIpDstAddr)); /* destination IP adress */
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapAddEtherHeader
 *
 *   Function:   Adds a Ethernet header
 *
 *   Inputs:
 *               uint8_t* buffer: buffers with recorded data
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapAddEtherHeader(VIDEORTP_bufferWriter_t* bw)
{
    assert(bw);
    VIDEORTP_bufWriteData(bw, &VIDEORTP_pcapEtherHead, sizeof(VIDEORTP_EtherHeader_t));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapAddPacketHeader
 *
 *   Function:   Adds the header of the captured packet
 *
 *   Inputs:
 *               uint8_t* buffer: buffers with recorded data
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapAddPacketHeader(VIDEORTP_bufferWriter_t* bw, size_t packetLength)
{
    assert(bw);
    VIDEORTP_pcapRecHdr_t head;
    head.tsSec = time(NULL);
    head.tsUsec = 0;
    head.inclLen = packetLength + VIDEORTP_PCAP_FRAME_HEADER_SIZE - sizeof(VIDEORTP_pcapRecHdr_t);
    head.origLen = packetLength + VIDEORTP_PCAP_FRAME_HEADER_SIZE - sizeof(VIDEORTP_pcapRecHdr_t);

    VIDEORTP_bufWriteData(bw, (void*) &head, sizeof(VIDEORTP_pcapRecHdr_t));
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapAddPCAPHeader
 *
 *   Function:   Adds a global title
 *
 *   Inputs:
 *               uint8_t* buffer: buffers with recorded data
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapAddPCAPHeader(VIDEORTP_bufferWriter_t* bw)
{
    assert(bw);
    VIDEORTP_bufWriteData(bw, (void*) &VIDEORTP_pcapHeadFile, sizeof(VIDEORTP_pcapHdr_t));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapCommitTransmissionBuffer
 *
 *   Function:   Saves data to disk
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable: VIDEORTP_pcapWriter_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static void VIDEORTP_pcapCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    VIDEORTP_pcapWriter_t* self = (void*) vtable;

    assert(self);
    assert(self->file);

    uint8_t headerBuffer[VIDEORTP_PCAP_FRAME_HEADER_SIZE];
    VIDEORTP_bufferWriter_t headerWriter;
    VIDEORTP_bufInit(&headerWriter, headerBuffer, sizeof(headerBuffer));

    uint8_t* payload = VIDEORTP_bufGetBasePointer(&self->bufferWriter);
    size_t payloadSize = VIDEORTP_bufGetBytesWritten(&(self->bufferWriter));

    VIDEORTP_pcapAddPacketHeader(&headerWriter, payloadSize);
    VIDEORTP_pcapAddEtherHeader(&headerWriter);
    VIDEORTP_pcapAddIP6Header(&headerWriter, payloadSize + VIDEORTP_PCAP_UDP_HEADER_SIZE);

    VIDEORTP_pcapAddUDPHeader(&headerWriter, payload, payloadSize);

    fwrite(headerBuffer, 1, VIDEORTP_bufGetBytesWritten(&headerWriter), self->file);
    fwrite(payload, 1, payloadSize, self->file);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapPrepareTransmissionBuffer
 *
 *   Function:   Returns a pointer to the buffer
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable: VIDEORTP_pcapWriter_t instance that the function works on
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t*: Pointer to VIDEORTP_bufferWriter_t struct
 *
 *   Side Effects:
 *
 *               Call clear buffer writer for self->bufferWriter
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
static VIDEORTP_bufferWriter_t* VIDEORTP_pcapPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    VIDEORTP_pcapWriter_t* self = (void*) vtable;

    assert(self);

    VIDEORTP_bufClear(&self->bufferWriter);

    return &self->bufferWriter;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapInit
 *
 *   Function:   Initializing the PCAP writer interface
 *
 *   Inputs:
 *               VIDEORTP_pcapWriter_t* self: VIDEORTP_pcapWriter_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_pcapInit(VIDEORTP_pcapWriter_t* self)
{
    assert(self);
    assert(self->fileName);
    self->vtable.commitTransmissionBuffer = VIDEORTP_pcapCommitTransmissionBuffer;
    self->vtable.prepareTransmissionBuffer = VIDEORTP_pcapPrepareTransmissionBuffer;
    self->file = fopen(self->fileName, "wb+");
    assert(self->file);
    VIDEORTP_bufInit(&self->bufferWriter, self->payloadBuffer, VIDEORTP_PCAP_LENGTH_DATA);

    uint8_t headerBuffer[VIDEORTP_PCAP_FRAME_HEADER_SIZE];
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, headerBuffer, VIDEORTP_PCAP_FRAME_HEADER_SIZE);
    VIDEORTP_pcapAddPCAPHeader(&bw);
    fwrite(headerBuffer, 1, VIDEORTP_bufGetBytesWritten(&bw), self->file);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pcapDeinit
 *
 *   Function:   Deinitializing the PCAP writer interface
 *
 *   Inputs:
 *               VIDEORTP_pcapWriter_t* self: VIDEORTP_pcapWriter_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-8, MAGAVSTR-585
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_pcapDeinit(VIDEORTP_pcapWriter_t* self)
{
    assert(self);
    if (self->file != NULL)
    {
        fflush(self->file);
        fclose(self->file);
        self->file = NULL;
    }
}
