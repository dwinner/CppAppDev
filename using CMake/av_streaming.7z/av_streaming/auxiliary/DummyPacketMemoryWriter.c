/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "DummyPacketMemoryWriter.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_dmwPrepareTransmissionBuffer
 *
 *   Function:   It shall return buffer writer by VIDEORTP_dummyPacketMemoryWriter_t
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable - interface
 *
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t*
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-19, MAGAVSTR-583, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */

VIDEORTP_bufferWriter_t* VIDEORTP_dmwPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_dummyPacketMemoryWriter_t* self = (VIDEORTP_dummyPacketMemoryWriter_t*) ((void*) vtable);
    VIDEORTP_bufClear(&(self->bufferWriter));
    return &(self->bufferWriter);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_dmwCommitTransmissionBuffer
 *
 *   Function:   It call write pattern for VIDEORTP_dummyPacketMemoryWriter_t VIDEORTP_bufferWriter_t. It need for test
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable - interface
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t*
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-19, MAGAVSTR-583, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_dmwCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_dmwGetLoadBuffer
 *
 *   Function:   It shall return loadBuffer by VIDEORTP_dummyPacketMemoryWriter_t
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable - interface
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t*
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-19, MAGAVSTR-583, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
uint8_t* VIDEORTP_dmwGetLoadBuffer(VIDEORTP_dummyPacketMemoryWriter_t* self)
{
    assert(self);
    return self->loadBuffer;
}

/* ===========================================================================
 *
 *   Name:       LANE_DETECTION_F_CalcLatDistBetwTwoObj_u16
 *
 *   Function:   It shall init VIDEORTP_dummyPacketMemoryWriter_t. Set it values and set interface functions
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable - interface
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t*
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-19, MAGAVSTR-583, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_dmwInit(VIDEORTP_dummyPacketMemoryWriter_t* self)
{
    assert(self);
    self->vtable.prepareTransmissionBuffer = VIDEORTP_dmwPrepareTransmissionBuffer;
    self->vtable.commitTransmissionBuffer = VIDEORTP_dmwCommitTransmissionBuffer;

    VIDEORTP_bufInit(&(self->bufferWriter), self->loadBuffer, VIDEORTP_MAX_TX_PAYLOAD_SIZE);
}
