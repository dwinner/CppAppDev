#ifndef DEMOGENERATORPIPELINESTAGE_H_INCLUDED
#define DEMOGENERATORPIPELINESTAGE_H_INCLUDED

#include "PayloadProvider.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

    // Generates data pattern
    typedef struct DemoGeneratorPipelineStage
    {
        /** @privatesection @{ */
        VIDEORTP_payloadProvider_t vtable; /* "virtual methods" of this object */
        uint8_t pattern; /* what to write in the generated packets */
        size_t nextChunkSize; /* amount of memory to be copied by copyChunk as promised by prepareNextChunk */
        /** @} */
    } DemoGeneratorPipelineStage;

    void DemoGeneratorPipelineStage_init(DemoGeneratorPipelineStage* self, uint8_t pattern);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
