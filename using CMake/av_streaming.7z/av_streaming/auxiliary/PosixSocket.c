/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PosixSocket.h"

#pragma comment(lib, "ws2_32")

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockPrepareTransmissionBuffer
 *
 *   Function:   Returns a pointer to the BufferWriter
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* vtable: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               VIDEORTP_BufferWriter_t*: Pointer to BufferWriter struct
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_posixSocket_t */
static VIDEORTP_bufferWriter_t* VIDEORTP_sockPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_posixSocket_t* self = (void*) vtable;
    VIDEORTP_bufClear(&(self->m_payloadWriter));
    return &self->m_payloadWriter;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockCommitTransmissionBuffer
 *
 *   Function:   The function transmits data over the network
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* vtable: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_posixSocket_t */
static void VIDEORTP_sockCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_posixSocket_t* self = (void*) vtable;

    assert(self->m_sockData.m_socket != INVALID_SOCKET);
    int res = sendto(self->m_sockData.m_socket, (char*) VIDEORTP_bufGetBasePointer(&self->m_payloadWriter),
                     VIDEORTP_bufGetBytesWritten(&(self->m_payloadWriter)), 0, (SOCKADDR*) &self->m_sockData.m_sockaddr,
                     sizeof(self->m_sockData.m_sockaddr));
    assert(res != SOCKET_ERROR);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockCreateSocket
 *
 *   Function:   Initializes and establishes a network connection
 *
 *   Inputs:
 *               VIDEORTP_sockData_t* sockData: Structure with data for connection initialization
 *               const char* address: network address
 *               const uint16_t port: destination port
 *
 *   Outputs:
 *               SOCKET: information about the established connection
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_sockData_t */
static SOCKET VIDEORTP_sockCreateSocket(VIDEORTP_sockData_t* sockData, const char* address, const uint16_t port)
{
    WSADATA wsaData;
    uint8_t res = WSAStartup(MAKEWORD(2, 2), &wsaData);
    assert(res == 0);
    struct addrinfo hints = { 0 };
    struct addrinfo* result = NULL;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_protocol = IPPROTO_TCP;

    const char str_port[6];
    itoa(port, str_port, 10);
    assert(getaddrinfo(address, str_port, &hints, &result) == 0);

    sockData->m_sockaddr.si_family = result->ai_family;
    if (sockData->m_sockaddr.si_family == AF_INET6)
    {
        memcpy(&sockData->m_sockaddr.Ipv6, result->ai_addr, result->ai_addrlen);
    }
    else
    {
        memcpy(&sockData->m_sockaddr.Ipv4, result->ai_addr, result->ai_addrlen);
    }
    freeaddrinfo(result);
    return socket(sockData->m_sockaddr.si_family, SOCK_DGRAM, IPPROTO_UDP);
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockInit
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* self: VIDEORTP_posixSocket_t instance that the function works on
 *               const char* address: network address
 *               const uint16_t port: destination port
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_sockInit(VIDEORTP_posixSocket_t* self, const char* address, const uint16_t port)
{
    assert(self);
    self->vtable.commitTransmissionBuffer = VIDEORTP_sockCommitTransmissionBuffer;
    self->vtable.prepareTransmissionBuffer = VIDEORTP_sockPrepareTransmissionBuffer;
    self->m_sockData.m_socket = VIDEORTP_sockCreateSocket(&self->m_sockData, address, port);
    VIDEORTP_bufInit(&(self->m_payloadWriter), self->m_payloadBuffer, sizeof(self->m_payloadBuffer));
    assert(self->m_sockData.m_socket != INVALID_SOCKET);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockDeinit
 *
 *   Function:   The function closes the network connection
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* self: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_sockDeinit(VIDEORTP_posixSocket_t* self)
{
    assert(self);
    closesocket(self->m_sockData.m_socket);
    WSACleanup();
    self->m_sockData.m_socket = INVALID_SOCKET;
}
