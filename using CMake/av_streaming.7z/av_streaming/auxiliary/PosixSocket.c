/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PosixSocket.h"

#pragma comment(lib, "ws2_32")

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockPrepareTransmissionBuffer
 *
 *   Function:   Returns a pointer to the BufferWriter
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* vtable: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               VIDEORTP_BufferWriter_t*: Pointer to BufferWriter struct
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_posixSocket_t */
static VIDEORTP_bufferWriter_t* VIDEORTP_sockPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_posixSocket_t* self = (void*) vtable;
    VIDEORTP_bufClear(&(self->m_payloadWriter));
    return &self->m_payloadWriter;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockCommitTransmissionBuffer
 *
 *   Function:   The function transmits data over the network
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* vtable: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               VideoRTP_errorCode
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22, MAGAVSTR-842
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_posixSocket_t */
static VideoRTP_errorCode VIDEORTP_sockCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_posixSocket_t* self = (void*) vtable;
    VideoRTP_errorCode err = VideoRTP_ok;

    if (self->m_socket == INVALID_SOCKET)
    {
        err = VideoRTP_invalidCall;
    }
    else
    {
        int res = send(self->m_socket, (char*) VIDEORTP_bufGetBasePointer(&self->m_payloadWriter),
                       VIDEORTP_bufGetBytesWritten(&(self->m_payloadWriter)), 0);
        if (res == SOCKET_ERROR)
        {
            err = VideoRTP_networkError;
        }
    }
    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockCreateSocket
 *
 *   Function:   Initializes and establishes a network connection
 *
 *   Inputs:
 *               const char* address: network address
 *               const uint16_t port: destination port
 *
 *   Outputs:
 *               SOCKET: information about the established connection
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_posixSocket_t */
static SOCKET VIDEORTP_sockCreateSocket(const char* address, const uint16_t port)
{
    SOCKET connection = INVALID_SOCKET;

    struct addrinfo hints = { 0 };
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;
    hints.ai_protocol = IPPROTO_UDP;

    char str_port[_MAX_U64TOSTR_BASE10_COUNT];
    _itoa_s(port, str_port, _countof(str_port), 10);

    struct addrinfo* addresses = NULL;
    if (getaddrinfo(address, str_port, &hints, &addresses) == 0)
    {
        /* Try each address/interface */
        for (struct addrinfo* addr = addresses; addr != NULL; addr = addr->ai_next)
        {
            connection = socket(addr->ai_family, addr->ai_socktype, addr->ai_protocol);
            if (connection != INVALID_SOCKET)
            {
                /* Set default destination of UDP datagrams */
                if (connect(connection, addr->ai_addr, addr->ai_addrlen) == 0)
                {
                    /* Use this address */
                    break;
                }
                closesocket(connection);
                connection = INVALID_SOCKET;
            }
        }

        freeaddrinfo(addresses);
    }

    return connection;
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockInit
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* self: VIDEORTP_posixSocket_t instance that the function works on
 *               const char* address: network address
 *               const uint16_t port: destination port
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_sockInit(VIDEORTP_posixSocket_t* self, const char* address, const uint16_t port)
{
    assert(self);
    self->vtable.commitTransmissionBuffer = VIDEORTP_sockCommitTransmissionBuffer;
    self->vtable.prepareTransmissionBuffer = VIDEORTP_sockPrepareTransmissionBuffer;
    VIDEORTP_bufInit(&(self->m_payloadWriter), self->m_payloadBuffer, sizeof(self->m_payloadBuffer));

    WSADATA wsaData;
    WSAStartup(MAKEWORD(2, 2), &wsaData);
    self->m_socket = VIDEORTP_sockCreateSocket(address, port);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sockDeinit
 *
 *   Function:   The function closes the network connection
 *
 *   Inputs:
 *               VIDEORTP_posixSocket_t* self: VIDEORTP_posixSocket_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_sockDeinit(VIDEORTP_posixSocket_t* self)
{
    assert(self);
    if (self->m_socket != INVALID_SOCKET)
    {
        closesocket(self->m_socket);
        self->m_socket = INVALID_SOCKET;
    }
    WSACleanup();
}
