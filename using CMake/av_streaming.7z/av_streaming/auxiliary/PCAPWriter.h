#ifndef PCAP_WRITER_H
#define PCAP_WRITER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <Winsock2.h>

#include "BufferWriter.h"
#include "PacketTransmitter.h"

/**
 * \defgroup PCAPWriter
 * @{
 * @brief Writes all packets to a PCAP file for analysis with Wireshark.
 *
 * Normally, RTP packets will be transferred on the network. They can be captured via Wireshark for debugging. For testing and
 * analysis purposes, it may be easier to write packets directly to a PCAP file. No test setup is necessary in this case.
 *
 * Note that PCAP files store raw ethernet frames. Therefore, RTP packets must be wrapped in dummy UDP/IP packets.
 * See [libpcap](https://wiki.wireshark.org/Development/LibpcapFileFormat) and [linktypes](https://www.tcpdump.org/linktypes.html)
 * for details.
 *
 * @startuml pcap_file_writer
 *  hide empty members
 *  class BufferWriter
 *
 *  interface PacketTransmitter {
 *      {abstract} + getBuffer() : BufferWriter*
 *      {abstract} + commitBuffer() : void
 *  }
 *
 *  PacketTransmitter ...> BufferWriter : <<use>>
 *
 *  class FileSystem <<TestSystem>> #LightGrey {
 *  }
 *
 *  class PcapFileWriter {
 *      - payloadBuffer : uint8_t[MAX_PAYLOAD_SIZE]
 *      - bufferWriter : BufferWriter
 *      - file : FILE*
 *      + getBuffer() : BufferWriter*
 *      + commitBuffer() : void
 *  }
 *
 *  PacketTransmitter <|.. PcapFileWriter : <<implement>>
 *  PcapFileWriter --> FileSystem : <<use>>
 *
 *  BufferWriter -* PcapFileWriter
 * @enduml
 */

/* Max data length for packet */
#define VIDEORTP_PCAP_LENGTH_DATA (1232)

/**
 * @brief This interface specifies a way to output packets
 * @implements VIDEORTP_packetTransmitter_t
 */
typedef struct PCAPWriter
{
    /** @privatesection @{ */
    /** Allocation of base class */
    VIDEORTP_packetTransmitter_t vtable;

    /** Buffer for payload */
    uint8_t payloadBuffer[VIDEORTP_PCAP_LENGTH_DATA];

    /** Buffer writer */
    VIDEORTP_bufferWriter_t bufferWriter;

    /** File name */
    char* fileName;

    /** File object */
    FILE* file;
    /** @} */
} VIDEORTP_pcapWriter_t;

/* ===========================================================================
 *
 *  Public Function Prototypes
 *
 * ========================================================================= */

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @brief Initialize fields of self
     * @public @memberof VIDEORTP_pcapWriter_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_pcapInit(VIDEORTP_pcapWriter_t* self);

    /**
     * @brief Deinitialize fields of self
     * @public @memberof VIDEORTP_pcapWriter_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_pcapDeinit(VIDEORTP_pcapWriter_t* self);

    /**@} PosixSocket global */

#ifdef __cplusplus
}
#endif /* _cplusplus  */

#endif /* PCAP_WRITER_H */
