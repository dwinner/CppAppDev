#ifndef DUMMY_PACKET_MEMORY_WRITTER_H
#define DUMMY_PACKET_MEMORY_WRITTER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include "PacketTransmitter.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Stores "transmitted" data in memory for testing purposes.
     * @implements VIDEORTP_packetTransmitter_t
     */
    typedef struct VIDEORTP_dummyPacketMemoryWriter_t
    {
        /** @privatesection @{ */
        VIDEORTP_packetTransmitter_t vtable;

        VIDEORTP_bufferWriter_t bufferWriter;
        uint8_t loadBuffer[VIDEORTP_MAX_TX_PAYLOAD_SIZE];
        /** @} */
    } VIDEORTP_dummyPacketMemoryWriter_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Return bufferWriter
     * @public @memberof VIDEORTP_packetTransmitter_t
     *
     * @param vtable instance of VIDEORTP_packetTransmitter_t
     *
     * @return VIDEORTP_bufferWriter_t*
     */
    VIDEORTP_bufferWriter_t* VIDEORTP_dmwPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable);

    /**
     * @brief Do nothing, this stub implementation by PacketTransmitter
     * @private @memberof VIDEORTP_packetTransmitter_t
     *
     * @param vtable instance of VIDEORTP_packetTransmitter_t
     *
     * @return * See VIDEORTP_packetTransmitter_t
     */
    void VIDEORTP_dmwCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable);

    /**
     * @brief return pointer to loadBuffer
     * @private @memberof VIDEORTP_packetTransmitter_t
     *
     * @param self instance of VIDEORTP_dummyPacketMemoryWriter_t
     *
     * @return uint8_t*
     */
    uint8_t* VIDEORTP_dmwGetLoadBuffer(VIDEORTP_dummyPacketMemoryWriter_t* self);

    /**
     * @brief Initialize VIDEORTP_dummyPacketMemoryWriter_t
     * @public @memberof VIDEORTP_packetTransmitter_t
     *
     * Init VIDEORTP_packetTransmitter_t interface
     * Init bufferWriter using loadBuffer
     *
     * @param self instance of VIDEORTP_dummyPacketMemoryWriter_t
     */
    void VIDEORTP_dmwInit(VIDEORTP_dummyPacketMemoryWriter_t* self);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* DUMMY_PACKET_MEMORY_WRITTER_H */
