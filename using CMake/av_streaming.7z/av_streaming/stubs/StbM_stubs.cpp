#include "StbM_stubs.h"
#include <time.h>

static int _base = 0;

Std_ReturnType StbM_GetCurrentTime(StbM_SynchronizedTimeBaseType timeBaseId, StbM_TimeStampType* timeStamp,
                                   StbM_UserDataType* userData)
{
    /* Returns a time value (Local Time Base derived from Global Time Base) in standard format
     * [out] timeStamp - Current timestamp that is valid at this time
     * [out] userData - User data of the Time Base
     */

    long ms; // Milliseconds
    time_t s; // Seconds
    struct timespec spec;

    timespec_get(&spec, TIME_UTC);

    timeStamp->nanoseconds = spec.tv_nsec;
    timeStamp->seconds = spec.tv_sec;

    return E_OK;
}
