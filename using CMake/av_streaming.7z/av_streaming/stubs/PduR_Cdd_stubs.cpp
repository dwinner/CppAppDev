#include "PduR_Cdd_stubs.h"

PduIdType AutosarPdu::g_nextId = 1;

std::map<PduIdType, AutosarPdu*> AutosarPdu::g_pdus;

AutosarPdu::AutosarPdu()
    : m_id(g_nextId++)
{
    g_pdus.emplace(m_id, this);
}

AutosarPdu::~AutosarPdu()
{
    g_pdus.erase(m_id);
}

std::vector<uint8_t> AutosarPdu::GetTransmittedPacket()
{
    if (m_packets.empty())
        return {};
    std::vector<uint8_t> packet(std::move(m_packets.front()));
    m_packets.pop_front();
    return packet;
}

Std_ReturnType PduR_CddTransmit(PduIdType TxPduId, const PduInfoType* PduInfoPtr)
{
    if (PduInfoPtr->SduLength <= 0)
        return E_NOT_OK;
    auto* pdu = AutosarPdu::g_pdus.at(TxPduId);
    pdu->m_packets.emplace_back(PduInfoPtr->SduDataPtr, PduInfoPtr->SduDataPtr + PduInfoPtr->SduLength);
    return E_OK;
}
