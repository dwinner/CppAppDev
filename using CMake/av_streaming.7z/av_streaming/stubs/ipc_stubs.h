#ifndef MAGNA_IPC_STUBS_H
#define MAGNA_IPC_STUBS_H

#include "ipc.h"

void IPC_SetBufferReleaseCallback(void (*callback)(void*));

#endif
