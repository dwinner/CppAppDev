#ifndef MAGNA_AUTOSAR_STBM_H
#define MAGNA_AUTOSAR_STBM_H

#include "Std_Types.h"

#ifdef __cplusplus
extern "C"
{
#endif

    typedef uint8_t StbM_TimeBaseStatusType;
#define TIMEOUT ((StbM_TimeBaseStatusType) 0x01)
#define SYNC_TO_GATEWAY ((StbM_TimeBaseStatusType) 0x04)
#define GLOBAL_TIME_BASE ((StbM_TimeBaseStatusType) 0x08)
#define TIMELEAP_FUTURE ((StbM_TimeBaseStatusType) 0x10)
#define TIMELEAP_PAST ((StbM_TimeBaseStatusType) 0x20)

    typedef uint16_t StbM_SynchronizedTimeBaseType;

    typedef struct StbM_TimeStampType
    {
        StbM_TimeBaseStatusType timeBaseStatus;
        uint32_t nanoseconds;
        uint32_t seconds;
        uint16_t secondsHi;
    } StbM_TimeStampType;

    typedef struct StbM_UserDataType
    {
        uint8_t userDataLength;
        uint8_t userByte0;
        uint8_t userByte1;
        uint8_t userByte2;
    } StbM_UserDataType;

    Std_ReturnType StbM_GetCurrentTime(StbM_SynchronizedTimeBaseType timeBaseId, StbM_TimeStampType* timeStamp,
                                       StbM_UserDataType* userData);

#ifdef __cplusplus
}
#endif

#endif
