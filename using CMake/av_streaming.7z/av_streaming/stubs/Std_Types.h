#ifndef MAGNA_AUTOSAR_STD_TYPES_H
#define MAGNA_AUTOSAR_STD_TYPES_H

#include <stddef.h>
#include <stdint.h>

typedef uint8_t Std_ReturnType;

#define E_OK ((Std_ReturnType) 0u)
#define E_NOT_OK ((Std_ReturnType) 1u)
#define E_NO_DTC_AVAILABLE ((Std_ReturnType) 2u)
#define E_SESSION_NOT_ALLOWED ((Std_ReturnType) 4u)
#define E_PROTOCOL_NOT_ALLOWED ((Std_ReturnType) 5u)
#define E_REQUEST_NOT_ACCEPTED ((Std_ReturnType) 8u)
#define E_REQUEST_ENV_NOK ((Std_ReturnType) 9u)
#define E_PENDING ((Std_ReturnType) 10u)
#define E_COMPARE_KEY_FAILED ((Std_ReturnType) 11u)
#define E_FORCE_RCRRP ((Std_ReturnType) 12u)

#endif
