#ifndef MAGNA_AUTOSAR_COMSTACK_TYPES_H
#define MAGNA_AUTOSAR_COMSTACK_TYPES_H

#include "Std_Types.h"

typedef uint8_t PduIdType;
typedef uint16_t PduLengthType;

typedef struct
{
    uint8_t* SduDataPtr;
    // uint8_t* MetaDataPtr; // introduced with AUTOSAR 4.3
    PduLengthType SduLength;
} PduInfoType;

#endif
