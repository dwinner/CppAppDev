#ifndef MAGNA_IPC_H
#define MAGNA_IPC_H

#ifdef __cplusplus
extern "C"
{
#endif

    /* TODO: Replace with real API from IPC module! */
    void IPC_OnBufferRelease(void* bufferPayload);

#ifdef __cplusplus
}
#endif

#endif
