#include "ipc_stubs.h"
#include <assert.h>

namespace
{
void (*bufferReleaseCallback)(void*);
}

void IPC_OnBufferRelease(void* bufferPayload)
{
    if (bufferReleaseCallback)
        bufferReleaseCallback(bufferPayload);
}

void IPC_SetBufferReleaseCallback(void (*callback)(void*))
{
    // Unregister the old callback before registering a new callback!
    assert((bufferReleaseCallback != nullptr) != (callback != nullptr));
    bufferReleaseCallback = callback;
}
