#ifndef MAGNA_AUTOSAR_PDUR_CDD_STUBS_H
#define MAGNA_AUTOSAR_PDUR_CDD_STUBS_H

#include "PduR_Cdd.h"
#include <deque>
#include <map>
#include <stdint.h>
#include <vector>

class AutosarPdu
{
    // next free ID
    static PduIdType g_nextId;

    // all allocated PDUs
    static std::map<PduIdType, AutosarPdu*> g_pdus;

    // PDU ID of this instance
    PduIdType m_id;

    // Result of PduR_CddTransmit calls to simulate errors.
    // Packets will be discarded unless the result is E_OK.
    Std_ReturnType m_result = E_OK;

    // Countdown until the result override becomes effective.
    // Each call to PduR_CddTransmit decrements the counter;
    // when reaching 0, PduR_CddTransmit will return m_result.
    int m_countdown = 0;

    // Data packets transmitted on this PDU
    std::deque<std::vector<uint8_t>> m_packets;

    AutosarPdu(const AutosarPdu& rhs) = delete;
    AutosarPdu& operator=(const AutosarPdu& rhs) = delete;

    friend Std_ReturnType PduR_CddTransmit(PduIdType TxPduId, const PduInfoType* PduInfoPtr);

public:
    AutosarPdu();
    ~AutosarPdu();

    std::vector<uint8_t> GetTransmittedPacket();

    PduIdType GetId() const
    {
        return m_id;
    }

    void SetResult(Std_ReturnType result = E_OK, int countdown = 0)
    {
        m_result = result;
        m_countdown = countdown;
    }
};

#endif
