#ifndef MAGNA_AUTOSAR_STBM_STUBS_H
#define MAGNA_AUTOSAR_STBM_STUBS_H

#include "StbM.h"

// TODO

#endif
