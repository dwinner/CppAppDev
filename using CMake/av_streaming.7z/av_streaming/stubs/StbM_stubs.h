#ifndef MAGNA_AUTOSAR_STBM_STUBS_H
#define MAGNA_AUTOSAR_STBM_STUBS_H

#include "StbM.h"

#ifdef __cplusplus
extern "C"
{
#endif

    void StbM_Reset(void);
    void StbM_SetCurrentTime(StbM_SynchronizedTimeBaseType timeBaseId, const StbM_TimeStampType* timeStamp,
                             const StbM_UserDataType* userData);

#ifdef __cplusplus
}
#endif

#endif
