/**
 * Import script for H.264 file into header
 */

#include "H264FileReader.h"
#include "importGeneratorUtils.h"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <memory>
#include <sstream>

using namespace std;

void printUsage();

static std::string base_name(std::string const& path)
{
    return path.substr(path.find_last_of("/\\") + 1);
}

static void genHeader(string videoFileName, size_t nalUnitsCount)
{
    const string headerFileName = base_name(videoFileName) + "_bin.h";
    ofstream fHeaderOut(headerFileName, ios_base::binary);

    // write include directives with header start
    string headerMarker(headerFileName);
    replaceAll(headerMarker, ".", "_");
    transform(headerMarker.begin(), headerMarker.end(), headerMarker.begin(),
              [](auto&& ch)
              {
                  return static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
              });

    string prologue = genPrologue(nalUnitsCount, headerMarker);
    fHeaderOut << prologue;

    string definePayloadArray = genDefinePayloadUnitStructArray(nalUnitsCount);
    fHeaderOut << definePayloadArray;

    // Write End header
    string epilogue = genEpilogue();
    fHeaderOut << epilogue;

    fHeaderOut.close();
}

static void genCode(string videoFileName, size_t nalUnitsCount, 
                    unique_ptr<valarray<unique_ptr<Nalu>>>& nalUnits)
{
    const string sourcrFileName = base_name(videoFileName) + "_bin.c";
    ofstream fsourceOut(sourcrFileName, ios_base::binary);

    string includeHeader = genIncludeHeader(base_name(videoFileName) + "_bin.h");
    fsourceOut << includeHeader;

    // Generate payload unit sizes
    string payloadUnitSizes = genPayloadUnitSizes(nalUnits);
    fsourceOut << payloadUnitSizes;

    // Generate payload unit arrays
    string payloadUnitArrays = genPayloadUnitArrays(nalUnits);
    fsourceOut << payloadUnitArrays;

    // Generate payload unit array of structures
    string payloadUnitStructArrays = genPayloadUnitStructArray(nalUnitsCount);
    fsourceOut << payloadUnitStructArrays;

    fsourceOut.close();
}

int main(int argc, const char* argv[])
{
    if (argc < 2)
    {
        printUsage();
        return EXIT_FAILURE;
    }

    const string h264FileName(argv[1]);
    unique_ptr<H264FileReader> h264FileReader = make_unique<H264FileReader>(h264FileName);
    unique_ptr<valarray<unique_ptr<Nalu>>> nalUnits = h264FileReader->GetNalUnits();
    size_t nalUnitsCount = nalUnits->size();

    genHeader(h264FileName, nalUnitsCount);
    genCode(h264FileName, nalUnitsCount, nalUnits);

    return EXIT_SUCCESS;
}

void printUsage()
{
    fprintf(stderr, "import_h264 H264-file");
}
