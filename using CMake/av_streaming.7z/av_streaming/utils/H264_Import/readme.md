# H.264 Import Tool

By default, the VideoStream test application streams a test video which is
embedded in the executable. The H.264 Import Tool converts a H.264 video
file into C code which can then be embedded in that application.

## Usage

    import_h264 testvideo.h264

This will generate `testvideo.h264_bin.c` and `testvideo.h264_bin.h` files
which can be embedded in an executable.

## Generated Code

The input H.264 file will be split into individual frames. The tool generates a
C array containing one entry for each video frame in the input file. Each entry
consists of the length (in bytes) of a frame and a pointer to the raw data.

Note that the tool relies on the presence of *access unit delimiters* (see
below) to split the file correctly. If no such delimiters are present, the file
will not be split correctly; for example, the tool might recognize only one big
frame or no frames at all.

## Preparing H.264 input video

MPEG (H.222.0, section 2.14) imposes certain constraints on an embedded H.264
stream. In particular, the stream must conform to the format specified in H.264
Annex B and it must contain Access Unit Delimiters (AUD NALUs). In a nutshell,
this means that video frames must be separated by a very specific byte sequence.

While H.264 files usually already conform to H.264 Annex B, often they do not
contain Access Unit Delimiters. The obvious way to generate such a file is to
configure an encoder to output Access Unit Delimiters in the encoded stream;
if this is not possible, as a workaround, a H.264 video stream can be streamed
using a different application (like FFmpeg) which adds Access Unit Delimiters.
The H.264 stream can then be extracted from the MPEG stream.

    ffmpeg -i testvideo.mp4 -c copy temp.ts
    ffmpeg -i temp.ts -c copy -an testvideo_with_aud.h264
