#include <sstream>
#include "importGeneratorUtils.h"

std::string genEpilogue()
{
    std::ostringstream strOut;

    strOut << "#ifdef __cplusplus" << "\n";
    strOut << "}" << "\n";
    strOut << "#endif" << "\n";
    strOut << "\n";
    strOut << "#endif" << "\n";
    strOut << "\n";

    return strOut.str();
}

std::string genIncludeHeader(std::string headerName)
{
    std::ostringstream strOut;
    strOut << "#include \"" << headerName << "\"\n\n";
    return strOut.str();
}

std::string genDefinePayloadUnitStructArray(size_t nalUnitsCount)
{
    return std::string("extern struct VIDEORTP_payloadUnit_t VIDEORTP_payloadUnits[VIDEORTP_PAYLOAD_UNIT_COUNT];\n\n");
}

std::string genPayloadUnitStructArray(size_t nalUnitsCount)
{
    std::ostringstream strOut;

    strOut << "struct VIDEORTP_payloadUnit_t VIDEORTP_payloadUnits[VIDEORTP_PAYLOAD_UNIT_COUNT] = " 
	       << "\n";
    strOut << "{" << "\n";
    for (size_t nalIdx = 0; nalIdx < nalUnitsCount; nalIdx++)
    {
        strOut << "\t"
                   << "{ "
                   << "VIDEORTP_payloadUnitData" << (nalIdx + 1) << ", "
                   << "VIDEORTP_PAYLOAD_UNIT_SIZE_" << (nalIdx + 1)
                   << " }";
        if (nalIdx != nalUnitsCount - 1)
        {
            strOut << ",";
        }

        strOut << "\n";
    }

    strOut << "};" << "\n";
    strOut << "\n";

    return strOut.str();
}

std::string genPayloadUnitArrays(const std::unique_ptr<std::valarray<std::unique_ptr<Nalu>>> &nalUnits)
{
    std::ostringstream strOut;

    for (size_t nalIdx = 0; nalIdx < nalUnits->size(); nalIdx++)
    {
        std::valarray<uint8_t> content = (*nalUnits)[nalIdx]->GetContent();

        strOut << "static const uint8_t VIDEORTP_payloadUnitData" << (nalIdx + 1)
                   << "[" << "VIDEORTP_PAYLOAD_UNIT_SIZE_" << (nalIdx + 1) << "] = { ";
        for (size_t byteIdx = 0; byteIdx < content.size(); byteIdx++)
        {
            strOut << static_cast<size_t>(content[byteIdx]);
            if (byteIdx != content.size() - 1)
            {
                strOut << ",";
            }
        }

        strOut << " };" << "\n";
    }

    strOut << "\n";

    return strOut.str();
}

std::string genPayloadUnitSizes(std::unique_ptr<std::valarray<std::unique_ptr<Nalu>>> &nalUnits)
{
    std::ostringstream strOut;

    for (size_t nalIdx = 0; nalIdx < nalUnits->size(); nalIdx++)
    {
        size_t length = (*nalUnits)[nalIdx]->GetLength();
        strOut << "#define VIDEORTP_PAYLOAD_UNIT_SIZE_" << (nalIdx + 1) << "  " << length << "\n";
    }

    strOut << "\n";

    return strOut.str();
}

std::string genPrologue(size_t nalUnitsCount, const std::string &headerMarker)
{
    std::ostringstream strOut;

    strOut << "#ifndef " << headerMarker << "\n";
    strOut << "#define " << headerMarker << "\n";
    strOut << "\n";

    strOut << "#ifdef __cplusplus" << "\n";
    strOut << "extern \"C\"" << "\n";
    strOut << "{" << "\n";
    strOut << "#endif" << "\n";
    strOut << "\n";

    strOut << "#include \"PayloadUnitSequenceRepeater.h\"" << "\n";
    strOut << "#include <stdint.h>" << "\n" << "\n";

    strOut << "#define VIDEORTP_PAYLOAD_UNIT_COUNT " << nalUnitsCount << "\n" << "\n";

    return strOut.str();
}

void replaceAll(std::string &str, const std::string &from, const std::string &to)
{
    if (from.empty())
    {
        return;
    }

    size_t start_pos = 0;
    while ((start_pos = str.find(from, start_pos)) != std::string::npos)
    {
        str.replace(start_pos, from.length(), to);

        // In case 'to' contains 'from', like replacing 'x' with 'yx'
        start_pos += to.length();
    }
}
