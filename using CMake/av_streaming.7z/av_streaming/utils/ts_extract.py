#!/usr/bin/env python3

import sys, argparse, struct, os, collections

TS_PACKET_SIZE = 188

# PES stream types with non-standard header
# H.222, 2.4.3.6, Table 2-22
RAW_PES_PACKETS = frozenset((
    0b_1011_1100, 0b_1011_1110, 0b_1011_1111, 0b_1111_0000,
    0b_1111_0001, 0b_1111_0010, 0b_1111_1000, 0b_1111_1111,
))

parser = argparse.ArgumentParser(
    description="Extract a video stream from a TS file")
parser.add_argument('--input', required=True,
    help="TS input file")
parser.add_argument('--output',
    help="PES output file")
parser.add_argument('--pid', type=int,
    help="PID of TS stream to save")
args = parser.parse_args()

# Read file as chunks
def read_ts_packets_from_file(filename):
    with open(filename, "rb") as f:
        while True:
            ts = f.read(TS_PACKET_SIZE)
            if len(ts) < TS_PACKET_SIZE:
                break
            yield ts

# Read PID and payload from TS packet
def parse_ts_packet(packet):
    if len(packet) < TS_PACKET_SIZE:
        return (None, False, b'')
    (sync, pid_ind, ctrl) = struct.unpack(">BHB", packet[:4])
    if sync != 0x47:
        return (None, False, b'')

    # Has payload?
    if ctrl & 0x10:
        # Skip adaptation field
        header_size = 4
        if ctrl & 0x20:
            header_size += 1 + packet[4]
        payload = packet[header_size:]
    else:
        payload = b''

    pid = pid_ind & 0x1FFF
    pusi = bool(pid_ind & 0x4000)
    return (pid, pusi, payload)

# Merge TS packets with the same PID.
# A new PES packet starts if the Payload Unit Start Indicator bit is set.
def assemble_pes_packets(stream):
    streams = collections.defaultdict(bytearray)

    for (pid, pusi, data) in stream:
        pes = streams[pid]
        if pusi and pes:
            yield (pid, pes)
            pes.clear()
        pes += data

    for pid,pes in streams.items():
        if pes:
            yield (pid, bytes(pes))

# Remove PES headers. Return the payload of a packet.
def remove_pes_header(pes):
    # start code
    if pes[0] != 0 or pes[1] != 0 or pes[2] != 1:
        return None
    # stream with PES header?
    stream_id = pes[3]
    if stream_id in RAW_PES_PACKETS:
        return None
    # skip all header fields
    header_size = 9 + pes[8]
    return pes[header_size:]

# read all packets
packets = read_ts_packets_from_file(args.input)
packets = map(parse_ts_packet, packets)

# filter by PID
packets = (t for t in packets if t[0] >= 0x0010 and t[0] <= 0x1FFE)
if args.pid is not None:
    packets = (t for t in packets if t[0] == args.pid)

# print file contents
if not args.output:
    for ts in packets:
        print(ts)
    sys.exit()

# Reconstruct elementary streams
packets = assemble_pes_packets(packets)
packets = ((pid, remove_pes_header(pes)) for pid,pes in packets)
packets = ((pid, pes) for pid,pes in packets if pes)

# write all elementary streams to separate files
files = {}
path, ext = os.path.splitext(args.output)
for pid,pes in packets:
    file = files.get(pid)
    if not file:
        filename = f"{path}_{pid:04x}{ext}"
        print(f"Writing PID 0x{pid:04x} to {filename}")
        file = open(filename, "wb")
        files[pid] = file
    file.write(pes)
for f in files.values():
    f.close()
