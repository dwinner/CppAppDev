#!/usr/bin/env python3

import itertools, argparse, socket, struct, time, re

DEFAULT_FRAME_RATE = 60
TS_PACKET_SIZE = 188 # H.222, 2.4.3
MIN_MTU_SIZE = 1280 # RFC8200
IP_HEADER_SIZE = 40 # RFC8200
UDP_HEADER_SIZE = 8 # RFC768
DEFAULT_RTP_SIZE = MIN_MTU_SIZE - IP_HEADER_SIZE - UDP_HEADER_SIZE # IP_AVT_1562
CLOCK = 27000000 # 27 MHz

# H.222, 2.4.3.3, Table 2-3
MPEG_PAT_PID = 0

# A generic data packet. Its contents depend on the protocol layer (H264, MPEG-TS, RTP, etc.)
class Packet:
    # data: A byte string with the contents
    # timestamp: Sample time or due time etc.
    # frame_start: Whether a frame starts in this packet (if known)
    # frame_end: Whether a frame ends in this packet (if known)
    def __init__(self, data, timestamp=None, frame_start=None, frame_end=None):
        self.data = data
        self.timestamp = timestamp
        self.frame_start = frame_start
        self.frame_end = frame_end

    # Dump a few bytes the raw contents
    def __str__(self) -> str:
        if len(self.data) <= 24:
            payload = self.data.hex(' ', -4)
        else:
            payload = (self.data[:16].hex(' ', -4) +
                " ... " + self.data[-8:].hex(' ', 4))
        return "<{:4}B @ {:11.08f}s: {}>".format(
            len(self.data), (self.timestamp or 0) / CLOCK, payload)

# A section of an MPEG program table
class Section:
    def __init__(self, id, label, data, num=0, last=0):
        self.data = data
        self.id = id
        self.label = label
        self.num = num
        self.last = last

    def __str__(self) -> str:
        count = min(32, len(self.data)) // 2
        return "<{:02x}.{:04x} {}/{} {:3}: {} ... {}>".format(
            self.id, self.label, self.num, self.last, len(self.data),
            self.data[:count].hex(' ', -4), self.data[-count:].hex(' ', 4))

## Generated Data

# Generates a stream of frames with random data
def generate_random_frames(count):
    print("Generating random input data")
    for i in range(count):
        length = 10 + 50 * (i % 51) + (i % 59)
        data = bytes((i % 256,)) * length
        yield Packet(data, None, True, True)

# Replaces the timestamps of all frames to simulate a target frame rate
def generate_timestamps(packet_stream, frame_rate, start_timestamp=0):
    for i,p in enumerate(packet_stream):
        timestamp = int(start_timestamp + i * CLOCK / frame_rate)
        yield Packet(p.data, timestamp, p.frame_start, p.frame_end)

## H.264

# Detect Access Unit Delimiter NALUs at the beginning of each frame.
# - NALUs start with 0x000001 or 0x00000001. Leading zeros can be ignored.
# - NALUs end with a stop bit. Trailing zeros can be ignored as well.
# - NALUs cannot contain three or more consecutive zeros.
# - Check the type field in the NALU header (H.264, 7.3.1).
# - The type of AUD NALUs is 9 (H.264, 7.4.1, Table 7-1). Ignore other bits.
AUD_NALU_PATTERN = b"(\0\0\0?\x01[\x09\x29\x49\x69].)"

# Read a H.264 stream from a file and return a stream of frames (access units).
# The file must conform to H.264 Annex B and include Access Unit Delimiter NALUs!
# See: H.222, 2.14.1 and H.264, 7.4.1.2.3
def read_h264_file(filename):
    print(f"Reading from {filename}")
    with open(filename, "rb") as file:
        # split also captures separators (even index = frame; odd index = AUD)
        nalus = re.split(AUD_NALU_PATTERN, file.read())
        # The first element has no AUD. It should be empty anyway.
        del nalus[0]
        # Group AUDs and actual frames into pairs.
        for aud,frame in zip(*[iter(nalus)]*2, strict=True):
            # Return the frame with its AUD.
            yield Packet(aud + frame, None, True, True)

## Data sinks

def write_to_file(filename):
    print(f"Writing stream to {filename}")
    with open(filename, mode="wb") as f:
        while True:
            packet = yield
            f.write(packet.data)

def send_to_host_udp(host, port):
    print(f"Sending stream to {host}:{port}")
    (family, type, proto, _, sockaddr) = socket.getaddrinfo(
        host, port, type=socket.SOCK_DGRAM)[0]
    with socket.socket(family, type, proto) as conn:
        conn.connect(sockaddr)
        while True:
            packet = yield
            conn.send(packet.data)

# Sinks must (generator-based) coroutines which process data returned by 'yield'
def send_stream_to_sinks(packet_stream, sinks):
    # Run to first 'yield'
    for s in sinks:
        next(s)
    # Forward packets to all sinks
    for p in packet_stream:
        for s in sinks:
            s.send(p)

## Filters

# Dumps each packet of a stream
def print_to_console(packet_stream, prefix="Packet"):
    for i,p in enumerate(packet_stream):
        print(f"{prefix:10} {i:5} {p}")
        yield p

# Delay processing to achieve the desired target frame rate.
# Assumes that all timestamps are based on the same clock.
def delay_packet_stream(packet_stream):
    # Find the first timestamp to use as reference
    for p in packet_stream:
        yield p
        if p.timestamp is not None:
            first_stream_timestamp = p.timestamp
            first_clock_timestamp = time.time()
            break

    # Wait until the next packet is due
    # Beware: This will break if the system clock jumps!
    for p in packet_stream:
        if p.timestamp is not None:
            clock_delay = time.time() - first_clock_timestamp
            stream_delay = (p.timestamp - first_stream_timestamp) / CLOCK
            if clock_delay < stream_delay:
                time.sleep(stream_delay - clock_delay)
        yield p

# MPEG-PES

# H.222, 2.4.3.6
# Input: Raw frames
# Output: PES packets (frames with PES headers)
def mpeg_add_pes_header_to_elementary_stream(packet_stream, id):
    for p in packet_stream:
        length = len(p.data) + 8 # length + header + PTS
        if length > 0xFFFF:
            length = 0
        ts = p.timestamp // 300 # 90 kHz
        header = struct.pack(
            ">3BBH3BBHH",
            0, 0, 1, # start code
            id, # stream ID
            length, # data length; optional for video
            0x80, # Flags
            0x80, # PTS only
            5, # PTS length
            ((ts >> 29) & 0x0E) | 0x21,
            ((ts >> 14) & 0xFFFE) | 0x01,
            ((ts << 1) & 0xFFFE) | 0x01)
        yield Packet(header + p.data, p.timestamp, p.frame_start, p.frame_end)

# MPEG-TS (PES)

# Helper class for generating MPEG-TS headers
# Handles packet counters and clocks
class MpegTsHeaderGenerator:
    def __init__(self, pid):
        # Each program has its own clock and continuity counter
        self.pid = pid
        self.continuity_counter = 0
        self.total_packet_counter = 0
        self.pcr = None

    def inject_pcr(self, pcr):
        self.pcr = pcr

    # H.222, 2.4.3.4
    # Generate an adaptation field of the requested minimum length.
    # The adaptation field may be longer than requested if a PCR field must be
    # added to the TS header. Note that the adaptation field might be empty if
    # neither padding/stuffing nor a PCR is required.
    def create_adaptation_field(self, min_len = 0):
        adaptation_field = bytearray()
        adaptation_flags = 0

        # IP_AVT_423: The packet count must be a multiple of 6
        # It only makes sense to count packets in this program because
        # other programs may use a different clock or no clock at all.
        if self.pcr and (self.total_packet_counter % 6) == 0:
            # PCR base (33 bit, 90kHz) + reserved + PCR extension (9 bit, 27MHz)
            pcr = ((self.pcr // 300) << 15) | 0x7E00 | (self.pcr % 300)
            adaptation_field += pcr.to_bytes(6, 'big')
            adaptation_flags |= 0x10 # PCR flag
            # Inject this PCR only once
            self.pcr = None

        # Add extra stuffing bytes after the adaptation field
        if len(adaptation_field) + 2 < min_len:
            adaptation_field += b'\xff' * (min_len - (len(adaptation_field) + 2))

        # Add flags (may be empty if only 2 stuffing bytes are needed)
        if len(adaptation_field) > 0 or min_len >= 2:
            adaptation_field.insert(0, adaptation_flags)

        # Add length field (may be empty if only 1 stuffing byte is needed)
        if len(adaptation_field) > 0 or min_len >= 1:
            # The length excludes the length field itself
            adaptation_field.insert(0, len(adaptation_field))

        return adaptation_field

    # H.222, 2.4.3.2
    # Create a TS packet header including padding/stuffing bytes to ensure
    # that the resulting TS packet has the correct size.
    def create_transport_packet_header(self, pusi, payload_length=TS_PACKET_SIZE):
        adaptation_field = self.create_adaptation_field(
            TS_PACKET_SIZE - 4 - payload_length)

        # Adaptation Field Control and Continuity Counter
        counter_and_control_flags = self.continuity_counter & 15
        # Payload bit
        if payload_length > 0:
            counter_and_control_flags |= 0x10
        # Adaptation Field bit
        if len(adaptation_field) > 0:
            counter_and_control_flags |= 0x20

        # Program ID
        pid_and_flags = self.pid & 0x1FFF
        # Payload Unit Start Indicator
        if pusi:
            pid_and_flags |= 0x4000

        header = struct.pack(">BHB",
            0x47, pid_and_flags, counter_and_control_flags)

        # Each PID has its own packet counters
        if payload_length > 0:
            self.continuity_counter = self.continuity_counter + 1
        self.total_packet_counter += 1

        return header + adaptation_field

# Input: PES packets
# Output: One or more TS packets for each PES packets
def mpeg_split_pes_packets_into_ts_packets(packet_stream, header_generator, frame_rate):
    for p in packet_stream:
        i = 0
        while i < len(p.data):
            # simulate sending TS packets in bursts
            timestamp = int(p.timestamp + i * 1000000000 / frame_rate / 2 / (len(p.data) + 1))

            # start of next TS packet payload
            begin_pos = i
            is_first_packet = begin_pos == 0

            # Need to determine the header size first because its length is variable
            # it (may or may not include a PCR or stuffing/padding bytes)
            header = header_generator.create_transport_packet_header(
                is_first_packet, len(p.data) - begin_pos)

            # end of next TS packet payload
            end_pos = begin_pos + TS_PACKET_SIZE - len(header)
            is_last_packet = end_pos >= len(p.data)

            payload = p.data[begin_pos:end_pos]
            assert len(header) + len(payload) == TS_PACKET_SIZE
            yield Packet(header + payload, timestamp, is_first_packet, is_last_packet)

            i = end_pos

# Occasionally tell the header generator to add a PCR field to the next TS packet header
# Input: TS packets
# Output: TS packets
def mpeg_trigger_pcr_injection(packet_stream, header_generator, start_timestamp, clock_offset):
    last_timestamp = None
    header_generator.inject_pcr(start_timestamp - clock_offset)
    for p in packet_stream:
        # IP_AVT_423: inject PCR approximately every 50ms (10% tolerance)
        if last_timestamp is None or last_timestamp + 45000000 < p.timestamp:
            # The PCR will actually be added to the TS next packet after "p"
            header_generator.inject_pcr(p.timestamp - clock_offset)
            last_timestamp = p.timestamp
        yield p

# MPEG-TS (Program Tables)

# Program Association Table (H.222, 2.4.4.4)
# Generates an association table which lists all available programs along with
# the PIDs of the TS streams containing their respective program map tables
# Output: MPEG sections
def mpeg_generate_program_association_sections(stream_id, program_number, pmt_pid):
    info = struct.pack(
        ">HH",
        program_number, # 0 = network PID; Other values are user defined
        0xE000 | pmt_pid) # PID of program map table
    yield Section(0, stream_id, info)

# Program Map Table (H.222, 2.4.4.9)
# Generates a map table listing all TS streams which belong to the same program
# Output: MPEG sections
def mpeg_generate_program_map_sections(program_number, pid, type):
    info = struct.pack(
        ">HHBHH",
        0xE000 | pid, # PID of TS stream with reference clock
        0xF000, # length of descriptors
        type, # Stream type (H.222, Table 2-34)
        0xE000 | pid, # PID of H.264 elementary stream
        0xF000) # length of descriptors
    yield Section(2, program_number, info)

# H.222, Annex A
def mpeg_crc32(data, crc=0xFFFFFFFF):
    for b in data:
        for i in range(8):
            if ((b >> (7 - i)) ^ (crc >> 31)) & 1:
                crc = ((crc & 0x7FFFFFFF) << 1) ^ 0x04C11DB7
            else:
                crc = ((crc & 0x7FFFFFFF) << 1)
    return crc

# Convert a section definition to a raw packet (H.222, 2.4.4.3)
def mpeg_serialize_section(section):
    length_flags = 5 + len(section.data) + 4 # remaining header + payload + crc
    length_flags |= 0xB000 # syntax indicator (i.e., data format) + reserved
    version = 0xC1 # reserved + version + current/next indicator
    header = struct.pack(">BHHBBB", section.id, length_flags,
        section.label, version, section.num, section.last)
    crc = mpeg_crc32(header, 0xFFFFFFFF)
    crc = mpeg_crc32(section.data, crc)
    # Note: Sections are "timeless" in this implementation
    return Packet(header + section.data + crc.to_bytes(4, 'big'))

# H.222, 2.4.4.2
# Split MPEG sections into TS packets.
# Note that sections have a different format than elementary streams.
# Input: Sections
# Output: TS packets
def mpeg_split_sections_into_ts_packets(sections, header_generator):
    # If a new section starts in a TS packet, it must contain a "pointer" field
    # specifying the offset to the start of the section. This allows fragmenting
    # large sections and aggregating small sections in TS packets without
    # additional padding.
    #
    # Beware: If the last chunk of a section has 183 bytes, no further section
    # can start in the same TS packet because the payload (183 bytes) plus a
    # pointer field (1 byte) plus its header (4 bytes) would fill a complete
    # TS packet (188 bytes). There would be no space left for the first byte of
    # the next section.
    #
    # For simplicity, in this implementation, sections always start at the
    # beginning of a TS packet and will be padded with 0xFF (H.222, 2.4.4.1).
    # (Stuffing in the adaptation field also seems to be a valid option.)

    for s in sections:
        i = 0
        while i < len(s.data):
            if i == 0:
                # The first packet includes a pointer field pointing to the beginning
                header = header_generator.create_transport_packet_header(True) + b"\x00"
            else:
                # The remaining packets do not need a pointer field
                header = header_generator.create_transport_packet_header(False)
            payload = s.data[i : i + TS_PACKET_SIZE - len(header)]
            padding = b"\xFF" * (TS_PACKET_SIZE - len(header) - len(payload))
            # TODO: Need to set the frame_start/frame_end flags?
            yield Packet(header + payload + padding, s.timestamp)
            i += len(payload)

# MPEG multiplexer/scheduler
# Input: Two TS strams
# Output: One TS stream
def mpeg_insert_sections_into_ts_stream(table_generator, ts_packet_stream, interval):
    last_timestamp = None
    for ts in ts_packet_stream:
        # Inject program tables into normal TS stream
        # Note: This assumes there is only one clock!
        # This will fail if there are two streams with different clocks.
        if last_timestamp is None or last_timestamp + interval <= ts.timestamp:
            yield from table_generator()
            last_timestamp = ts.timestamp
        # Pass through video stream
        yield ts

# RTP

# Helper class for generating RTP headers
# Handles sequence counters
class RtpHeaderGenerator:
    def __init__(self, payload_type, synchronization_source, initial_sequence_number=0) -> None:
        self.payload_type = payload_type
        self.synchronization_source = synchronization_source
        self.sequence_number = initial_sequence_number

    def create_rtp_header(self, marker, timestamp):
        self.sequence_number += 1
        # RFC3550
        return struct.pack(">BBHII",
            0x80,
            (0x80 if marker else 0) | (self.payload_type & 0x7F),
            self.sequence_number & 0xFFFF,
            timestamp & 0xFFFFFFFF,
            self.synchronization_source)

# RFC3550/RFC3551
# Combine as many TS packets as possible into one RTP packet
# Input: TS packets
# Output: RTP packets
def rtp_combine_ts_packets(packet_stream, header_generator, max_size, ip_avt):
    max_size -= 12 # RTP header
    timestamp = None
    payload = bytearray()

    # IP_AVT_594: Set the marker bit of fragmented packets. This cannot happen
    # because MPEG-TS packets contained in RTP packets must not be fragmented.
    # RFC3551/RFC2250: Set the marker bit if the timestamp is discontinuous.
    # This is only the case for the first packet (when starting a new stream).
    # Note: When embedding elementary streams directly (without MPEG-TS),
    # the marker bit would have to be set on the last packet of a frame.
    marker = not ip_avt

    for p in packet_stream:
        # Send current RTP packet before it grows too big
        if len(payload) + len(p.data) > max_size:
            yield Packet(
                header_generator.create_rtp_header(marker, timestamp) + payload,
                timestamp)
            marker = False
            timestamp = None
            payload = bytearray()

        payload += p.data
        if timestamp is None:
            timestamp = p.timestamp

    # Send final RTP packet
    if len(payload) > 0:
        yield Packet(
            header_generator.create_rtp_header(marker, timestamp) + payload,
            timestamp)

## Main program

parser = argparse.ArgumentParser(description="A/V muxer prototype")
parser.add_argument('--print', action=argparse.BooleanOptionalAction, default=True,
    help="Print all packets to the console")
parser.add_argument('--output',
    help="Save stream to file")
parser.add_argument('--host',
    help="Send stream to UDP address")
parser.add_argument('--port', type=int,
    help="Send stream to UDP port")
parser.add_argument('--input',
    help="Read H264 input stream from file")
parser.add_argument('--generate', type=int, default=1000,
    help="How many dummy packets to generate")
parser.add_argument('--loop', action=argparse.BooleanOptionalAction, default=False,
    help="Repeat stream indefinitely")
parser.add_argument('--time', type=float, default=5,
    help="Starting timestamp (seconds)")
parser.add_argument('--fps', type=float, default=DEFAULT_FRAME_RATE,
    help="Frame rate of video")
parser.add_argument('--mpegts', action=argparse.BooleanOptionalAction, default=True,
    help="Wrap data in MPEG-TS packets")
parser.add_argument('--mpegts-tables', type=float, default=250,
    help="Interval to resend program tables (milliseconds)")
parser.add_argument('--mpegts-program', type=int, default=1,
    help="Program Number of the MPEG video stream")
parser.add_argument('--mpegts-pmt-pid', type=int, default=0x1000,
    help="PID of the MPEG Program Map Table")
parser.add_argument('--mpegts-video-pid', type=int, default=0x0100,
    help="PID of the MPEG video elementary stream")
parser.add_argument('--mpegts-stream-id', type=int, default=1,
    help="MPEG Transport Stream ID in Program Association Table")
parser.add_argument('--clock-offset', type=float, default=50,
    help="Offset of MPEG clock (milliseconds)")
parser.add_argument('--rtp', action=argparse.BooleanOptionalAction, default=True,
    help="Wrap data in RTP packets")
parser.add_argument('--rtp-size', type=int, default=DEFAULT_RTP_SIZE,
    help="Maximum size of RTP packets")
parser.add_argument('--realtime', action=argparse.BooleanOptionalAction, default=False,
    help="Send packets in real time (with delay)")
parser.add_argument('--ip-avt', action=argparse.BooleanOptionalAction, default=False,
    help="Comply with VW LAH.DUM.035.F (IP Audio/Video Transport)")
args = parser.parse_args()

# Read or generate input
if args.input:
    # H.264 video stream
    stream = read_h264_file(args.input)
    mpeg_pes_type = 0xE0 # H.222, Table 2-22
    mpeg_pmt_type = 0x1B # H.222, Table 2-34
else:
    # Private stream with PTS
    stream = generate_random_frames(args.generate)
    mpeg_pes_type = 0xBD # H.222, Table 2-22
    mpeg_pmt_type = 0x06 # H.222, Table 2-34

# Loop input video indefinitely
if args.loop:
    stream = itertools.cycle(stream)

# Generate timestamps according to the desired frame rate
frame_rate = max(0.01, args.fps)
start_timestamp = int(args.time * CLOCK)
stream = generate_timestamps(stream, frame_rate, start_timestamp)
if args.print:
    stream = print_to_console(stream, "Raw Frame")

# Wrap stream in MPEG-TS packets
if args.mpegts:
    clock_offset = int(args.clock_offset / 1000 * CLOCK)
    table_interval = int(args.mpegts_tables / 1000 * CLOCK)

    # Header generators must be static because of continuity counters
    pat_header = MpegTsHeaderGenerator(MPEG_PAT_PID)
    pmt_header = MpegTsHeaderGenerator(args.mpegts_pmt_pid)
    video_header = MpegTsHeaderGenerator(args.mpegts_video_pid)

    # Generate program tables on demand (can be called repeatedly)
    def mpeg_table_generator():
        # MPEG Program Association Table
        pat_sections = map(mpeg_serialize_section, mpeg_generate_program_association_sections(
            args.mpegts_stream_id, args.mpegts_program, args.mpegts_pmt_pid))
        if args.print:
            pat_sections = print_to_console(pat_sections, "MPEG-PAT")
        yield from mpeg_split_sections_into_ts_packets(pat_sections, pat_header)

        # MPEG Program Map Table
        pmt_sections = map(mpeg_serialize_section, mpeg_generate_program_map_sections(
            args.mpegts_program, args.mpegts_video_pid, mpeg_pmt_type))
        if args.print:
            pmt_sections = print_to_console(pmt_sections, "MPEG-PMT")
        yield from mpeg_split_sections_into_ts_packets(pmt_sections, pmt_header)

    # MPEG Video Elementary Stream
    stream = mpeg_add_pes_header_to_elementary_stream(stream, mpeg_pes_type)
    if args.print:
        stream = print_to_console(stream, "MPEG-PES")
    stream = mpeg_split_pes_packets_into_ts_packets(stream, video_header, frame_rate)
    stream = mpeg_trigger_pcr_injection(stream, video_header, start_timestamp, clock_offset)

    # Merge all MPEG streams
    stream = mpeg_insert_sections_into_ts_stream(mpeg_table_generator, stream, table_interval)
    if args.print:
        stream = print_to_console(stream, "MPEG-TS")

if args.mpegts:
    if args.ip_avt:
        rtp_payload_type = 0x7F # IP_AVT_1562
    else:
        rtp_payload_type = 33 # RFC2250
else:
    rtp_payload_type = 96 # RFC3551: dynamic (i.e., undefined/private)

# Wrap stream in RTP packets
if args.rtp:
    rtp_stream_header = RtpHeaderGenerator(rtp_payload_type, 0xbaadc0de)
    stream = rtp_combine_ts_packets(stream, rtp_stream_header, args.rtp_size, args.ip_avt)
    if args.print:
        stream = print_to_console(stream, "RTP")

# Reduce bandwidth to maintain the desired frame rate.
# This should be the last step to ensure that "early" TS packets do not need
# to wait for "late" TS packets which happen to be sent in the same RTP packet.
if args.realtime:
    stream = delay_packet_stream(stream)

# Send packets to all specified sinks
sinks = []
if args.host and args.port:
    sinks.append(send_to_host_udp(args.host, args.port))
if args.output:
    sinks.append(write_to_file(args.output))
send_stream_to_sinks(stream, sinks)
