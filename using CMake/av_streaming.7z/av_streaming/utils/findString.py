import sys
def check():
    found = False
    datafile = open('output.txt')
    for line in datafile:
        if "Stream #0:0: Video: h264 (High) ([27][0][0][0] / 0x001B), yuv420p(progressive), 1280x480 [SAR 2:3 DAR 16:9], 25 fps, 60 tbr, 90k tbn, 50 tbc" in line:
           found = True
           break
    return found

if check():
    sys.exit(0)
else:
    sys.exit(1)