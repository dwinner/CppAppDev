#!/usr/bin/perl

################################################################################
#
# PlantUML and Draw.IO files and index generator
#
# Features
# - Creates output directory (if it does not exist already)
# - Discovers all *.pu and *.drawio files in current working directory
# - Generates diagrams (only if source is newer than target)
# - Writes index HTML with toc/top links and <img> of diagrams
#
# Notes
# - Sorts files lexically to achieve stable behavior
# - Does work with spaces in file names, but that's pure luck
# - Output format can be configured in $format
# - Path to PlantUML and Draw.IO most probably needs to be adapted locally
# - Does not delete files; output directory will collect garbage
#
################################################################################

use strict;
use File::stat;

################################################################################
# Local adaptation area
my $pucall     = 'java -jar C:\Tool\plantuml\plantuml-1.2021.14.jar';
my $drawiocall = 'c:\Program Files\draw.io\draw.io.exe';


################################################################################
# Global variables and constants
my $index      = 'index.html';
my $outdir     = 'gen';
my $format     = 'svg';  # 'png' or 'svg'
my $charset    = 'UTF-8';
my @files;

################################################################################
# Helper functions
use constant { FT_PUML => 0, FT_DRAWIO => 1, FT_UNKNOWN => 2 };
sub get_file_type {
	return FT_PUML if (m/^([^\.]+)\.pu$/);
	return FT_DRAWIO if (m/^([^\.]+)\.drawio$/);
	return FT_UNKNOWN;
}

sub get_file_mtime {
	my $stat = stat($_[0]);
	return defined $stat ? $stat->mtime : 0;
}

################################################################################
# Create output directory if needed
if (not -d $outdir) {
	print "create output directory $outdir\n";
	mkdir $outdir or die "$!";
}

################################################################################
# Get names of all .pu and .drawio files
opendir (DIR, ".");
foreach (readdir DIR) {
	my $ft = get_file_type($_);
	push @files, $_ if ($ft == FT_PUML or $ft == FT_DRAWIO);
}
closedir DIR;

################################################################################
# Generate figures for each diagram
foreach (sort @files) {
	print "generate diagram \"$_\"...";
	if (get_file_mtime($_) <= get_file_mtime("$outdir/$_.$format")) {
		print " skipped.\n";
		next;
	}

	my $ft = get_file_type($_);
	if ($ft == FT_PUML) {
		system ("$pucall -charset $charset -t$format -p < \"$_\" > \"$outdir/$_.$format\"") == 0 or die "$!";
	} elsif ($ft == FT_DRAWIO) {
		system ("\"$drawiocall\" -x \"$_\" -o \"$outdir/$_.$format\"") == 0 or die "$!";
	}
	print " ok.\n";
}

################################################################################
# Generate index html
print "write index to \"$outdir/$index\"...";
open(FH, '>', "$outdir/$index") or die $!;

print FH <<END;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
  <head>
    <title>Diagrams</title>
    <style type="text/css">
      img { border-style: solid; border-width: 2px; padding: 10px; }
    </style>
  </head>
  <body>
    <h1>Diagrams</h1>
    <hr>
END

print FH "    <ul>\n";
foreach (sort @files) {
	print FH "      <li><a href=\"#fig-$_\">$_</a></li>\n";
}
print FH "    </ul>\n";
print FH "    <hr>\n";

foreach (sort @files) {
	print FH "    <h2><a name=\"fig-$_\">$_</a></h2>\n";
	print FH "    <img src=\"$_.$format\">\n";
	print FH "    <p>\n";
	print FH "      <a href=\"#top\">top</a>\n";
	print FH "    </p>\n";
}

print FH <<END;
  </body>
</html>
END

close(FH);
print " ok.\n";
