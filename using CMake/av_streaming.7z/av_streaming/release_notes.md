# VIDEORTP - Release notes - Version X002 (IS6)

## Commit and Delivery Branch

The software package was released on 06.07.2022.
Please see the following references:

* Magna relase branch: `2022/feature/17098003_VideoRTP_integration_3`
* Magna commit: `fdcb9258546844683ef0c4ee6c2b104d7f1e56e2`
* Integration task: `17161887`
* Internal Schleissheimer release: `6c3da7c06d461e513d3c74fe290ae8e490064d84`


## Changes

1.  Implement `VIDEORTP_startFrame` and `VIDEORTP_appendFrame` APIs to process
    video stream from IPC.
1.  Revise `VIDEORTP_init`. Add configuration structure as per design specification.
1.  Fix MPEG-PTS/DTS timestamps overflowing every ~5 seconds in test stream.
1.  Update VideoTestStream application to use IPC interface internally.


## Release Notes

### Enabling the Module

The module can be enabled by setting the variable `Rte_CDD_VideoRTP_VideoTransmissionOn`
to `TRUE`

### Enabling Dummy Test Video

**Enabling the test video is not recommended for release software.**

To enable or disable the test video, set the CMake compile-time options
`VIDEORTP_ENABLE_STATIC_INPUT` and `VIDEORTP_ENABLE_TEST_VIDEO` accordingly.

The test video can be enabled at runtime when calling `VIDEORTP_init`. Set
`VIDEORTP_initConfiguration.avMasterConfiguration.isTestVideoEnabled` to `true`
to enable the test video.

Note that input to `VIDEORTP_startFrame` and `VIDEORTP_appendFrame` APIs will be
ignored while the test video is active.

For testing purposes, the module supports multiple streaming modes which can be
selected by changing `VIDEORTP_STREAMING_MODE` in `VideoRTP.h`:

* IP_AVT synchronous (payload type 122, default)
* IP_AVT isochronous (payload type 127)
* RFC2250 (payload type 33, only for testing with VLC or ffmpeg etc.)


## QAC

Magna QAC was not available at the time of this writing.
This will be done once the pull request has been finished.


## Coverage and Test Result

Generated HTML reports will be uploaded to PTC Integrity
/L2H5050/KP03_ProductEngineering/40_Software/50_Supplier/03_Eeins_SSH/30_SWTest

### Coverage
Coverage Clang during automated unit / component tests:

*   Function Coverage: **100.00%**
*   Line Coverage: **99.06%**
*   Region Coverage: **99.29%**
*   Branch Coverage: **91.57%**

Note: The test coverage includes the test video.

**Remark:** The branch coverage results from defensive programming which will
not be covered with automated test and can only be reached by interfering with
the system with a debugger.

### Test Results

gTest has run with 227 tests and 224 tests passed (0 failures, 0 errors, 3 skipped).

The skipped tests does not make sens if testing with dummy video, therefore they a skipped during
a component test run.


## Utilization

Measurement is pending.


## Known Defects

None.


## Known Issues and Remarks

1.  The integration of the VideoRTP software component was verified with a dummy
    test video since other essential components (IPC and wrapper/parent module 
    of VIDEORTP) were not ready at the time of this writing.
    This implies that a 'fully' integrated system might behave differently
    (e.g. external latency, CPU load, etc.).

1.  During testing with the TDA4, the video stream with the VW stream IDs
    (as defined in the customer requirements) was not playable in the standard
    players like VLC. Using the standarized RFC2250 stream IDs the stream worked fine.
    The issue is to configure the VLC correctly to accept non standard stream IDs
    defined by VW. _This is not a defect of the VideoRTP module._
