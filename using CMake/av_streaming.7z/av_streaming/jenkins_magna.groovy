pipeline {
   agent { label 'A965' }

    stages {
        stage('RunTest') {
            steps {
                bat "deploy.bat"
            }
            post {
                always{
                    recordIssues(enabledForFailure: true, tools: [cmake(), clang()])
                }
            }
        }
/*		stage('analyze') {
            parallel{
				stage ("TSDUCK Script") {
					steps {
						dir('utils') {
							script {
								try { timeout(time: 5, unit: 'MINUTES') {
								def now = new Date()
								fileName = now.format("yyMMdd.HHmm", TimeZone.getTimeZone('UTC'))
								fileName = "D:\\magnaReport\\analyze" + fileName + ".txt"
                                
								bat "D:\\videos\\TSDuck\\bin\\tsp.exe -v --timed-log -I ip 65000  -P pcrbitrate  -P until --seconds 5 -P analyze --json --service-analysis --table-analysis --ts-analysis -w  --error-analysis  -O drop  >> ${fileName} 2>&1"
								rc = bat(returnStatus: true, script: "C:\\Tool\\Python3\\python.exe findString_duck.py ${fileName}")
								bat "taskkill /f /im VideoStream.exe"
								if (rc != 0) { 
									echo"exit code is NOT zero"
									error("Aborting search .")
								}
								else {
									echo "exit code is zero"
								}
								}	catch(all) { }
							}
						}
					}
				}
				stage ("run APP") {
					steps {
						dir('build\\VideoStream') {
							try { timeout(time: 5, unit: 'MINUTES') {
							bat "copy /Y D:\\videos\\video.h264"
							bat "VideoStream.exe --input test_noloop.h264 --host 127.0.0.1 --port 65000 --loop 1 --generate 9999999999999999 >logts.txt 2>&1 ||  EXIT /B 0"
							}	catch(all) { }
						}
					}
				}
			}
		}		
		stage('stuffanalyze') {
            parallel{
				stage ("TSDUCK Script") {
					steps {
						dir('utils') {
							script {
								def now = new Date()
								fileName = now.format("yyMMdd.HHmm", TimeZone.getTimeZone('UTC'))
								fileName = "D:\\magnaReport\\stuffanalyze" + fileName + ".txt"
                                
								bat "D:\\videos\\TSDuck\\bin\\tsp.exe -v --timed-log -I ip 65000 -P pcrbitrate -P  until --seconds 5 -P stuffanalyze -p 0x00 -p 0x1000 -O drop  >>  ${fileName} 2>&1"
								bat "taskkill /f /im VideoStream.exe"
								// rc = bat(returnStatus: true, script: "C:\\Tool\\Python3\\python.exe findString_duck.py ${fileName}")
								// if (rc != 0) { 
								 	echo"exit code is NOT zero"
								// 	error("Aborting search .")
								// }
								// else {
								// 	echo "exit code is zero"
								// }
							}
						}
					}
				}
				stage ("run APP") {
					steps {
						dir('build\\VideoStream') {
							bat "copy /Y D:\\videos\\video.h264"
							bat "VideoStream.exe --input test_noloop.h264 --host 127.0.0.1 --port 65000 --loop 1 --generate 9999999999999999 >logts.txt 2>&1 ||  EXIT /B 0"
						}
					}
				}
			}
		}
		stage('pcrverify') {
            parallel{
				stage ("run APP") {
					steps {
						dir('build\\VideoStream') {
							bat "copy /Y D:\\videos\\video.h264"
							bat "VideoStream.exe --input test_noloop.h264 --host 127.0.0.1 --port 65000 --loop 1 --generate 9999999999999999 >logts.txt 2>&1 ||  EXIT /B 0"
						}
					}
				}
				stage ("TSDUCK Script") {
					steps {
						dir('utils') {
							script {
								def now = new Date()
								fileName = now.format("yyMMdd.HHmm", TimeZone.getTimeZone('UTC'))
								fileName = "D:\\magnaReport\\pcrverify" + fileName + ".txt"
                                
								bat "D:\\videos\\TSDuck\\bin\\tsp.exe -v --timed-log -I ip 65000 -P pcrbitrate -P  until --seconds 10 -P pcrverify -i -j 0 -t -p 0x00 -p 0x1000 -O drop >> ${fileName} 2>&1"
								rc = bat(returnStatus: true, script: "C:\\Tool\\Python3\\python.exe findString_duck.py ${fileName}")
								bat "taskkill /f /im VideoStream.exe"
								if (rc != 0) { 
									echo"exit code is NOT zero"
									error("Aborting search .")
								}
								else {
									echo "exit code is zero"
								}
							}
						}
					}
				}
			}
		}
		stage('pes') {
            parallel{
				stage ("run APP") {
					steps {
						dir('build\\VideoStream') {
							bat "copy /Y D:\\videos\\video.h264"
							bat "VideoStream.exe --input test_noloop.h264 --host 127.0.0.1 --port 65000 --loop 1 --generate 9999999999999999 >logts.txt 2>&1 ||  EXIT /B 0"
						}
					}
				}
				stage ("TSDUCK Script") {
					steps {
						dir('utils') {
							script {
								def now = new Date()
								fileName = now.format("yyMMdd.HHmm", TimeZone.getTimeZone('UTC'))
								fileName = "D:\\magnaReport\\pes" + fileName + ".txt"
                                
								bat "D:\\videos\\TSDuck\\bin\\tsp.exe -v --timed-log -I ip 65000 -P pcrbitrate -P  until --seconds 5 -P pes -h --h26x-default-format H.264 --packet-index -i --multiple-files -s -t -v -O drop >> ${fileName} 2>&1"
								// rc = bat(returnStatus: true, script: "C:\\Tool\\Python3\\python.exe findString_duck.py ${fileName}")
								bat "taskkill /f /im VideoStream.exe"
								// if (rc != 0) { 
								// 	echo"exit code is NOT zero"
								// 	error("Aborting search .")
								// }
								// else {
								// 	echo "exit code is zero"
								// }
							}
						}
					}
				}
			}
        }
		stage('pcrextract') {
            parallel{
				stage ("run APP") {
					steps {
						dir('build\\VideoStream') {
							bat "copy /Y D:\\videos\\video.h264"
							bat "VideoStream.exe --input test_noloop.h264 --host 127.0.0.1 --port 65000 --loop 1 --generate 9999999999999999 >logts.txt 2>&1 ||  EXIT /B 0"
						}
					}
				}
				stage ("TSDUCK Script") {
					steps {
						dir('utils') {
							script {
								def now = new Date()
								fileName = now.format("yyMMdd.HHmm", TimeZone.getTimeZone('UTC'))
								fileName = "D:\\magnaReport\\pcrextract" + fileName + ".txt"
                                
								bat "D:\\videos\\TSDuck\\bin\\tsp.exe -v --timed-log -I ip 65000  -P until --seconds 5 -P pcrextract -O drop >> ${fileName} 2>&1"
								bat "taskkill /f /im VideoStream.exe"
								// rc = bat(returnStatus: true, script: "C:\\Tool\\Python3\\python.exe findString_duck.py ${fileName}")
								// if (rc != 0) { 
								// 	echo"exit code is NOT zero"
								// 	error("Aborting search .")
								// }
								// else {
								// 	echo "exit code is zero"
								// }
							}
						}
					}
				}
			}
        }*/
    } 
    post {
        always{
            xunit (
                thresholds: [ skipped(failureThreshold: '0'), failed(failureThreshold: '0') ],
                tools: [ CTest(pattern: 'build/Testing/**/Test.xml') ]
            )
        }
    }
}