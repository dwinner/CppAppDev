#ifndef AVB_RTCP_PACKET_BUILDER_H
#define AVB_RTCP_PACKET_BUILDER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include "sysdef.h"
#include <VideoRTP.h>

#ifdef __cplusplus
extern "C"
{
#endif

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */

/* version = 2 (2 bits), padding = 0 (1 bit), report count = 0 (5 bits) */
#define VIDEORTP_RTCP_HEADER_START 0x80
/** RTCP packet type is AVB RTCP (208)*/
#define VIDEORTP_RTCP_AVB_PACKET_TYPE 0xD0
/** RTCP header length constant */
#define VIDEORTP_RTCP_LENGTH_VALUE 0x0009
/** Size of packet */
#define VIDEORTP_RTCP_PACKET_SIZE 40
/** Payload type for MPEG-TS streaming [RFC2250] */
#define VIDEORTP_RTCP_RFC2250_PAYLOAD_TYPE 33
/** Payload type for IP_AVT isochronous streaming [IP_AVT_415] */
#define VIDEORTP_RTCP_IP_AVT_ISO_PAYLOAD_TYPE 0x7F
/** Payload type for IP_AVT synchronous streaming [IP_AVT_396] */
#define VIDEORTP_RTCP_IP_AVT_SYN_PAYLOAD_TYPE 0x7A
/** Marker bit default value for VIDEORTP_rtpStreamingMode_RFC2250 */
#define VIDEORTP_RTCP_RFC2250_MARKER_BIT 1
/** Marker bit default value for IP_AVT*/
#define VIDEORTP_RTCP_IP_AVT_MARKER_BIT 0

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    typedef enum
    {
        VIDEORTP_rtpStreamingMode_RFC2250 = 0,
        VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS = 1,
        VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS = 2
    } VIDEORTP_rtpStreamingMode_t;

    /**
     * \defgroup AvbRtcpPacketBuilder
     * @{
     * @brief Builds RTCP packets associating RTP and IEEE 802.1AS timestamps as per IEEE 1733.
     *
     * @startuml rtcp_packet_creation
     *  hide empty members
     *
     * class RtcpSessionConfiguration <<struct>> {
     *     + uint8_t payloadType
     *     + uint8_t ssrc[4]
     *     + uint8_t rtcpName[4]
     *     + uint16_t gmTimeBaseIndicator
     *     + uint8_t gmIdentity[10]
     *     + uint8_t streamId[8]
     *     + uint32_t t_deliveryCompensationOffset
     *     + VIDEORTP_rtpStreamingMode_t streamingMode
     * }
     *  class AvbRtcpPacketBuilder {
     *      + buildPacket(rtpTimestamp : uint32_t, ieeeTimestamp : uint32_t, packetBuffer : BufferWriter&) : void
     *      - configuration : const RtcpSessionConfiguration*
     *  }
     *  AvbRtcpPacketBuilder o- RtcpSessionConfiguration
     * @enduml
     *
     * The configuration is shared between @ref VIDEORTP_rtpHeaderBuilder_t "RTP" and
     * @ref VIDEORTP_avbRtcpPacketBuilder_t "RTCP" packetizers.
     * It is just a collection of "static" settings (determined either during compilation, instantiation, or connection setup) and
     * various IDs to be included in RTP and RTCP packets.
     */

    /**
     * @brief The structure contains variable fields for the rtcp packet header
     *
     */
    typedef struct VIDEORTP_rtcpSessionConfiguration_t
    {
        /** @publicsection @{ */
        /** @brief A field for the payload type in RTP header
         *
         * In mode RFC2250: RTP Payload Type for MPEG = 33
         * In mode VW LAH IP_AVT: RTP payload type = 0x7A assuming synchronous streaming
         * In mode VW LAH IP_AVT: RTP payload type = 0x7F assuming isochronous streaming
         */
        uint8_t payloadType;

        /** @brief The synchronization source identifier, i.e., the originator of this RTP or RTCP packet */
        uint8_t ssrc[VIDEORTP_RTCP_SSRC_SIZE];

        /** @brief This field contains a name chosen to uniquely identify this set of RTCP packets with respect to other RTCP
         * packets that the application might receive */
        uint8_t rtcpName[VIDEORTP_RTCP_NAME_SIZE];

        /** @brief This field is used to communicate the Grand Master currently being ‘listened to’ by the talker for purposes of
         * relating media and IEEE 802.1AS time. */
        uint8_t gmIdentity[VIDEORTP_RTCP_GM_IDENTITY_SIZE];

        /** @brief Ethernet stream ID (for traffic shaping etc. on lower network layers) */
        uint8_t streamId[VIDEORTP_RTCP_STREAM_ID_SIZE];

        /** @brief Timestamp offset [IP_AVT_391] */
        uint32_t deliveryCompensationOffset;

        /** @brief Controls rtp header setting switcher between IP_AVT and VIDEORTP_rtpStreamingMode_RFC2250 modes */
        VIDEORTP_rtpStreamingMode_t streamingMode;

        /** @brief Initial sequence counter RFC3550 section 5.1 */
        uint16_t initialSequenceCounter;

        /** @brief Initial timestamp RFC3550 section 5.1 */
        uint32_t initialTimestamp;
        /** @} */
    } VIDEORTP_rtcpSessionConfiguration_t;

    /**
     * @brief Struct contains data for building RTCP header
     */
    typedef struct VIDEORTP_avbRtcpPacketBuilder_t
    {
        /** @privatesection @{ */
        /** @brief Data with RTCP header fields */
        const VIDEORTP_rtcpSessionConfiguration_t* configuration;
        /** @} */
    } VIDEORTP_avbRtcpPacketBuilder_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_rtcpSessionConfiguration_t instance
     * @public @memberof VIDEORTP_rtcpSessionConfiguration_t
     *
     * @param configuration The instance of VIDEORTP_rtcpSessionConfiguration_t
     * @param streamingMode Controls rtp header setting switcher
     */
    void VIDEORTP_rtcpInitConfig(VIDEORTP_rtcpSessionConfiguration_t* configuration, VIDEORTP_rtpStreamingMode_t streamingMode);

    /**
     * @brief Initialize VIDEORTP_avbRtcpPacketBuilder_t instance
     * @public @memberof VIDEORTP_avbRtcpPacketBuilder_t
     *
     * @param self The instance of VIDEORTP_avbRtcpPacketBuilder_t
     * @param configuration Pointer to session configuration
     */
    void VIDEORTP_rtcpInit(VIDEORTP_avbRtcpPacketBuilder_t* self, const VIDEORTP_rtcpSessionConfiguration_t* configuration);

    /**
     * @brief Writes an AVB RTCP packet to the destination buffer.
     * @public @memberof VIDEORTP_avbRtcpPacketBuilder_t
     *
     * According with IEEE 1733:
     *
     * - 2 bits version : always 2
     * - 1 bit padding : always 0
     * - 5 bits reportCount : always 0
     *
     * - 8 bits packetType : always 208 (AVB RTCP)
     * - 16 bits length : always 9
     *
     * - 32 bits bits SSRC :  from configuration
     * - 32 bits name : from configuration
     * - 16 bits gmTimeBaseIndicator: parameter
     *
     * - 80 bits gmIdentity : from configuration
     * - 64 bits streamId : from configuration
     *
     * - 32 bits asTimestamp : taken in the function
     * - 32 bits rtpTimestamp : taken in the function
     *
     * @note In result: 320 bits = 40 bytes => length = 40/4 - 1 = 9 (according with IEEE 1733)
     *
     * @param self The instance of VIDEORTP_avbRtcpPacketBuilder_t
     * @param rtpTimestamp RTP timestamp/counter of previous RTP packet [IP_AVT_1537]
     * @param ieeeTimestamp IEEE 802.1AS timestamp of the same RTP packet [IP_AVT_1786]
     * @param ieeeTimeBaseIndicator IEEE 802.1AS time base indicator of the timestamp [IP_AVT_1786]
     * @param packetBuffer Destination buffer for RTCP packet
     *
     * @return Whether the destination buffer is large enough
     */
    bool VIDEORTP_rtcpBuildPacket(VIDEORTP_avbRtcpPacketBuilder_t* self, uint32_t rtpTimestamp, uint32_t ieeeTimestamp,
                                  uint16_t ieeeTimeBaseIndicator, VIDEORTP_bufferWriter_t* packetBuffer);

    /**@} AvbRtcpPacketBuilder global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* AVB_RTCP_PACKET_BUILDER_H */
