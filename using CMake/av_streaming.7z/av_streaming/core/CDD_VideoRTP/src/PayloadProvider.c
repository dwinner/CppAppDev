/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "PayloadProvider.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initPayloadChunkInfo
 *
 *   Function:   Initializes a payload chunk info structure.
 *               The flags will be initialized according to the arguments.
 *               The timestamps will be initialized to invalid/empty values.
 *
 *   Inputs:
 *               VIDEORTP_payloadChunkInfo_t* chunkInfo: Structure to initialize
 *               size_t readPosition: current read position within the current frame (payload unit)
 *               size_t chunkSize: size of the next chunk to be returned by the calling pipeline stage
 *               size_t payloadUnitSize: total size of the current frame (payload unit)
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_initPayloadChunkInfo(VIDEORTP_payloadChunkInfo_t* chunkInfo, size_t readPosition, size_t chunkSize,
                                   size_t payloadUnitSize)
{
    assert(readPosition <= payloadUnitSize);
    assert(chunkSize <= payloadUnitSize - readPosition);

    chunkInfo->payloadUnitSize = payloadUnitSize;
    chunkInfo->isPayloadUnitStart = readPosition == 0;
    chunkInfo->isPayloadUnitEnd = (readPosition + chunkSize) == payloadUnitSize;

    chunkInfo->sampleTimestamp = VIDEORTP_InvalidTimestamp;
}
