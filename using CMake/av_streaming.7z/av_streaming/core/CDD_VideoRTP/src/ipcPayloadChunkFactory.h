#ifndef PAYLOAD_CHUNK_FACTORY_H
#define PAYLOAD_CHUNK_FACTORY_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ipcFramePayloadChunk.h"

#ifdef __cplusplus
extern "C"
{
#endif
/**
 * \defgroup IpcPayloadChunkFactory
 * @{
 *
 * @brief Factory for creating @ref PayloadChunk instances.
 *
 * The PayloadChunkFactory combines the concepts of a Factory method and a resource pool.
 * When being initialized by a call to the @ref VIDEORTP_payloadChunkFactoryInit "init" method
 * the internal item pool is converted into PayloadChunk instances being added into a free
 * queue.
 *
 * A call to the @ref VIDEORTP_payloadChunkFactoryCreate "create" method takes one element
 * from this free queue, passes its arguments to the PayloadChunk's init method and returns this
 * initialized instance to the caller.
 *
 * Conversely, a call to the @ref VIDEORTP_payloadChunkFactoryDestroy "destroy" method returns a
 * so-created PayloadChunk instance to the free list for later use.
 *
 * @note If available, the destroy method calls the PayloadChunk's release callback.
 * @warning If creating a PayloadChunk instance failed (e.g. because free queue is out of PayloadChunk instances)
 * the caller is responsible to release the memory associated with the payload buffer. Not doing so causes
 * resource leaks.
 */

/* ===========================================================================
 *
 *   Private Macros
 *
 * ========================================================================= */

/** The maximum number of payload chunks that can be allocated */
#define VIDEORTP_FACTORY_MAX_CHUNK_COUNT 100

    /**
     * @brief Structure holding the data specific to a @ref PayloadChunkFactory instance.
     *
     */
    typedef struct VIDEORTP_ipcPayloadChunkFactory_t
    {
        /** @privatesection @{ */
        /** Array of VIDEORTP_ipcFramePayloadChunk_t instances */
        VIDEORTP_ipcFramePayloadChunk_t itemPool[VIDEORTP_FACTORY_MAX_CHUNK_COUNT];
        /** Queue of free elements */
        VIDEORTP_ipcPayloadChunkQueue_t freeQueue;
        /** @} */
    } VIDEORTP_ipcPayloadChunkFactory_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_ipcPayloadChunkFactory_t
     * @public @memberof VIDEORTP_ipcPayloadChunkFactory_t
     *
     * @param self VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
     */
    void VIDEORTP_payloadChunkFactoryInit(VIDEORTP_ipcPayloadChunkFactory_t* self);

    /**
     * @brief Allocates VIDEORTP_ipcFrame_t instance
     * @public @memberof VIDEORTP_ipcPayloadChunkFactory_t
     *
     * @param self VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
     * @param buffer Buffer with frame chunk
     * @param size Total chunk size
     * @param releaseCallback Release buffer callback to IPC
     *
     * @return VIDEORTP_ipcFramePayloadChunk_t*
     */
    VIDEORTP_ipcFramePayloadChunk_t* VIDEORTP_payloadChunkFactoryCreate(VIDEORTP_ipcPayloadChunkFactory_t* self, const void* buffer,
                                                                        const size_t size,
                                                                        VIDEORTP_releaseBufferCb_t releaseCallback);

    /**
     * @brief Destroy allocated VIDEORTP_ipcFrame_t instance
     * @public @memberof VIDEORTP_ipcPayloadChunkFactory_t
     *
     * @param self VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
     * @param item The element to be destroyed
     */
    void VIDEORTP_payloadChunkFactoryDestroy(VIDEORTP_ipcPayloadChunkFactory_t* self, VIDEORTP_ipcFramePayloadChunk_t* item);

    /**@} PayloadChunkFactory global */

#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PAYLOAD_CHUNK_FACTORY_H */
