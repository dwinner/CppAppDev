/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "PayloadUnitRepeater.h"
#include <assert.h>

static size_t VIDEORTP_repPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData);
static void VIDEORTP_repCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer);

/* ===========================================================================
 *
 *   Name:       VIDEORTP_repInit
 *
 *   Function:   It shall initialize VIDEORTP_payloadUnitRepeater_t with VIDEORTP_bufferWriter_t
 *
 *   Inputs:
 *               VIDEORTP_payloadUnitRepeater_t* self: VIDEORTP_payloadUnitRepeater_t instance that the function works on
 *               const VIDEORTP_bufferWriter_t* destBW: Payload unit to be repeated
 *
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-70, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_repInit(VIDEORTP_payloadUnitRepeater_t* self, const VIDEORTP_bufferWriter_t* destBW)
{
    VIDEORTP_repInitRaw(self, VIDEORTP_bufGetBasePointer(destBW), VIDEORTP_bufGetBytesWritten(destBW));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_repInit
 *
 *   Function:   It shall initialize VIDEORTP_payloadUnitRepeater_t with buffer pointer and length
 *
 *   Inputs:
 *               VIDEORTP_payloadUnitRepeater_t* self: VIDEORTP_payloadUnitRepeater_t instance that the function works on
 *               const void* data: data buffer which will be repeated
 *               size_t length: size of data buffer
 *
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-70, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_repInitRaw(VIDEORTP_payloadUnitRepeater_t* self, const void* data, size_t length)
{
    assert(self);
    assert(data);

    self->vtable.prepareNextChunk = VIDEORTP_repPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_repCopyChunk;
    self->payloadUnit.buffer = data;
    self->payloadUnit.length = length;
    self->readPosition = 0;
    self->nextChunkSize = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_repPrepareNextChunk
 *
 *   Function:   It shall return the minimum of maximumSize and remaining content length
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               size_t maximumSize: maximum available space of destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t Amount of data which can be copied
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-70, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadUnitRepeater_t */
static size_t VIDEORTP_repPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_payloadUnitRepeater_t* self = (VIDEORTP_payloadUnitRepeater_t*) ((void*) vtable);

    assert(self->payloadUnit.buffer);

    self->nextChunkSize = VIDEORTP_sysGetMin(self->payloadUnit.length - self->readPosition, maximumSize);
    VIDEORTP_initPayloadChunkInfo(metaData, self->readPosition, self->nextChunkSize, self->payloadUnit.length);

    return self->nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_repCopyChunk
 *
 *   Function:   Copy as much data into payloadBuffer as promised in last call VIDEORTP_repPrepareNextChunk
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               VIDEORTP_bufferWriter_t* payloadBuffer: Payload unit to be repeated
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-70, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadUnitRepeater_t */
static void VIDEORTP_repCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_payloadUnitRepeater_t* self = (VIDEORTP_payloadUnitRepeater_t*) ((void*) vtable);

    assert(self->readPosition <= self->payloadUnit.length);
    const uint8_t* chunkStartPointer = (const uint8_t*) self->payloadUnit.buffer + self->readPosition;
    VIDEORTP_bufWriteData(payloadBuffer, chunkStartPointer, self->nextChunkSize);
    self->readPosition += self->nextChunkSize;
    assert(self->readPosition <= self->payloadUnit.length);

    /* Restart if the end of the payload unit was reached. */
    if (self->readPosition == self->payloadUnit.length)
    {
        self->readPosition = 0;
    }
}
