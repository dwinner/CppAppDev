/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoRtpUtil.h"
#include "ConstantsMPEG.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_timerTick
 *
 *   Function:   Advance a timer/counter and check whether it has elapsed
 *
 *   Inputs:
 *               uint32_t* timer: Current timer/counter value
 *               uint32_t ticksSinceLastCall: Elapsed time since the last call of this function
 *               uint32_t interval: Ticks between two timer events
 *
 *   Outputs:
 *               bool: Whether the timer has elapsed
 *
 *   Side Effects:
 *               Increments *timer
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: 16813296, 16805593
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_timerTick(uint32_t* timer, uint32_t ticksSinceLastCall, uint32_t interval)
{
    assert(interval > 0);

    uint32_t newTimer = *timer + ticksSinceLastCall;
    bool elapsed = false;
    if (newTimer >= interval)
    {
        elapsed = true;

        /* Keep overflow (if any) to maintain the correct frequency (on average at least). */
        newTimer -= interval;

        /* Do not try to catch up if timers were not handled in time. */
        if (newTimer >= interval)
        {
            newTimer = 0;
        }
    }
    *timer = newTimer;
    return elapsed;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_convertTimestamp
 *
 *   Function:   Convert an StbM timestamp (1GHz) to an MPEG timestamp (27MHz)
 *
 *   Inputs:
 *               const StbM_TimeStampType* timestamp: Timestamp to convert (1GHz)
 *
 *   Outputs:
 *               MPEG timestamp (27MHz)
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-810
 *
 *   Traceability to SW Req: 16805566
 *
 *   Remarks:
 *               Values which cannot be represented exactly will be rounded down.
 *
 * ========================================================================= */
uint64_t VIDEORTP_convertTimestamp(const StbM_TimeStampType* timestamp)
{
    /* Nanoseconds and VIDEORTP_CLOCK_RATE fit in an uint32 so their product cannot overflow an uint64 */
    uint64_t seconds = (uint64_t) timestamp->seconds + ((uint64_t) timestamp->secondsHi << UINT64_C(32));
    uint64_t ts = (uint64_t) seconds * VIDEORTP_CLOCK_RATE;
    ts += (uint64_t) timestamp->nanoseconds * VIDEORTP_CLOCK_RATE / UINT64_C(1000000000);
    return ts;
}
