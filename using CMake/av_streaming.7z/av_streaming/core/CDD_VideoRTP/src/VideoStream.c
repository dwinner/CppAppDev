/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoStream.h"
#include "ConstantsOEM.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_estimatePacketsPerCycle
 *
 *   Function:   Estimate how many RTP packets need to be transferred per cycle
 *               in order to cope with the given target video bandwidth.
 *
 *   Inputs:
 *               const VIDEORTP_videoStreamConfig_t* config: Video stream configuration
 *
 *   Outputs:
 *               A lower bound for RTP packets to be transferred per cycle.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-855
 *
 *   Traceability to SW Req: 16813244, 16813212, 16813244
 *
 *   Remarks:
 *               Sending fewer packets per cycle may lead to congestion.
 *
 * ========================================================================= */
/** @memberof VIDEORTP_videoStreamConfig_t */
static uint32_t VIDEORTP_estimatePacketsPerCycle(const VIDEORTP_videoStreamConfig_t* config)
{
    /* Maximum raw video data */
    uint32_t payloadBytesPerSec = config->targetDataRate / 8;
    /* PES header at the beginning of each frame */
    payloadBytesPerSec += config->targetFrameRate * VIDEORTP_PES_HEADER_SIZE_WITH_DTS;
    /* Padding at the end of each frame */
    payloadBytesPerSec += config->targetFrameRate * (VIDEORTP_TS_PACKET_SIZE - VIDEORTP_TS_MINIMUM_HEADER_SIZE);
    assert(payloadBytesPerSec > 0);

    /* TS packets needed for payload */
    uint32_t tsPacketsPerSec
        = VideoRTP_divideRoundUp(payloadBytesPerSec, VIDEORTP_TS_PACKET_SIZE - VIDEORTP_TS_MINIMUM_HEADER_SIZE);
    /* Might need to generate extra dummy packets to send PCR */
    tsPacketsPerSec += VideoRTP_divideRoundUp(1000, VIDEORTP_PCR_INTERVAL) * VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
    /* Assume MPEG PAT/PMT fit in one TS packet each */
    assert(config->tableConfig.interval > 0);
    tsPacketsPerSec += 2 * VideoRTP_divideRoundUp(1000, config->tableConfig.interval)
        * VideoRTP_divideRoundUp(VIDEORTP_PROGRAM_TABLE_SIZE, VIDEORTP_TS_PACKET_SIZE - VIDEORTP_TS_MINIMUM_HEADER_SIZE);
    assert(tsPacketsPerSec > 0);

    /* Minimum supported IPv6 UDP packet size */
    uint32_t availableRtpPacketSize = VIDEORTP_MAX_TX_PAYLOAD_SIZE;
    /* RTP header (without extensions) */
    availableRtpPacketSize -= VIDEORTP_RTP_HEADER_SIZE;
    assert(availableRtpPacketSize > 0);

    /* How many TS packets fit into a network packet */
    uint32_t tsPacketsPerRtpPacket = VideoRTP_divideRoundDown(availableRtpPacketSize, VIDEORTP_TS_PACKET_SIZE);
    assert(tsPacketsPerRtpPacket > 0);
    uint32_t rtpPacketsPerSec = VideoRTP_divideRoundUp(tsPacketsPerSec, tsPacketsPerRtpPacket);
    assert(rtpPacketsPerSec > 0);

    /* How many packets to transfer per cycle to guarantee that the bandwidth can be reached */
    assert(config->cyclicInterval > 0);
    uint32_t rtpPacketsPerCycle = VideoRTP_divideRoundUp(rtpPacketsPerSec * config->cyclicInterval, 1000);
    assert(rtpPacketsPerCycle > 0);

    return rtpPacketsPerCycle;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initVideoStream
 *
 *   Function:   The function initializes a network connection for data transmission over the network or to file writer
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               VIDEORTP_packetTransmitter_t* rtpTransmitter: Pipeline output
 *               VIDEORTP_packetTransmitter_t* rtcpTransmitter: Control packets
 *               const VIDEORTP_videoStreamConfig_t* config: Streaming mode and IDs
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407, MAGAVSTR-801
 *
 *   Traceability to SW Req: 16805651
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_initVideoStream(VIDEORTP_videoStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                              VIDEORTP_packetTransmitter_t* rtcpTransmitter, const VIDEORTP_videoStreamConfig_t* config)
{
    assert(stream);
    assert(config);
    assert(config->cyclicInterval > 0);

    VIDEORTP_payloadProvider_t* comp;

    stream->rtpTransmitter = rtpTransmitter;
    stream->rtcpTransmitter = rtcpTransmitter;
    stream->cyclicInterval = config->cyclicInterval;
    stream->packetsPerCycle = VIDEORTP_estimatePacketsPerCycle(config);
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    /* Use static input only if it was configured correctly */
    stream->isStaticInputActive = config->isStaticInputEnabled && (config->staticInputConfig.payloadUnits != NULL)
        && (config->staticInputConfig.payloadUnitCount > (size_t) 0);
#endif

    /* Merge individual sub-streams (ordered by priority) */
    VIDEORTP_muxInit(&stream->multiplexer);

    /* Program association tables have the highest priority because they list the available programs. */
    comp = VIDEORTP_initProgramAssociationTableStream(&stream->patStream, &config->tableConfig);
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* Program map tables define one program. */
    comp = VIDEORTP_initProgramMapTableStream(&stream->pmtStream, &config->tableConfig);
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* The actual video elementary stream */
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        comp = VIDEORTP_initStaticInputStream(&stream->staticInput, &config->staticInputConfig);
    }
    else
    {
        comp = VIDEORTP_initIPCInputStream(&stream->ipcInput, &config->ipcInputConfig);
    }
#else
    comp = VIDEORTP_initIPCInputStream(&stream->ipcInput, &config->ipcInputConfig);
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* Padding has the lowest priority so it does not suppress the video stream.
        Padding only makes sense for static input */
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        comp = VIDEORTP_initPaddingStream(&stream->padStream, config->targetDataRate / 8, &stream->staticInput.counter);
        VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);
    }
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    /* Initialize RTP stream */
    VIDEORTP_initRtpStream(&stream->rtpStream, &stream->multiplexer.vtable, &config->rtpConfig);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_deinitVideoStream
 *
 *   Function:   The function deinitializes stream
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: 16805651
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_deinitVideoStream(VIDEORTP_videoStream_t* stream)
{
    assert(stream);

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        /* Does it need to do something */
    }
    else
    {
        VIDEORTP_ipcDeinitIPCInputStream(&stream->ipcInput);
    }
#else
    VIDEORTP_ipcDeinitIPCInputStream(&stream->ipcInput);
#endif
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicVideoStream
 *
 *   Function:   The main function that implements the transmission of packets over the network / writing to a file
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *
 *   Outputs:
 *               VideoRTP_errorCode: VideoRTP_ok if some packets could be sent successfully; any other value if an error occurred.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407, MAGAVSTR-662, MAGAVSTR-801, MAGAVSTR-843, MAGAVSTR-842
 *
 *   Traceability to SW Req: 16813230, 16813252, 16813244
 *
 *   Remarks:
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_cyclicVideoStream(VIDEORTP_videoStream_t* stream)
{
    assert(stream);

    /* Forward cyclic call to all stream components */
    VIDEORTP_cyclicProgramTableStream(&stream->patStream, stream->cyclicInterval);
    VIDEORTP_cyclicProgramTableStream(&stream->pmtStream, stream->cyclicInterval);
    VIDEORTP_cyclicRtpStream(&stream->rtpStream, stream->cyclicInterval);

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        VIDEORTP_cyclicStaticInputStream(&stream->staticInput, stream->cyclicInterval);
        VIDEORTP_cyclicPaddingStream(&stream->padStream, stream->cyclicInterval);
    }
    else
    {
        VIDEORTP_cyclicIPCInputStream(&stream->ipcInput, stream->cyclicInterval);
    }
#else
    VIDEORTP_cyclicIPCInputStream(&stream->ipcInput, stream->cyclicInterval);
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    VideoRTP_errorCode err = VideoRTP_invalidCall;

    /* To reduce bursts (which might overload the network stack), limit the
     * maximum number of packets per cyclic call. As a rough estimate, sending
     * one RTP packet (containing 6 MPEG-TS packets) per millisecond is
     * sufficient for an input stream of approximately 8.5mbit/s. */
    for (uint32_t packets = stream->packetsPerCycle; packets > 0; --packets)
    {
        err = VIDEORTP_sendRtpPacket(&stream->rtpStream, stream->rtpTransmitter, stream->rtcpTransmitter);
        if ((err == VideoRTP_queueEmpty) && (packets < stream->packetsPerCycle))
        {
            /* The queue may be empty now, but at least one packet was sent successfully. */
            err = VideoRTP_ok;
            break;
        }
        if (err != VideoRTP_ok)
        {
            /* A real error occurred or the queue was completely empty. */
            break;
        }
    }

    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_startFrameVideoStream
 *
 *   Function:   Creates frame
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               const size_t frameSize: frame full size
 *               VIDEORTP_timestamp* timestamp: Sampling timestamp of this frame
 *
 *   Outputs:
 *               true: if start frame successful
 *               false: if start frame unsuccessful
 *
 *   Side Effects:
 *               If static input is enabled and active, input from IPC will be ignored.
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555, 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_startFrameVideoStream(VIDEORTP_videoStream_t* stream, const size_t frameSize, const VIDEORTP_timestamp* timestamp)
{
    assert(stream);
    assert(timestamp);

    bool res = true;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    res = !stream->isStaticInputActive;
#endif
    if (res)
    {
        res = VIDEORTP_ipcInputStartFrame(&stream->ipcInput, frameSize, timestamp);
    }
    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_AppendFrameVideStream
 *
 *   Function:   Appends payload chunk to frame
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               const void* bufferPayload: payload chunk
 *               const size_t bufferSize: size of payload chunk
 *               VIDEORTP_releaseBufferCb_t bufferReleaseCallback:
 *
 *   Outputs:
 *               true: if append chunk successful
 *               false: if append chunk unsuccessful
 *
 *   Side Effects:
 *               If static input is enabled and active, input from IPC will be ignored.
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: 16802575, 16813236, 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_appendFrameVideoStream(VIDEORTP_videoStream_t* stream, const void* bufferPayload, const size_t bufferSize,
                                     VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    assert(stream);

    bool res = true;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    res = !stream->isStaticInputActive;
#endif
    if (res)
    {
        res = VIDEORTP_ipcInputAppendFrame(&stream->ipcInput, bufferPayload, bufferSize, bufferReleaseCallback);
    }
    return res;
}
