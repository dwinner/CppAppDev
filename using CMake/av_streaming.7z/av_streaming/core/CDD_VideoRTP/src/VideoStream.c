/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoStream.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initVideoStream
 *
 *   Function:   The function initializes a network connection for data transmission over the network or to file writer
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               VIDEORTP_packetTransmitter_t* rtpTransmitter: Pipeline output
 *               VIDEORTP_packetTransmitter_t* rtcpTransmitter: Control packets
 *               const VIDEORTP_videoStreamConfig_t* config: Streaming mode and IDs
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407, MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * * ========================================================================= */
void VIDEORTP_initVideoStream(VIDEORTP_videoStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                              VIDEORTP_packetTransmitter_t* rtcpTransmitter, const VIDEORTP_videoStreamConfig_t* config)
{
    VIDEORTP_payloadProvider_t* comp;

    stream->rtpTransmitter = rtpTransmitter;
    stream->rtcpTransmitter = rtcpTransmitter;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    /* Use static input only if it was configured correctly */
    stream->isStaticInputActive = config->isStaticInputEnabled && (config->staticInputConfig.payloadUnits != NULL)
        && (config->staticInputConfig.payloadUnitCount > 0);
#endif

    /* Merge individual sub-streams (ordered by priority) */
    VIDEORTP_muxInit(&stream->multiplexer);

    /* Program association tables have the highest priority because they list the available programs. */
    comp = VIDEORTP_initProgramAssociationTableStream(&stream->patStream, &config->tableConfig);
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* Program map tables define one program. */
    comp = VIDEORTP_initProgramMapTableStream(&stream->pmtStream, &config->tableConfig);
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* The actual video elementary stream */
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        comp = VIDEORTP_initStaticInputStream(&stream->staticInput, &config->staticInputConfig);
    }
    else
    {
        comp = VIDEORTP_initIPCInputStream(&stream->ipcInput, &config->ipcInputConfig);
    }
#else
    comp = VIDEORTP_initIPCInputStream(&stream->ipcInput, &config->ipcInputConfig);
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */
    VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);

    /* Padding has the lowest priority so it does not suppress the video stream.
        Padding only makes sense for static input */
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        comp = VIDEORTP_initPaddingStream(&stream->padStream, &stream->staticInput.counter);
        VIDEORTP_pipeAddMultiplePredecessor(&stream->multiplexer.base, comp);
    }
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    /* Initialize RTP stream */
    VIDEORTP_initRtpStream(&stream->rtpStream, &stream->multiplexer.vtable, &config->rtpConfig);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_deinitVideoStream
 *
 *   Function:   The function deinitializes stream
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * * ========================================================================= */
void VIDEORTP_deinitVideoStream(VIDEORTP_videoStream_t* stream)
{
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        /* Does it need to do something */
    }
    else
    {
        VIDEORTP_ipcDeinitIPCInputStream(&stream->ipcInput);
    }
#else
    VIDEORTP_ipcDeinitIPCInputStream(&stream->ipcInput);
#endif
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicVideoStream
 *
 *   Function:   The main function that implements the transmission of packets over the network / writing to a file
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407, MAGAVSTR-662, MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicVideoStream(VIDEORTP_videoStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Forward cyclic call to all stream components */
    VIDEORTP_cyclicProgramTableStream(&stream->patStream, timeSinceLastCall);
    VIDEORTP_cyclicProgramTableStream(&stream->pmtStream, timeSinceLastCall);
    VIDEORTP_cyclicRtpStream(&stream->rtpStream, timeSinceLastCall);

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    if (stream->isStaticInputActive)
    {
        VIDEORTP_cyclicStaticInputStream(&stream->staticInput, timeSinceLastCall);
        VIDEORTP_cyclicPaddingStream(&stream->padStream, timeSinceLastCall);
    }
    else
    {
        VIDEORTP_cyclicIPCInputStream(&stream->ipcInput, timeSinceLastCall);
    }
#else
    VIDEORTP_cyclicIPCInputStream(&stream->ipcInput, timeSinceLastCall);
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    /* Send as many packets as available */
    while (VIDEORTP_sendRtpPacket(&stream->rtpStream, stream->rtpTransmitter, stream->rtcpTransmitter))
    {
        continue; /* until there are no more packets left */
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_startFrameVideoStream
 *
 *   Function:   Creates frame
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               const size_t frameSize: frame full size
 *               const uint64_t samplingTime: frame timestamp
 *
 *   Outputs:
 *               true: if start frame successful
 *               false: if start frame unsuccessful
 *
 *   Side Effects:
 *               If static input is enabled and active, input from IPC will be ignored.
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_startFrameVideoStream(VIDEORTP_videoStream_t* stream, const size_t frameSize, const uint64_t samplingTime)
{
    bool res = true;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    res = !stream->isStaticInputActive;
#endif
    if (res)
    {
        res = VIDEORTP_ipcInputStartFrame(&stream->ipcInput, frameSize, samplingTime);
    }
    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_AppendFrameVideStream
 *
 *   Function:   Appends payload chunk to frame
 *
 *   Inputs:
 *               VIDEORTP_videoStream_t* stream: VIDEORTP_videoStream_t instance that the function works on
 *               const void* bufferPayload: payload chunk
 *               const size_t bufferSize: size of payload chunk
 *               VIDEORTP_releaseBufferCb_t bufferReleaseCallback:
 *
 *   Outputs:
 *               true: if append chunk successful
 *               false: if append chunk unsuccessful
 *
 *   Side Effects:
 *               If static input is enabled and active, input from IPC will be ignored.
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_appendFrameVideoStream(VIDEORTP_videoStream_t* stream, const void* bufferPayload, const size_t bufferSize,
                                     VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    bool res = true;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    res = !stream->isStaticInputActive;
#endif
    if (res)
    {
        res = VIDEORTP_ipcInputAppendFrame(&stream->ipcInput, bufferPayload, bufferSize, bufferReleaseCallback);
    }
    return res;
}
