/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PaddingCalculator.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_padCalcInit
 *
 *   Function:   Initialize VIDEORTP_paddingCalculator_t
 *
 *   Inputs:
 *               VIDEORTP_paddingCalculator_t* self: VIDEORTP_paddingCalculator_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-453, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_padCalcInit(VIDEORTP_paddingCalculator_t* self)
{
    assert(self);

    self->targetPadding = 0;
    self->dataRate = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_padCalcPadding
 *
 *   Function:   Calculate and return padding size to achieve the desired total data rate.
 *
 *   Inputs:
 *               VIDEORTP_paddingCalculator_t* self: VIDEORTP_paddingCalculator_t instance that the function works on
 *               size_t payloadCounter: Amount of real data (without padding) transferred since the last call
 *               uint32_t elapsedTime: Time in milliseconds since the last call
 *
 *   Outputs:
 *               size_t Padding to generate in the next interval (assuming the next interval has the same length as elapsedTime)
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-453, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Assumes the calculation will be updated in regular intervals (e.g., every x milliseconds).
 *            If the actual interval jitters, the calculation will be inaccurate.
 *
 * ========================================================================= */
size_t VIDEORTP_padCalcPadding(VIDEORTP_paddingCalculator_t* self, size_t payloadCounter, uint32_t elapsedTime)
{
    if (elapsedTime > 0)
    {
        /* Determine rate of useful data since the last call. */
        self->dataRate = payloadCounter * 1000 / elapsedTime;

        if (VIDEORTP_TARGET_DATARATE > self->dataRate)
        {
            /* Determine required padding until the next call, assuming the data rate remains constant. */
            self->targetPadding = (VIDEORTP_TARGET_DATARATE - self->dataRate) * elapsedTime / 1000;
        }
        else
        {
            self->targetPadding = 0;
        }
    }
    else
    {
        self->dataRate = 0;
    }

    return self->targetPadding;
}
