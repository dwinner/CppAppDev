
/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "IpcFrameProvider.h"
#include "SinglyLinkedList.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcRemoveFrame
 *
 *   Function:   It removes frame from queue
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameProvider_t* self: VIDEORTP_ipcFrameProvider_t instance that the function works on
 *               VIDEORTP_ipcFrame_t* frame: frame to be deleted
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_ipcFrameProvider_t */
static void VIDEORTP_ipcRemoveFrame(VIDEORTP_ipcFrameProvider_t* self, VIDEORTP_ipcFrame_t* frame)
{
    assert(self);
    assert(frame);

    /* This may be NULL if no frame is currently "active"; otherwise, it must
     * point to the end of the queue because that's the only place where more
     * data can be appended. */
    assert(self->newestFrame == NULL || self->newestFrame == self->frameQueue.tail);

    VIDEORTP_ipcFrame_t* dequeueFrame = NULL;
    VIDEORTP_slistPopFront(&self->frameQueue, &dequeueFrame);
    assert(dequeueFrame == frame);

    /* Avoid dangling pointer */
    if (dequeueFrame == self->newestFrame)
    {
        self->newestFrame = NULL;
    }

    VIDEORTP_frameFactoryDestroy(&self->frameFactory, dequeueFrame);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcPrepareNextChunk
 *
 *   Function:   It shall return the minimum of maximumSize and content length
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               size_t maximumSize: maximum available space of destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *               Remove frames from queue header if it's not complete
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_ipcFrameProvider_t */
static size_t VIDEORTP_ipcPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);
    VIDEORTP_ipcFrameProvider_t* self = (VIDEORTP_ipcFrameProvider_t*) ((void*) vtable);

    self->nextChunkSize = 0;
    VIDEORTP_ipcFrame_t* frame = NULL;
    VIDEORTP_slistPeekFront(&self->frameQueue, &frame);

    while (frame != NULL)
    {
        if ((frame->bytesIn < frame->totalSize) && frame->next != NULL)
        {
            /*
             * Some chunks of this frame are missing.
             * The caller did not provide a valid and complete frame.
             * Possible reasons include queue overflow.
             *
             * TODO: This error handling is incomplete! The remaining pipeline
             * stages need to recover from corrupted frames. It may be necessary
             * to reinitialize the encoder, the IPC channel, or even the decoder.
             *
             * For now, ensure that this module does not crash and just continue.
             * The emitted RTP frames will probably contain garbage, however.
             */

            /* Discard the incomplete frame */
            VIDEORTP_ipcRemoveFrame(self, frame);
            /* continue with next frame */
            VIDEORTP_slistPeekFront(&self->frameQueue, &frame);
            continue;
        }

        self->nextChunkSize = VIDEORTP_ipcFrameGetAvailableBytes(frame);
        self->nextChunkSize = VIDEORTP_sysGetMin(self->nextChunkSize, maximumSize);
        if (self->nextChunkSize != 0)
        {
            VIDEORTP_initPayloadChunkInfo(metaData, frame->bytesOut, self->nextChunkSize, frame->totalSize);
            metaData->sampleTimestamp = frame->samplingTime;
        }
        break;
    }

    return self->nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcCopyChunk
 *
 *   Function:   Copy as much data into payloadBuffer as promissed in last call VIDEORTP_repPrepareNextChunk
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               VIDEORTP_bufferWriter_t* payloadBuffer: destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_ipcFrameProvider_t */
static void VIDEORTP_ipcCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);
    VIDEORTP_ipcFrameProvider_t* self = (VIDEORTP_ipcFrameProvider_t*) ((void*) vtable);

    assert(self->nextChunkSize <= VIDEORTP_bufGetAvailableSpace(payloadBuffer));

    VIDEORTP_ipcFrame_t* frame = NULL;

    VIDEORTP_slistPeekFront(&self->frameQueue, &frame);

    size_t frameSize
        = VIDEORTP_ipcFrameGetData(frame, VIDEORTP_bufGetWritableChunk(payloadBuffer, self->nextChunkSize), self->nextChunkSize);

    assert(frameSize == self->nextChunkSize);

    if (VIDEORTP_ipcFrameGetRemainingBytes(frame) == 0)
    {
        VIDEORTP_ipcRemoveFrame(self, frame);
    }
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcInit
 *
 *   Function:   Initialize VIDEORTP_ipcFrameProvider_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameProvider_t* self: VIDEORTP_ipcFrameProvider_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
void VIDEORTP_ipcInit(VIDEORTP_ipcFrameProvider_t* self)
{
    assert(self);

    self->vtable.copyChunk = VIDEORTP_ipcCopyChunk;
    self->vtable.prepareNextChunk = VIDEORTP_ipcPrepareNextChunk;
    self->newestFrame = NULL;
    self->nextChunkSize = 0;
    VIDEORTP_slistInit(&self->frameQueue);
    VIDEORTP_frameFactoryInit(&self->frameFactory);
    VIDEORTP_payloadChunkFactoryInit(&self->chunkFactory);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcDeinit
 *
 *   Function:   Deinitialize VIDEORTP_ipcFrameProvider_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameProvider_t* self: VIDEORTP_ipcFrameProvider_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
void VIDEORTP_ipcDeinit(VIDEORTP_ipcFrameProvider_t* self)
{
    VIDEORTP_ipcFrame_t* currentFrame;
    do
    {
        currentFrame = NULL;
        VIDEORTP_slistPeekFront(&self->frameQueue, &currentFrame);
        if (currentFrame != NULL)
        {
            VIDEORTP_ipcRemoveFrame(self, currentFrame);
        }
    } while (currentFrame != NULL);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcStartFrame
 *
 *   Function:   Creates frame
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameProvider_t* self: VIDEORTP_ipcFrameProvider_t instance that the function works on
 *               size_t frameSize: frame full size
 *               uint64_t samplingTime: frame timestamp
 *
 *   Outputs:
 *               true: if start frame successful
 *               false: if start frame unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
bool VIDEORTP_ipcStartFrame(VIDEORTP_ipcFrameProvider_t* self, const size_t frameSize, const uint64_t samplingTime)
{
    assert(self);

    self->newestFrame = VIDEORTP_frameFactoryCreate(&self->frameFactory, &self->chunkFactory, frameSize, samplingTime);
    bool res = (self->newestFrame != NULL);
    if (res)
    {
        VIDEORTP_slistPushBack(&self->frameQueue, self->newestFrame);
    }

    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcAppendFrame
 *
 *   Function:   Appends payload chunk to frame
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameProvider_t* self: VIDEORTP_ipcFrameProvider_t instance that the function works on
 *               void* bufferPayload: payload chunk
 *               size_t bufferSize: size of payload chunk
 *               VIDEORTP_releaseBufferCb_t releaseCb: release buffer callback
 *
 *   Outputs:
 *               true: if append chunk successful
 *               true: if append chunk unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
bool VIDEORTP_ipcAppendFrame(VIDEORTP_ipcFrameProvider_t* self, const void* bufferPayload, const size_t bufferSize,
                             VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    assert(self);

    bool res = (self->newestFrame != NULL);
    if (res)
    {
        res = VIDEORTP_ipcFrameAddPayloadChunk(self->newestFrame, bufferPayload, bufferSize, bufferReleaseCallback);
    }

    return res;
}
