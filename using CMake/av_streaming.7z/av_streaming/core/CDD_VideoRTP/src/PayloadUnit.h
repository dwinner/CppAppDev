#ifndef PAYLOAD_UNIT_H
#define PAYLOAD_UNIT_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include <stddef.h>

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup PayloadUnit
     * @{
     * @brief Store payload pointer and length e.g. a single video frame
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Defines a payload unit, e.g., a single video frame.
     */
    typedef struct VIDEORTP_payloadUnit_t
    {
        /**
         * @brief Payload pointer
         *
         */
        const void* buffer;
        /**
         * @brief Payload length
         *
         */
        size_t length;
    } VIDEORTP_payloadUnit_t;

    /**@} PayloadUnit global */
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PAYLOAD_UNIT_H */
