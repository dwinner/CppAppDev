/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "RtpStream.h"
#include "ConstantsMPEG.h"
#include "ConstantsOEM.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initRtpStream
 *
 *   Function:   The function initializes a network connection for data transmission over the network or to file writer
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               VIDEORTP_payloadProvider_t* packetSource: Source stream
 *               const VIDEORTP_rtcpSessionConfiguration_t* config: Configuration for all stream components
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * * ========================================================================= */
void VIDEORTP_initRtpStream(VIDEORTP_rtpStream_t* stream, VIDEORTP_payloadProvider_t* packetSource,
                            const VIDEORTP_rtcpSessionConfiguration_t* config)
{
    /* Send RTCP immediately */
    stream->rtcpTimer = 0;
    stream->rtcpElapsed = true;

    /* Store a copy because the packet builders need the IDs */
    stream->rtpConfig = *config;

    VIDEORTP_rtpPacketizerInit(&stream->rtpPacketizer, packetSource, &stream->rtpConfig, 1);
    VIDEORTP_rtcpInit(&stream->rtcpPacketizer, &stream->rtpConfig);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicRtpStream
 *
 *   Function:   Cyclically checks if RTCP packets have to be transmitted
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicRtpStream(VIDEORTP_rtpStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Send RTCP */
    if (VIDEORTP_timerTick(&stream->rtcpTimer, timeSinceLastCall, VIDEORTP_RTCP_INTERVAL))
    {
        stream->rtcpElapsed = true;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sendRtpPacket
 *
 *   Function:   Send a RTP and RTCP packet
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               VIDEORTP_packetTransmitter_t* rtpTransmitter: Pipeline output
 *               VIDEORTP_packetTransmitter_t* rtcpTransmitter: Control packets
 *
 *   Outputs:
 *               Returns false when there are no more packets to send
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-754
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_sendRtpPacket(VIDEORTP_rtpStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                            VIDEORTP_packetTransmitter_t* rtcpTransmitter)
{
    /* Send RTP packet */
    VIDEORTP_bufferWriter_t* rtpBuf = VIDEORTP_txPrepareTransmissionBuffer(rtpTransmitter);
    bool hasRtpPacket = VIDEORTP_rtpBuildPacket(&stream->rtpPacketizer, rtpBuf);
    if (hasRtpPacket)
    {
        VIDEORTP_txCommitTransmissionBuffer(rtpTransmitter);
    }

    if (hasRtpPacket && rtcpTransmitter != NULL && stream->rtcpElapsed)
    {
        stream->rtcpElapsed = false;

        /* Add offset and convert to nanoseconds */
        uint32_t rtp = VIDEORTP_rtpGetPacketTimestamp(&stream->rtpPacketizer.headerBuilder);
        uint32_t offset = stream->rtpConfig.deliveryCompensationOffset * (VIDEORTP_CLOCK_RATE / 300 / 1000);
        uint32_t ieee = (uint32_t) (((uint64_t) rtp + offset) * (1000000000 / 10000) / (VIDEORTP_CLOCK_RATE / 300 / 10000));

        /* Send RTCP packet */
        VIDEORTP_bufferWriter_t* rtcpBuf = VIDEORTP_txPrepareTransmissionBuffer(rtcpTransmitter);
        if (VIDEORTP_rtcpBuildPacket(&stream->rtcpPacketizer, rtp, ieee, rtcpBuf))
        {
            VIDEORTP_txCommitTransmissionBuffer(rtcpTransmitter);
        }
    }

    return hasRtpPacket;
}
