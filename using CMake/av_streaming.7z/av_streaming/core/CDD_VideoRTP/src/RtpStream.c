/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "RtpStream.h"
#include "ConstantsMPEG.h"
#include "ConstantsOEM.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initRtpStream
 *
 *   Function:   The function initializes a network connection for data transmission over the network or to file writer
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               VIDEORTP_payloadProvider_t* packetSource: Source stream
 *               const VIDEORTP_rtcpSessionConfiguration_t* config: Configuration for all stream components
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: 16802568, 16805601, 16805645, 16805835, 16805852, 16806035
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_initRtpStream(VIDEORTP_rtpStream_t* stream, VIDEORTP_payloadProvider_t* packetSource,
                            const VIDEORTP_rtcpSessionConfiguration_t* config)
{
    /* Send RTCP immediately */
    stream->rtcpTimer = 0;
    stream->rtcpElapsed = true;

    /* Store a copy because the packet builders need the IDs */
    stream->rtpConfig = *config;

    VIDEORTP_rtpPacketizerInit(&stream->rtpPacketizer, packetSource, &stream->rtpConfig);
    VIDEORTP_rtcpInit(&stream->rtcpPacketizer, &stream->rtpConfig);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicRtpStream
 *
 *   Function:   Cyclically checks if RTCP packets have to be transmitted
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: 16802568, 16805601, 16805835, 16805852, 16805883
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicRtpStream(VIDEORTP_rtpStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Send RTCP */
    if (VIDEORTP_timerTick(&stream->rtcpTimer, timeSinceLastCall, VIDEORTP_RTCP_INTERVAL))
    {
        stream->rtcpElapsed = true;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sendRtpPacket
 *
 *   Function:   Send a RTP and RTCP packet
 *
 *   Inputs:
 *               VIDEORTP_rtpStream_t* stream: VIDEORTP_rtpStream_t instance that the function works on
 *               VIDEORTP_packetTransmitter_t* rtpTransmitter: Pipeline output
 *               VIDEORTP_packetTransmitter_t* rtcpTransmitter: Control packets
 *
 *   Outputs:
 *               VideoRTP_errorCode
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-754, MAGAVSTR-842, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16802568, 16805601, 16805639, 16805645, 16805727, 16805835, 16805852,
 * 16805883, 16805928, 16806035
 *
 *   Remarks:
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_sendRtpPacket(VIDEORTP_rtpStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                                          VIDEORTP_packetTransmitter_t* rtcpTransmitter)
{
    VideoRTP_errorCode err = VideoRTP_ok;
    /* Send RTP packet */
    VIDEORTP_bufferWriter_t* rtpBuf = VIDEORTP_txPrepareTransmissionBuffer(rtpTransmitter);
    err = VIDEORTP_rtpBuildPacket(&stream->rtpPacketizer, rtpBuf);

    if (err == VideoRTP_ok)
    {
        err = VIDEORTP_txCommitTransmissionBuffer(rtpTransmitter);
    }

    if (err == VideoRTP_ok && rtcpTransmitter != NULL && stream->rtcpElapsed)
    {
        stream->rtcpElapsed = false;

        /* Add offset and convert to nanoseconds */
        VIDEORTP_timestamp timestamp = VIDEORTP_rtpGetPacketTimestamp(&stream->rtpPacketizer.headerBuilder);
        uint32_t rtp
            = (uint32_t) (timestamp.mpegPresentationTimestamp / UINT64_C(300)); /* Convert from 27 MHz to 90 kHz as per RFC3551 */
        uint32_t offset = stream->rtpConfig.deliveryCompensationOffset * UINT32_C(1000000); /* Convert from ms to ns */
        uint32_t ieee = timestamp.gptpTimestamp + offset; /* unsigned addition may overflow */

        /* Send RTCP packet */
        VIDEORTP_bufferWriter_t* rtcpBuf = VIDEORTP_txPrepareTransmissionBuffer(rtcpTransmitter);
        if (VIDEORTP_rtcpBuildPacket(&stream->rtcpPacketizer, rtp, ieee, timestamp.gptpTimeBaseIndicator, rtcpBuf))
        {
            err = VIDEORTP_txCommitTransmissionBuffer(rtcpTransmitter);
        }
    }

    return err;
}
