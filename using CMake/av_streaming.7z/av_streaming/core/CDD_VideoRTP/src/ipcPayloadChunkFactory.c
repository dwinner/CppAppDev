/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ipcPayloadChunkFactory.h"
#include "SinglyLinkedList.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_payloadChunkFactoryInit
 *
 *   Function:   Initialize VIDEORTP_ipcFrameProvider_t
 *
 *   Inputs:
 *               VIDEORTP_ipcPayloadChunkFactory_t* self: VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
void VIDEORTP_payloadChunkFactoryInit(VIDEORTP_ipcPayloadChunkFactory_t* self)
{
    assert(self);
    VIDEORTP_slistInit(&self->freeQueue);

    for (size_t i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        VIDEORTP_slistPushBack(&self->freeQueue, &self->itemPool[i]);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_payloadChunkFactoryCreate
 *
 *   Function:   Initialize VIDEORTP_ipcFrameProvider_t
 *
 *   Inputs:
 *               VIDEORTP_ipcPayloadChunkFactory_t* self: VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
 *               void* buffer: Buffer with frame chunk
 *               size_t size: Total chunk size
 *               VIDEORTP_releaseBufferCb_t releaseCallback: Release buffer callback to IPC
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
VIDEORTP_ipcFramePayloadChunk_t* VIDEORTP_payloadChunkFactoryCreate(VIDEORTP_ipcPayloadChunkFactory_t* self, const void* buffer,
                                                                    const size_t size, VIDEORTP_releaseBufferCb_t releaseCallback)
{
    assert(self);
    assert(buffer);

    VIDEORTP_ipcFramePayloadChunk_t* chunk = NULL;
    VIDEORTP_slistPopFront(&self->freeQueue, &chunk);
    if (chunk != NULL)
    {
        VIDEORTP_ipcFrameChunkInit(chunk, buffer, size, releaseCallback);
    }
    else
    {
        /* caller must release the buffer */
    }

    return chunk;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_payloadChunkFactoryDestroy
 *
 *   Function:   Initialize VIDEORTP_ipcFrameProvider_t
 *
 *   Inputs:
 *               VIDEORTP_ipcPayloadChunkFactory_t* self: VIDEORTP_ipcPayloadChunkFactory_t instance that the function works on
 *               VIDEORTP_ipcFramePayloadChunk_t* item: The element to be destroyed
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Implementation of VIDEORTP_payloadProvider_t
 *
 * ========================================================================= */
void VIDEORTP_payloadChunkFactoryDestroy(VIDEORTP_ipcPayloadChunkFactory_t* self, VIDEORTP_ipcFramePayloadChunk_t* item)
{
    assert(self);
    assert(item);

    /* call ReleseCallback function and reset all item params*/
    VIDEORTP_ipcFrameChunkReleaseBuffer(item);
    item->releaseBufferCb = NULL;
    item->next = NULL;
    VIDEORTP_slistPushBack(&self->freeQueue, item);
}
