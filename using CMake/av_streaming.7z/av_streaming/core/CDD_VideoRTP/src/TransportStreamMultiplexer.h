#ifndef TRANSPORT_STREAM_MULTIPLEXER_H
#define TRANSPORT_STREAM_MULTIPLEXER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include "PayloadProvider.h"
#include "PipelineStageWithMultiplePredecessors.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup TransportStreamMultiplexer
     * @{
     *
     * @brief Takes input from multiple sources and forms a single MPEG TS stream.
     *
     * The TransportStreamMultiplexer implements the PayloadProvider interface to provide a stream of
     * MPEG TS payload units which it takes from a list of predecessor stages.
     *
     * @startuml
     * hide empty members
     *
     * interface PayloadProvider
     * class PipelineStageWithMultiplePredecessors
     * class TransportStreamMultiplexer
     * PayloadProvider <|.. TransportStreamMultiplexer : <<implement>>
     * TransportStreamMultiplexer *- PipelineStageWithMultiplePredecessors
     * @enduml
     *
     * The TransportStreamMultiplexer assumes that the input sources have been added to the @ref
     * PipelineStageWithMultiplePredecessors part in the order of their priority, e.g. it always picks the first predecessor that
     * can deliver data. To temporarily block a source, a @ref PayloadGate can be inserted into the pipeline.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief This structure contains data for pipelines data multiplexing
     * @implements VIDEORTP_payloadProvider_t
     *
     * @see PipelineStageWithMultiplePredecessors
     * @see PayloadProvider
     */
    typedef struct VIDEORTP_transportStreamMultiplexer_t
    {
        /** @privatesection @{ */
        /** Instance of PayloadProvider interface */
        VIDEORTP_payloadProvider_t vtable;
        /** Index of current selected predecessor */
        size_t selectedPredecessorIndex;
        /** Instance of predecessors provider */
        VIDEORTP_pipelineStageWithMultiplePredecessors_t base;
        /** @} */
    } VIDEORTP_transportStreamMultiplexer_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize self VIDEORTP_transportStreamMultiplexer_t instance
     * @public @memberof VIDEORTP_transportStreamMultiplexer_t
     *
     * Initialize VIDEORTP_transportStreamMultiplexer_t instance.
     * Define VIDEORTP_payloadProvider_t interface.
     *
     * @param self The instance of VIDEORTP_transportStreamMultiplexer_t
     */
    void VIDEORTP_muxInit(VIDEORTP_transportStreamMultiplexer_t* self);

    /**@} TransportStreamMultiplexer global */

#ifdef __cplusplus
}
#endif

#endif /* TRANSPORT_STREAM_MULTIPLEXER_H */
