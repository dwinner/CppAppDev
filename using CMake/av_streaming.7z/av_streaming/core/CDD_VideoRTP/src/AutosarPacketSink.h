#ifndef AUTOSAR_PACKET_SINK_H_INCLUDED
#define AUTOSAR_PACKET_SINK_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "PacketTransmitter.h"
#include <PduR_Cdd.h>

/* ===========================================================================
 *
 *  Public Typedefs
 *
 * ========================================================================= */

/**
 * \defgroup AutosarPacketSink
 * @{
 * @brief Send packets via AUTOSAR PDU Router API
 *
 * The AUTOSAR packet sink provides a single transmission buffer.
 * See @ref PacketTransmitter for details.
 *
 * @startuml autosar_packet_sink
 *  hide empty members
 *
 *  class BufferWriter
 *
 *  interface PacketTransmitter {
 *      {abstract} + getBuffer() : BufferWriter*
 *      {abstract} + commitBuffer() : void
 *  }
 *
 *  PacketTransmitter .> BufferWriter : <<use>>
 *
 *  class AutosarPacketSink {
 *      - m_payloadBuffer : uint8_t[MAX_PAYLOAD_SIZE]
 *      - m_payloadWriter : BufferWriter
 *      - m_txPduId : PduIdType
 *      + getBuffer() : BufferWriter*
 *      + commitBuffer() : void
 *  }
 *  PacketTransmitter <|.. AutosarPacketSink : <<implement>>
 *
 *  BufferWriter --* AutosarPacketSink
 *
 *  class PduRouter <<AUTOSAR>> #LightGrey {
 *      + PduR_CddTransmit(TxPduId : PduIdType, PduInfoPtr : const PduInfoType*) : Std_ReturnType
 *  }
 *  AutosarPacketSink --> PduRouter : <<use>>
 *
 *  class PduInfoType <<AUTOSAR>> <<struct>> #LightGrey {
 *      + SduDataPtr : uint8*
 *      + SduLength : PduLengthType
 *  }
 *  AutosarPacketSink --> PduInfoType : <<use>>
 *  PduRouter .> PduInfoType : <<use>>
 * @enduml
 */

/**
 * @brief This interface specifies a way to output packets
 * @implements VIDEORTP_packetTransmitter_t
 */
typedef struct
{
    /** @privatesection @{ */
    /**
     * @brief Allocation of base class
     *
     */
    VIDEORTP_packetTransmitter_t vtable;
    /**
     * @brief ID of AUTOSAR source PDU which accepts data
     */
    PduIdType m_txPduId;
    /**
     * @brief Buffer for transmitted data
     *
     */
    VIDEORTP_buffer_t m_payloadBuffer;
    /**
     * @brief Allocation of BufferWriter class
     *
     */
    VIDEORTP_bufferWriter_t m_payloadWriter;
    /** @} */
} VIDEORTP_asrPacketSink_t;

/* ===========================================================================
 *
 *  Public Defines
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Public Function Prototypes
 *
 * ========================================================================= */

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @brief Initialize fields of self
     * @public @memberof VIDEORTP_asrPacketSink_t
     *
     * @param self instance that the function works on
     * @param pduIdType unique AUTOSAR PDU ID
     */
    void VIDEORTP_asrInitPacketSink(VIDEORTP_asrPacketSink_t* self, PduIdType pduIdType);

    /**
     * @brief Deinitialize fields of self
     * @public @memberof VIDEORTP_asrPacketSink_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_asrDeinitPacketSink(VIDEORTP_asrPacketSink_t* self);

#ifdef __cplusplus
}
#endif

/** @} */

#endif /* AUTOSAR_PACKET_SINK_H_INCLUDED */
