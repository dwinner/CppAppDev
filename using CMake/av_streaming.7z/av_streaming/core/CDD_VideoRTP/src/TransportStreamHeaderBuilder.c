/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "TransportStreamHeaderBuilder.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetTimestampMod
 *
 *   Function:   Return self->timestampPacketCounter by module 6
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               uint8_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: IP_AVT_423, 16805908, 16805944, 16813296
 * requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static uint8_t VIDEORTP_tsGetTimestampMod(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    return self->timestampPacketCounter % (uint64_t) VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetContinuityCounterMod
 *
 *   Function:   Return self->continuityCounter by module 16
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               uint8_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static uint8_t VIDEORTP_tsGetContinuityCounterMod(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    return VIDEORTP_TS_CONTINUITY_COUNTER_MASK & (self->continuityCounter % VIDEORTP_TS_CONTINUITY_COUNTER_MOD);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsIsPcrAllowed
 *
 *   Function:   Check if a PCR is allowed at all in this transport stream.
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self:
 *
 *   Outputs:
 *               bool True if and only if this stream can include PCRs at all (regardless of stream state).
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static bool VIDEORTP_tsIsPcrAllowed(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    /* Not all PIDs may include a PCR; see H.222 standard section 2.4.3.3 in table 2-3 */
    bool isValidPid = (self->pid <= (uint16_t) 0x0001) || ((self->pid >= (uint16_t) 0x0010) && (self->pid <= (uint16_t) 0x1FFE));

    /* Need to know how to get PCR timestamps for this stream */
    bool hasPcrFunction = (self->pcrQueryFunction != NULL);

    return isValidPid && hasPcrFunction;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsIsPcrPacket
 *
 *   Function:   Check if a PCR is allowed in the next packet header (whether or not it is actually available).
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self:
 *
 *   Outputs:
 *               bool True if and only if the next header packet hypothetically might include a PCR.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static bool VIDEORTP_tsIsPcrPacket(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    uint8_t counter = VIDEORTP_tsGetTimestampMod(self);
    return self->includePcr && (counter == (uint8_t) 0);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsIsPcrValid
 *
 *   Function:   Check if a valid PCR is actually available and can be inserted into the next header.
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self:
 *
 *   Outputs:
 *               bool True if and only if the next header packet actually will include a PCR.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static bool VIDEORTP_tsIsPcrValid(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    return VIDEORTP_tsIsPcrPacket(self) && (self->nextProgramClockReference != VIDEORTP_InvalidTimestamp);
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsInitHeaderBuilder
 *
 *   Function:   Initialize VIDEORTP_transportStreamHeaderBuilder_t instance
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               uint16_t pid: PID of this MPEG transport stream
 *               VIDEORTP_pcrQueryFunction pcrQueryFunction: Optional pointer to a function which returns the current PCR.
 *               void* pcrQueryContext: User-defined data for the PCR function.
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsInitHeaderBuilder(VIDEORTP_transportStreamHeaderBuilder_t* self, uint16_t pid,
                                  VIDEORTP_pcrQueryFunction pcrQueryFunction, void* pcrQueryContext)
{
    assert(self);

    self->pid = pid;
    self->pcrQueryFunction = pcrQueryFunction;
    self->pcrQueryContext = pcrQueryContext;

    self->payloadUnitStartIndicator = false;
    self->includePcr = false;
    self->nextProgramClockReference = VIDEORTP_InvalidTimestamp;
    self->timestampPacketCounter = 0;
    self->continuityCounter = VIDEORTP_TS_CONTINUITY_COUNTER_MOD - 1;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetMinimumHeaderSize
 *
 *   Function:   It shall calculate and return minimum size of TS header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               size_t Ret: VIDEORTP_TS_MINIMUM_HEADER_SIZE + VIDEORTP_TS_ADAPTATION_FIELD_SIZE, if can include PCR
 *               size_t VIDEORTP_TS_MINIMUM_HEADER_SIZE, if can not include PCR
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_tsGetMinimumHeaderSize(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    assert(self);

    /* Minimum size without PCR */
    size_t headerSize = VIDEORTP_TS_MINIMUM_HEADER_SIZE;

    if (VIDEORTP_tsIsPcrValid(self))
    {
        /* Add space for PCR */
        headerSize += (size_t) VIDEORTP_TS_ADAPTATION_FIELD_SIZE;
    }

    return headerSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsSetPacketMetaData
 *
 *   Function:   Determines flags for the next TS packet header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               VIDEORTP_payloadChunkInfo_t* metadata: Metadata about packet. Must not be NULL.
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsSetPacketMetaData(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_payloadChunkInfo_t* metadata)
{
    assert(self);
    assert(metadata);

    self->payloadUnitStartIndicator = metadata->isPayloadUnitStart;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsPrepareHeader
 *
 *   Function:   Prepare the next header without writing anything
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Updates PCR
 *
 *   Traceability to SDD: MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *              This function should be called shortly before VIDEORTP_tsBuildHeader in
 *              order to update any volatile data needed for the next header.
 *              In particular, this is needed for size calculations.
 *
 * ========================================================================= */
void VIDEORTP_tsPrepareHeader(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    assert(self);

    /* Query the PCR only if it could be included in the very next header so the PCR is not calculated needlessly. */
    if (VIDEORTP_tsIsPcrPacket(self))
    {
        /* Get up-to-date program clock reference. Usually this will be called
         * right before a header is built, so the PCR should not be too old. */
        self->nextProgramClockReference = (*self->pcrQueryFunction)(self->pcrQueryContext);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsBuildHeader
 *
 *   Function:   Build TS header according to H.222.
 *               If necessary, an adaptation field with PCR will be added.
 *               The remaining buffer space will be filled with stuffing bytes.
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               VIDEORTP_bufferWriter_t* buffer: Destination buffer (will be filled completely).
 *
 *   Outputs:
 *
 *   Side Effects:
 *               continuityCounter and timestampPacketCounter will be incremented
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805566, 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsBuildHeader(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_bufferWriter_t* buffer)
{
    assert(self);
    assert(buffer);

    size_t totalHeaderLength = VIDEORTP_bufGetAvailableSpace(buffer);
    assert(totalHeaderLength >= VIDEORTP_tsGetMinimumHeaderSize(self));

    /* Space not needed by the TS header or stuffing bytes must be payload. */
    bool hasPayload = totalHeaderLength < VIDEORTP_TS_PACKET_SIZE;
    /* Unused space after the TS header and adaptation field will be filled with stuffing bytes. */
    bool hasStuffing = totalHeaderLength > VIDEORTP_tsGetMinimumHeaderSize(self);
    bool hasPcr = VIDEORTP_tsIsPcrValid(self);
    bool hasAdaptationField = hasPcr || hasStuffing;

    /* Packets without payload must have stuffing, therefore TS packets cannot be completely empty. */
    assert(hasPayload || hasAdaptationField);

    /* Byte 1: Sync byte */
    VIDEORTP_bufWriteInteger(buffer, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));

    /*
        Bytes 2 + 3:
        transport_error_indicator (1 bit to 0)
        payload_unit_start_indicator (1 bit if self->payloadUnitStartIndicator)
        transport_priority (1 bit to 0)
        PID (13 bits is self->pid)
    */
    uint16_t pidAndFlags = (uint16_t) VIDEORTP_TS_INDICATOR_AND_PID_MASK & (self->pid | (self->payloadUnitStartIndicator << 14));
    VIDEORTP_bufWriteInteger(buffer, pidAndFlags, sizeof(pidAndFlags));

    /*
        Byte 4:
        scrambled = 0b00
        adaptationFieldControl = 0bYX
        continuityCounter = 0bZZZZ
    */
    uint8_t adaptationFieldControl = 0;
    if (hasPayload)
    {
        adaptationFieldControl |= (uint8_t) VIDEORTP_TS_PAYLOAD_MASK;
        /* Pre-increment counter because packets without payload may not increment it (H.222.0, 2.4.3.3) */
        self->continuityCounter = (self->continuityCounter + 1) % VIDEORTP_TS_CONTINUITY_COUNTER_MOD;
    }
    if (hasAdaptationField)
    {
        adaptationFieldControl |= (uint8_t) VIDEORTP_TS_ADAPTATION_FIELD_MASK;
    }
    adaptationFieldControl |= VIDEORTP_tsGetContinuityCounterMod(self);
    VIDEORTP_bufWriteInteger(buffer, adaptationFieldControl, sizeof(adaptationFieldControl));

    if (VIDEORTP_bufGetAvailableSpace(buffer) > 0)
    {
        /* Byte 5: Length of adaptation field (including stuffing bytes) */
        size_t adaptationFieldLength = VIDEORTP_bufGetAvailableSpace(buffer) - (size_t) 1;
        VIDEORTP_bufWriteInteger(buffer, adaptationFieldLength, sizeof(uint8_t));

        if (VIDEORTP_bufGetAvailableSpace(buffer) > 0)
        {
            /* Byte 6: Adaptation Field Flags */
            if (hasPcr)
            {
                /* adaptation field with PCR */
                VIDEORTP_bufWriteInteger(buffer, VIDEORTP_TS_PCR_FLAG_TRUE, sizeof(uint8_t));

                /* Bytes 7..12: 33 bit PCR base, 6 bit reserved, 9 bit PCR extension */
                uint64_t pcrBase = self->nextProgramClockReference / (uint64_t) 300;
                uint64_t pcrExt = self->nextProgramClockReference % (uint64_t) 300;
                uint64_t pcrAdaptationField = (pcrBase << 15) | (uint64_t) 0x7E00 | pcrExt;
                VIDEORTP_bufWriteInteger(buffer, pcrAdaptationField, VIDEORTP_TS_PCR_SIZE);

                /* Wait for the next trigger before inserting another PCR */
                self->includePcr = false;
            }
            else
            {
                /* empty adaptation field */
                VIDEORTP_bufWriteInteger(buffer, 0, sizeof(uint8_t));
            }

            /* Fill the rest with stuffing bytes */
            if (VIDEORTP_bufGetAvailableSpace(buffer) > 0)
            {
                VIDEORTP_bufWritePattern(buffer, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(buffer));
            }
        }
    }

    /* Increase PCR counter [IP_AVT_423] */
    self->timestampPacketCounter = (self->timestampPacketCounter + 1) % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsInjectPcr
 *
 *   Function:   Enqueue a PCR (Program Clock Reference) for inclusion in the next TS header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Updates PCR flag
 *
 *   Traceability to SDD: MAGAVSTR-26, MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks: Must be called only for specific PIDs (see H.222, table 2-3, note 1)
 *            Calling this method is only needed for streams which are referenced
 *            in a Program Map Table as the PCR source for some program.
 *
 * ========================================================================= */
void VIDEORTP_tsInjectPcr(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    assert(self);

    if (VIDEORTP_tsIsPcrAllowed(self))
    {
        self->includePcr = true;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsIsPcrPending
 *
 *   Function:   Return whether injection of a PCR timestamp was requested and is still pending.
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               bool True if and only if a PCR timestamp still needs to be injected.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-844, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_tsIsPcrPending(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    assert(self);
    return self->includePcr;
}
