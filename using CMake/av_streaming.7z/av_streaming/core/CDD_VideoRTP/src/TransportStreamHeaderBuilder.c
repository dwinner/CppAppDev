/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "TransportStreamHeaderBuilder.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetTimestampMod
 *
 *   Function:   Return self->timestampPacketCounter by module 6
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               uint8_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: IP_AVT_423, <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static uint8_t VIDEORTP_tsGetTimestampMod(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    return self->timestampPacketCounter % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetContinuityCounterMod
 *
 *   Function:   Return self->continuityCounter by module 16
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               uint8_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static uint8_t VIDEORTP_tsGetContinuityCounterMod(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    return VIDEORTP_TS_CONTINUITY_COUNTER_MASK & (self->continuityCounter % VIDEORTP_TS_CONTINUITY_COUNTER_MOD);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsCanIncludePCR
 *
 *   Function:   It shall check can packet include PCR
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self:
 *
 *   Outputs:
 *               bool
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamHeaderBuilder_t */
static bool VIDEORTP_tsCanIncludePCR(const VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    /* H.222 Table 2-3 */
    return ((self->pid <= 0x0001) || ((self->pid > 0x0010) && (self->pid < 0x1FFE))) && (VIDEORTP_tsGetTimestampMod(self) == 0)
        && (self->nextProgramClockReference != VIDEORTP_InvalidTimestamp);
}
/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsInitHeaderBuilder
 *
 *   Function:   Initialize VIDEORTP_transportStreamHeaderBuilder_t instance
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               uint16_t pid: Program ID
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsInitHeaderBuilder(VIDEORTP_transportStreamHeaderBuilder_t* self, uint16_t pid)
{
    assert(self);

    self->pid = pid;
    self->payloadUnitStartIndicator = false;
    self->nextProgramClockReference = VIDEORTP_InvalidTimestamp; /* PCR */
    self->timestampPacketCounter = 0;
    self->continuityCounter = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsGetMinimumHeaderSize
 *
 *   Function:   It shall calculate and return minimum size of TS header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *
 *   Outputs:
 *               size_t Ret: VIDEORTP_TS_MINIMUM_HEADER_SIZE + VIDEORTP_TS_ADAPTATION_FIELD_SIZE, if can include PCR
 *               size_t VIDEORTP_TS_MINIMUM_HEADER_SIZE, if can not include PCR
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_tsGetMinimumHeaderSize(VIDEORTP_transportStreamHeaderBuilder_t* self)
{
    assert(self);

    size_t headerSize = VIDEORTP_TS_MINIMUM_HEADER_SIZE;

    bool pcrFlag = VIDEORTP_tsCanIncludePCR(self);
    if (pcrFlag)
    {
        headerSize += VIDEORTP_TS_ADAPTATION_FIELD_SIZE;
    }

    return headerSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsSetPacketMetaData
 *
 *   Function:   Determines flags for the next TS packet header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               VIDEORTP_payloadChunkInfo_t* metadata: Metadata about packet
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsSetPacketMetaData(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_payloadChunkInfo_t* metadata)
{
    assert(self);

    if (metadata != NULL)
    {
        self->payloadUnitStartIndicator = metadata->isPayloadUnitStart;
    }
    else
    {
        self->payloadUnitStartIndicator = false;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsBuildHeader
 *
 *   Function:   Build TS header according to H.222.
 *               If necessary, an adaptation field with PCR will be added.
 *               The remaining buffer space will be filled with stuffing bytes.
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               VIDEORTP_bufferWriter_t* buffer: Destination buffer (will be filled completely).
 *
 *   Outputs:
 *
 *   Side Effects:
 *               continuityCounter and timestampPacketCounter will be incremented
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsBuildHeader(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_bufferWriter_t* buffer)
{
    assert(self);
    assert(buffer);

    bool res = true;

    /* sync byte */
    res = res && VIDEORTP_bufWriteInteger(buffer, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));

    /*
        transport_error_indicator (1 bit to 0)
        payload_unit_start_indicator (1 bit if self->payloadUnitStartIndicator)
        transport_priority (1 bit to 0)
        PID (13 bits is self->pid)
    */
    uint16_t pidAndFlags = VIDEORTP_TS_INDICATOR_AND_PID_MASK & (self->pid | (self->payloadUnitStartIndicator << 14));
    res = res && VIDEORTP_bufWriteInteger(buffer, pidAndFlags, sizeof(pidAndFlags));

    bool pcrFlag = VIDEORTP_tsCanIncludePCR(self);
    if (pcrFlag)
    {
        /* scrambled = 0b00, adaptationFieldContorl = 0b11, continuityCounter = 0 */
        res = res
            && VIDEORTP_bufWriteInteger(buffer, VIDEORTP_TS_ADAPTATION_FIELD_MASK | VIDEORTP_tsGetContinuityCounterMod(self),
                                        sizeof(uint8_t));

        uint8_t adaptationFieldLength = VIDEORTP_bufGetAvailableSpace(buffer) - 1;
        res = res && VIDEORTP_bufWriteInteger(buffer, adaptationFieldLength, sizeof(adaptationFieldLength));

        /* adaptation flags */
        res = res && VIDEORTP_bufWriteInteger(buffer, VIDEORTP_TS_PCR_FLAG_TRUE, sizeof(uint8_t));

        /* clock references */
        res = res && VIDEORTP_bufWriteInteger(buffer, self->nextProgramClockReference, VIDEORTP_TS_PCR_SIZE);

        /* stuffing */
        if (VIDEORTP_bufGetAvailableSpace(buffer))
        {
            res = res && VIDEORTP_bufWritePattern(buffer, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(buffer));
        }

        self->nextProgramClockReference = VIDEORTP_InvalidTimestamp;
    }
    else
    {
        /* dummy adaptation field */
        if (VIDEORTP_bufGetAvailableSpace(buffer) > 1)
        {
            /* scrambled = 0b00, adaptationFieldContorl = 0b10, continuityCounter = 0 */
            res = res
                && VIDEORTP_bufWriteInteger(buffer,
                                            VIDEORTP_TS_ADAPTATION_FIELD_MASK
                                                | (VIDEORTP_TS_CONTINUITY_COUNTER_MASK & VIDEORTP_tsGetContinuityCounterMod(self)),
                                            sizeof(uint8_t));

            uint8_t adaptationFieldLength = VIDEORTP_bufGetAvailableSpace(buffer) - 1;
            res = res && VIDEORTP_bufWriteInteger(buffer, adaptationFieldLength, sizeof(adaptationFieldLength));

            if (adaptationFieldLength > 0)
            {
                /* adaptation flags */
                res = res && VIDEORTP_bufWriteInteger(buffer, 0, sizeof(uint8_t));
                /* stuffing */
                res = res
                    && VIDEORTP_bufWritePattern(buffer, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(buffer));
            }
        }
        else if (VIDEORTP_bufGetAvailableSpace(buffer) > 0)
        {
            /* scrambled = 0b00, adaptationFieldContorl = 0b01, continuityCounter = 0 */
            res = res
                && VIDEORTP_bufWriteInteger(buffer,
                                            VIDEORTP_TS_ADAPTATION_FIELD_PAYLOAD_ONLY_MASK
                                                | (VIDEORTP_TS_CONTINUITY_COUNTER_MASK & VIDEORTP_tsGetContinuityCounterMod(self)),
                                            sizeof(uint8_t));
        }
    }

    /* increase and check continuity counter */
    self->continuityCounter = (self->continuityCounter + 1) % VIDEORTP_TS_CONTINUITY_COUNTER_MOD;
    /* increase and check timestampPacketCounter */
    self->timestampPacketCounter = (self->timestampPacketCounter + 1) % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsInjectPcr
 *
 *   Function:   Enqueue a PCR (Program Clock Reference) for inclusion in the next TS header
 *
 *   Inputs:
 *               VIDEORTP_transportStreamHeaderBuilder_t* self: The instance of VIDEORTP_transportStreamHeaderBuilder_t
 *               uint64_t timestamp: PCR timestamp to include in header
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Updates nextProgramClockReference
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Must be called only for specific PIDs (see H.222, table 2-3, note 1)
 *            Calling this method is only needed for streams which are referenced
 *            in a Program Map Table as the PCR source for some program.
 *
 * ========================================================================= */
void VIDEORTP_tsInjectPcr(VIDEORTP_transportStreamHeaderBuilder_t* self, uint64_t timestamp)
{
    assert(self);

    uint64_t programClockReferenceBase = timestamp / 300; /* 33 bits */
    uint8_t reserved = 0x3F; /* 6 bits */
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; /* 9 bits */

    self->nextProgramClockReference
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));
}
