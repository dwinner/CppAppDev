#ifndef PES_PACKETIZER_PIPELINE_H
#define PES_PACKETIZER_PIPELINE_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <assert.h>
#include <stdint.h>

#include "ConstantsMPEG.h"

#include "BufferWriter.h"
#include "PayloadProvider.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup ElementaryStreamPacketizer
     * @{
     * @brief Adds a PES header to payload units
     *
     * This pipeline stage adds a header to MPEG elementary stream packets. The elementary stream may contain any raw data (usually
     * audio or video); The caller needs to provide a suitable stream id/type. The presentation timestamps will be copied from the
     * metadata of the underlying payload units.
     *
     * Usually, PES packets will be wrapped in TS packets. PES packets (which may be "large") will be sliced into chunks of 184
     * bytes or less; the TS header consumes 4 bytes or more. The actual size varies depending on the TS header size. The PES header
     * will be inserted at the beginning of the first chunk.
     *
     * See H.222.0 2.4.3.6 and 2.4.3.7 for details.
     *
     * @startuml pes_header_creation
     *  hide empty members
     *
     *  interface PayloadProvider
     *  class PipelineStageWithSinglePredecessor
     *
     *  ' Pipeline implementation
     *  class ElementaryStreamPacketizer {
     *      + prepareNextChunk(maximumSize : size_t, metaData : PayloadChunkInfo*) : size_t
     *      + copyChunk(payloadBuffer : BufferWriter*) : void
     *  }
     *  PayloadProvider <|.. ElementaryStreamPacketizer
     *  PipelineStageWithSinglePredecessor <|-- ElementaryStreamPacketizer
     *
     *  ' Things to build PES header
     *  class ElementaryStreamPacketizer {
     *      - getHeaderSize() : size_t
     *      - setPacketMetaData(metaData : PayloadChunkInfo*) : void
     *      - buildHeader(buffer : BufferWriter&) : void
     *      - streamId : uint8_t
     *      - pesSize : size_t
     *      - needHeader : bool
     *      - timePts : int64_t
     *      - timeDts : int64_t
     *  }
     * @enduml
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Adds a PES header to an elementary stream.
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** Implementation of interface */
        VIDEORTP_payloadProvider_t vtable;

        /** Stream ID/type */
        uint8_t streamID;

        /** Size pes data */
        size_t pesSize;

        /** Time stamp PTS */
        uint64_t timePTS;

        /** Time stamp DTS */
        uint64_t timeDTS;

        /** Previous pipeline stage */
        VIDEORTP_payloadProvider_t* base;

        /** Flag for adding a PES header to a packet */
        bool needHeader;
        /** @} */
    } VIDEORTP_pesStreamPacketizer_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_pesStreamPacketizer_t
     * @public @memberof VIDEORTP_pesStreamPacketizer_t
     *
     * @param self instance that the function works on
     * @param predecessor previous pipeline stage
     * @param streamId stream id according to H.222.0 2.4.3.7 Table 2-22
     *  - Audio stream IDs = 0xC0 .. 0xDF
     *  - Video stream IDs = 0xE0 .. 0xEF
     */
    void VIDEORTP_pesInitPacketizer(VIDEORTP_pesStreamPacketizer_t* self, VIDEORTP_payloadProvider_t* predecessor,
                                    uint8_t streamId);

#ifdef __cplusplus
}
#endif

#endif /* PES_PACKETIZER_PIPELINE_H */
