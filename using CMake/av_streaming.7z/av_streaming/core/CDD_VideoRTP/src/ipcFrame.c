
/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ipcFrame.h"
#include "SinglyLinkedList.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frameRemoveChunk
 *
 *   Function:   Function should remove chunk from frame
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *               VIDEORTP_ipcFramePayloadChunk_t* chunk: block to be removed
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_ipcFrame_t */
static void VIDEORTP_frameRemoveChunk(VIDEORTP_ipcFrame_t* self, VIDEORTP_ipcFramePayloadChunk_t* chunk)
{
    assert(self);
    assert(chunk);
    VIDEORTP_unused(chunk);

    assert(self->payloadChunkQueue.head == chunk); /* Chunk must be at the front of this list */
    VIDEORTP_ipcFramePayloadChunk_t* chunkDequeue = NULL;
    VIDEORTP_slistPopFront(&self->payloadChunkQueue, &chunkDequeue);
    assert(chunkDequeue == chunk);

    VIDEORTP_payloadChunkFactoryDestroy(self->chunkFactory, chunkDequeue);
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameInit
 *
 *   Function:   Initialize VIDEORTP_ipcFrame_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *               VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory: Factory of chunks
 *               size_t frameSize: Total frame size
 *               VIDEORTP_timestamp* timestamp: Sampling timestamp of this frame
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555, 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcFrameInit(VIDEORTP_ipcFrame_t* self, VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory, const size_t frameSize,
                           const VIDEORTP_timestamp* timestamp)
{
    assert(self);
    assert(chunkFactory);
    assert(timestamp);

    self->timestamp = *timestamp;
    self->totalSize = frameSize;
    self->bytesIn = 0;
    self->bytesOut = 0;
    self->next = NULL;
    self->chunkFactory = chunkFactory;

    VIDEORTP_slistInit(&self->payloadChunkQueue);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameDeinit
 *
 *   Function:   Deinitialize VIDEORTP_ipcFrame_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcFrameDeinit(VIDEORTP_ipcFrame_t* self)
{
    VIDEORTP_ipcFramePayloadChunk_t* currentChunk;
    do
    {
        currentChunk = NULL;
        VIDEORTP_slistPeekFront(&self->payloadChunkQueue, &currentChunk);
        if (currentChunk != NULL)
        {
            VIDEORTP_frameRemoveChunk(self, currentChunk);
        }
    } while (currentChunk != NULL);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetSamplingTime
 *
 *   Function:   Return frame samplingTime
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *               uint64_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805555
 *
 *   Remarks:
 *
 * ========================================================================= */
uint64_t VIDEORTP_ipcFrameGetSamplingTime(VIDEORTP_ipcFrame_t* self)
{
    assert(self);
    return self->timestamp.mpegPresentationTimestamp;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetDecodingTime
 *
 *   Function:   Return frame decoding time
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *               uint64_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-911, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805555
 *
 *   Remarks:
 *
 * ========================================================================= */
uint64_t VIDEORTP_ipcFrameGetDecodingTime(VIDEORTP_ipcFrame_t* self)
{
    assert(self);
    return self->timestamp.mpegDecodingTimestamp;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetTotalSize
 *
 *   Function:   Return frame total size
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameGetTotalSize(VIDEORTP_ipcFrame_t* self)
{
    assert(self);
    return self->totalSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetRemainingBytes
 *
 *   Function:   Return remaining size of frame
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameGetRemainingBytes(VIDEORTP_ipcFrame_t* self)
{
    assert(self);
    return self->totalSize - self->bytesOut;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetAvailableBytes
 *
 *   Function:   Return available to send bytes
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameGetAvailableBytes(VIDEORTP_ipcFrame_t* self)
{
    assert(self);
    return self->bytesIn - self->bytesOut;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameGetData
 *
 *   Function:   Copies data to a buffer and returns the size of the copied data
 *
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *               void* buffer: Destination buffer
 *               size_t max: Buffer available space
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameGetData(VIDEORTP_ipcFrame_t* self, void* buffer, const size_t max)
{
    assert(self);
    assert(buffer);

    uint8_t* writePointer = buffer;
    size_t totalBytesCopied = 0;

    VIDEORTP_ipcFramePayloadChunk_t* currentChunk = NULL;
    VIDEORTP_slistPeekFront(&self->payloadChunkQueue, &currentChunk);
    while (totalBytesCopied < max && currentChunk != NULL)
    {
        const size_t bytesCopied = VIDEORTP_ipcFrameChunkGetData(currentChunk, writePointer, max - totalBytesCopied);
        writePointer += bytesCopied;
        totalBytesCopied += bytesCopied;

        if (VIDEORTP_ipcFrameChunkGetRemainingSize(currentChunk) == (size_t) 0)
        {
            VIDEORTP_frameRemoveChunk(self, currentChunk);
            VIDEORTP_slistPeekFront(&self->payloadChunkQueue, &currentChunk);
        }
    }

    self->bytesOut += totalBytesCopied;
    return totalBytesCopied;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameAddPayloadChunk
 *
 *   Function:   Adds chunk to frame
 *
 *               Add chunk to payloadChunkQueue and increase bytesIn
 *   Inputs:
 *               VIDEORTP_ipcFrame_t* self: VIDEORTP_ipcFrame_t instance that the function works on
 *               const void* chunkBuffer: New payload buffer to add. May be NULL.
 *               size_t chunkSize: Size of payload chunk
 *               VIDEORTP_releaseBufferCb_t releaseCb: release buffer callback. May be NULL.
 *
 *   Outputs:
 *               true: if successful
 *               false: if unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802575, 16813236, 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_ipcFrameAddPayloadChunk(VIDEORTP_ipcFrame_t* self, const void* chunkBuffer, size_t chunkSize,
                                      VIDEORTP_releaseBufferCb_t releaseCb)
{
    assert(self);

    bool res = (chunkSize > (size_t) 0) && (chunkBuffer != NULL) && (chunkSize <= (self->totalSize - self->bytesIn));
    if (res)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk
            = VIDEORTP_payloadChunkFactoryCreate(self->chunkFactory, chunkBuffer, chunkSize, releaseCb);
        res = chunk != NULL;
        if (res)
        {
            VIDEORTP_slistPushBack(&self->payloadChunkQueue, chunk);
            self->bytesIn += VIDEORTP_ipcFrameChunkGetRemainingSize(chunk);
        }
    }
    return res;
}
