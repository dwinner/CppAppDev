#ifndef FRAME_PAYLOAD_CHUNK_H
#define FRAME_PAYLOAD_CHUNK_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup FramePayloadChunk
     * @{
     *
     * @brief Chunk of video data being part of a frame.
     *
     * The FramePayloadChunk class wraps a piece of memory that holds a part of a video frame.
     * It can be consumed by one or more calls to @ref VIDEORTP_ipcFrameChunkGetData "getData",
     * where FramePayloadChunk internally keeps track of the number of bytes already consumed.
     * The number of bytes left for consumption can be queried using
     * @ref VIDEORTP_ipcFrameChunkGetRemainingSize "getRemainingSize".
     *
     * FramePayloadChunk was designed to deal with memory that belongs to an external provider,
     * originally the Inter-Processor Communication subsystem. One core assumption is that the
     * memory stays valid until it is explicitly released. For this a callback function is used,
     * which is passed to the @ref VIDEORTP_ipcFrameChunkInit "init" method. It is triggered by
     * a call to @ref VIDEORTP_ipcFrameChunkReleaseBuffer "releaseBuffer".
     *
     * @warning Missing to call @ref VIDEORTP_ipcFrameChunkReleaseBuffer "releaseBuffer" will cause
     * resource leaks! Since a call to @ref VIDEORTP_ipcFrameChunkReleaseBuffer "releaseBuffer"
     * without having a callback specified is safe, it should generally be done when destroying a
     * FramePayloadChunk instance.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Release buffer callback function pointer
     *
     */
    typedef void (*VIDEORTP_releaseBufferCb_t)(void* buffer);

    /**
     * @brief Contains data about chunk of frame
     *
     */
    typedef struct VIDEORTP_ipcFramePayloadChunk_t
    {
        /** @privatesection @{ */
        /** Pointer to chunk start */
        uint8_t* basePointer;
        /** Pointer to read element */
        uint8_t* readPointer;
        /** Total chunk size */
        size_t totalSize;
        /** Pointer to release buffer callback */
        VIDEORTP_releaseBufferCb_t releaseBufferCb;
        /** Pointer to next chunk of frame */
        struct VIDEORTP_ipcFramePayloadChunk_t* next;
        /** @} */
    } VIDEORTP_ipcFramePayloadChunk_t;

    /**
     * @brief Queue of VIDEORTP_ipcPayloadChunkQueue_t instances
     *
     * @see VIDEORTP_ipcPayloadChunkQueue_t
     */
    typedef struct VIDEORTP_ipcPayloadChunkQueue_t
    {
        /** @privatesection @{ */
        /** First element of queue */
        VIDEORTP_ipcFramePayloadChunk_t* head;
        /** Last element of queue */
        VIDEORTP_ipcFramePayloadChunk_t* tail;
        /** @} */
    } VIDEORTP_ipcPayloadChunkQueue_t;

    /**
     * @brief Initialize VIDEORTP_ipcFramePayloadChunk_t
     * @public @memberof VIDEORTP_ipcFramePayloadChunk_t
     *
     * @param self VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
     * @param payloadBuffer Buffer with frame chunk
     * @param chunkSize Total chunk size
     * @param releaseBufferCallback Release buffer callback to IPC
     */
    void VIDEORTP_ipcFrameChunkInit(VIDEORTP_ipcFramePayloadChunk_t* self, const void* payloadBuffer, const size_t chunkSize,
                                    VIDEORTP_releaseBufferCb_t releaseBufferCallback);

    /**
     * @brief Return remaining size of frame chunk
     * @public @memberof VIDEORTP_ipcFramePayloadChunk_t
     *
     * @param self VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameChunkGetRemainingSize(VIDEORTP_ipcFramePayloadChunk_t* self);

    /**
     * @brief Copies data to a buffer and returns the size of the copied data
     * @public @memberof VIDEORTP_ipcFramePayloadChunk_t
     *
     * @param self VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
     * @param buffer Destination buffer
     * @param max Buffer available space
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameChunkGetData(VIDEORTP_ipcFramePayloadChunk_t* self, void* buffer, const size_t max);

    /**
     * @brief Calls callback with release source buffer with chunk
     * @public @memberof VIDEORTP_ipcFramePayloadChunk_t
     *
     * @param self VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
     */
    void VIDEORTP_ipcFrameChunkReleaseBuffer(VIDEORTP_ipcFramePayloadChunk_t* self);

    /**@} FramePayloadChunk global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* FRAME_PAYLOAD_CHUNK_H */
