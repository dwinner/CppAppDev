/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include <assert.h>
#include <string.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufInit
 *
 *   Function:   Init self. Set basePonter, capacity, writePosition
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               void* buffer: buffer where VIDEORTP_bufferWriter_t must write
 *               size_t capacity: buffer capacity
 *
 *   Outputs:
 *               bool Ret: return true if data copied successfull
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_bufInit(VIDEORTP_bufferWriter_t* self, void* buffer, const size_t capacity)
{
    assert(self);

    if (buffer != NULL)
    {
        self->basePointer = (uint8_t*) buffer;
        self->capacity = capacity;
        self->writePosition = 0;
    }
    else
    {
        self->basePointer = NULL;
        self->capacity = 0;
        self->writePosition = 0;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufWriteData
 *
 *   Function:   It shall copy bytes from data by length
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               void* data: must be copied data
 *               size_t length: length of must be copied data
 *
 *   Outputs:
 *               bool Ret: return true if data copied successfull
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_bufWriteData(VIDEORTP_bufferWriter_t* self, const void* data, const size_t length)
{
    assert(self);
    assert(data);
    uint8_t* dest = VIDEORTP_bufGetWritableChunk(self, length);
    uint8_t* src = (uint8_t*) data;
    bool res = dest != NULL;
    if (res)
    {
        memcpy(dest, src, length);
    }

    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufWriteInteger
 *
 *   Function:   It shall copy bytes from data by length as big endian
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               uint32_t data : must be copied data
 *               uint8_t typeSize : length of must be copied data
 *
 *   Outputs:
 *               bool Ret: return true if data copied successful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_bufWriteInteger(VIDEORTP_bufferWriter_t* self, const uint64_t data, const uint8_t typeSize)
{
    assert(self);

    uint8_t* dest = VIDEORTP_bufGetWritableChunk(self, typeSize);
    bool res = dest != NULL;
    if (res)
    {
        for (int32_t i = 0; i < typeSize; ++i)
        {
            dest[i] = (uint8_t) (data >> ((typeSize - 1 - i) * 8));
        }
    }

    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufWritePattern
 *
 *   Function:   It shall write pattern value to buffer according to the length
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               uint8_t pattern : recordable sample
 *               size_t length : length of must be filled by pattern
 *
 *   Outputs:
 *               bool Ret: return true if pattern success wrote
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_bufWritePattern(VIDEORTP_bufferWriter_t* self, const uint8_t pattern, const size_t length)
{
    assert(self);

    uint8_t* dest = VIDEORTP_bufGetWritableChunk(self, length);
    bool res = dest != NULL;
    if (res)
    {
        int temp = (int) pattern;
        memset(dest, temp, length);
    }

    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufSpawnChildWriter
 *
 *   Function:   It shall create child VIDEORTP_bufferWriter_t whom can write chunk buffer
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               size_t length: child buffer length from current writer position
 *
 *   Outputs:
 *               VIDEORTP_bufferWriter_t child:
 *                   if child create invalid child.basePointer == nullptr && childLength == 0
 *
 *   Side Effects: Set self.writePosition after child.basePointer
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_bufferWriter_t VIDEORTP_bufSpawnChildWriter(VIDEORTP_bufferWriter_t* self, const size_t length)
{
    assert(self);

    VIDEORTP_bufferWriter_t child;
    /* set writePosition after child */
    void* childBasePointer = VIDEORTP_bufGetWritableChunk(self, length);
    ;
    if (childBasePointer != NULL)
    {
        VIDEORTP_bufInit(&child, childBasePointer, length);
    }
    else
    {
        VIDEORTP_bufInit(&child, NULL, 0);
    }
    return child;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufGetBasePointer
 *
 *   Function:   It shall return buffer base pointer
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *
 *   Outputs:
 *               void* basePointer
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
void* VIDEORTP_bufGetBasePointer(const VIDEORTP_bufferWriter_t* self)
{
    assert(self);
    return self->basePointer;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufGetBytesWritten
 *
 *   Function:   It shall return current buffer write position
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *
 *   Outputs:
 *               size_t writePosition
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_bufGetBytesWritten(const VIDEORTP_bufferWriter_t* self)
{
    assert(self);

    return self->writePosition;
}

/* ===========================================================================
 *
 *   Name:       getAvailableSpace
 *
 *   Function:   It shall return buffer available space
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *
 *   Outputs:
 *               size_t res
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_bufGetAvailableSpace(const VIDEORTP_bufferWriter_t* self)
{
    assert(self);

    size_t res = 0;
    if (self->capacity > (size_t) 0)
    {
        res = self->capacity - self->writePosition;
    }
    return res;
}

/* ===========================================================================
 *
 *   Name:       clear
 *
 *   Function:   It shall set writePosition to 0
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_bufClear(VIDEORTP_bufferWriter_t* self)
{
    assert(self);

    self->writePosition = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_bufGetWritableChunk
 *
 *   Function:   Check if the requested amount of memory is available
 *               and return a pointer to that.
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* self: VIDEORTP_bufferWriter_t instance that the function works on
 *               size_t length: length of writable chunk
 *
 *   Outputs:
 *        Pointer to a buffer of the requested size. All bytes must be written
 *        by the caller. Returns NULL if not enough space is available.
 *
 *   Side Effects:
 *        Advance write position to next byte after the returned chunk
 *
 *   Traceability to SDD: MAGAVSTR-13, MAGAVSTR-583
 *
 *   Traceability to SW Req: 16813256
 *
 *   Remarks:
 *        The caller must write all bytes of the returned chunk of memory.
 *        Requesting 0 bytes is always allowed, although nothing may be written.
 *
 * ========================================================================= */
uint8_t* VIDEORTP_bufGetWritableChunk(VIDEORTP_bufferWriter_t* self, const size_t length)
{
    assert(self);

    uint8_t* oldPointer = NULL;
    if (self->capacity > (size_t) 0 && length <= VIDEORTP_bufGetAvailableSpace(self))
    {
        oldPointer = self->basePointer + self->writePosition;
        self->writePosition += length;
    }
    return oldPointer;
}
