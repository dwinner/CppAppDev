#ifndef PAYLOAD_UNIT_SEQUENCE_REPEATER_H
#define PAYLOAD_UNIT_SEQUENCE_REPEATER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include "PayloadProvider.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup PayloadUnitSequenceRepeater
     * @{
     * @brief Indefinitely repeats a sequence of pre-generated payload units (e.g., a short video).
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Defines a payload unit, e.g., a single video frame.
     */
    typedef struct VIDEORTP_payloadUnit_t
    {
        const void* buffer;
        size_t length;
    } VIDEORTP_payloadUnit_t;

    /**
     * @brief Repeats a sequence of pre-generated payload units.
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct VIDEORTP_payloadUnitSequenceRepeater_t
    {
        /** @privatesection @{ */
        /**
         * @brief Implementation of PayloadProvider interface.
         *
         */
        VIDEORTP_payloadProvider_t vtable;

        /**
         * @brief Read position within the current payload unit.
         *
         */
        size_t readPosition;

        /**
         * @brief Size of next chunk that will be copied
         *
         */
        size_t nextChunkSize;

        /**
         * @brief Input array with payload and size.
         *
         */
        const VIDEORTP_payloadUnit_t* payloadUnitArray;

        /**
         * @brief Size array with payload unit.
         *
         */
        size_t payloadUnitArraySize;

        /**
         * @brief Current payload unit (array index).
         *
         */
        size_t payloadUnitArrayPosition;
        /** @} */
    } VIDEORTP_payloadUnitSequenceRepeater_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_PayloadUnitSequenceRepeater_t
     * @public @memberof VIDEORTP_payloadUnitSequenceRepeater_t
     *
     * @note The provided array must remain valid throughout the lifetime of the payload unit sequence repeater.
     *
     * @param self Instance to initialize
     * @param unitArray Array of payload units to read from
     * @param arraySize Count of payload units in array
     */
    void VIDEORTP_seqInit(VIDEORTP_payloadUnitSequenceRepeater_t* self, const VIDEORTP_payloadUnit_t* unitArray,
                          const size_t arraySize);

    /**@} PayloadUnitSequenceRepeater global */

#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* PAYLOAD_UNIT_SEQUNCE_REPEATER_H */
