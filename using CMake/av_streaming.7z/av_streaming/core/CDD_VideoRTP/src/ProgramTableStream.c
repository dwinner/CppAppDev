/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "ProgramTableStream.h"
#include "ProgramAssociationTableBuilder.h"
#include "ProgramMapTableBuilder.h"
#include "VideoRtpUtil.h"

#define VIDEORTP_ELEMENTARY_STREAM_PID 0x1B
#define VIDEORTP_PROGRAM_ASSOCIATION_TABLE_PID 0

/* ===========================================================================
 *
 *   Name:       VIDEORTP_prepareProgramTableStream
 *
 *   Function:   Perform common initialization of program tables
 *
 *   Inputs:
 *               VIDEORTP_mpegProgramTableStream_t* stream: VIDEORTP_mpegProgramTableStream_t instance that the function works on
 *               uint16_t pid: MPEG-TS PID of the stream containing this program table
 *               uint32_t interval: Interval between two copies of this program table in the MPEG transport stream
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_mpegProgramTableStream_t */
static void VIDEORTP_prepareProgramTableStream(VIDEORTP_mpegProgramTableStream_t* stream, uint16_t pid, uint32_t interval)
{
    VIDEORTP_bufInit(&stream->writer, stream->buffer, sizeof(stream->buffer));

    VIDEORTP_repInit(&stream->repeater, &stream->writer);
    VIDEORTP_sectInit(&stream->sectionPacketizer, &stream->repeater.vtable);
    VIDEORTP_tsInitPacketizer(&stream->tsPacketizer, &stream->sectionPacketizer.vtable, pid);
    VIDEORTP_gateInit(&stream->gate, &stream->tsPacketizer.vtable);

    /* Send tables etc. immediately */
    stream->interval = interval;
    stream->timer = interval;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initProgramMapTableStream
 *
 *   Function:   Prepares a stream containing a program map table
 *
 *   Inputs:
 *               VIDEORTP_mpegProgramTableStream_t* stream: VIDEORTP_mpegProgramTableStream_t instance that the function works on
 *               const VIDEORTP_mpegProgramTableStreamConfig_t* config: Program table configuration and parameters
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initProgramMapTableStream(VIDEORTP_mpegProgramTableStream_t* stream,
                                                               const VIDEORTP_mpegProgramTableStreamConfig_t* config)
{
    VIDEORTP_prepareProgramTableStream(stream, config->pmtPid, config->interval);

    VIDEORTP_programMapTableBuilder_t tableBuilder;
    VIDEORTP_pmtInit(&tableBuilder, config->program, config->videoPid, &stream->writer);
    VIDEORTP_pmtAddElementaryStreamPid(&tableBuilder, config->videoPid, VIDEORTP_ELEMENTARY_STREAM_PID);
    VIDEORTP_pmtFinalize(&tableBuilder);

    return &stream->gate.base;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initProgramAssociationTableStream
 *
 *   Function:   Prepares a stream containing a program association table
 *
 *   Inputs:
 *               VIDEORTP_mpegProgramTableStream_t* stream: VIDEORTP_mpegProgramTableStream_t instance that the function works on
 *               const VIDEORTP_mpegProgramTableStreamConfig_t* config: Program table configuration and parameters
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initProgramAssociationTableStream(VIDEORTP_mpegProgramTableStream_t* stream,
                                                                       const VIDEORTP_mpegProgramTableStreamConfig_t* config)
{
    VIDEORTP_prepareProgramTableStream(stream, VIDEORTP_PROGRAM_ASSOCIATION_TABLE_PID, config->interval);

    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    VIDEORTP_patInit(&tableBuilder, config->streamId, &stream->writer);
    VIDEORTP_patAddProgram(&tableBuilder, config->program, config->pmtPid);
    VIDEORTP_patFinalize(&tableBuilder);

    return &stream->gate.base;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicProgramTableStream
 *
 *   Function:   Cyclically checks if the program table is to be transmitted again
 *
 *   Inputs:
 *               VIDEORTP_mpegProgramTableStream_t* stream: VIDEORTP_mpegProgramTableStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicProgramTableStream(VIDEORTP_mpegProgramTableStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Send MPEG program tables */
    if (VIDEORTP_timerTick(&stream->timer, timeSinceLastCall, stream->interval))
    {
        VIDEORTP_gateEnable(&stream->gate);
    }
}
