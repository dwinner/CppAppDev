#ifndef SINGLY_LINKED_LIST_H_INCLUDED
#define SINGLY_LINKED_LIST_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/**
 * @defgroup SinglyLinkedList
 * @{
 * @brief Helper macros to manage an intrusive singly linked list (FIFO).
 *
 * The list requires two data structures. These structures need some pointers as described below. They may (and usually do) contain
 * additional fields which are not related to the list, i.e., the actual user data.
 *
 * @note This list is implemented using macros so the implementation does not rely on any specific data type (which would certainly
 * require a lot of type casting otherwise) and can be easily reused with different user-provided data structures.
 *
 * The first data structure is for list elements:
 *
 * @code {.c}
 * struct MyData
 * {
 *     ...
 *     struct MyData* next;
 *     ...
 * };
 * @endcode
 *
 * This structure contains a @c next pointer to the next list element. It will be overwritten when the list element is inserted into
 * or removed from a list. That pointer should have the same type as the data structure itself, so this is a recursive structure.
 * This pointer must not be modified by the user if that element was added to a list.
 *
 * List elements can be contained in only one list at a time because there is only one @c next pointer. Nevertheless, list elements
 * may be moved between lists. These elements must be removed from their old list before they may be inserted into a new list.
 *
 * Altough not required, a user might want to initialize @c next to NULL as a reminder that an element is not part of any list.
 *
 * @invariant The @c next pointer points to the element inserted after this element.
 * @invariant The @c next pointer of the last element is @c NULL.
 *
 * The second data structure is for the list container itself:
 *
 * @code {.c}
 * struct MyList
 * {
 *     ...
 *     struct MyData* head;
 *     struct MyData* tail;
 *     ...
 * };
 * @endcode
 *
 * This structure has a @c head pointer which points to the first element in a list. This element will be returned/removed first.
 * The @c tail pointer points to the last element in a list. New elements will be appended after this element.
 *
 * @invariant If a list is empty, @c head and @c tail are @c NULL.
 * @invariant If a list contains only one element, @c head and @c tail both point to that element.
 * @invariant If a list contains two or more elements, @c head points to the first element and @c tail points to the last element.
 */

/**
 * @brief Creates an empty singly linked list.
 * @param list Pointer to a list structure with @c head and @c tail pointers. Must not be @c NULL or have side effects.
 */
#define VIDEORTP_slistInit(list)                                                                                                   \
    do                                                                                                                             \
    {                                                                                                                              \
        (list)->head = NULL;                                                                                                       \
        (list)->tail = NULL;                                                                                                       \
    } while (0)

/**
 * @brief Check if a list is empty
 * @param list Pointer to a list structure with @c head and @c tail pointers. Must not be @c NULL or have side effects.
 * @return whether the list is empty
 */
#define VIDEORTP_slistIsEmpty(list) ((list)->head == NULL)

/**
 * @brief Append an item to the end of a list.
 * @param list Pointer to a list structure with @c head and @c tail pointers. Must not be @c NULL or have side effects.
 * @param element Pointer to an element which will be added to the list. Must not be @c NULL or have side effects. Its @c next
 * pointer will be overwritten. The original value of @c next will be ignored.
 */
#define VIDEORTP_slistPushBack(list, element)                                                                                      \
    do                                                                                                                             \
    {                                                                                                                              \
        assert((element) != NULL);                                                                                                 \
        if ((list)->tail == NULL)                                                                                                  \
        {                                                                                                                          \
            /* only one element */                                                                                                 \
            (list)->head = (element);                                                                                              \
            (list)->tail = (element);                                                                                              \
        }                                                                                                                          \
        else                                                                                                                       \
        {                                                                                                                          \
            /* append to end */                                                                                                    \
            (list)->tail->next = (element);                                                                                        \
            (list)->tail = (element);                                                                                              \
        }                                                                                                                          \
        (element)->next = NULL;                                                                                                    \
    } while (0)

/**
 * @brief Return the first element of a list. The element remains in the list.
 * @param list Pointer to a list structure with @c head and @c tail pointers. Must not be @c NULL or have side effects.
 * @param element Pointer to a variable which will receive a pointer to the first list element. The variable will be set to @c NULL
 * instead if the list is empty.
 */
#define VIDEORTP_slistPeekFront(list, element)                                                                                     \
    do                                                                                                                             \
    {                                                                                                                              \
        (*(element)) = (list)->head;                                                                                               \
    } while (0)

/**
 * @brief Remove and return the first element of a list.
 * @param list Pointer to a list structure with @c head and @c tail pointers. Must not be @c NULL or have side effects.
 * @param element Pointer to a variable which will receive a pointer to the removed list element. The variable will be set to @c
 * NULL instead if the list is empty.
 * @note The @c next pointer of the returned list element will be reset to @c NULL, but users should not rely on this behavior.
 */
#define VIDEORTP_slistPopFront(list, element)                                                                                      \
    do                                                                                                                             \
    {                                                                                                                              \
        (*(element)) = (list)->head;                                                                                               \
        if ((*(element)) == (list)->tail)                                                                                          \
        {                                                                                                                          \
            /* no or only one element */                                                                                           \
            (list)->head = NULL;                                                                                                   \
            (list)->tail = NULL;                                                                                                   \
        }                                                                                                                          \
        else                                                                                                                       \
        {                                                                                                                          \
            /* remove from beginning */                                                                                            \
            (list)->head = (*(element))->next;                                                                                     \
        }                                                                                                                          \
        if ((*(element)) != NULL)                                                                                                  \
        {                                                                                                                          \
            (*(element))->next = NULL;                                                                                             \
        }                                                                                                                          \
    } while (0)

/** @} */

#endif
