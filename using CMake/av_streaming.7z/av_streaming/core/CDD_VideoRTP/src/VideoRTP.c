/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoRTP.h"
#include "AutosarPacketSink.h"
#include "VideoRtpUtil.h"
#include "VideoStream.h"

#ifdef VIDEORTP_RELEASE_BUFFER_HEADER
#include VIDEORTP_RELEASE_BUFFER_HEADER
#endif

#ifdef VIDEORTP_ENABLE_TEST_VIDEO
#include "test_noloop.h264_bin.h"
#endif

/**
 * @brief Wrapper for RTP socket connection
 */
static VIDEORTP_asrPacketSink_t VIDEORTP_rtpSocket;

/**
 * @brief Wrapper for RTCP socket connection
 */
static VIDEORTP_asrPacketSink_t VIDEORTP_rtcpSocket;

/**
 * @brief State for creating an RTP video stream (including input buffers).
 */
static VIDEORTP_videoStream_t VIDEORTP_videoStream;

/**
 * @brief State for initializing module
 */
static bool VIDEORTP_isInitialized = false;

/* ===========================================================================
 *
 *   Name:       VIDEORTP_init
 *
 *   Function:   Initialize the VideoRTP module and prepare for streaming.
 *
 *   Inputs:
 *               const VIDEORTP_initConfiguration* config: Stream parameters and configuration
 *
 *   Outputs:
 *               VideoRTP_errorCode
 *
 *   Side Effects:
 *               Initialize RTP stream data structures.
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-843, MAGAVSTR-810
 *
 *   Traceability to SW Req: 16813230, 16813252, 16805562, 16805566, 16805645, 16805727, 16805813, 16805822, 16805835, 16806035,
 * 16813185, 16813198, 16813201, 16813203, 16813207, 16813210
 *
 *   Remarks: After the VideoRTP module has been initialized,
 *            call VIDEORTP_cyclic to send UDP/RTP packets.
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_init(const VIDEORTP_initConfiguration* config)
{
    VideoRTP_errorCode err = config != NULL ? VideoRTP_ok : VideoRTP_invalidParameter;
    if (err == VideoRTP_ok)
    {
        err = VIDEORTP_isInitialized ? VideoRTP_invalidCall : VideoRTP_ok;
    }

    /* Detect invalid configuration settings now rather than crashing later */
    if (err == VideoRTP_ok)
    {
        /* Timer intervals cannot be zero */
        if ((config->mainFunctionPeriod == 0) || (config->avMasterConfiguration.patInterval == 0))
        {
            err = VideoRTP_invalidParameter;
        }
        /* Data rate and frame rate cannot be zero because the stream would be "empty" */
        if ((config->targetDataRate == 0) || (config->targetFrameRate == 0))
        {
            err = VideoRTP_invalidParameter;
        }
    }

    if (err == VideoRTP_ok)
    {
        VIDEORTP_videoStreamConfig_t videoConfig = { 0 };

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        videoConfig.isStaticInputEnabled = config->isTestVideoEnabled;

        videoConfig.staticInputConfig.fps = config->targetFrameRate;
        videoConfig.staticInputConfig.tsPid = config->avMasterConfiguration.videoPid;
        videoConfig.staticInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
        videoConfig.staticInputConfig.payloadUnits = NULL;
        videoConfig.staticInputConfig.payloadUnitCount = 0;

#ifdef VIDEORTP_ENABLE_TEST_VIDEO
        videoConfig.staticInputConfig.payloadUnits = VIDEORTP_payloadUnits;
        videoConfig.staticInputConfig.payloadUnitCount = VIDEORTP_PAYLOAD_UNIT_COUNT;
#endif
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

        videoConfig.ipcInputConfig.tsPid = config->avMasterConfiguration.videoPid;
        videoConfig.ipcInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
        videoConfig.ipcInputConfig.timeBaseId = config->timeBaseId;

        videoConfig.tableConfig.interval = config->avMasterConfiguration.patInterval;
        videoConfig.tableConfig.program = config->avMasterConfiguration.programId;
        videoConfig.tableConfig.pmtPid = config->avMasterConfiguration.pmtPid;
        videoConfig.tableConfig.videoPid = config->avMasterConfiguration.videoPid;
        videoConfig.tableConfig.streamId = config->avMasterConfiguration.streamId;

        VIDEORTP_rtcpInitConfig(&videoConfig.rtpConfig, VIDEORTP_STREAMING_MODE);
        memcpy(videoConfig.rtpConfig.ssrc, config->sessionConfiguration.ssrc, VIDEORTP_RTCP_SSRC_SIZE);
        memcpy(videoConfig.rtpConfig.rtcpName, config->sessionConfiguration.name, VIDEORTP_RTCP_NAME_SIZE);
        memcpy(videoConfig.rtpConfig.gmIdentity, config->sessionConfiguration.gmIdentity, VIDEORTP_RTCP_GM_IDENTITY_SIZE);
        memcpy(videoConfig.rtpConfig.streamId, config->sessionConfiguration.streamId, VIDEORTP_RTCP_STREAM_ID_SIZE);
        videoConfig.rtpConfig.initialSequenceCounter = config->sessionConfiguration.initialSequenceCounter;
        videoConfig.rtpConfig.initialTimestamp = config->sessionConfiguration.initialTimestamp;
        videoConfig.rtpConfig.deliveryCompensationOffset = config->avMasterConfiguration.deliveryCompensationOffset;

        videoConfig.cyclicInterval = config->mainFunctionPeriod;
        videoConfig.targetDataRate = config->targetDataRate;
        videoConfig.targetFrameRate = config->targetFrameRate;

        VIDEORTP_asrInitPacketSink(&VIDEORTP_rtpSocket, config->rtpPdu);
        VIDEORTP_asrInitPacketSink(&VIDEORTP_rtcpSocket, config->rtcpPdu);

        VIDEORTP_initVideoStream(&VIDEORTP_videoStream, &VIDEORTP_rtpSocket.vtable, &VIDEORTP_rtcpSocket.vtable, &videoConfig);

        VIDEORTP_isInitialized = true;
    }
    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_deinit
 *
 *   Function:   Deinitialize the VideoRTP module.
 *
 *   Inputs:
 *
 *   Outputs:
 *               VideoRTP_errorCode
 *
 *   Side Effects:
 *               Destroy RTP stream data structures.
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16813230, 16813252, 16805813, 16813203, 16813207
 *
 *   Remarks: Call VIDEORTP_init again to re-initialize the module.
 *            No other VideoRTP function may be called until then.
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_deinit(void)
{
    VideoRTP_errorCode err = VIDEORTP_isInitialized ? VideoRTP_ok : VideoRTP_invalidCall;

    if (err == VideoRTP_ok)
    {
        VIDEORTP_deinitVideoStream(&VIDEORTP_videoStream);
        VIDEORTP_asrDeinitPacketSink(&VIDEORTP_rtcpSocket);
        VIDEORTP_asrDeinitPacketSink(&VIDEORTP_rtpSocket);

        VIDEORTP_isInitialized = false;
    }
    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclic
 *
 *   Function:   Cyclic processing.
 *
 *   Inputs:
 *
 *   Outputs:
 *               VideoRTP_errorCode
 *
 *   Side Effects:
 *               Sends pending RTP packets via network connection.
 *               Previously added buffers (with VIDEORTP_startFrame or VIDEORTP_appendFrame) may be released.
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16813230, 16813252, 16805727, 16813203, 16813207, 16813212
 *
 *   Remarks: Perform cyclic operations, such as sending UDP/RTP packets which have accumulated so far.
 *            This function may be called only if VIDEORTP_init has completed.
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_cyclic(void)
{
    VideoRTP_errorCode err = VIDEORTP_isInitialized ? VideoRTP_ok : VideoRTP_invalidCall;
    if (err == VideoRTP_ok)
    {
        err = VIDEORTP_cyclicVideoStream(&VIDEORTP_videoStream);
    }
    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_startFrame
 *
 *   Function:   Initialize the VideoRTP module and prepare for streaming.
 *
 *   Inputs:
 *               size_t frameSize: Total size of the frame. The sum of the size of all payload chunks.
 *               const VIDEORTP_timestampInformation* frameTime: Sampling timestamp of this frame.
 *               void* bufferPayload: Optional pointer to the first chunk of the new frame. May be NULL.
 *               size_t bufferSize: If bufferPayload is not NULL, this specifies the size of the first chunk.
 *
 *   Outputs:
 *            VideoRTP_errorCode:
 *            - VideoRTP_ok if a new frame was allocated. If specified, the bufferPayload will be stored.
 *              It will be released later by calling @todo VIDEORTP_RELEASE_BUFFER_FUNCTION.
 *            - VideoRTP_queueFull if an error occurred. The bufferPayload will *not* be stored. It will *not* be released by this
 *              module.
 *            - VideoRTP_invalidCall if module not initialized
 *
 *   Side Effects:
 *            The previous video frame (if any) will be marked as complete; appending more data is no longer possible.
 *            VIDEORTP_appendFrame will append data to the new video frame.
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16813230, 16813252, 16802573, 16802575, 16802577, 16802579, 16805555,
 * 16805560, 16805562, 16805566, 16805702, 16805822, 16805894, 16813203, 16813215, 16813222, 16813226, 16813220, 16813236, 16813246,
 * 16813248, 16813250, 16813252, 16813254
 *
 *   Remarks:
 *            The caller must ensure that the total size of all payload buffers
 *            (whether added with VIDEORTP_startFrame or VIDEORTP_appendFrame)
 *            exactly equals the specified frame size.
 *            Providing too much or too little data may corrupt the RTP stream!
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_startFrame(size_t frameSize, const VIDEORTP_timestampInformation* frameTime, void* bufferPayload,
                                       size_t bufferSize)
{
    VideoRTP_errorCode err = VIDEORTP_isInitialized ? VideoRTP_ok : VideoRTP_invalidCall;
    if (err == VideoRTP_ok)
    {
        VIDEORTP_timestamp timestamp = { 0 };
        timestamp.mpegPresentationTimestamp = VIDEORTP_convertTimestamp(&frameTime->mpegPresentationTimestamp);
        timestamp.mpegDecodingTimestamp = VIDEORTP_convertTimestamp(&frameTime->mpegDecodingTimestamp);
        timestamp.gptpTimestamp = frameTime->gptpTimestamp;
        timestamp.gptpTimeBaseIndicator = frameTime->gptpTimeBaseIndicator;

        bool res = VIDEORTP_startFrameVideoStream(&VIDEORTP_videoStream, frameSize, &timestamp);
        if (res)
        {
            res = VIDEORTP_appendFrameVideoStream(&VIDEORTP_videoStream, bufferPayload, bufferSize,
                                                  VIDEORTP_RELEASE_BUFFER_FUNCTION);
        }
        err = res ? VideoRTP_ok : VideoRTP_queueFull;
    }
    return err;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_appendFrame
 *
 *   Function:   Add more data to the current video frame.
 *
 *   Inputs:
 *               void* bufferPayload: Mandatory pointer to the first chunk of the new frame. May not be NULL.
 *               size_t bufferSize: Specifies the size of the first chunk.
 *
 *   Outputs: VideoRTP_ok if the buffer was appended to the current frame. The bufferPayload will be released later.
 *            VideoRTP_errorCode if an error occurred. The bufferPayload will *not* be released.
 *
 *   Side Effects:
 *            The previous video frame (if any) will be marked as complete; appending more data is no longer possible.
 *            VIDEORTP_appendFrame will append data to the new video frame.
 *
 *   Traceability to SDD: MAGAVSTR-662, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16813230, 16813252, 16802575, 16802577, 16813203, 16813215, 16813226,
 * 16813220, 16813236, 16813246, 16813248, 16813250, 16813252, 16813254
 *
 *   Remarks:
 *           This function may be called only after a successfull call to VIDEORTP_startFrame.
 *
 * ========================================================================= */
VideoRTP_errorCode VIDEORTP_appendFrame(void* bufferPayload, size_t bufferSize)
{
    VideoRTP_errorCode err = VIDEORTP_isInitialized ? VideoRTP_ok : VideoRTP_invalidCall;
    if (err == VideoRTP_ok)
    {
        bool res
            = VIDEORTP_appendFrameVideoStream(&VIDEORTP_videoStream, bufferPayload, bufferSize, VIDEORTP_RELEASE_BUFFER_FUNCTION);
        err = res ? VideoRTP_ok : VideoRTP_queueFull;
    }
    return err;
}
