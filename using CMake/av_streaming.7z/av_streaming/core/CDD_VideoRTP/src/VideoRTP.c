/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoRTP.h"
#include "AutosarPacketSink.h"
#include "VideoStream.h"

#ifdef VIDEORTP_RELEASE_BUFFER_HEADER
#include VIDEORTP_RELEASE_BUFFER_HEADER
#endif

#ifdef VIDEORTP_ENABLE_TEST_VIDEO
#include "test_noloop.h264_bin.h"
#endif

/**
 * @brief Wrapper for RTP socket connection
 */
static VIDEORTP_asrPacketSink_t VIDEORTP_rtpSocket;

/**
 * @brief Wrapper for RTCP socket connection
 */
static VIDEORTP_asrPacketSink_t VIDEORTP_rtcpSocket;

/**
 * @brief State for creating an RTP video stream (including input buffers).
 */
static VIDEORTP_videoStream_t VIDEORTP_videoStream;

/* ===========================================================================
 *
 *   Name:       VIDEORTP_init
 *
 *   Function:   Initialize the VideoRTP module and prepare for streaming.
 *
 *   Inputs:
 *               const VIDEORTP_initConfiguration* config: Stream parameters and configuration
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Initialize RTP stream data structures.
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks: After the VideoRTP module has been initialized,
 *            call VIDEORTP_cyclic to send UDP/RTP packets.
 *
 * ========================================================================= */
void VIDEORTP_init(const VIDEORTP_initConfiguration* config)
{
    VIDEORTP_videoStreamConfig_t videoConfig = { 0 };

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    videoConfig.isStaticInputEnabled = config->avMasterConfiguration.isTestVideoEnabled;
    videoConfig.staticInputConfig.fps = VIDEORTP_TEST_VIDEO_FRAME_RATE;
    videoConfig.staticInputConfig.tsPid = config->avMasterConfiguration.streamID;
    videoConfig.staticInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
    videoConfig.staticInputConfig.pcrDelay = config->avMasterConfiguration.deliveryCompensationOffset;
    videoConfig.staticInputConfig.payloadUnits = NULL;
    videoConfig.staticInputConfig.payloadUnitCount = 0;
#ifdef VIDEORTP_ENABLE_TEST_VIDEO
    videoConfig.staticInputConfig.payloadUnits = VIDEORTP_payloadUnits;
    videoConfig.staticInputConfig.payloadUnitCount = VIDEORTP_PAYLOAD_UNIT_COUNT;
#endif
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    videoConfig.ipcInputConfig.tsPid = config->avMasterConfiguration.streamID;
    videoConfig.ipcInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
    videoConfig.ipcInputConfig.pcrDelay = config->avMasterConfiguration.deliveryCompensationOffset;

    videoConfig.tableConfig.interval = 250;
    videoConfig.tableConfig.program = config->avMasterConfiguration.programID;
    videoConfig.tableConfig.pmtPid = 0x1000;
    videoConfig.tableConfig.videoPid = config->avMasterConfiguration.streamID;
    videoConfig.tableConfig.streamId = 1;

    VIDEORTP_rtcpInitConfig(&videoConfig.rtpConfig, VIDEORTP_STREAMING_MODE);
    videoConfig.rtpConfig.ssrc[0] = 1;
    videoConfig.rtpConfig.ssrc[1] = 2;
    videoConfig.rtpConfig.ssrc[2] = 3;
    videoConfig.rtpConfig.ssrc[3] = 4;

    VIDEORTP_asrInitPacketSink(&VIDEORTP_rtpSocket, config->rtpPdu);
    VIDEORTP_asrInitPacketSink(&VIDEORTP_rtcpSocket, config->rtcpPdu);

    VIDEORTP_initVideoStream(&VIDEORTP_videoStream, &VIDEORTP_rtpSocket.vtable, &VIDEORTP_rtcpSocket.vtable, &videoConfig);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_deinit
 *
 *   Function:   Deinitialize the VideoRTP module.
 *
 *   Inputs:
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Destroy RTP stream data structures.
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks: Call VIDEORTP_init again to re-initialize the module.
 *            No other VideoRTP function may be called until then.
 *
 * ========================================================================= */
void VIDEORTP_deinit(void)
{
    VIDEORTP_deinitVideoStream(&VIDEORTP_videoStream);
    VIDEORTP_asrDeinitPacketSink(&VIDEORTP_rtcpSocket);
    VIDEORTP_asrDeinitPacketSink(&VIDEORTP_rtpSocket);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclic
 *
 *   Function:   Cyclic processing.
 *
 *   Inputs:
 *
 *   Outputs:
 *
 *   Side Effects:
 *               Sends pending RTP packets via network connection.
 *               Previously added buffers (with VIDEORTP_startFrame or VIDEORTP_appendFrame) may be released.
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks: Perform cyclic operations, such as sending UDP/RTP packets which have accumulated so far.
 *            This function may be called only if VIDEORTP_init has completed.
 *
 * ========================================================================= */
void VIDEORTP_cyclic(void)
{
    VIDEORTP_cyclicVideoStream(&VIDEORTP_videoStream, VIDEORTP_CYCLIC_INTERVAL);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_startFrame
 *
 *   Function:   Initialize the VideoRTP module and prepare for streaming.
 *
 *   Inputs:
 *               size_t frameSize: Total size of the frame. The sum of the size of all payload chunks.
 *               uint64_t samplingTime: Sampling timestamp of this frame.
 *               void* bufferPayload: Optional pointer to the first chunk of the new frame. May be NULL.
 *               size_t bufferSize: If bufferPayload is not NULL, this specifies the size of the first chunk.
 *               const VIDEORTP_timestampInformation* frameTime: Sampling timestamp of this frame.
 *
 *   Outputs: true if a new frame was allocated. If specified, the bufferPayload will be stored.
 *            It will be released later by calling @todo VIDEORTP_RELEASE_BUFFER_FUNCTION.
 *            false if an error occurred. The bufferPayload will *not* be stored. It will *not* be released by this module.
 *
 *   Side Effects:
 *            The previous video frame (if any) will be marked as complete; appending more data is no longer possible.
 *            VIDEORTP_appendFrame will append data to the new video frame.
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *            The caller must ensure that the total size of all payload buffers
 *            (whether added with VIDEORTP_startFrame or VIDEORTP_appendFrame)
 *            exactly equals the specified frame size.
 *            Providing too much or too little data may corrupt the RTP stream!
 *
 * ========================================================================= */
bool VIDEORTP_startFrame(size_t frameSize, uint64_t samplingTime, void* bufferPayload, size_t bufferSize,
                         const VIDEORTP_timestampInformation* frameTime)
{
    bool res = VIDEORTP_startFrameVideoStream(&VIDEORTP_videoStream, frameSize, samplingTime);
    if (res)
    {
        res = VIDEORTP_appendFrameVideoStream(&VIDEORTP_videoStream, bufferPayload, bufferSize, VIDEORTP_RELEASE_BUFFER_FUNCTION);
    }
    return res;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_appendFrame
 *
 *   Function:   Add more data to the current video frame.
 *
 *   Inputs:
 *               void* bufferPayload: Mandatory pointer to the first chunk of the new frame. May not be NULL.
 *               size_t bufferSize: Specifies the size of the first chunk.
 *
 *   Outputs: true if the buffer was appended to the current frame. The bufferPayload will be released later.
 *            false if an error occurred. The bufferPayload will *not* be released.
 *
 *   Side Effects:
 *            The previous video frame (if any) will be marked as complete; appending more data is no longer possible.
 *            VIDEORTP_appendFrame will append data to the new video frame.
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *           This function may be called only after a successfull call to VIDEORTP_startFrame.
 *
 * ========================================================================= */
bool VIDEORTP_appendFrame(void* bufferPayload, size_t bufferSize)
{
    return VIDEORTP_appendFrameVideoStream(&VIDEORTP_videoStream, bufferPayload, bufferSize, VIDEORTP_RELEASE_BUFFER_FUNCTION);
}
