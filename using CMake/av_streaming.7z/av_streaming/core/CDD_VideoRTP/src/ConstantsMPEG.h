#ifndef CONSTANTS_MPEG_H
#define CONSTANTS_MPEG_H

#include <stdint.h>

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */

/** ElementaryStreamPacketizer & PaddingElementaryStreamGenerator */

/** PES header size with DTS */
#define VIDEORTP_PES_HEADER_SIZE_WITH_DTS 19
/** PES header size without DTS */
#define VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS 14

/** Program stream type */
#define VIDEORTP_PES_PROGRAM_STREAM_MAP 0xbc
/** Private stream 1 type */
#define VIDEORTP_PES_PRIVATE_STREAM_1 0xbd
/** Padding stream type */
#define VIDEORTP_PES_PADDING_STREAM 0xbe
/** Private stream 2 type */
#define VIDEORTP_PES_PRIVATE_STREAM_2 0xbf
/** Audio stream type */
#define VIDEORTP_PES_AUDIO_STREAM_0 0xc0
/** Video stream type */
#define VIDEORTP_PES_VIDEO_STREAM_0 0xe0
/** ECM stream type */
#define VIDEORTP_PES_ECM_STREAM 0xf0
/** EMM stream type */
#define VIDEORTP_PES_EMM_STREAM 0xf1
/** DSMCC stream type */
#define VIDEORTP_PES_DSMCC_STREAM 0xf2
/** E stream type */
#define VIDEORTP_PES_TYPE_E_STREAM 0xf8
/** Metadata stream type */
#define VIDEORTP_PES_METADATA_STREAM 0xfc
/** Extendend stream ID type */
#define VIDEORTP_PES_EXTENDED_STREAM_ID 0xfd
/** Program stream directory */
#define VIDEORTP_PES_PROGRAM_STREAM_DIRECTORY 0xff

/* Header without PTS and DTS */
#define VIDEORTP_PES_FLAGS 0x80

#define VIDEORTP_PES_FLAGS_WITHOUT_DTS 0x80

#define VIDEORTP_PES_FLAGS_WITH_DTS 0xC0

#define VIDEORTP_PES_TIME_SIZE 5

/* Timestamp constants  */
/** Timestamp tag, presentation timestamp followed by a decoding time stamp */
#define VIDEORTP_TS_TIMESTAMP_TAG_PTSDTS 0x30
/** Timestamp tag presentation time stamp */
#define VIDEORTP_TS_TIMESTAMP_TAG_PTS 0x20
/** Timestamp tag decoding time stamp */
#define VIDEORTP_TS_TIMESTAMP_TAG_DTS 0x10

/**
 * @brief PES packet prefix
 *
 */
#define VIDEORTP_PES_START_CODE_PREFIX 0x000001

/**
 * @brief Size of PES packet prefix
 *
 */
#define VIDEORTP_PES_START_CODE_PREFIX_SIZE 3

/**
 * @brief Size of stream id
 *
 */
#define VIDEORTP_PES_STREAM_ID_SIZE 1

/**
 * @brief Size of PES packet length field
 *
 */
#define VIDEORTP_PES_LENGTH_SIZE 2

/**
 * @brief Size of PES packet header
 *
 */
#define VIDEORTP_PES_HEADER_SIZE (VIDEORTP_PES_START_CODE_PREFIX_SIZE + VIDEORTP_PES_STREAM_ID_SIZE + VIDEORTP_PES_LENGTH_SIZE)

/**
 * @brief Minimal size of PES packet  (It needs at least 1 byte of padding because PES_packet_length can not be 0)
 *
 */
#define VIDEORTP_PES_MIN_SIZE (VIDEORTP_PES_HEADER_SIZE + 1)

/**
 * @brief Constants for shift and logical multiplication operations
 *
 */
#define VIDEORTP_PES_TIMESTAMP_BIT_MASK_0 UINT64_C(0x0e)

#define VIDEORTP_PES_TIMESTAMP_BIT_MASK_1 UINT64_C(0xff)

#define VIDEORTP_PES_TIMESTAMP_BIT_MASK_2 UINT64_C(0xfe)

#define VIDEORTP_PES_TIMESTAMP_BIT_MASK_3 UINT64_C(0xff)

#define VIDEORTP_PES_TIMESTAMP_BIT_MASK_4 UINT64_C(0xfe)

#define VIDEORTP_PES_TIMESTAMP_MARKER_BIT UINT64_C(0x01)

/**
 * @brief Number of bytes from start of packet until end of pes_packet_length field
 *
 */
#define VIDEORTP_PES_PACKET_LEN UINT32_C(6)

/**
 * @brief Padding pattern
 *
 */
#define VIDEORTP_PATTERN 0xFF

/** TransportStreamPacketizer & TransportStreamHeaderBuilder */

/** Sync byte, declared in H.222 */
#define VIDEORTP_TS_SYNC_BYTE 0x47
/** Mask for writing Payload Unit Start Indicator flag and PID field */
#define VIDEORTP_TS_INDICATOR_AND_PID_MASK 0x5FFF
/** Mask for writing pcr mask */
#define VIDEORTP_TS_PCR_MASK UINT64_C(0x0000FFFFFFFFFFFF)
/** Mask for writing continuity counter */
#define VIDEORTP_TS_CONTINUITY_COUNTER_MASK UINT8_C(0x0F)
/** Mask for writing pcr flag */
#define VIDEORTP_TS_PCR_FLAG_TRUE 0x10
/** Stuffing byte value */
#define VIDEORTP_TS_PACKET_STUFFING_BYTE 0xFF
/** Continuity counter mod */
#define VIDEORTP_TS_CONTINUITY_COUNTER_MOD 16
/** Continuity counter timestamp packet counter */
#define VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD 6

/** Size of PCR fields wirh reserved bits */
#define VIDEORTP_TS_PCR_SIZE 6
/** Size of TS packet */
#define VIDEORTP_TS_PACKET_SIZE 188
/**
 * @brief Minimum TS header size
 *
 * @note syncByte (uint8_t) + PID (uint16_t) + scrambled, adaptationFieldControl, continuityCounter (2 bits + 2 bits + 4 bits =
 * uint8_t)
 *
 */
#define VIDEORTP_TS_MINIMUM_HEADER_SIZE 4
/**
 * @brief TS adaptation field size
 *
 * @note adaptationFieldLength (uint8_t) + discontinuityIndicator ... adaptationFieldExtensionFlag (uint8_t) +
 * programClockReferenceBase, reserved, programClockReferenceExtension (33 bits + 6 bits + 9 bits = 6 byte)
 *
 */
#define VIDEORTP_TS_ADAPTATION_FIELD_SIZE (VIDEORTP_TS_PCR_SIZE + 2)
/** TS header size with PCR */
#define VIDEORTP_TS_WITH_PCR (VIDEORTP_TS_MINIMUM_HEADER_SIZE + VIDEORTP_TS_ADAPTATION_FIELD_SIZE)
/**
 * @brief Mask for TS adaptation field control: payload present
 *
 * scrambled:
 * 00 - no scrambled
 * anything else - user-defined
 *
 * adaptationFieldControl:
 * 00 - reserved for future use by ISO/IEC
 * 01 - no adaptation_field, payload only
 * 10 - adaptation_field only, no payload
 * 11 - adaptation field followed by payload
 *
 * The continuity_counter is a 4-bit field incrementing with each transport stream packet with the same PID.
 * The continuity_counter wraps around to 0 after its maximum value.
 * The continuity_counter shall not be incremented when the adaptation_field_control of the packet equals '00'or '10'.
 */
#define VIDEORTP_TS_PAYLOAD_MASK 0x10
/**
 * @brief Mask for TS adaptation field control: adaptation field present
 */
#define VIDEORTP_TS_ADAPTATION_FIELD_MASK 0x20

/** ProgramAssociationTableBuilder & ProgramMapTableBuilder */

/**
 * @brief Max size of PMT descriptor (not defined in H.222)
 *
 */
#define VIDEORTP_PMT_MAX_PROGRAM_INFO_LENGTH 256
/**
 * @brief Max number of streams. Audio and Video
 *
 */
#define VIDEORTP_PMT_MAX_STREAMS_NUMBER 2
/**
 * @brief Max pmt section length
 *
 */
#define VIDEORTP_PMT_SECTION_MAX_LENGTH UINT32_C(1021)
/**
 * @brief Max pat section length
 *
 */
#define VIDEORTP_PAT_SECTION_MAX_SIZE VIDEORTP_PMT_SECTION_MAX_LENGTH
/**
 * @brief 3 is sizes sum by table id, section_syntax_indicator, zero, reserved, section_length
 *
 */
#define VIDEORTP_PMT_MAX_SIZE (VIDEORTP_PMT_SECTION_MAX_LENGTH + 3)
/**
 * @brief 3 is sizes sum by table id, section_syntax_indicator, zero, reserved, section_length
 *
 */
#define VIDEORTP_PAT_MAX_SIZE VIDEORTP_PMT_MAX_SIZE
/**
 * @brief TS_program_map_section on H.222
 *
 */
#define VIDEORTP_PMT_TABLE_ID 0x02
/**
 * @brief Type of first video stream
 *
 */
#define VIDEORTP_AVC_VIDEO_STREAM_TYPE 0x1B
/**
 * @brief Predefined PID of MPEG Program Association Table
 *
 */
#define VIDEORTP_PROGRAM_ASSOCIATION_TABLE_PID 0
/**
 * @brief Stub type of stream
 *
 */
#define VIDEORTP_STREAM_TYPE_STUB 0

/** TimeStampGenerator */

/** Base frequency for timestamp calculation (27 MHz as per MPEG specification) */
#define VIDEORTP_CLOCK_RATE UINT64_C(27000000)

/** CRC 32 */

/**
 * @brief Generator polynom for MPEG CRC32 (H.222.0 Annex A)
 *
 */
#define VIDEORTP_MPEG2_CRC_POLYNOM 0x04C11DB7
/**
 * @brief Init value for CRC32 calculation
 *
 */
#define VIDEORTP_MPEG2_CRC_INIT 0xFFFFFFFF
/**
 * @brief Fliped output bits for CRC32 calculation
 *
 */
#define VIDEORTP_MPEG2_CRC_XOR_OUT 0x00
#endif /* CONSTANTS_MPEG_H */
