#ifndef FRAME_FACTORY_H
#define FRAME_FACTORY_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ipcFrame.h"

#ifdef __cplusplus
extern "C"
{
#endif
/**
 * \defgroup FrameFactory
 * @{
 *
 * @brief Factory for creating @ref Frame instances.
 *
 * The FrameFactory combines the concepts of a Factory method and a resource pool.
 * When being initialized by a call to the @ref VIDEORTP_frameFactoryInit "init" method
 * the internal item pool is converted into Frame instances being added into a free
 * queue.
 *
 * A call to the @ref VIDEORTP_frameFactoryCreate "create" method takes one element
 * from this free queue, passes its arguments to the Frame's init method and returns this
 * initialized instance to the caller.
 *
 * Conversely, a call to the @ref VIDEORTP_frameFactoryDestroy "destroy" method returns a
 * so-created Frame instance to the free list for later use.
 *
 * @note The destroy method does no cleanup! The caller must take care that the Frame
 * being destroyed does not contain any data that could cause resource leaks.
 */

/* ===========================================================================
 *
 *   Private Macros
 *
 * ========================================================================= */

/** The maximum number of frames that can be allocated */
#define VIDEORTP_FACTORY_FRAME_MAX_COUNT 20

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Structure holding the data specific to a @ref FrameFactory instance.
     *
     */
    typedef struct VIDEORTP_ipcFrameFactory_t
    {
        /** @privatesection @{ */
        /** Array of VIDEORTP_ipcFrame_t instances */
        VIDEORTP_ipcFrame_t itemPool[VIDEORTP_FACTORY_FRAME_MAX_COUNT];
        /** Queue of free elements */
        VIDEORTP_ipcFrameQueue_t freeQueue;
        /** @} */
    } VIDEORTP_ipcFrameFactory_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_ipcFrameFactory_t
     * @public @memberof VIDEORTP_ipcFrameFactory_t
     *
     * @param self VIDEORTP_ipcFrameFactory_t instance that the function works on
     */
    void VIDEORTP_frameFactoryInit(VIDEORTP_ipcFrameFactory_t* self);

    /**
     * @brief Allocates VIDEORTP_ipcFrame_t instance
     * @public @memberof VIDEORTP_ipcFrameFactory_t
     *
     * @param self VIDEORTP_ipcFrameFactory_t instance that the function works on
     * @param chunkFactory Pointer to allocator of VIDEORTP_ipcFramePayloadChunk_t instances
     * @param frameSize Total frame size
     * @param samplingTime Sample time of frame
     *
     * @return VIDEORTP_ipcFrame_t*
     *
     * @see VIDEORTP_ipcFrame_t
     * @see VIDEORTP_ipcPayloadChunkFactory_t
     */
    VIDEORTP_ipcFrame_t* VIDEORTP_frameFactoryCreate(VIDEORTP_ipcFrameFactory_t* self,
                                                     VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory, const size_t frameSize,
                                                     const uint64_t samplingTime);

    /**
     * @brief Destroy allocated VIDEORTP_ipcFrame_t instance
     * @public @memberof VIDEORTP_ipcFrameFactory_t
     *
     * @param self VIDEORTP_ipcFrameFactory_t instance that the function works on
     * @param item The element to be destroyed
     */
    void VIDEORTP_frameFactoryDestroy(VIDEORTP_ipcFrameFactory_t* self, VIDEORTP_ipcFrame_t* item);

    /**@} FrameFactory global */

#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* FRAME_FACTORY_H */
