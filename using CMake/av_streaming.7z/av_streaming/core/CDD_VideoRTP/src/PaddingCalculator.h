#ifndef PRE_GENERATED_VIDEO_H
#define PRE_GENERATED_VIDEO_H
/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif
/**
 * \defgroup paddingCalculator
 * @{
 * @brief Calculates amount of padding required to reach a given target data rate.
 */

/* ===========================================================================
 *
 *   Public Macros
 *
 * ========================================================================= */

/** Target data rate in bytes/sec */
#define VIDEORTP_TARGET_DATARATE (6000000 / 8)

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Contains data for calculating target padding size
     *
     */
    typedef struct VIDEORTP_paddingCalculator_t
    {
        /** @privatesection @{ */
        /** Target padding size */
        size_t targetPadding;
        /** Current (approximate) data rate */
        size_t dataRate;
        /** @} */
    } VIDEORTP_paddingCalculator_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_paddingCalculator_t
     * @public @memberof VIDEORTP_paddingCalculator_t
     *
     * @param self VIDEORTP_paddingCalculator_t instance that the function works on
     */
    void VIDEORTP_padCalcInit(VIDEORTP_paddingCalculator_t* self);

    /**
     * @brief Calculate and return padding size to achieve the desired total data rate.
     * @public @memberof VIDEORTP_paddingCalculator_t
     *
     * Assumes the calculation will be updated in regular intervals (e.g., every x milliseconds).
     * If the actual interval jitters, the calculation will be inaccurate.
     *
     * @param self VIDEORTP_paddingCalculator_t instance that the function works on
     * @param payloadCounter Amount of real data (without padding) transferred since the last call
     * @param elapsedTime Time in milliseconds since the last call
     * @return size_t Padding to generate in the next interval (assuming the next interval has the same length as elapsedTime)
     */
    size_t VIDEORTP_padCalcPadding(VIDEORTP_paddingCalculator_t* self, size_t payloadCounter, uint32_t elapsedTime);

    /**@} paddingCalculator global */

#ifdef __cplusplus
} /* extern "C" */

#endif

#endif /* PRE_GENERATED_VIDEO_H */
