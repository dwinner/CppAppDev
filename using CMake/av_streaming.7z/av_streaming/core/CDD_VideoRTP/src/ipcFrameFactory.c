/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ipcFrameFactory.h"
#include "SinglyLinkedList.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:      VIDEORTP_frameFactoryInit
 *
 *   Function:   Initialize VIDEORTP_ipcFrameFactory_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameFactory_t* self: VIDEORTP_ipcFrameFactory_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frameFactoryInit(VIDEORTP_ipcFrameFactory_t* self)
{
    assert(self);
    VIDEORTP_slistInit(&self->freeQueue);

    for (size_t i = 0; i < (size_t) VIDEORTP_FACTORY_FRAME_MAX_COUNT; i++)
    {
        VIDEORTP_slistPushBack(&self->freeQueue, &self->itemPool[i]);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frameFactoryCreate
 *
 *   Function:   Initialize VIDEORTP_ipcFrameFactory_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameFactory_t* self: VIDEORTP_ipcFrameFactory_t instance that the function works on
 *               VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory: Pointer to allocator of VIDEORTP_ipcFramePayloadChunk_t instances
 *               size_t frameSize: Total frame size
 *               VIDEORTP_timestamp* timestamp: Sampling timestamp of this frame
 *
 *   Outputs:
 *               VIDEORTP_ipcFrame_t*
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_ipcFrame_t* VIDEORTP_frameFactoryCreate(VIDEORTP_ipcFrameFactory_t* self, VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory,
                                                 const size_t frameSize, const VIDEORTP_timestamp* timestamp)
{
    assert(self);
    assert(timestamp);

    VIDEORTP_ipcFrame_t* frame = NULL;

    /* Empty frames would block the pipeline because they will never be removed */
    if (frameSize > (size_t) 0)
    {
        VIDEORTP_slistPopFront(&self->freeQueue, &frame);
        if (frame != NULL)
        {
            VIDEORTP_ipcFrameInit(frame, chunkFactory, frameSize, timestamp);
        }
    }

    return frame;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_frameFactoryDestroy
 *
 *   Function:   Destroy allocated VIDEORTP_ipcFrame_t instance
 *
 *   Inputs:
 *               VIDEORTP_ipcFrameFactory_t* self: VIDEORTP_ipcFrameFactory_t instance that the function works on
 *               VIDEORTP_ipcFrame_t* item: The element to be destroyed
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_frameFactoryDestroy(VIDEORTP_ipcFrameFactory_t* self, VIDEORTP_ipcFrame_t* item)
{
    assert(self);
    assert(item);

    VIDEORTP_ipcFrameDeinit(item);
    VIDEORTP_slistPushBack(&self->freeQueue, item);
}
