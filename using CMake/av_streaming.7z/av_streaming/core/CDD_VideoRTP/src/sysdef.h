#if !defined(SYS_DEF_H)
#define SYS_DEF_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup util Utilities
     * @{
     * @brief Helper functions and macros
     */

    /* ===========================================================================
     *
     *  Public Macros
     *
     * ========================================================================= */

/** @brief Returns the lesser value */
#define VIDEORTP_sysGetMin(x, y) (((x) < (y)) ? (x) : (y))
/** @brief Returns the greater value */
#define VIDEORTP_sysGetMax(x, y) (((x) > (y)) ? (x) : (y))

/**@} */
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* SYS_DEF_H */
