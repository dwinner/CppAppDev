/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "TransportStreamMultiplexer.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
*
*   Name:       VIDEORTP_muxPrepareNextChunk
*
*   Function:   Call prepareNextChunk for every predecessor.
*                If result non-zero will store predecessor index to self->selectedPredecessorIndex for future calling copyChunk and
return
*
*   Inputs:
*               VIDEORTP_payloadProvider_t* vtable: The instance of VIDEORTP_transportStreamMultiplexer_t
*               size_t maximumSize: Maximum available space of destination buffer
*               VIDEORTP_payloadChunkInfo_t* metadata: Meta data about packet data
*
*   Outputs:
                size_t
*
*   Side Effects:
*
*   Traceability to SDD: MAGAVSTR-88, <further tickets, or if bug tickets exists and fix something here>
*
*   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
*
*   Remarks:
*
* ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamMultiplexer_t */
static size_t VIDEORTP_muxPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metadata)
{
    assert(vtable);
    assert(metadata);

    VIDEORTP_transportStreamMultiplexer_t* self = (VIDEORTP_transportStreamMultiplexer_t*) ((void*) vtable);
    size_t nextChunkSize = 0;

    size_t predecessorsCount = VIDEORTP_pipeGetMultiplePredecessorCount(&(self->base));
    for (size_t predIndex = 0; predIndex < predecessorsCount; predIndex++)
    {
        VIDEORTP_payloadProvider_t* predecessor = VIDEORTP_pipeGetMultiplePredecessor(&(self->base), predIndex);
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(predecessor, maximumSize, metadata);
        if (nextChunkSize > 0)
        {
            self->selectedPredecessorIndex = predIndex;
            break;
        }
    }
    return nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_muxCopyChunk
 *
 *   Function:   Copy predecessor data at self->selectedPredecessorIndex to destination buffer with payloadBuffer
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: VIDEORTP_payloadProvider_t instance that the function works on
 *               VIDEORTP_bufferWriter_t* payloadBuffer: Destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-88, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamMultiplexer_t */
static void VIDEORTP_muxCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);

    VIDEORTP_transportStreamMultiplexer_t* self = (VIDEORTP_transportStreamMultiplexer_t*) ((void*) vtable);

    if (self->selectedPredecessorIndex < VIDEORTP_pipeGetMultiplePredecessorCount(&(self->base)))
    {
        VIDEORTP_pipeCopyChunk(VIDEORTP_pipeGetMultiplePredecessor(&(self->base), self->selectedPredecessorIndex), payloadBuffer);
    }
    self->selectedPredecessorIndex = VIDEORTP_MUX_INVALID_PREDECESSOR_INDEX;
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_muxInit
 *
 *   Function:   Initialize self VIDEORTP_transportStreamMultiplexer_t instance
 *
 *   Inputs:
 *               VIDEORTP_transportStreamMultiplexer_t* self: The instance of VIDEORTP_transportStreamMultiplexer_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-88, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_muxInit(VIDEORTP_transportStreamMultiplexer_t* self)
{
    assert(self);
    self->vtable.prepareNextChunk = VIDEORTP_muxPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_muxCopyChunk;

    self->selectedPredecessorIndex = VIDEORTP_MUX_INVALID_PREDECESSOR_INDEX;
    VIDEORTP_pipeInitStageWithMultiplePredecessors(&(self->base));
}
