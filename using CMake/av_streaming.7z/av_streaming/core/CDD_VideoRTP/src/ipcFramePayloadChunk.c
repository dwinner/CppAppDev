
/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ipcFramePayloadChunk.h"
#include <assert.h>
#include <string.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameChunkInit
 *
 *   Function:   Initialize VIDEORTP_ipcFramePayloadChunk_t
 *
 *   Inputs:
 *               VIDEORTP_ipcFramePayloadChunk_t* self: VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
 *               void* payloadBuffer: Buffer with frame chunk
 *               size_t chunkSize: Total chunk size
 *               VIDEORTP_releaseBufferCb_t releaseBufferCallback: Release buffer callback to IPC
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16802575, 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcFrameChunkInit(VIDEORTP_ipcFramePayloadChunk_t* self, const void* payloadBuffer, const size_t chunkSize,
                                VIDEORTP_releaseBufferCb_t releaseBufferCallback)
{
    assert(self);
    assert(payloadBuffer);

    self->basePointer = (const uint8_t*) payloadBuffer;
    self->readPointer = self->basePointer;
    self->totalSize = chunkSize;
    self->releaseBufferCb = releaseBufferCallback;
    self->next = NULL;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameChunkGetRemainingSize
 *
 *   Function:   Return remaining size of frame chunk
 *
 *   Inputs:
 *               VIDEORTP_ipcFramePayloadChunk_t* self: VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameChunkGetRemainingSize(VIDEORTP_ipcFramePayloadChunk_t* self)
{
    assert(self);

    size_t value = self->totalSize - (size_t) (self->readPointer - self->basePointer);

    return value;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameChunkGetData
 *
 *   Function:   Copies data to a buffer and returns the size of the copied data
 *
 *   Inputs:
 *               VIDEORTP_ipcFramePayloadChunk_t* self: VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
 *               void* buffer: Destination buffer
 *               size_t max: Buffer available space
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_ipcFrameChunkGetData(VIDEORTP_ipcFramePayloadChunk_t* self, void* buffer, const size_t max)
{
    assert(self);
    assert(buffer);

    size_t chunkSize = 0;
    if (VIDEORTP_ipcFrameChunkGetRemainingSize(self) > (size_t) 0)
    {
        size_t remainingSize = VIDEORTP_ipcFrameChunkGetRemainingSize(self);
        chunkSize = VIDEORTP_sysGetMin(remainingSize, max);

        uint8_t* dst = (uint8_t*) buffer;
        memcpy(dst, self->readPointer, chunkSize);
        self->readPointer += chunkSize;
    }
    return chunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcFrameChunkReleaseBuffer
 *
 *   Function:   Calls callback with release source buffer with chunk
 *
 *   Inputs:
 *               VIDEORTP_ipcFramePayloadChunk_t* self: VIDEORTP_ipcFramePayloadChunk_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-24, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcFrameChunkReleaseBuffer(VIDEORTP_ipcFramePayloadChunk_t* self)
{
    assert(self);

    if (self->releaseBufferCb != NULL)
    {
        self->releaseBufferCb((void*) self->basePointer);
        self->basePointer = NULL;
        self->readPointer = NULL;
        self->totalSize = 0;
    }
}
