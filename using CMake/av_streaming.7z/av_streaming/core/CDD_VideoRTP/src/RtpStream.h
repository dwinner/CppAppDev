#ifndef RTP_STREAM_H_INCLUDED
#define RTP_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "AvbRtcpPacketBuilder.h"
#include "PacketTransmitter.h"
#include "PayloadProvider.h"
#include "RtpPacketizer.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @defgroup RtpStream
     * @{
     * @brief Wraps an MPEG transport stream in RTP packets.
     */

    /**
     * @brief Wraps MPEG-TS packets in RTP packets.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** @brief RTP configuration parameters */
        VIDEORTP_rtcpSessionConfiguration_t rtpConfig;

        /** @brief Assemble RTP packets */
        VIDEORTP_rtpPaketizer_t rtpPacketizer;

        /** @brief Assemble RTCP packets */
        VIDEORTP_avbRtcpPacketBuilder_t rtcpPacketizer;
        /** @brief When to send the next RTCP packet */
        uint32_t rtcpTimer;
        /** @brief Whether to send an RTCP packet */
        bool rtcpElapsed;
        /** @} */
    } VIDEORTP_rtpStream_t;

    /**
     * @brief The function initializes a network connection for data transmission over the network or to file writer
     * @public @memberof VIDEORTP_rtpStream_t
     *
     * @param stream Instance this function works on
     * @param packetSource Source stream
     * @param config Stream configuration
     */
    void VIDEORTP_initRtpStream(VIDEORTP_rtpStream_t* stream, VIDEORTP_payloadProvider_t* packetSource,
                                const VIDEORTP_rtcpSessionConfiguration_t* config);

    /**
     * @brief Cyclically checks if RTCP packets have to be transmitted
     * @public @memberof VIDEORTP_rtpStream_t
     *
     * @param stream Instance this function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicRtpStream(VIDEORTP_rtpStream_t* stream, uint32_t timeSinceLastCall);

    /**
     * @brief Send a RTP and RTCP packet
     * @public @memberof VIDEORTP_rtpStream_t
     *
     * @param stream Instance this function works on
     * @param rtpTransmitter Pipeline output
     * @param rtcpTransmitter Control packets
     * @return Returns false when there are no more packets to send
     */
    bool VIDEORTP_sendRtpPacket(VIDEORTP_rtpStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                                VIDEORTP_packetTransmitter_t* rtcpTransmitter);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
