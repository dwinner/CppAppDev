#ifndef IPC_INPUT_STREAM_H_INCLUDED
#define IPC_INPUT_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "ElementaryStreamPacketizer.h"
#include "IpcFrameProvider.h"
#include "StbM.h"
#include "TransportStreamPacketizer.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @defgroup IpcInputStream
     * @{
     * @brief Wraps a data stream received via IPC into an MPEG transport stream.
     */

    /**
     * @brief Configuration of an IPC video stream.
     */
    typedef struct
    {
        /** @brief MPEG PES packet type ID */
        uint8_t streamId;
        /** @brief MPEG-TS PID */
        uint16_t tsPid;
        /** @brief Source clock for current time (MPEG Program Clock Reference) */
        StbM_SynchronizedTimeBaseType timeBaseId;
    } VIDEORTP_ipcInputStreamConfig_t;

    /**
     * @brief Creates an MPEG transport stream from a (dynamic) video data stream.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** @brief Stores video input stream from IPC */
        VIDEORTP_ipcFrameProvider_t ipcFrame;

        /** @brief Packetize frames */
        VIDEORTP_pesStreamPacketizer_t pesPacketizer;
        /** @brief Wrap in transport stream */
        VIDEORTP_transportStreamPacketizer_t tsPacketizer;

        /** @brief Source clock for current time (MPEG Program Clock Reference) */
        StbM_SynchronizedTimeBaseType timeBaseId;
        /** @brief When to inject the next PCR timestamp in the video stream */
        uint32_t pcrTimer;
        /** @} */
    } VIDEORTP_ipcInputStream_t;

    /**
     * @brief The function prepares a pipeline for transferring H264 data from a file
     * @public @memberof VIDEORTP_ipcInputStream_t
     *
     * @param stream Instance this function works on
     * @param config Stream configuration
     * @return Pointer to the output pipeline stage which should be connected to the next stage.
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_initIPCInputStream(VIDEORTP_ipcInputStream_t* stream,
                                                            const VIDEORTP_ipcInputStreamConfig_t* config);

    /**
     * @brief The function deinit inputStream
     * @public @memberof VIDEORTP_ipcInputStream_t
     *
     * @param self
     */
    void VIDEORTP_ipcDeinitIPCInputStream(VIDEORTP_ipcInputStream_t* self);

    /**
     * @brief Cyclically checks if another frame is to be transmitted. Also includes the PCR.
     * @public @memberof VIDEORTP_ipcInputStream_t
     *
     * @param stream Instance this function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicIPCInputStream(VIDEORTP_ipcInputStream_t* stream, uint32_t timeSinceLastCall);

    /**
     * @brief Creates frame
     * @public @memberof VIDEORTP_ipcInputStream_t
     *
     * @param self VIDEORTP_ipcInputStream_t instance that the function works on
     * @param frameSize frame full size
     * @param timestamp Sampling timestamp of this frame
     * @return true if start frame successful
     * @return false if start frame unsuccessful
     */
    bool VIDEORTP_ipcInputStartFrame(VIDEORTP_ipcInputStream_t* self, const size_t frameSize, const VIDEORTP_timestamp* timestamp);

    /**
     * @brief Appends payload chunk to frame
     * @public @memberof VIDEORTP_ipcInputStream_t
     *
     * @param self VIDEORTP_ipcInputStream_t instance that the function works on
     * @param bufferPayload payload chunk
     * @param bufferSize size of payload chunk
     * @return true if append chunk successful
     * @return false if append chunk unsuccessful
     */
    bool VIDEORTP_ipcInputAppendFrame(VIDEORTP_ipcInputStream_t* self, const void* bufferPayload, const size_t bufferSize,
                                      VIDEORTP_releaseBufferCb_t bufferReleaseCallback);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
