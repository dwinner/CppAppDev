/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "StaticInputStream.h"
#include "ConstantsOEM.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initStaticInputStream
 *
 *   Function:   The function prepares a pipeline for transferring H264 data from a file
 *
 *   Inputs:
 *               VIDEORTP_staticInputStream_t* stream: VIDEORTP_staticInputStream_t instance that the function works on
 *               const VIDEORTP_staticInputStreamConfig_t* config: configuration settings
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initStaticInputStream(VIDEORTP_staticInputStream_t* stream,
                                                           const VIDEORTP_staticInputStreamConfig_t* config)
{
    /* TODO: Fix rounding error if 1000 ms is not evenly divisible by frame rate */
    stream->frameInterval = 1000 / config->fps;
    /* Send tables etc. immediately */
    stream->frameTimer = stream->frameInterval;

    /* Send first PCR as soon as possible */
    stream->pcrTimer = VIDEORTP_PCR_INTERVAL;
    /* Convert ms to MPEG clock */
    stream->pcrDelay = config->pcrDelay * (VIDEORTP_CLOCK_RATE / 1000);

    VIDEORTP_seqInit(&stream->repeater, config->payloadUnits, config->payloadUnitCount);
    VIDEORTP_cntInit(&stream->counter, &stream->repeater.vtable);
    VIDEORTP_tgenInit(&stream->timeGenerator, stream->pcrDelay, config->fps, &stream->counter.vtable);
    VIDEORTP_pesInitPacketizer(&stream->pesPacketizer, &stream->timeGenerator.vtable, config->streamId);
    VIDEORTP_tsInitPacketizer(&stream->tsPacketizer, &stream->pesPacketizer.vtable, config->tsPid);
    VIDEORTP_gateInit(&stream->gate, &stream->tsPacketizer.vtable);

    return &stream->gate.base;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicStaticInputStream
 *
 *   Function:   Cyclically checks if another frame is to be transmitted. Also includes the PCR.
 *
 *   Inputs:
 *               VIDEORTP_staticInputStream_t* stream: VIDEORTP_staticInputStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicStaticInputStream(VIDEORTP_staticInputStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Send next frame */
    if (VIDEORTP_timerTick(&stream->frameTimer, timeSinceLastCall, stream->frameInterval))
    {
        VIDEORTP_gateEnable(&stream->gate);
    }

    /* Inject PCR into next packet */
    if (VIDEORTP_timerTick(&stream->pcrTimer, timeSinceLastCall, VIDEORTP_PCR_INTERVAL))
    {
        /* This stream is generated, so there is no real "current" time or clock.
         * Use generated "sampling" timestamps so at least the timestamps match. */
        uint64_t pcr = VIDEORTP_tgenCalculateTimestamp(&stream->timeGenerator);
        VIDEORTP_tsInjectPcr(&stream->tsPacketizer.builder, pcr - stream->pcrDelay);
    }
}
