/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ProgramSectionPacketizer.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sectPrepareNextChunk
 *
 *   Function:   Copy chunks from the predecessor stage. Add a pointer field to the first chunk. Add padding to the last chunk.
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: VIDEORTP_payloadProvider_t instance to be initialized
 *               size_t maximumSize: maximum available space of destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t : size of next chunk
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-27, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_programSectionPacketizer_t */
static size_t VIDEORTP_sectPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                            VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_programSectionPacketizer_t* self = (VIDEORTP_programSectionPacketizer_t*) ((void*) vtable);

    self->needPointer = false;
    /* data size without pointer */
    self->nextChunkSize = VIDEORTP_pipePrepareNextChunk(self->predecessor, maximumSize, metaData);
    if (self->nextChunkSize > (size_t) 0)
    {
        /* Add pointer field to the first chunk */
        if (metaData->isPayloadUnitStart)
        {
            /* Adjust chunk size */
            self->nextChunkSize
                = VIDEORTP_pipePrepareNextChunk(self->predecessor, maximumSize - (size_t) VIDEORTP_SECT_POINTER_SIZE, metaData);
            if (self->nextChunkSize > (size_t) 0)
            {
                self->nextChunkSize += (size_t) VIDEORTP_SECT_POINTER_SIZE;
                self->needPointer = metaData->isPayloadUnitStart;
            }
        }
        /* Add padding to the last chunk */
        if (self->nextChunkSize > (size_t) 0 && metaData->isPayloadUnitEnd)
        {
            /* Fill the whole buffer */
            assert(self->nextChunkSize <= maximumSize);
            self->nextChunkSize = maximumSize;
        }
    }

    return self->nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sectCopyChunk
 *
 *   Function:   This should add the pointer, call copyChunk of the predecessor, and add padding
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: VIDEORTP_payloadProvider_t instance to be initialized
 *               VIDEORTP_bufferWriter_t* payloadBuffer: destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-27, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_programSectionPacketizer_t */
static void VIDEORTP_sectCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_programSectionPacketizer_t* self = (VIDEORTP_programSectionPacketizer_t*) ((void*) vtable);
    assert(self->nextChunkSize > (size_t) 0);

    /* Add pointer field before the first chunk */
    size_t before = VIDEORTP_bufGetAvailableSpace(payloadBuffer);
    if (self->needPointer)
    {
        VIDEORTP_bufWriteInteger(payloadBuffer, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t));
    }

    /* Add actual section */
    VIDEORTP_pipeCopyChunk(self->predecessor, payloadBuffer);
    size_t after = VIDEORTP_bufGetAvailableSpace(payloadBuffer);

    /* Fill the rest with padding */
    size_t writtenDataSize = before - after;
    if (writtenDataSize < self->nextChunkSize)
    {
        VIDEORTP_bufWritePattern(payloadBuffer, VIDEORTP_SECT_PADDING, self->nextChunkSize - writtenDataSize);
    }
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_sectInit
 *
 *   Function:   It shall initialize self
 *
 *   Inputs:
 *               VIDEORTP_programSectionPacketizer_t* self: VIDEORTP_programSectionPacketizer_t instance to be initialized
 *               VIDEORTP_payloadProvider_t* predecessor: previous stage of the pipeline
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-27, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_sectInit(VIDEORTP_programSectionPacketizer_t* self, VIDEORTP_payloadProvider_t* predecessor)
{
    assert(self);
    assert(predecessor);

    self->vtable.prepareNextChunk = VIDEORTP_sectPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_sectCopyChunk;
    self->predecessor = predecessor;
}
