/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "TransportStreamPacketizer.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsPrepareNextChunk
 *
 *   Function:  Calculate and return packet chunk size
 *
 *              Call prepareNextChunk for predecessor, store its return value
 *              Send metadata to TransportStreamHeaderBuilder
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: The instance of VIDEORTP_payloadProvider_t the that the function is working on
 *               size_t maximumSize: Maximum available space of destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metadata: Meta data about packet data
 *
 *   Outputs:
 *               size_t ret: VIDEORTP_TS_PACKET_SIZE if predecessor->prepareNextChunk > 0
 *               size_t ret: 0 if predecessor->prepareNextChunk == 0
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamPacketizer_t */
static size_t VIDEORTP_tsPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                          VIDEORTP_payloadChunkInfo_t* metadata)
{
    assert(vtable);
    assert(metadata);

    VIDEORTP_transportStreamPacketizer_t* self = (VIDEORTP_transportStreamPacketizer_t*) ((void*) vtable);

    size_t ret = 0;

    /* TS packets have a fixed size and cannot be fragmented */
    if (maximumSize >= VIDEORTP_TS_PACKET_SIZE)
    {
        /* Note: Unused space will be filled with stuffing bytes */
        size_t minHeaderSize = VIDEORTP_tsGetMinimumHeaderSize(&(self->builder));
        self->nextChunkSize = VIDEORTP_pipePrepareNextChunk(self->predecessor, VIDEORTP_TS_PACKET_SIZE - minHeaderSize, metadata);

        if (self->nextChunkSize > 0)
        {
            VIDEORTP_tsSetPacketMetaData(&(self->builder), metadata);
            ret = VIDEORTP_TS_PACKET_SIZE; /* includes padding/stuffing */
        }
    }

    return ret;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsCopyChunk
 *
 *   Function:   Copy TS packet to the destination buffer with payloadBuffer
 *
 *               Sapwn child headerBufferWriter for inserting TS header later
 *               Call copyChunk for predecessor
 *               Build header and write it with headerBufferWriter
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: The instance of VIDEORTP_payloadProvider_t the that the function is working on
 *               VIDEORTP_bufferWriter_t* payloadBuffer: Destination buffer writer
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_transportStreamPacketizer_t */
static void VIDEORTP_tsCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    VIDEORTP_transportStreamPacketizer_t* self = (VIDEORTP_transportStreamPacketizer_t*) ((void*) vtable);

    /* header and stuffing */
    VIDEORTP_bufferWriter_t headerWriter
        = VIDEORTP_bufSpawnChildWriter(payloadBuffer, VIDEORTP_TS_PACKET_SIZE - self->nextChunkSize);
    VIDEORTP_tsBuildHeader(&(self->builder), &headerWriter);

    /* actual payload */
    VIDEORTP_pipeCopyChunk(self->predecessor, payloadBuffer);
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tsInitPacketizer
 *
 *   Function:   Initialize VIDEORTP_transportStreamPacketizer_t instance
 *
 *   Inputs:
 *               VIDEORTP_transportStreamPacketizer_t* self: The instance of VIDEORTP_transportStreamPacketizer_t the that the
 * function is working on VIDEORTP_payloadProvider_t predecessor: Previous generation stage uint16_t pid: Program ID
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-26, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tsInitPacketizer(VIDEORTP_transportStreamPacketizer_t* self, VIDEORTP_payloadProvider_t* predecessor, uint16_t pid)
{
    assert(self);

    self->vtable.prepareNextChunk = VIDEORTP_tsPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_tsCopyChunk;
    self->nextChunkSize = 0;
    self->predecessor = predecessor;
    VIDEORTP_tsInitHeaderBuilder(&(self->builder), pid);
}
