#ifndef PROGRAM_MAP_TABLE_BUILDER_H
#define PROGRAM_MAP_TABLE_BUILDER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ConstantsMPEG.h"

#include "BufferWriter.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup ProgramMapTableBuilder
     * @{
     * @brief Generates MPEG Program Map Table Sections
     *
     * A Program Map Table (PMT) defines the contents of a single program in an
     * MPEG transport stream. This data structure lists the packet identifiers
     * (PID) of all elementary streams which belong to a program.
     *
     * A ProgramMapTableBuilder can be used to generate such a table.
     * Note that the program ID should match the respective program ID in the
     * @ref ProgramAssociationTableBuilder "Program Association Table".
     * Multiple elementary streams can be added in a loop by calling
     * @ref VIDEORTP_pmtAddElementaryStreamPid "addElementaryStreamPid".
     * Calling @ref VIDEORTP_pmtFinalize "finalize" will write the MPEG section
     * header and append the CRC to the program definition.
     *
     * The generated PMT can be inserted in the MPEG stream using a
     * @ref PayloadUnitRepeater. To avoid excessive bandwidth consumption,
     * the PMT should be throttled using a @ref PayloadGate.
     *
     * @startuml pmt_builder
     *  hide footbox
     *
     *  actor Main
     *  participant ProgramMapTableBuilder
     *  participant BufferWriter
     *
     *  Main -> BufferWriter++ : init(&buffer, sizeof(buffer))
     *      return
     *
     *  Main -> ProgramMapTableBuilder++ : init(programId, pcrPID, &BufferWriter)
     *      loop
     *          ProgramMapTableBuilder -> BufferWriter++ : writeData(...)
     *              note right: Write section header
     *              return
     *      end
     *      return
     *
     *  loop for all programs
     *      Main -> ProgramMapTableBuilder++ : addElementaryStreamPid(pid, type)
     *          note right: Add elementary stream to internal list
     *          return
     *  end
     *
     *  Main -> ProgramMapTableBuilder++ : finalize()
     *      loop
     *          ProgramMapTableBuilder -> BufferWriter++ : writeData(...)
     *              note right: Write list and append CRC
     *              return
     *      end
     *      return
     * @enduml
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Enum define PID values according H.222
     *
     * @note According H.222 Table 2-3. The transport packets with PID values 0x0000, 0x0001, and 0x0010-0x1FFE are allowed to carry
     * a PCR
     * @note H.222: from 0x0010 to 0x1FFE May be assigned as network_PID, Program_map_PID, elementaryPID, or for other purposes
     *
     */
    typedef enum VIDEORTP_pcrPID_t
    {
        /**
         * @brief Program association
         *
         */
        VIDEORTP_PCR_PID_PAT = 0x0000,
        /**
         * @brief Conditional access table
         *
         */
        VIDEORTP_PCR_PID_CAT,
        /**
         * @brief Transport stream description table
         *
         */
        VIDEORTP_PCR_PID_TSDT,
        /**
         * @brief IPMP control information table
         *
         */
        VIDEORTP_PCR_PID_IPMB,
        /**
         * @brief Adaptive streaming information
         *
         */
        VIDEORTP_PCR_PID_ASI,

        /**
         * @brief Reserved values begin
         *
         */
        VIDEORTP_PCR_PID_RESERVED_BEGIN,
        /**
         * @brief Reserved values end
         *
         */
        VIDEORTP_PCR_PID_RESERVED_END = 0x000F,

        /**
         * @brief Program map table
         *
         * H.222 from 0x0010 to 0x1FFE May be assigned as network_PID, Program_map_PID, elementaryPID, or for other purposes
         *
         */
        VIDEORTP_PCR_PID_PMT = 0x0100,

        /**
         * @brief Null Packet
         *
         */
        VIDEORTP_PCR_PID_NULL = 0x1FFF
    } VIDEORTP_pcrPID_t;

    /**
     * @brief struct contan general pmt data
     *
     */
    typedef struct VIDEORTP_pmtStream_t
    {
        /**
         * @brief type of stream according H.222 Table 2-34
         *
         */
        uint8_t streamType;

        /**
         * @brief reserved bits (set to 1)
         *
         */
        uint16_t reserved1 : 3;
        /**
         * @brief PID of the transport stream packets which carry the associated program element
         *
         */
        uint16_t elementaryPID : 13;

        /**
         * @brief reserved bits (set to 1)
         *
         */
        uint16_t reserved2 : 4;
        /**
         * @brief The number of bytes of the descriptors of the associated program element immediately following the ES_info_length
         * field
         *
         */
        uint16_t infoLength : 12;

        /**
         * @brief Elementary stream descriptor (H.222)
         *
         */
        uint8_t info[VIDEORTP_PMT_MAX_PROGRAM_INFO_LENGTH];
    } VIDEORTP_pmtStream_t;

    /**
     * @brief Struct contain elementary stream data in pmt
     *
     * @note According with H.222
     *
     */
    typedef struct VIDEORTP_pmt_t
    {
        /**
         * @brief program number
         *
         */
        uint16_t programNumber;
        /**
         * @brief version number
         *
         */
        uint8_t versionNumber;
        /**
         * @brief section number
         *
         */
        uint8_t sectionNumber;
        /**
         * @brief last section number
         *
         */
        uint8_t lastSectionNumber;
        /**
         * @brief pcrPID
         *
         */
        uint32_t pcrPID;
        /**
         * @brief program info length
         *
         */
        uint16_t infoLength;
        /**
         * @brief descriptor (H.222)
         *
         */
        uint8_t info[VIDEORTP_PMT_MAX_PROGRAM_INFO_LENGTH];
        /**
         * @brief max streams number
         *
         */
        uint32_t streamsSize;
        /**
         * @brief streams number
         *
         */
        uint32_t numStreams;
        /**
         * @brief streams array
         *
         */
        VIDEORTP_pmtStream_t streams[VIDEORTP_PMT_MAX_STREAMS_NUMBER];
    } VIDEORTP_pmt_t;

#if 0 /* for example full pmt section */
struct {
    uint8_t         table_id;

    uint16_t        section_syntax_indicator:1;
    uint16_t        zero:1;
    uint16_t        reserved1:2;
    uint16_t        section_length:12;

    uint16_t        programNumber;

    uint8_t         reserved2:2;
    uint8_t         versionNumber:5;
    uint8_t         current_next_indicator:1;

    uint8_t         section_number;

    uint16_t        reserved_3:3;
    uint16_t        PRC_PID:13;

    uint16_t        reserved_4:4;
    uint16_t        program_info_length:12;
    uint8_t*        descriptor;

    uint8_t*     streams;

    uint32_t        CRC_32;

} typedef pmt_section;
#endif /* for example full pmt section */

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Writes a Program Map Table (PMT) according to H.222 to a buffer.
     *
     * Example usage:
     *
     * @code {.c}
     * // Create destination buffer
     * uint8_t buffer[VIDEORTP_PMT_MAX_SIZE] = {};
     * VIDEORTP_bufferWriter_t bufferWriter;
     * VIDEORTP_bufInit(&bufferWriter, buffer, sizeof(buffer));
     *
     * // Initialize builder
     * uint16_t programId = 1;
     * uint16_t pcrPID = 0x1000;
     * VIDEORTP_programMapTableBuilder_t programMapTableBuilder;
     * VIDEORTP_pmtInit(&programMapTableBuilder, programId, pcrPID, &bufferWriter);
     *
     * // Add one or more elementary streams
     * uint16_t elementaryStreamPid = 0xAD;
     * uint18_t elementaryStreamType = 0x1B;
     * VIDEORTP_pmtAddElementaryStreamPid(&programMapTableBuilder, elementaryStreamPid, elementaryStreamType);
     *
     * // Finalize table (write header and CRC)
     * VIDEORTP_pmtFinalize(&programMapTableBuilder);
     * @endcode
     *
     * After calling finalize, the PMT was written to the buffer and
     * the builder should not be used any more.
     */
    typedef struct VIDEORTP_programMapTableBuilder_t
    {
        /** @privatesection @{ */
        /**
         * @brief Destination VIDEORTP_bufferWriter_t. It write pmt to destination buffer
         *
         */
        VIDEORTP_bufferWriter_t* section;
        /**
         * @brief Buffer writer for pmt.section_length
         *
         */
        VIDEORTP_bufferWriter_t lengthField;
        /**
         * @brief Current pmt
         *
         */
        VIDEORTP_pmt_t pmt;
        /** @} */
    } VIDEORTP_programMapTableBuilder_t;

    /**
     * @brief Construct a new Program Map Table Builder object
     * @public @memberof VIDEORTP_programMapTableBuilder_t
     *
     * @note Create pmt and write to buffer follow data: table_id, program_nuber, versionNumber, current_next_indicator,
     * section_number, last_section_number, PCR_PID
     *
     *       Destination buffer size must be VIDEORTP_PMT_SECTION_MAX_LENGTH + 3
     *
     * @param self VIDEORTP_programMapTableBuilder_t instance that the function works on
     * @param programId Program ID as specified in the Program Association Table
     * @param pcrPID PID of an elementary stream which carries the program clock reference (PCR) for this program
     * @param destBW VIDEORTP_bufferWriter_t which writes pmt data to buffer
     */
    void VIDEORTP_pmtInit(VIDEORTP_programMapTableBuilder_t* self, uint16_t programId, uint16_t pcrPID,
                          VIDEORTP_bufferWriter_t* destBW);

    /**
     * @brief Add elementary stream to pmt streams
     * @public @memberof VIDEORTP_programMapTableBuilder_t
     *
     * @note Create new VIDEORTP_pmtStream_t fill it stubed data and add to pmt
     *
     * @param self VIDEORTP_programMapTableBuilder_t instance that the function works on
     * @param pid Elementary stream pid. Valid range 0..0x1FFF
     * @param streamType Type of elementary stream
     */
    void VIDEORTP_pmtAddElementaryStreamPid(VIDEORTP_programMapTableBuilder_t* self, uint16_t pid, uint8_t streamType);

    /**
     * @brief Write pmt data with CRC_32 using section
     * @public @memberof VIDEORTP_programMapTableBuilder_t
     *
     * @note It write section_syntax_indicator, section length.Also write program_info_length, info, streams and them data, add
     * CRC_32 to end.
     *
     * @param self VIDEORTP_programMapTableBuilder_t instance that the function works on
     *
     * all reserved bits set to 1, more in H.222
     */
    void VIDEORTP_pmtFinalize(VIDEORTP_programMapTableBuilder_t* self);

    /**@} ProgramMapTableBuilder global */

#ifdef __cplusplus
}
#endif
#endif /* PROGRAM_MAP_TABLE_BUILDER_H */
