#ifndef VIDEO_STREAM_H_INCLUDED
#define VIDEO_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "IPCInputStream.h"
#include "PacketTransmitter.h"
#include "ProgramTableStream.h"
#include "RtpStream.h"
#include "TransportStreamMultiplexer.h"

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
#include "PaddingStream.h"
#include "StaticInputStream.h"
#endif

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @defgroup VideoStream
     * @{
     * @brief Merges various MPEG streams and wraps them in an RTP stream.
     */

    /**
     * @brief Configuration of a video stream.
     */
    typedef struct
    {
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        /** @brief Select input stream */
        bool isStaticInputEnabled;
        /** @brief Configuration of static video input */
        VIDEORTP_staticInputStreamConfig_t staticInputConfig;
#endif
        /** @brief Configuration of MPEG stream (metadata) */
        VIDEORTP_mpegProgramTableStreamConfig_t tableConfig;
        /** @brief Configuration of RTP stream */
        VIDEORTP_rtcpSessionConfiguration_t rtpConfig;
        /** @brief Configuration of IPC channel */
        VIDEORTP_ipcInputStreamConfig_t ipcInputConfig;
    } VIDEORTP_videoStreamConfig_t;

    /**
     * @brief Assembles an MPEG transport stream from various sources and wraps it in an RTP stream.
     */
    typedef struct
    {
        /** @privatesection @{ */
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        /** @brief Whether to use the static input stream instead of the IPC input stream */
        bool isStaticInputActive;
        /** @brief MPEG transport stream containing input video */
        VIDEORTP_staticInputStream_t staticInput;
        /** @brief MPEG transport stream containing padding */
        VIDEORTP_paddingStream_t padStream;
#endif

        /* @brief IPC pipeline input */
        VIDEORTP_ipcInputStream_t ipcInput;

        /** @brief MPEG transport stream containing Program Association Table */
        VIDEORTP_mpegProgramTableStream_t patStream;
        /** @brief MPEG transport stream containing Program Map Table */
        VIDEORTP_mpegProgramTableStream_t pmtStream;

        /** @brief Merge all individual MPEG transport streams into one stream */
        VIDEORTP_transportStreamMultiplexer_t multiplexer;

        /** @brief RTP packetizer */
        VIDEORTP_rtpStream_t rtpStream;

        /** @brief Pipeline video output */
        VIDEORTP_packetTransmitter_t* rtpTransmitter;

        /** @brief Control channel */
        VIDEORTP_packetTransmitter_t* rtcpTransmitter;
        /** @} */
    } VIDEORTP_videoStream_t;

    /**
     * @brief The function initializes a network connection for data transmission over the network or to file writer
     * @public @memberof VIDEORTP_videoStream_t
     *
     * @param stream Instance this function works on
     * @param rtpTransmitter Pipeline output
     * @param rtcpTransmitter Control packets
     * @param config Stream configuration
     */
    void VIDEORTP_initVideoStream(VIDEORTP_videoStream_t* stream, VIDEORTP_packetTransmitter_t* rtpTransmitter,
                                  VIDEORTP_packetTransmitter_t* rtcpTransmitter, const VIDEORTP_videoStreamConfig_t* config);

    /**
     * @brief The function deinitializes stream
     * @public @memberof VIDEORTP_videoStream_t
     *
     * @param stream Instance this function works on
     */
    void VIDEORTP_deinitVideoStream(VIDEORTP_videoStream_t* stream);

    /**
     * @brief The main function that implements the transmission of packets over the network / writing to a file
     * @public @memberof VIDEORTP_videoStream_t
     *
     * @param stream Instance this function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicVideoStream(VIDEORTP_videoStream_t* stream, uint32_t timeSinceLastCall);

    /**
     * @brief Creates frame
     * @public @memberof VIDEORTP_videoStream_t
     *
     * @param self VIDEORTP_videoStream_t instance that the function works on
     * @param frameSize frame full size
     * @param samplingTime frame timestamp
     * @return true if start frame successful
     * @return false if start frame unsuccessful
     */
    bool VIDEORTP_startFrameVideoStream(VIDEORTP_videoStream_t* stream, const size_t frameSize, const uint64_t samplingTime);

    /**
     * @brief Appends payload chunk to frame
     * @public @memberof VIDEORTP_videoStream_t
     *
     * @param self VIDEORTP_videoStream_t instance that the function works on
     * @param bufferPayload payload chunk
     * @param bufferSize size of payload chunk
     * @return true if append chunk successful
     * @return false if append chunk unsuccessful
     */
    bool VIDEORTP_appendFrameVideoStream(VIDEORTP_videoStream_t* stream, const void* bufferPayload, const size_t bufferSize,
                                         VIDEORTP_releaseBufferCb_t bufferReleaseCallback);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
