/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <assert.h>

#include "PipelineStageWithMultiplePredecessors.h"

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pipeInitStageWithMultiplePredecessors
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_pipelineStageWithMultiplePredecessors_t* self: VIDEORTP_pipelineStageWithMultiplePredecessors_t instance
 * that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_pipeInitStageWithMultiplePredecessors(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self)
{
    assert(self);
    for (uint8_t it = 0; it < VIDEORTP_MAX_PREDECESSOR_COUNT; it++)
    {
        self->predecessor[it] = NULL;
    }
    self->count = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pipeAddMultiplePredecessor
 *
 *   Function:   Add predecessor stage
 *
 *   Inputs:
 *               VIDEORTP_pipelineStageWithMultiplePredecessors_t* self: VIDEORTP_pipelineStageWithMultiplePredecessors_t instance
 * that the function works on VIDEORTP_payloadProvider_t* predecessor: a pointer to predecessor stage
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_pipeAddMultiplePredecessor(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self,
                                         VIDEORTP_payloadProvider_t* predecessor)
{
    assert(self);
    assert(predecessor);

    if (self->count >= VIDEORTP_MAX_PREDECESSOR_COUNT)
    {
        memmove(self->predecessor, &self->predecessor[1],
                sizeof(VIDEORTP_payloadProvider_t*) * (VIDEORTP_MAX_PREDECESSOR_COUNT - 1));
        self->predecessor[VIDEORTP_MAX_PREDECESSOR_COUNT - 1] = predecessor;
    }
    else
    {
        self->predecessor[self->count] = predecessor;
        self->count++;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pipeGetMultiplePredecessor
 *
 *   Function:   Returns the predecessor by index
 *
 *   Inputs:
 *               VIDEORTP_pipelineStageWithMultiplePredecessors_t* self: VIDEORTP_pipelineStageWithMultiplePredecessors_t instance
 * that the function works on VIDEORTP_payloadProvider_t* predecessor: a pointer to predecessor stage
 *
 *   Outputs:
 *               VIDEORTP_payloadProvider_t*: pointer to predecessor
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_pipeGetMultiplePredecessor(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self,
                                                                const size_t index)
{
    assert(index < self->count);
    return self->predecessor[index];
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pipeGetMultiplePredecessorCount
 *
 *   Function:   Returns the number of predecessors
 *
 *   Inputs:
 *               VIDEORTP_pipelineStageWithMultiplePredecessors_t* self: VIDEORTP_pipelineStageWithMultiplePredecessors_t instance
 * that the function works on VIDEORTP_payloadProvider_t* predecessor: a pointer to predecessor stage
 *
 *   Outputs:
 *               size_t: Count of the predecessors
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_pipeGetMultiplePredecessorCount(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self)
{
    assert(self);
    return self->count;
}
