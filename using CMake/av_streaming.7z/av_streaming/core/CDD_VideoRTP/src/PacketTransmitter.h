#if !defined(PACKET_TRANSMITTER_H)
#define PACKET_TRANSMITTER_H

#include <assert.h>

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "BufferWriter.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * \defgroup PacketTransmitter
 * @{
 *
 * @brief This interface specifies a way to output packets
 *
 * Assembled packets can be transferred via network, saved to a file,
 * or processed in other ways. This interface specifies a generic way to
 * transfer packets.
 *
 * For instance, assume an implementation with a single transfer buffer:
 *
 * @startuml packet_transmitter_classes
 * hide empty members
 *
 * interface PacketTransmitter {
 *     {abstract} + prepareTransmissionBuffer() : BufferWriter*
 *     {abstract} + commitTransmissionBuffer() : void
 * }
 *
 * PacketTransmitter ..> BufferWriter : <<provide>>
 *
 * class MyPacketTransmitterImpl {
 *     - m_payloadBuffer : uint8_t[VIDEORTP_MAX_TX_PAYLOAD_SIZE]
 *     - m_payloadWriter : BufferWriter
 *     - m_socket : int
 *     + prepareTransmissionBuffer() : BufferWriter*
 *     + commitTransmissionBuffer() : void
 * }
 * PacketTransmitter <|.. MyPacketTransmitterImpl : <<implement>>
 *
 * MyPacketTransmitterImpl *- BufferWriter
 * @enduml
 *
 * The first step is always to retrieve an empty buffer. This buffer can be
 * filled with a packet. When done, this buffer can be "committed". At this
 * point, the packet will be transferred by whatever means the
 * implementation supports.
 *
 * @startuml packet_transmitter_sequence
 * hide footbox
 *
 * actor "Main Function" as Main
 * participant MyPacketTransmitterImpl
 * participant "MyPacketTransmitterImpl::m_payloadWriter" as payloadWriter
 * participant Network
 *
 * Main -> MyPacketTransmitterImpl++ : prepareTransmissionBuffer()
 *   MyPacketTransmitterImpl -> payloadWriter++ : clear()
 *   return
 * return currentBuffer = prepareTransmissionBuffer()
 *
 * == create packet ==
 *
 * loop until packet is complete
 *   Main -> payloadWriter++ : currentBuffer->writeData(...)
 *   return
 * end
 *
 * == send packet ==
 *
 * Main -> MyPacketTransmitterImpl++ : commitTransmissionBuffer()
 *   MyPacketTransmitterImpl -> payloadWriter++ : getBasePointer()
 *   return ptr = getBasePointer()
 *   MyPacketTransmitterImpl -> payloadWriter++ : getBytesWritten()
 *   return len = getBytesWritten()
 *   MyPacketTransmitterImpl -> Network++ : send(m_socket, ptr, len)
 *   return
 * return
 * @enduml
 *
 * There can only be one "active" buffer at a time. Getting a new buffer
 * or committing the currently active buffer invalidates the previously
 * active buffer. Only the most recently returned buffer is active.
 * Nevertheless, an implementation may allocate several buffers internally.
 *
 * Note that the interface returns a destination buffer which must be
 * committed explicitly. This allows the implementation certain optimizations.
 * For instance, an implementation may allocate the destination/transfer
 * buffer in a special hardware memory region which is shared with a network
 * interface adapter. In that case, the packet can be constructed directly
 * in an appropriate transfer buffer and the implementation does not need
 * to "memcpy" the data before transferring it.
 *
 * @note To implement this interface, add a VIDEORTP_packetTransmitter_t
 * field at the beginning of your struct and set its function pointers to
 * functions in your module. Use @ref VIDEORTP_txPrepareTransmissionBuffer
 * and @ref VIDEORTP_txCommitTransmissionBuffer to call its methods.
 * See @ref id_ood for further details.
 */

/* ===========================================================================
 *
 *  Public Typedefs
 *
 * ========================================================================= */

/**
 * @brief Max payload size for packet [IP_AVT_575, IP_AVT_1562]
 *
 * - MAC payload (max. 1500) => 1280 (min. link MTU as per RFC 8200)
 * - IPv6 payload (max. 1460) => 1240 (40 byte IPv6 header)
 * - UDP payload (max. 1452) => 1232 (8 byte UDP header)
 */
#define VIDEORTP_MAX_TX_PAYLOAD_SIZE 1232

    typedef uint8_t VIDEORTP_buffer_t[VIDEORTP_MAX_TX_PAYLOAD_SIZE];

    /**
     * @brief Structure defining the interface as function pointers.
     */
    typedef struct VIDEORTP_packetTransmitter_t
    {
        /** @protectedsection @{ */
        /**
         * @brief Returns an empty destination buffer. Discards previous buffers.
         *
         * Once #prepareTransmissionBuffer or #commitTransmissionBuffer are called, any previously returned
         * buffer becomes inactive and may no longer be written to; that is,
         * unless unless the implementation reuses a buffer and returns it
         * again. An implementation may support multiple buffers or it may be
         * limited to a single buffer which it recycles constantly.
         *
         * Calling #prepareTransmissionBuffer again without calling #commitTransmissionBuffer will silently
         * discard the previous buffer so it will not be transferred.
         *
         * @param self Points to the vtable of an instance implementing this interface.
         * @return New active destination buffer.
         */
        VIDEORTP_bufferWriter_t* (*prepareTransmissionBuffer)(struct VIDEORTP_packetTransmitter_t* self);

        /**
         * @brief Commit the current buffer and send the packet.
         *
         * This commits the packet and causes the implementation to "transmit"
         * it, whatever that means in the context of the implementation.
         * Only the currently active buffer will be transmitted.
         * The currently active buffer becomes inactive after this call.
         * Call #prepareTransmissionBuffer again to request a new buffer to write the next packet
         * into. Calling #commitTransmissionBuffer without an active buffer is undefined.
         *
         * @param self Points to the vtable of an instance implementing this interface.
         */
        VideoRTP_errorCode (*commitTransmissionBuffer)(struct VIDEORTP_packetTransmitter_t* self);
        /** @} */
    } VIDEORTP_packetTransmitter_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /** @copydoc VIDEORTP_packetTransmitter_t::prepareTransmissionBuffer
     * @public @memberof VIDEORTP_packetTransmitter_t */
    static inline VIDEORTP_bufferWriter_t* VIDEORTP_txPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* self)
    {
        assert(self);
        return (*self->prepareTransmissionBuffer)(self);
    }

    /** @copydoc VIDEORTP_packetTransmitter_t::commitTransmissionBuffer
     * @public @memberof VIDEORTP_packetTransmitter_t */
    static inline VideoRTP_errorCode VIDEORTP_txCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* self)
    {
        assert(self);
        return (*self->commitTransmissionBuffer)(self);
    }

    /**@} PacketTransmitter global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PACKET_TRANSMITTER_H */
