#ifndef PROGRAM_TABLE_STREAM_H_INCLUDED
#define PROGRAM_TABLE_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "PayloadGate.h"
#include "PayloadUnitRepeater.h"
#include "ProgramSectionPacketizer.h"
#include "TransportStreamPacketizer.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup ProgramTableStream
 * @{
 * @brief Adds various MPEG program tables to a transport stream.
 */

/**
 * @brief Maximum supported size of an MPEG program table
 */
#define VIDEORTP_PROGRAM_TABLE_SIZE 32 /* bytes */

    /**
     * @brief Configuration of an MPEG program table.
     */
    typedef struct
    {
        /** @brief Interval to resend program tables (milliseconds) */
        uint32_t interval;
        /** @brief Program Number of the MPEG video stream */
        uint32_t program;
        /** @brief PID of the MPEG Program Map Table */
        uint32_t pmtPid;
        /** @brief PID of the MPEG video elementary stream */
        uint32_t videoPid;
        /** @brief MPEG Transport Stream ID in Program Association Table */
        uint32_t streamId;
    } VIDEORTP_mpegProgramTableStreamConfig_t;

    /**
     * @brief Provides a transport stream containing an MPEG program table.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** @brief Buffer containing MPEG program table */
        uint8_t buffer[VIDEORTP_PROGRAM_TABLE_SIZE];
        /** @brief Writer for initial setup */
        VIDEORTP_bufferWriter_t writer;
        /** @brief Initial pipeline data generator */
        VIDEORTP_payloadUnitRepeater_t repeater;
        /** @brief Packetize program table sections */
        VIDEORTP_programSectionPacketizer_t sectionPacketizer;
        /** @brief Wrap in transport stream */
        VIDEORTP_transportStreamPacketizer_t tsPacketizer;
        /** @brief Enable on demand */
        VIDEORTP_payloadGate_t gate;
        /** @brief When to send program association table and program map table */
        uint32_t timer;
        /** @brief How fast to send program tables */
        uint32_t interval;
        /** @} */
    } VIDEORTP_mpegProgramTableStream_t;

    /**
     * @brief Prepares a stream containing a program map table
     * @public @memberof VIDEORTP_mpegProgramTableStream_t
     *
     * @param stream Instance this function works on
     * @param config Stream configuration
     * @return Pointer to the output pipeline stage which should be connected to the next stage.
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_initProgramMapTableStream(VIDEORTP_mpegProgramTableStream_t* stream,
                                                                   const VIDEORTP_mpegProgramTableStreamConfig_t* config);
    /**
     * @brief Prepares a stream containing a program association table
     * @public @memberof VIDEORTP_mpegProgramTableStream_t
     *
     * @param stream Instance this function works on
     * @param config Stream configuration
     * @return Pointer to the output pipeline stage which should be connected to the next stage.
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_initProgramAssociationTableStream(VIDEORTP_mpegProgramTableStream_t* stream,
                                                                           const VIDEORTP_mpegProgramTableStreamConfig_t* config);
    /**
     * @brief Cyclically checks if the program table is to be transmitted again
     * @public @memberof VIDEORTP_mpegProgramTableStream_t
     *
     * @param stream Instance this function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicProgramTableStream(VIDEORTP_mpegProgramTableStream_t* stream, uint32_t timeSinceLastCall);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
