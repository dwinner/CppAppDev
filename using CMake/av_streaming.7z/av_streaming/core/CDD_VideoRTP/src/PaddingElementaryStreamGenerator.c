/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "PaddingElementaryStreamGenerator.h"
#include <assert.h>

static size_t VIDEORTP_padPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData);
static void VIDEORTP_padCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer);

/* ===========================================================================
 *
 *   Name:       VIDEORTP_padInit
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_paddingElementaryStreamGenerator_t* self: pointer to the instance
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-447
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_padInit(VIDEORTP_paddingElementaryStreamGenerator_t* self)
{
    assert(self);

    self->base.prepareNextChunk = VIDEORTP_padPrepareNextChunk;
    self->base.copyChunk = VIDEORTP_padCopyChunk;
    self->padding = 0;
    self->chunkSize = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_padPrepareNextChunk
 *
 *   Function:   Validate requested size of chunk
 *
 *   Inputs:
 *               VIDEORTP_PayloadProvider_t* vtable: pointer to the instance of VIDEORTP_PayloadGate_t
 *               size_t maximumSize:  maximum available space of destination buffer
 *               VIDEORTP_PayloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t : size of next chunk
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-447
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_paddingElementaryStreamGenerator_t */
static size_t VIDEORTP_padPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_paddingElementaryStreamGenerator_t* self = (VIDEORTP_paddingElementaryStreamGenerator_t*) ((void*) vtable);
    size_t result = 0;

    /*
      If less padding than requested is remaining, return 0 (copy nothing).
        * Avoid generating too much padding
      If less padding than the minimum PES header size is remaining, return 0 (copy nothing).
        * Avoid fragmenting packets
    */
    if (maximumSize <= self->padding && maximumSize >= VIDEORTP_PES_MIN_SIZE)
    {
        result = maximumSize;
        VIDEORTP_initPayloadChunkInfo(metaData, 0, maximumSize, maximumSize);
    }

    self->chunkSize = result;

    return result;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_padCopyChunk
 *
 *   Function:   Write PES packet header and padding bytes
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: pointer to the instance of VIDEORTP_PayloadGate_t
 *               VIDEORTP_BufferWriter_t* payloadBuffer: destination VIDEORTP_BufferWriter_t
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-447
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_paddingElementaryStreamGenerator_t */
static void VIDEORTP_padCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_paddingElementaryStreamGenerator_t* self = (VIDEORTP_paddingElementaryStreamGenerator_t*) ((void*) vtable);

    assert(self->padding >= self->chunkSize);

    /* Write packet_start_code_prefix */
    VIDEORTP_bufWriteInteger(payloadBuffer, VIDEORTP_PES_START_CODE_PREFIX, VIDEORTP_PES_START_CODE_PREFIX_SIZE);
    /* Write stream_id */
    VIDEORTP_bufWriteInteger(payloadBuffer, VIDEORTP_PES_PADDING_STREAM, VIDEORTP_PES_STREAM_ID_SIZE);
    /* Write PES_packet_length */
    const size_t payloadLength = self->chunkSize - VIDEORTP_PES_HEADER_SIZE;
    VIDEORTP_bufWriteInteger(payloadBuffer, payloadLength, VIDEORTP_PES_LENGTH_SIZE);
    /* Write payload */
    VIDEORTP_bufWritePattern(payloadBuffer, VIDEORTP_PATTERN, payloadLength);

    self->padding -= self->chunkSize;
}
