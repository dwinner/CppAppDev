/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "TimestampGenerator.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tgenCalculateTimestamp
 *
 *   Function:   Calculate timestamp with VIDEORTP_timestampGenerator_t data
 *
 *   Inputs:
 *               VIDEORTP_timestampGenerator_t* self: The instance of VIDEORTP_timestampGenerator_t
 *
 *   Outputs:
 *               uint64_t the current timetamp
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-219
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
uint64_t VIDEORTP_tgenCalculateTimestamp(VIDEORTP_timestampGenerator_t* self)
{
    assert(self);
    return (self->startTimestamp + ((self->currentPayloadNumber * VIDEORTP_CLOCK_RATE) / self->framerate));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tgenPrepareNextChunk
 *
 *   Function:   Return next chunk size
 *               Сall VIDEORTP_pipePrepareNextChunk for the predecessor.
 *               self->isPayloadUnitEnd = metaData->isPayloadUnitEnd.
 *               Replace the timestamp in the metadata.
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: The instance of VIDEORTP_payloadProvider_t
 *               size_t maximumSize: Maximum available space of destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metaData: Meta data about packet data
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-219
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_timestampGenerator_t */
static size_t VIDEORTP_tgenPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                            VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_timestampGenerator_t* self = (VIDEORTP_timestampGenerator_t*) ((void*) vtable);

    size_t nextChunkSize = 0;
    if (self->base != NULL)
    {
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(self->base, maximumSize, metaData);
        if (nextChunkSize > 0)
        {
            self->isPayloadUnitEnd = metaData->isPayloadUnitEnd;
            metaData->sampleTimestamp = VIDEORTP_tgenCalculateTimestamp(self);
        }
    }
    return nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tgenCopyChunk
 *
 *   Function:   Copy data to the destination buffer with payloadBuffer
 *               Increases self->currentPayloadNumber if the last byte was copied from predecessor
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: The instance of VIDEORTP_payloadProvider_t
 *               VIDEORTP_bufferWriter_t* payloadBuffer: Destination buffer writer
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-219
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_timestampGenerator_t */
static void VIDEORTP_tgenCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_timestampGenerator_t* self = (VIDEORTP_timestampGenerator_t*) ((void*) vtable);

    if (self->base != NULL)
    {
        VIDEORTP_pipeCopyChunk(self->base, payloadBuffer);
        /* Increment the timestamp for the next frame or payload unit */
        if (self->isPayloadUnitEnd)
        {
            self->currentPayloadNumber++;
        }
    }
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_tgenInit
 *
 *   Function:   Initialize VIDEORTP_timestampGenerator_t instance
 *
 *   Inputs:
 *               VIDEORTP_timestampGenerator_t* self: The instance of VIDEORTP_timestampGenerator_t
 *               uint64_t timestamp: Initial timestamp of the first payload unit
 *               uint64_t framerate: Frame frequency
 *               VIDEORTP_payloadProvider_t* predecessor: Previous pipeline stage
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-219
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_tgenInit(VIDEORTP_timestampGenerator_t* self, uint64_t timestamp, uint64_t framerate,
                       VIDEORTP_payloadProvider_t* predecessor)
{
    assert(self);
    assert(predecessor);

    self->vtable.prepareNextChunk = VIDEORTP_tgenPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_tgenCopyChunk;

    self->currentPayloadNumber = 0;
    self->framerate = framerate;
    self->startTimestamp = timestamp;
    self->isPayloadUnitEnd = false;
    self->base = predecessor;
}
