/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "RtpPacketizer.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpHeaderBuilder_t_Init
 *
 *   Function:   It shall initialize VIDEORTP_rtpHeaderBuilder_t_Init
 *
 *   Inputs:
 *               VIDEORTP_rtpHeaderBuilder_t* self: VIDEORTP_rtpHeaderBuilder_t instance that the function works on
 *               VIDEORTP_rtcpSessionConfiguration_t* config: VIDEORTP_rtcpSessionConfiguration_t instance for RTCP data
 *               uint16_t sequenceNumber: uses as internal counter
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-123
 *
 *   Traceability to SW Req: 16802568, 16805601, 16805694
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_rtpHeaderBuilderInit(VIDEORTP_rtpHeaderBuilder_t* self, const VIDEORTP_rtcpSessionConfiguration_t* config)
{
    assert(self);
    assert(config);
    self->config = config;
    self->nextSequenceNumber = config->initialSequenceCounter;
    VIDEORTP_initPayloadChunkInfo(&self->metaDataAccumulator, 0, 0, VIDEORTP_RTP_HEADER_SIZE);
    self->lastValidTimestamp.mpegPresentationTimestamp = VIDEORTP_InvalidTimestamp;
    self->lastValidTimestamp.mpegDecodingTimestamp = VIDEORTP_InvalidTimestamp;
    self->lastValidTimestamp.gptpTimestamp = 0;
    self->lastValidTimestamp.gptpTimeBaseIndicator = 0;

    switch (self->config->streamingMode)
    {
        case VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS:
        case VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS:
            self->markerBitFlag = VIDEORTP_RTCP_IP_AVT_MARKER_BIT;
            break;
        /* case VIDEORTP_rtpStreamingMode_RFC2250: */
        default:
            self->markerBitFlag = VIDEORTP_RTCP_RFC2250_MARKER_BIT;
            break;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpGetPacketTimestamp
 *
 *   Function:   Return the RTP timestamp of the last RTP packet header
 *
 *   Inputs:
 *               VIDEORTP_rtpHeaderBuilder_t* self: VIDEORTP_rtpHeaderBuilder_t instance that the function works on
 *
 *   Outputs:
 *               RTP timestamp of the last RTP packet header
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-770, MAGAVSTR-811
 *
 *   Traceability to SW Req: 16802568, 16805566, 16805598, 16805601,
 * 16805694
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_timestamp VIDEORTP_rtpGetPacketTimestamp(VIDEORTP_rtpHeaderBuilder_t* self)
{
    assert(self);

    VIDEORTP_timestamp result;

    /* Get timestamp for RTP packet */
    if (self->metaDataAccumulator.sampleTimestamp.mpegPresentationTimestamp == VIDEORTP_InvalidTimestamp)
    {
        /* fall back to timestamp of previous packet */
        result = self->lastValidTimestamp;
    }
    else
    {
        /* use first timestamp of current packet */
        result = self->metaDataAccumulator.sampleTimestamp;
    }

    /* Add initial timestamp to let the RTP timestamps start at a "random" or configured value.
     * For consistency, convert it from 90kHz RTP clock to 27MHz MPEG clock,
     * even though the caller probably will want to convert it back immediately. */
    uint64_t offset = (uint64_t) self->config->initialTimestamp * UINT64_C(300);
    result.mpegPresentationTimestamp += offset;
    result.mpegDecodingTimestamp += offset;

    return result;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpPacketizer_Init
 *
 *   Function:   It shall initialize VIDEORTP_rtpPacketizer_Init
 *
 *   Inputs:
 *               VIDEORTP_rtpPaketizer_t* self: VIDEORTP_rtpPaketizer_t instance that the function works on
 *               VIDEORTP_payloadProvider_t* predecessor: Contains previous data of the pipeline
 *               VIDEORTP_rtcpSessionConfiguration_t* config: VIDEORTP_rtcpSessionConfiguration_t instance for RTCP data
 *               uint16_t sequenceNumber: contains the sequence number
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-123
 *
 *   Traceability to SW Req: 16802568
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_rtpPacketizerInit(VIDEORTP_rtpPaketizer_t* self, VIDEORTP_payloadProvider_t* predecessor,
                                const VIDEORTP_rtcpSessionConfiguration_t* config)
{
    assert(self);
    assert(predecessor);
    assert(config);

    VIDEORTP_rtpHeaderBuilderInit(&(self->headerBuilder), config);
    self->predecessor = predecessor;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpBuildHeader
 *
 *   Function:   It shall write RTP header into packet buffer.
 *
 *   Inputs:
 *               VIDEORTP_rtpHeaderBuilder_t* self: self contains the structure of VIDEORTP_rtpHeaderBuilder_t
 *               BufferWriter* self: BufferWriter instance that the function works on
 *
 *   Outputs:
 *              void: all data is written by pointer to input parameter
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-123
 *
 *   Traceability to SW Req: 16802568, 16805566, 16805598, 16805601, 16805617, 16805694
 *
 *   Remarks:
 *	RTP header format (https://www.rfc-editor.org/rfc/rfc3550.html#section-5.1, ch 5.1):
 *	version(V), 2 bits, V=2
 *   padding(P), 1 bit, P=0 - NOT USED
 *	extension(X), 1 bit, X=0 - NOT USED
 *	CSRC count (CC), 4 bits, CSRC count = 0 - NOT USED
 *	marker(M), 1 bit
 *	payload type(PT), 7 bits = 33
 *	sequence number, 16 bits
 *	timestamp: 32 bits
 *	SSRC, 32 bits
 *	CSRC list, 0 to 15 items, 32 bits each - NOT USED
 *   Filling of all parameters done according the ticket https://schleissheimer.atlassian.net/browse/MAGAVSTR-410
 *
 * ========================================================================= */
void VIDEORTP_rtpBuildHeader(VIDEORTP_rtpHeaderBuilder_t* self, VIDEORTP_bufferWriter_t* buffer)
{
    assert(self);
    assert(buffer);

    /* Store the current timestamp as fallback for the following packets (just in case they do not include a timestamp). */
    if (self->metaDataAccumulator.sampleTimestamp.mpegPresentationTimestamp != VIDEORTP_InvalidTimestamp)
    {
        self->lastValidTimestamp = self->metaDataAccumulator.sampleTimestamp;
    }

    /*8 bites: (header_V_P_X_CC << 4) | (0x0F & header_CSRC) */
    /*headerVPXCC = 0x80 | headerCSRC = 0x00*/
    VIDEORTP_bufWriteInteger(buffer, (uint8_t) 0x80 | (uint8_t) 0x00, sizeof(uint8_t));

    /* (headerM=0x00 << 7) | (headerPT=0x7F & headerPT) */
    /* In mode RFC2250 for first value: VIDEORTP_bufWriteInteger(buffer, (0x01 << 7) | (0x7F & 0x33), sizeof(uint8_t)); */
    /* In mode RFC2250 for other values: VIDEORTP_bufWriteInteger(buffer, (0x00 << 7) | (0x7F & 0x33), sizeof(uint8_t)); */
    /* In mode VW LAH IP_AVT for any value: VIDEORTP_bufWriteInteger(buffer, (0x00 << 7) | (0x7F & 0x7F), sizeof(uint8_t)); */
    VIDEORTP_bufWriteInteger(buffer, (self->markerBitFlag << 7) | (0x7F & self->config->payloadType), sizeof(uint8_t));
    /* For VW LAH IP_AVT marker bit is always 0 because MPEG-TS packets will not be fragmented.
     * For RFC2250 marker bit is equal 1 on first RTP packet only because there is a discontinuity. */
    if (self->markerBitFlag == 1)
    {
        self->markerBitFlag = 0;
    }

    /* Sequence number: 16 bits */
    /* In case of max number will automatically shift to 0 */
    VIDEORTP_bufWriteInteger(buffer, self->nextSequenceNumber++, sizeof(uint16_t));

    /*RTP timestamp: 32 bits */
    VIDEORTP_timestamp timestamp = VIDEORTP_rtpGetPacketTimestamp(self);
    uint64_t rtpTimestamp = timestamp.mpegPresentationTimestamp / UINT64_C(300); /* Convert from 27 MHz to 90 kHz as per RFC3551 */
    VIDEORTP_bufWriteInteger(buffer, rtpTimestamp, sizeof(uint32_t));

    /*SSRC */
    VIDEORTP_bufWriteData(buffer, self->config->ssrc, sizeof(self->config->ssrc));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpAddPacketMetaData
 *
 *   Function:   Store the last valid timestamp
 *
 *   Inputs:
 *               VIDEORTP_rtpPaketizer_t* self: This instance containing the last known timestamp
 *               const VIDEORTP_payloadChunkInfo_t* tempMetaData: Metadata of the next TS packet to extract the timestamp from
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-123
 *
 *   Traceability to SW Req: 16802568, 16805566, 16805601, 16805694
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_rtpAddPacketMetaData(VIDEORTP_rtpHeaderBuilder_t* self, const VIDEORTP_payloadChunkInfo_t* tempMetaData)
{
    if (self->metaDataAccumulator.sampleTimestamp.mpegPresentationTimestamp == VIDEORTP_InvalidTimestamp)
    {
        self->metaDataAccumulator = *tempMetaData;
    }
    else
    {
        self->lastValidTimestamp = self->metaDataAccumulator.sampleTimestamp;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtpBuildPacket
 *
 *   Function:   It shall prepare memory for the header of rtp and pack tc packages into rtp package
 *
 *   Inputs:
 *               VIDEORTP_rtpPaketizer_t* self: self contains all data and virtual methods for RTP
 *               VIDEORTP_bufferWriter_t* packetBuffer: packetBuffer provides BufferWriter
 *
 *   Outputs:
 *              VideoRTP_errorCode
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-123, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16802568, 16805566, 16805601, 16805605, 16805614, 16805620, 16805694, 16805717, 16805917
 *
 *   Remarks:
 *
 * ========================================================================= */
/**
 * brief prepare and write RTP packet into BufferWriter
 *
 * param packetBuffer buffer where provided BufferWriter
 */
VideoRTP_errorCode VIDEORTP_rtpBuildPacket(VIDEORTP_rtpPaketizer_t* self, VIDEORTP_bufferWriter_t* packetBuffer)
{
    assert(self);
    assert(packetBuffer);
    VideoRTP_errorCode err = VideoRTP_ok;

    /* According RTP fixed header fields it shall return the expected size of the RTP header*/
    /* uint8_t = 8 bits, RTP header length (CSRC list count = 0 ) 96 bits / 12 uint8_t */
    size_t rtpHeaderSize = VIDEORTP_RTP_HEADER_SIZE;
    if (packetBuffer->capacity >= rtpHeaderSize)
    {
        /* from packetBuffer to headerWriter */
        VIDEORTP_bufferWriter_t child = VIDEORTP_bufSpawnChildWriter(packetBuffer, rtpHeaderSize);

        size_t availableSpace = VIDEORTP_bufGetAvailableSpace(packetBuffer);

        /* Check if at least one TS packet is available */
        size_t chunkSize
            = VIDEORTP_pipePrepareNextChunk(self->predecessor, availableSpace, &(self->headerBuilder.metaDataAccumulator));
        if (chunkSize > (size_t) 0)
        {
            for (;;)
            {
                /* Copy TS packet */
                VIDEORTP_pipeCopyChunk(self->predecessor, packetBuffer);
                availableSpace = VIDEORTP_bufGetAvailableSpace(packetBuffer);

                /* Check if another TS packet is available */
                VIDEORTP_payloadChunkInfo_t tempMetaData;
                chunkSize = VIDEORTP_pipePrepareNextChunk(self->predecessor, availableSpace, &tempMetaData);
                assert(chunkSize <= availableSpace);
                if (chunkSize == (size_t) 0)
                {
                    /* This was the last TS packet */
                    break;
                }
                VIDEORTP_rtpAddPacketMetaData(&self->headerBuilder, &tempMetaData);
            }

            VIDEORTP_rtpBuildHeader(&(self->headerBuilder), &child);
        }
        else
        {
            err = VideoRTP_queueEmpty;
        }
    }
    else
    {
        err = VideoRTP_error;
    }
    return err;
}
