/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "crc32_mpeg2.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Defines
 *
 * ========================================================================= */

/** Flag for generate table */
static bool VIDEORTP_CRC32IsTableGenerated = false;
/** Array containing crc32/mpeg2 values */
static uint32_t VIDEORTP_CRC32Table[256];

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_CRC32generateTable
 *
 *   Function:   It generate table with crc32/mpeg2 values
 *               Fill VIDEORTP_CRC32Table and set VIDEORTP_CRC32IsTableGenerated to true
 *
 *   Inputs:
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-651 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: Table size 1Kb, but it faster then calculate crc when it need
 *
 * ========================================================================= */
static void VIDEORTP_CRC32generateTable()
{
    for (uint32_t i = 0; i < 256; i++)
    {
        uint32_t crc = i << 24;
        for (uint32_t j = 0; j < 8; j++)
        {
            /* Check first bit */
            if (crc >> 31)
            {
                crc = (crc << 1) ^ VIDEORTP_MPEG2_CRC_POLYNOM;
            }
            else
            {
                crc = (crc << 1);
            }
        }
        VIDEORTP_CRC32Table[i] = crc;
    }

    VIDEORTP_CRC32IsTableGenerated = true;
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_CRC32calculate
 *
 *   Function:   Calculate CRC32/MPEG2 checksum
 *
 *   Inputs:
 *               uint8_t *buf: data for which to calculate crc
 *               size_t len: size of data
 *
 *   Outputs:
 *               uint32_t crc: calculated crc
 *
 *   Side Effects: Calculates a CRC32/MPEG2 checksum using a pregenerated table.
 *                 The table will be generated automatically on the first call.
 *                 This is not reentrant/thread-safe until the first call has completed.
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-651 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
uint32_t VIDEORTP_CRC32calculate(const void* buf, size_t len)
{
    assert(buf);

    if (!VIDEORTP_CRC32IsTableGenerated)
    {
        VIDEORTP_CRC32generateTable();
    }
    uint32_t crc = VIDEORTP_MPEG2_CRC_INIT;

    const uint8_t* _buf = (const uint8_t*) buf;
    while (len--)
    {
        uint32_t index_in_table = (((uint8_t) (crc >> 24)) ^ (*(_buf++))) & 0xFF;
        crc = (crc << 8) ^ VIDEORTP_CRC32Table[index_in_table];
    }

    crc ^= VIDEORTP_MPEG2_CRC_XOR_OUT;
    return crc;
}
