/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "PayloadGate.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_gatePrepareNextChunk
 *
 *   Function:   Forward call to predecessor if gate is enabled.
 *
 *   Inputs:
 *               VIDEORTP_PayloadProvider_t* vtable: pointer to the instance of VIDEORTP_PayloadGate_t
 *               size_t maximumSize:  maximum available space of destination buffer
 *               VIDEORTP_PayloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t : size of next chunk
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-89
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadGate_t */
static size_t VIDEORTP_gatePrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                            VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_payloadGate_t* self = (VIDEORTP_payloadGate_t*) ((void*) vtable);
    size_t result = 0;

    if (self->enabled && self->predecessor)
    {
        result = VIDEORTP_pipePrepareNextChunk(self->predecessor, maximumSize, metaData);
        if (result > 0)
        {
            self->lastChunk = metaData->isPayloadUnitEnd;
        }
    }

    return result;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_gateCopyChunk
 *
 *   Function:   Forward call to predecessor if gate is enabled.
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: pointer to the instance of VIDEORTP_PayloadGate_t
 *               VIDEORTP_BufferWriter_t* payloadBuffer: destination VIDEORTP_BufferWriter_t
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-89
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadGate_t */
static void VIDEORTP_gateCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_payloadGate_t* self = (VIDEORTP_payloadGate_t*) ((void*) vtable);

    if (self->enabled && self->predecessor)
    {
        VIDEORTP_pipeCopyChunk(self->predecessor, payloadBuffer);

        if (self->lastChunk)
        {
            self->enabled = false;
            self->lastChunk = false;
        }
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_gateInit
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_PayloadGate_t* self: VIDEORTP_PayloadGate_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-89
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_gateInit(VIDEORTP_payloadGate_t* self, VIDEORTP_payloadProvider_t* predecessor)
{
    assert(self);
    assert(predecessor);

    self->base.prepareNextChunk = VIDEORTP_gatePrepareNextChunk;
    self->base.copyChunk = VIDEORTP_gateCopyChunk;
    self->predecessor = predecessor;
    self->enabled = false;
    self->lastChunk = false;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_gateEnable
 *
 *   Function:   Enable gate stage of pipeline
 *
 *   Inputs:
 *               VIDEORTP_PayloadGate_t* self: VIDEORTP_PayloadGate_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-89
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_gateEnable(VIDEORTP_payloadGate_t* self)
{
    assert(self);

    self->enabled = true;
}
