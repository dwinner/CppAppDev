#ifndef TEST_NOLOOP_H264_BIN_H
#define TEST_NOLOOP_H264_BIN_H

#ifdef __cplusplus
extern "C"
{
#endif

#include "PayloadUnitSequenceRepeater.h"
#include <stdint.h>

#define VIDEORTP_PAYLOAD_UNIT_COUNT 145

    extern struct VIDEORTP_payloadUnit_t VIDEORTP_payloadUnits[VIDEORTP_PAYLOAD_UNIT_COUNT];

#ifdef __cplusplus
};
#endif

#endif
