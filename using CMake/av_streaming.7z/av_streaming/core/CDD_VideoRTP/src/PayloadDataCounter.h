#ifndef PAYLOAD_DATA_CONTER_H
#define PAYLOAD_DATA_CONTER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "PayloadProvider.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup PayloadDataCounter
     * @{
     * @brief Counts the number of bytes produced by a pipeline stage.
     *
     * This pipeline stage accumulates all data. It forwards all data from its predecessor without
     * modification and not produce any data by itself.
     *
     * This stage is useful to measure the actual bandwidth needed by a stream.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief The structure contains the count of data written from the predecessor to the destination
     * @implements VIDEORTP_payloadProvider_t
     *
     * @see PayloadDataCounter
     */
    typedef struct VIDEORTP_payloadDataCounter_t
    {
        /** @privatesection @{ */
        /** @brief Implement VIDEORTP_payloadProvider_t interface */
        VIDEORTP_payloadProvider_t vtable;
        /** @brief Predecessor pipeline stage */
        VIDEORTP_payloadProvider_t* base;
        /** @brief Numbers of written bytes by predecessor */
        size_t counter;
        /** @} */
    } VIDEORTP_payloadDataCounter_t;

    /* ===========================================================================
     *
     *  Public Defines
     *
     * ========================================================================= */

    /**
     * @brief Initialize the VIDEORTP_payloadDataCounter_t instance
     * @public @memberof VIDEORTP_payloadDataCounter_t
     *
     * @param self Instance of VIDEORTP_payloadDataCounter_t
     * @param predecessor Previous pipeline stage
     */
    void VIDEORTP_cntInit(VIDEORTP_payloadDataCounter_t* self, VIDEORTP_payloadProvider_t* predecessor);

    /**
     * @brief Reset data counter
     * @public @memberof VIDEORTP_payloadDataCounter_t
     *
     * @param self Instance of VIDEORTP_payloadDataCounter_t
     */
    void VIDEORTP_cntResetCounter(VIDEORTP_payloadDataCounter_t* self);

    /**
     * @brief Return data counter
     * @public @memberof VIDEORTP_payloadDataCounter_t
     *
     * @param self Instance of VIDEORTP_payloadDataCounter_t
     * @return Number of bytes transferred since the last reset
     */
    size_t VIDEORTP_cntGetCounter(VIDEORTP_payloadDataCounter_t* self);

/**@} PayloadDataCounter global */
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PAYLOAD_DATA_CONTER_H */
