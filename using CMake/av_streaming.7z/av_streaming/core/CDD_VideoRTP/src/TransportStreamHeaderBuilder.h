#ifndef TRANSPORT_STREAM_HEADER_BUILDER_H
#define TRANSPORT_STREAM_HEADER_BUILDER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ConstantsMPEG.h"

#include "BufferWriter.h"
#include "PayloadProvider.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup TransportStreamHeaderBuilder
     * @{
     * @brief Builds a TS packet header including stuffing/padding.
     *
     * TransportStreamHeaderBuilder builds a MPEG TS packet header according to a set of rules.
     * It needs to be instantiated once for each MPEG TS stream (stream specific state).
     * If requested so by calling @ref VIDEORTP_tsInjectPcr "injectPcr", it includes a PCR
     * (program reference clock) as soon as it is allowed.
     * It also maintains the continuity counter including proper overflow handling.
     *
     * If the data being added by the previous stage is too short to fill the entire buffer
     * space being offered (e.g., last packet for a picture frame), stuffing is added. By
     * this a constant packet length as required by MPEG TS can be achieved.
     *
     * Since the TransportStreamHeaderBuilder contains the exclusive knowledge about whether
     * the PCR needs to be added, the minimum header size must be queried using
     * @ref VIDEORTP_tsGetMinimumHeaderSize "getMinimumHeaderSize" to get a reliable answer
     * (e.g., when the following pipeline stage needs to reserve memory).
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Struct contains data for building TS header
     *
     * @see TransportStreamPacketizer
     */
    typedef struct VIDEORTP_transportStreamHeaderBuilder_t
    {
        /** @privatesection @{ */
        /** Program ID */
        uint16_t pid;
        /** Flag by start packet data */
        bool payloadUnitStartIndicator;
        /** PCR field */
        uint64_t nextProgramClockReference;
        /** Counter to determine when a PCR may be included */
        uint8_t timestampPacketCounter;
        /** Continuity counter */
        uint8_t continuityCounter;
        /** @} */
    } VIDEORTP_transportStreamHeaderBuilder_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_transportStreamHeaderBuilder_t instance
     * @public @memberof VIDEORTP_transportStreamHeaderBuilder_t
     *
     * @param self The instance of VIDEORTP_transportStreamHeaderBuilder_t
     * @param pid Program ID
     */
    void VIDEORTP_tsInitHeaderBuilder(VIDEORTP_transportStreamHeaderBuilder_t* self, uint16_t pid);

    /**
     * @brief It shall calculate and return minimum size of TS header
     * @public @memberof VIDEORTP_transportStreamHeaderBuilder_t
     *
     * Check can this packet include PCR by next conditions:
     * - PID value is accepted for PCR
     * - timestamp % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD == 0
     * - PCR is alid value
     *
     * size is taken into account follow fields:
     * - syncByte (uint8_t)
     * - PID (uint16_t)
     * - scrambled, adaptationFieldContorl, continuityCounter (2 bits + 2 bits + 4 bits = uint8_t)
     * result is 4 bytes
     *
     * if can include PCR added:
     * - adapTationFieldLength (uint8_t)
     * - discontinuityIndicator, random_access_indicator, elementary_stream_priority_indicator,
     *   PCR_flag, OPCR_flag, splicing_point_flag, transport_private_data_flag, adaptationFieldExtensionFlag (every is 1 bit =
     * uint8_t)
     * - programClockReferenceBase, reserved, programClockReferenceExtension (33 bits + 6 bits + 9 bits = 6 bytes)
     * result is 8 bytes + previous 4 bytes = 12 bytes
     *
     * @param self The instance of VIDEORTP_transportStreamHeaderBuilder_t
     * @return size_t 12 if can include PCR
     * @return size_t 4 if can not include PCR
     */
    size_t VIDEORTP_tsGetMinimumHeaderSize(VIDEORTP_transportStreamHeaderBuilder_t* self);

    /**
     * @brief Set self->payloadUnitStartIndicator from medatata
     * @public @memberof VIDEORTP_transportStreamHeaderBuilder_t
     *
     * @param self The instance of VIDEORTP_transportStreamHeaderBuilder_t
     * @param metadata Metadata about packet
     */
    void VIDEORTP_tsSetPacketMetaData(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_payloadChunkInfo_t* metadata);

    /**
     * @brief Build TS header according with H.222 with necessary fields
     * @public @memberof VIDEORTP_transportStreamHeaderBuilder_t
     *
     * Check can packet include PCR and fill header
     *
     * If can include PCR will be written full adaptation field
     * Else if the writer has space left, it will be filled with stuffing
     *
     * If packet include adaptation_field self->continuityCounter will be incremented
     * For each packet self->timestampPacketCounter will increase
     *
     * Check self->continuityCounter and reset every 16th increasing (every 16th packet)
     * Check self->timestampPacketCounter and reset every 6th increasing (every 6th packet)
     *
     * @param self The instance of VIDEORTP_transportStreamHeaderBuilder_t
     * @param buffer Writer for destination buffer
     */
    void VIDEORTP_tsBuildHeader(VIDEORTP_transportStreamHeaderBuilder_t* self, VIDEORTP_bufferWriter_t* buffer);

    /**
     * @brief Calculate PCR for header and store in self->nextProgramClockReference
     * @public @memberof VIDEORTP_transportStreamHeaderBuilder_t
     *
     * Calculate PCR and remember it to self->nextProgramClockReference
     * Must be called only for specific PIDs (see H.222, table 2-3, note 1)
     *
     * @param self The instance of VIDEORTP_transportStreamHeaderBuilder_t
     * @param timestamp Generated timestamp for PCR calculation
     */
    void VIDEORTP_tsInjectPcr(VIDEORTP_transportStreamHeaderBuilder_t* self, uint64_t timestamp);

    /**@} TransportStreamPacketizer global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TRANSPORT_STREAM_HEADER_BUILDER_H */
