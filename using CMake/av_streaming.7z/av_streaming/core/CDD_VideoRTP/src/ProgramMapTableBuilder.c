/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ProgramMapTableBuilder.h"
#include "crc32_mpeg2.h"
#include <assert.h>
#include <string.h>

/* ===========================================================================
 *
 *   Private Function Prototypes
 *
 * ========================================================================= */

static VIDEORTP_pmt_t VIDEORTP_pmtCreateEmptyTable(uint16_t programNumber, uint8_t versionNumber, uint16_t pcrPID);
/**
 * @brief Calculate PMT section length
 * @private @memberof VIDEORTP_programMapTableBuilder_t
 *
 * @param self VIDEORTP_programMapTableBuilder_t instance that the function works on
 *
 * @return uint16_t
 */
static uint16_t VIDEORTP_pmtGetSectionLength(VIDEORTP_programMapTableBuilder_t* self);

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtInit
 *
 *   Function:   Init self. It fill all possible self fields on init stage using destBW
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint16_t programId : Program ID as specified in the Program Association Table
 *               uint16_t pcrPID: PID of an elementary stream which carries the program clock reference (PCR) for this program
 *               VIDEORTP_bufferWriter_t* destBW: destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: pid size must be 13 bits
 *
 * ========================================================================= */
void VIDEORTP_pmtInit(VIDEORTP_programMapTableBuilder_t* self, uint16_t programId, uint16_t pcrPID, VIDEORTP_bufferWriter_t* destBW)
{
    assert(self);
    assert(destBW);

    self->section = destBW;
    self->pmt = VIDEORTP_pmtCreateEmptyTable(programId, 0, VIDEORTP_PCR_PID_PMT);

    VIDEORTP_bufferWriter_t* section = self->section;

    /* TS_program_map_section on H.222 */
    uint8_t table_id = VIDEORTP_PMT_TABLE_ID;
    VIDEORTP_bufWriteInteger(section, table_id, sizeof(table_id));

    /* spawn child for section length field */
    self->lengthField = VIDEORTP_bufSpawnChildWriter(section, sizeof(uint16_t));

    VIDEORTP_bufWriteInteger(section, self->pmt.programNumber, sizeof(self->pmt.programNumber));

    /* fill 2 reserved bits, version number to 0 and current_next_indicator to 1 */
    uint8_t version_number_and_current_next_indicator = 0xC1;
    VIDEORTP_bufWriteInteger(section, version_number_and_current_next_indicator, sizeof(version_number_and_current_next_indicator));

    /* always zero on H.222 */
    uint8_t section_number = 0x00;
    VIDEORTP_bufWriteInteger(section, section_number, sizeof(section_number));
    /* always zero on H.222 */
    uint8_t last_section_number = 0x00;
    VIDEORTP_bufWriteInteger(section, last_section_number, sizeof(last_section_number));

    /* fill 3 bits reserved and PCR_PID */
    uint16_t pcr = 0xE000 | (0xEFFF & pcrPID);
    VIDEORTP_bufWriteInteger(section, pcr, sizeof(uint16_t));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtAddElementaryStreamPid
 *
 *   Function:   It shall create and elementary stream to current pmt
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint16_t pid: valid range 0..0x1FFF
 *               uint8_t streamType: type of elementary stream
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: pid size must be 13 bits
 *
 * ========================================================================= */
void VIDEORTP_pmtAddElementaryStreamPid(VIDEORTP_programMapTableBuilder_t* self, uint16_t pid, uint8_t streamType)
{
    assert(self);

    if (self->pmt.numStreams < self->pmt.streamsSize)
    {
        VIDEORTP_pmtStream_t stream = { /* stream type */
                                        streamType,
                                        /* reserved */
                                        1,
                                        /* elementaryPID */
                                        pid,
                                        /* reserved */
                                        1,
                                        /* infoLength */
                                        0,
                                        /* info */
                                        { 0 }
        };

        self->pmt.streams[self->pmt.numStreams] = stream;
        self->pmt.numStreams++;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtFinalize
 *
 *   Function:   It shall write current pmt data using destination VIDEORTP_bufferWriter_t
 *
 *   Inputs:
 *               uint16_t pid: valid range 0..0x1FFF
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: All reserved bits are set to 1
 *            It write section_syntax_indicator, section length.
 *            Also write program_info_length, info, streams and them data.
 *            Add CRC_32 to end.
 *
 *            table_id, program_nuber, versionNumber, current_next_indicator, section_number, last_section_number, PCR_PID wrote by
 * constructor;
 *
 * ========================================================================= */
void VIDEORTP_pmtFinalize(VIDEORTP_programMapTableBuilder_t* self)
{
    assert(self);
    VIDEORTP_bufferWriter_t* lengthField = &(self->lengthField);
    VIDEORTP_bufferWriter_t* section = self->section;
    uint16_t section_length = VIDEORTP_pmtGetSectionLength(self);
    if (section_length != 0)
    {
        /* section_syntax_indicator set to 1 by H.222
        section include into self section_syntax_indicator, zero, reserved 2 bits and 14 bits by section_length */
        VIDEORTP_bufWriteInteger(lengthField, 0xB000 | section_length, sizeof(uint16_t));

        /* fill 4 bits reserverd and 12 bits program_info_length */
        VIDEORTP_bufWriteInteger(section, 0xF000 | self->pmt.infoLength, sizeof(uint16_t));
        /* pmt descriptor */
        VIDEORTP_bufWriteData(section, &self->pmt.info, self->pmt.infoLength);

        for (uint32_t i = 0; i < self->pmt.numStreams; i++)
        {
            VIDEORTP_bufWriteInteger(section, self->pmt.streams[i].streamType, sizeof(self->pmt.streams[i].streamType));
            /* 3 bits reserved and elementaryPID 13 bits */
            VIDEORTP_bufWriteInteger(section, 0xE000 | self->pmt.streams[i].elementaryPID, sizeof(uint16_t));
            /* 4 bits reserved and infoLength 12 bits */
            VIDEORTP_bufWriteInteger(section, 0xF000 | self->pmt.streams[i].infoLength, sizeof(uint16_t));
            VIDEORTP_bufWriteData(section, &(self->pmt.streams[i].info), self->pmt.streams[i].infoLength);
        }

        uint32_t CRC_32
            = VIDEORTP_CRC32calculate((uint8_t*) VIDEORTP_bufGetBasePointer(section), VIDEORTP_bufGetBytesWritten(section));
        VIDEORTP_bufWriteInteger(section, CRC_32, sizeof(CRC_32));
    }
}

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtCreateEmptyTable
 *
 *   Function:   It shall create empy pmt
 *
 *   Inputs:
 *               uint16_t programNumber:
 *               uint8_t versionNumber:
 *               uint16_t pcrPID:
 *
 *   Outputs:
 *               VIDEORTP_pmt_t:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pmt_t */
static VIDEORTP_pmt_t VIDEORTP_pmtCreateEmptyTable(uint16_t programNumber, uint8_t versionNumber, uint16_t pcrPID)
{
    if (pcrPID <= VIDEORTP_PCR_PID_RESERVED_END || pcrPID >= VIDEORTP_PCR_PID_NULL)
    {
        /* This check PCR_PID range */
    }

    VIDEORTP_pmt_t pmt = { programNumber, versionNumber, 0x00, 0x00, pcrPID, 0, { 0 }, VIDEORTP_PMT_MAX_STREAMS_NUMBER, 0, { 0 } };

    return pmt;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtGetSectionLength
 *
 *   Function:   It calculate section lnght field for current pmt
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint8_t* data:
 *               size_t dataSize:
 *
 *   Outputs:
 *               uint32_t:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
uint16_t VIDEORTP_pmtGetSectionLength(VIDEORTP_programMapTableBuilder_t* self)
{
    /* 13 bytes is size of all fields after section length in pmt_section */
    uint32_t sectionLength = sizeof(self->pmt.programNumber) + sizeof(self->pmt.versionNumber) + sizeof(self->pmt.sectionNumber)
        + sizeof(self->pmt.lastSectionNumber) + sizeof(self->pmt.pcrPID) + self->pmt.infoLength + sizeof(uint32_t);
    for (size_t i = 0; i < self->pmt.numStreams; i++)
    {
        /* 5 bytes if size of stream fields */
        sectionLength += 5 + self->pmt.streams[i].infoLength;
    }
    if (sectionLength > VIDEORTP_PMT_SECTION_MAX_LENGTH)
    {
        assert(NULL);
        sectionLength = 0;
    }
    return sectionLength;
}
