/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ProgramMapTableBuilder.h"
#include "crc32_mpeg2.h"
#include <assert.h>
#include <string.h>

/* ===========================================================================
 *
 *   Private Function Prototypes
 *
 * ========================================================================= */
/**
 * @brief Calculate PMT section length
 * @private @memberof VIDEORTP_programMapTableBuilder_t
 *
 * @param self VIDEORTP_programMapTableBuilder_t instance that the function works on
 *
 * @return size_t
 */
static size_t VIDEORTP_pmtGetSectionLength(VIDEORTP_programMapTableBuilder_t* self);

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtInit
 *
 *   Function:   Init self. It fill all possible self fields on init stage using destBW
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint16_t programId : Program ID as specified in the Program Association Table
 *               uint16_t pcrPID: PID of an elementary stream which carries the program clock reference (PCR) for this program
 *               VIDEORTP_bufferWriter_t* destBW: destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-809 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *              pid size must be 13 bits
 *              each reserved bit will be set to 1
 *
 * ========================================================================= */
void VIDEORTP_pmtInit(VIDEORTP_programMapTableBuilder_t* self, uint16_t programId, uint16_t pcrPID, VIDEORTP_bufferWriter_t* destBW)
{
    assert(self);
    assert(destBW);

    self->streamCounter = 0;
    self->section = destBW;

    /* TS_program_map_section on H.222 */
    uint8_t table_id = VIDEORTP_PMT_TABLE_ID;
    VIDEORTP_bufWriteInteger(destBW, table_id, sizeof(table_id));

    /* spawn child for section length field */
    self->lengthField = VIDEORTP_bufSpawnChildWriter(destBW, sizeof(uint16_t));

    VIDEORTP_bufWriteInteger(destBW, programId, sizeof(uint16_t));

    /* fill 2 reserved bits, version number to 0 and current_next_indicator to 1 */
    uint8_t version_number_and_current_next_indicator = UINT8_C(0xC1);
    VIDEORTP_bufWriteInteger(destBW, version_number_and_current_next_indicator, sizeof(version_number_and_current_next_indicator));

    /* always zero on H.222 */
    uint8_t section_number = UINT8_C(0x00);
    VIDEORTP_bufWriteInteger(destBW, section_number, sizeof(section_number));
    /* always zero on H.222 */
    uint8_t last_section_number = UINT8_C(0x00);
    VIDEORTP_bufWriteInteger(destBW, last_section_number, sizeof(last_section_number));

    /* fill 3 bits reserved and PCR_PID */
    uint16_t pcr = UINT16_C(0xE000) | (UINT16_C(0x1FFF) & pcrPID);
    VIDEORTP_bufWriteInteger(destBW, pcr, sizeof(uint16_t));

    /* fill 4 bits reserverd and 12 bits program_info_length, program_info_length == 0 */
    VIDEORTP_bufWriteInteger(destBW, 0xF000, sizeof(uint16_t));
    /* pmt info has zero length, so doesn't necesary to write */
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtAddElementaryStreamPid
 *
 *   Function:   It shall create and elementary stream to current pmt
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint16_t pid: valid range 0..0x1FFF
 *               uint8_t streamType: type of elementary stream
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-809 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *              pid size must be 13 bits
 *              each reserved bit will be set to 1
 *              info always empty therefore
 *
 * ========================================================================= */
void VIDEORTP_pmtAddElementaryStreamPid(VIDEORTP_programMapTableBuilder_t* self, uint16_t pid, uint8_t streamType)
{
    assert(self);

    if (self->streamCounter < VIDEORTP_PMT_MAX_STREAMS_NUMBER)
    {
        self->streamCounter++;

        VIDEORTP_bufWriteInteger(self->section, streamType, sizeof(uint8_t));
        /* 3 bits reserved and elementaryPID 13 bits */
        VIDEORTP_bufWriteInteger(self->section, (uint16_t) 0xE000 | ((uint16_t) 0x1FFF & pid), sizeof(uint16_t));
        /* 4 bits reserved and infoLength 12 bits */
        VIDEORTP_bufWriteInteger(self->section, (uint16_t) 0xF000, sizeof(uint16_t));
        /* info always have zero length, so it is not necessary to write */
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtFinalize
 *
 *   Function:   It shall write current pmt data using destination VIDEORTP_bufferWriter_t
 *
 *   Inputs:
 *               uint16_t pid: valid range 0..0x1FFF
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-809 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks: Each reserved bit will be set to 1
 *            It writes section_length, section_syntax_indicator and CRC_32.
 *
 *            All remaining fields were written with Init function
 *
 * ========================================================================= */
void VIDEORTP_pmtFinalize(VIDEORTP_programMapTableBuilder_t* self)
{
    assert(self);
    VIDEORTP_bufferWriter_t* lengthField = &(self->lengthField);
    size_t section_length = VIDEORTP_pmtGetSectionLength(self);

    /* section_syntax_indicator set to 1 by H.222
    section include into self section_syntax_indicator, zero, reserved 2 bits and 14 bits by section_length */
    VIDEORTP_bufWriteInteger(lengthField, (uint16_t) 0xB000 | section_length, sizeof(uint16_t));
    uint32_t CRC_32
        = VIDEORTP_CRC32calculate((uint8_t*) VIDEORTP_bufGetBasePointer(self->section), VIDEORTP_bufGetBytesWritten(self->section));
    VIDEORTP_bufWriteInteger(self->section, CRC_32, sizeof(CRC_32));
}

/* ===========================================================================
 *
 *   Private Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pmtGetSectionLength
 *
 *   Function:   It calculate section lnght field for current pmt
 *
 *   Inputs:
 *               VIDEORTP_programMapTableBuilder_t* self: VIDEORTP_programMapTableBuilder_t instance that the function works on
 *               uint8_t* data:
 *               size_t dataSize:
 *
 *   Outputs:
 *               size_t:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-77, MAGAVSTR-600, MAGAVSTR-809 <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *              for each stream info length is 0
 *              pmt info length is 0
 *
 * ========================================================================= */
size_t VIDEORTP_pmtGetSectionLength(VIDEORTP_programMapTableBuilder_t* self)
{
    /* Size of all fields after section length in pmt_section
    Constant part:
    2 bytes - program number
    1 byte - version number
    1 bytes - section number
    1 bytes - last section number
    4 bytes - pcrPID
    4 bytes - CRC
    Total: 13 bytes

    Dynamic part:
    streams (for each stream 5 bytes is size of fields)
    pmt info (for this case always 0)
    */
    size_t sectionLength
        = sizeof(uint16_t) + UINT32_C(3) * sizeof(uint8_t) + UINT32_C(2) * sizeof(uint32_t) + UINT32_C(5) * self->streamCounter;
    assert(sectionLength > 0 && sectionLength <= VIDEORTP_PMT_SECTION_MAX_LENGTH);
    return sectionLength;
}
