/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "IPCInputStream.h"
#include "ConstantsOEM.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initIPCInputStream
 *
 *   Function:   The function prepares a pipeline for transferring H264 data from a file
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const VIDEORTP_ipcInputStreamConfig_t* config: configuration settings
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initIPCInputStream(VIDEORTP_ipcInputStream_t* stream,
                                                        const VIDEORTP_ipcInputStreamConfig_t* config)
{
    /* Send first PCR as soon as possible */
    stream->pcrTimer = VIDEORTP_PCR_INTERVAL;
    /* Convert ms to MPEG clock */
    stream->pcrDelay = config->pcrDelay * (VIDEORTP_CLOCK_RATE / 1000);

    VIDEORTP_ipcInit(&stream->ipcFrame);

    VIDEORTP_pesInitPacketizer(&stream->pesPacketizer, &stream->ipcFrame.vtable, config->streamId);

    VIDEORTP_tsInitPacketizer(&stream->tsPacketizer, &stream->pesPacketizer.vtable, config->tsPid);

    return &stream->tsPacketizer.vtable;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initIPCInputStream
 *
 *   Function:   The function deinit inputStream
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcDeinitIPCInputStream(VIDEORTP_ipcInputStream_t* self)
{
    VIDEORTP_ipcDeinit(&self->ipcFrame);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicIPCInputStream
 *
 *   Function:   Cyclically checks if another frame is to be transmitted. Also includes the PCR.
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicIPCInputStream(VIDEORTP_ipcInputStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Inject PCR into next packet */
    if (VIDEORTP_timerTick(&stream->pcrTimer, timeSinceLastCall, VIDEORTP_PCR_INTERVAL))
    {
        /* TODO: Need to get the current system time from StbM! MAGAVSTR-810
         * As a temporary workaround, use the sampling time of the
         * current frame (converted back to 27MHz from 90kHz). */
        // Std_ReturnType ret = StbM_GetCurrentTime(stream->timeBaseId, &stream->timeStamp, &stream->userData);
        // if (ret == E_OK)
        // {
        //     uint64_t pcr = stream->timeStamp.nanoseconds / 1000 + stream->timeStamp.seconds * 1000;
        //     VIDEORTP_tsInjectPcr(&stream->tsPacketizer.builder, pcr);
        // }

        uint64_t pcr = stream->pesPacketizer.timePTS * 300;
        VIDEORTP_tsInjectPcr(&stream->tsPacketizer.builder, pcr);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcInputStartFrame
 *
 *   Function:   Creates frame
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* self: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const size_t frameSize: frame full size
 *               const uint64_t samplingTime: frame timestamp
 *
 *   Outputs:
 *               true: if start frame successful
 *               false: if start frame unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_ipcInputStartFrame(VIDEORTP_ipcInputStream_t* self, const size_t frameSize, const uint64_t samplingTime)
{
    return VIDEORTP_ipcStartFrame(&self->ipcFrame, frameSize, samplingTime);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcInputAppendFrame
 *
 *   Function:   Appends payload chunk to frame
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* self: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const void* bufferPayload: payload chunk
 *               const size_t bufferSize: size of payload chunk
 *               VIDEORTP_releaseBufferCb_t bufferReleaseCallback:
 *
 *   Outputs:
 *               true: if append chunk successful
 *               false: if append chunk unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: <TBD>
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_ipcInputAppendFrame(VIDEORTP_ipcInputStream_t* self, const void* bufferPayload, const size_t bufferSize,
                                  VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    return VIDEORTP_ipcAppendFrame(&self->ipcFrame, bufferPayload, bufferSize, bufferReleaseCallback);
}
