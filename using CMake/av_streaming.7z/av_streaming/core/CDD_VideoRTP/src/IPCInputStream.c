/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "IPCInputStream.h"
#include "ConstantsOEM.h"
#include "VideoRtpUtil.h"

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcQueryPcr
 *
 *   Function:   Reads the current time from StbM and converts it to an MPEG PCR timestamp
 *
 *   Inputs:
 *               void* context: Pointer to IPC input stream
 *
 *   Outputs:
 *               MPEG PCR
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-844, MAGAVSTR-810
 *
 *   Traceability to SW Req: 16805908, 16805944, 11587814, 11587924, 16813296, 16887461
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @memberof VIDEORTP_ipcInputStream_t */
static uint64_t VIDEORTP_ipcQueryPcr(void* context)
{
    VIDEORTP_ipcInputStream_t* stream = context;
    assert(stream);

    uint64_t pcr = VIDEORTP_InvalidTimestamp;

    /* Read Media Clock from StbM */
    StbM_TimeStampType timeStamp;
    StbM_UserDataType userData;
    Std_ReturnType ret = StbM_GetCurrentTime(stream->timeBaseId, &timeStamp, &userData);
    if (ret == E_OK)
    {
        /* Convert 1GHz (nanosecond) resolution to 27MHz MPEG System Clock. */
        pcr = VIDEORTP_convertTimestamp(&timeStamp);
    }

    return pcr;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initIPCInputStream
 *
 *   Function:   The function prepares a pipeline for transferring H264 data from a file
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const VIDEORTP_ipcInputStreamConfig_t* config: configuration settings
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-810
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initIPCInputStream(VIDEORTP_ipcInputStream_t* stream,
                                                        const VIDEORTP_ipcInputStreamConfig_t* config)
{
    /* Send first PCR as soon as possible */
    stream->pcrTimer = VIDEORTP_PCR_INTERVAL;
    stream->timeBaseId = config->timeBaseId;

    VIDEORTP_ipcInit(&stream->ipcFrame);
    VIDEORTP_pesInitPacketizer(&stream->pesPacketizer, &stream->ipcFrame.vtable, config->streamId);
    VIDEORTP_tsInitPacketizer(&stream->tsPacketizer, &stream->pesPacketizer.vtable, config->tsPid, VIDEORTP_ipcQueryPcr, stream);

    return &stream->tsPacketizer.vtable;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initIPCInputStream
 *
 *   Function:   The function deinit inputStream
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_ipcDeinitIPCInputStream(VIDEORTP_ipcInputStream_t* self)
{
    VIDEORTP_ipcDeinit(&self->ipcFrame);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicIPCInputStream
 *
 *   Function:   Cyclically checks if another frame is to be transmitted. Also includes the PCR.
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* stream: VIDEORTP_ipcInputStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801, MAGAVSTR-815
 *
 *   Traceability to SW Req: 16805908, 16805944, 16813296
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicIPCInputStream(VIDEORTP_ipcInputStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Inject PCR into next packet */
    if (VIDEORTP_timerTick(&stream->pcrTimer, timeSinceLastCall, VIDEORTP_PCR_INTERVAL))
    {
        VIDEORTP_tsInjectPcr(&stream->tsPacketizer.builder);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcInputStartFrame
 *
 *   Function:   Creates frame
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* self: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const size_t frameSize: frame full size
 *               VIDEORTP_timestamp* timestamp: Sampling timestamp of this frame
 *
 *   Outputs:
 *               true: if start frame successful
 *               false: if start frame unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: 16802573, 16802575, 16805555, 16805908, 16805944, 16813236
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_ipcInputStartFrame(VIDEORTP_ipcInputStream_t* self, const size_t frameSize, const VIDEORTP_timestamp* timestamp)
{
    assert(self);
    assert(timestamp);

    return VIDEORTP_ipcStartFrame(&self->ipcFrame, frameSize, timestamp);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_ipcInputAppendFrame
 *
 *   Function:   Appends payload chunk to frame
 *
 *   Inputs:
 *               VIDEORTP_ipcInputStream_t* self: VIDEORTP_ipcInputStream_t instance that the function works on
 *               const void* bufferPayload: payload chunk
 *               const size_t bufferSize: size of payload chunk
 *               VIDEORTP_releaseBufferCb_t bufferReleaseCallback:
 *
 *   Outputs:
 *               true: if append chunk successful
 *               false: if append chunk unsuccessful
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-801
 *
 *   Traceability to SW Req: 16802575, 16805908, 16805944, 16813236, 16813252
 *
 *   Remarks:
 *
 * ========================================================================= */
bool VIDEORTP_ipcInputAppendFrame(VIDEORTP_ipcInputStream_t* self, const void* bufferPayload, const size_t bufferSize,
                                  VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    return VIDEORTP_ipcAppendFrame(&self->ipcFrame, bufferPayload, bufferSize, bufferReleaseCallback);
}
