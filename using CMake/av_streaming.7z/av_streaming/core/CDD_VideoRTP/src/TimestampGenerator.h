#ifndef TIMESTAMP_GENERATOR_H
#define TIMESTAMP_GENERATOR_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ConstantsMPEG.h"

#include "PayloadProvider.h"
#include "PipelineStageWithSinglePredecessor.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup TimestampGenerator
     * @{
     * @brief Synthesizes sampling timestamps of payload units.
     *
     * For testing, it can be useful to stream static data, e.g., a pre-recorded video. In a real system, the frame grabber or video
     * encoder would provide accurate sampling timestamps, but there is no such instance in a stream with static pre-generated data.
     *
     * A timestamp generator pipeline stage solves this problem by synthesizing timestamps. This pipeline stage is a simple filter
     * which does not add or modify any data; instead, it merely replaces the sampling timestamp in the metadata field returned by
     * @ref VIDEORTP_pipePrepareNextChunk "prepareNextChunk".
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief The structure contains data for calculating and adding a timestamp to the metadata
     * @implements VIDEORTP_payloadProvider_t
     * @extends VIDEORTP_pipelineStageWithSinglePredecessor_t
     */
    typedef struct VIDEORTP_timestampGenerator_t
    {
        /** @privatesection @{ */
        /** @brief Implementation of VIDEORTP_payloadProvider_t interface */
        VIDEORTP_payloadProvider_t vtable;

        /** @brief Predecessor pipeline stage
         * @invariant not @c NULL
         */
        VIDEORTP_payloadProvider_t* base;

        /** @brief Payload number for which timestamp will be calculated */
        uint32_t currentPayloadNumber;

        /** @brief Frame frequency */
        uint64_t framerate;

        /** @brief Initial timestamp */
        uint64_t startTimestamp;

        /** @brief Next DTS to insert; invalid if DTS should be equal to PTS */
        uint64_t nextDts;

        /** @brief Signals the end of the current frame or payload unit.
         *
         * After the last chunk of a frame has been copied, @ref VIDEORTP_tgenCopyChunk "copyChunk" must increase the frame counter
         * and timestamp. */
        bool isPayloadUnitEnd;
        /** @} */
    } VIDEORTP_timestampGenerator_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_timestampGenerator_t instance
     * @public @memberof VIDEORTP_timestampGenerator_t
     *
     * @param self The instance of VIDEORTP_timestampGenerator_t
     * @param timestamp Initial timestamp of the first payload unit
     * @param framerate Frame frequency
     * @param predecessor Previous pipline stage
     */
    void VIDEORTP_tgenInit(VIDEORTP_timestampGenerator_t* self, uint64_t timestamp, uint64_t framerate,
                           VIDEORTP_payloadProvider_t* predecessor);

    /**
     * @brief Get the current timetamp
     * @public @memberof VIDEORTP_timestampGenerator_t
     *
     * @param self The VIDEORTP_timestampGenerator_t instance
     * @return The current timestamp
     */
    uint64_t VIDEORTP_tgenCalculateTimestamp(VIDEORTP_timestampGenerator_t* self);

    /**
     * @brief Set the decoding timestamp for the next frame
     * @public @memberof VIDEORTP_timestampGenerator_t
     *
     * The decoding timestamp will only be set for one frame;
     * following frames will revert to the presentation timestamp.
     *
     * @param self The VIDEORTP_timestampGenerator_t instance
     * @param dts The decoding timestamp of the next frame
     */
    void VIDEORTP_tgenSetDecodingTimestamp(VIDEORTP_timestampGenerator_t* self, uint64_t dts);

/**@} TimestampGenerator global */
#ifdef __cplusplus
} /* extern "C" */
#endif
#endif /* TIMESTAMP_GENERATOR_H */
