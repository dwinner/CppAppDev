#ifndef PADDINGELEMENTARYSTREAMGENERATOR_H_INCLUDED
#define PADDINGELEMENTARYSTREAMGENERATOR_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <stdint.h>

#include "ConstantsMPEG.h"

#include "PayloadProvider.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup PaddingElementaryStreamGenerator
     * @{
     * @brief Generates padding PES packets.
     *
     * For testing, it can be useful to stream with "maximum" bandwidth. This pipeline stage generates dummy/padding packets to
     * arbitrarily increase bandwidth consumption of an MPEG stream.
     *
     * @note This generator produces PES packets, so it should be followed by a
     * @ref VIDEORTP_transportStreamPacketizer_t "TS packetizer" with its own PID.
     *
     * @note NULL TS packets (MPEG) or NULL NALUs (H.264) are alternate ways to generate dummy data.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Structure to keep PaddingElementaryStreamGenerator fields and base class
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct
    {
        /** @privatesection @{ */
        /**
         * @brief Implementation of VIDEORTP_payloadProvider_t
         *
         */
        VIDEORTP_payloadProvider_t base;
        /**
         * @brief Total amount of bytes to generate (default = 0)
         *
         */
        size_t padding;
        /**
         * @brief Number of bytes to generate in the next copyChunk call (default = 0)
         *
         */
        size_t chunkSize;
        /** @} */
    } VIDEORTP_paddingElementaryStreamGenerator_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_paddingElementaryStreamGenerator_t
     * @public @memberof VIDEORTP_paddingElementaryStreamGenerator_t
     *
     * @param self pointer to instance
     */
    void VIDEORTP_padInit(VIDEORTP_paddingElementaryStreamGenerator_t* self);

    /**@} PaddingElementaryStreamGenerator global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
