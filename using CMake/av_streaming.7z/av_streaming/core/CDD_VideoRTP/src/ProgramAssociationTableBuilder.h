#ifndef PROGRAM_ASSOCIATION_TABLE_H
#define PROGRAM_ASSOCIATION_TABLE_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ConstantsMPEG.h"

#include "BufferWriter.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup ProgramAssociationTableBuilder
     * @{
     * @brief Generates MPEG Program Association Table Sections
     *
     * A Program Association Table (PAT) is the main index in an MPEG transport
     * stream. This data structure lists all available programs in a transport
     * stream along with packet identifiers (PID) of the respective Program Map
     * Tables (PMT).
     *
     * A ProgramAssociationTableBuilder can be used to generate such a table.
     * Multiple MPEG programs can be added in a loop by calling
     * @ref VIDEORTP_patAddProgram "addProgram".
     * Calling @ref VIDEORTP_patFinalize "finalize" will write the MPEG section
     * header and append the CRC to the program list in the destination buffer.
     *
     * The generated PAT can be inserted in the MPEG stream using a
     * @ref PayloadUnitRepeater. To avoid excessive bandwidth consumption,
     * the PAT should be throttled using a @ref PayloadGate.
     *
     * @startuml pat_builder
     *  hide footbox
     *
     *  actor Main
     *  participant ProgramAssociationTableBuilder
     *  participant BufferWriter
     *
     *  Main -> BufferWriter++ : init(&buffer, sizeof(buffer))
     *      return
     *
     *  Main -> ProgramAssociationTableBuilder++ : init(tsId, &BufferWriter)
     *      loop
     *          ProgramAssociationTableBuilder -> BufferWriter++ : writeData(...)
     *              note right: Write section header
     *              return
     *      end
     *      return
     *
     *  loop for all programs
     *      Main -> ProgramAssociationTableBuilder++ : addProgram(programNumber, programMapPid)
     *          loop
     *              ProgramAssociationTableBuilder -> BufferWriter++ : writeData(...)
     *                  note right: Write program entry
     *                  return
     *          end
     *          return
     *  end
     *
     *  Main -> ProgramAssociationTableBuilder++ : finalize()
     *      loop
     *          ProgramAssociationTableBuilder -> BufferWriter++ : writeData(...)
     *              note right: Complete header and append CRC
     *              return
     *      end
     *      return
     * @enduml
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Struct containig writers for ProgramAssociationSection
     * @implements VIDEORTP_payloadProvider_t
     * @see VIDEORTP_programMapTableBuilder_t
     */
    typedef struct VIDEORTP_programAssociationTableBuilder_t
    {
        /** @privatesection @{ */
        /**
         * @brief Destination VIDEORTP_bufferWriter_t. It write data to the destination buffer
         *
         */
        VIDEORTP_bufferWriter_t* section;
        /**
         * @brief Buffer writer for section_length
         *
         * The length field in the section header is only known after all
         * programs have been written. This buffer writer can be used to write
         * the length field after everything else.
         */
        VIDEORTP_bufferWriter_t lengthField;
        /**
         * @brief number of programs
         *
         */
        uint16_t programCount;
        /** @} */
    } VIDEORTP_programAssociationTableBuilder_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Init the Program Association Table builder.
     * @public @memberof VIDEORTP_programAssociationTableBuilder_t
     *
     * @note Initialize the builder according to H.222.
     *
     * @param self the VIDEORTP_programAssociationTableBuilder_t instance the function is working on
     * @param tsId Transport stream id
     * @param destBW destination VIDEORTP_bufferWriter_t
     */
    void VIDEORTP_patInit(VIDEORTP_programAssociationTableBuilder_t* self, const uint16_t tsId, VIDEORTP_bufferWriter_t* destBW);

    /**
     * @brief Write the programNumber and programMapPid using destination VIDEORTP_bufferWriter_t
     * @public @memberof VIDEORTP_programAssociationTableBuilder_t
     *
     * @param self the VIDEORTP_programAssociationTableBuilder_t instance the function is working on
     * @param programNumber Program number
     * @param programMapPid Program map pid
     */
    void VIDEORTP_patAddProgram(VIDEORTP_programAssociationTableBuilder_t* self, const uint16_t programNumber,
                                const uint16_t programMapPid);

    /**
     * @brief It shall write the section length field to destination buffer, calculate CRC32 and write it to destination buffer
     * @public @memberof VIDEORTP_programAssociationTableBuilder_t
     *
     * @note Write sectionLengthField using lengthField, calculate CRC32 and write it using section VIDEORTP_bufferWriter_t
     *
     * @param self the VIDEORTP_programAssociationTableBuilder_t instance the function is working on
     */
    void VIDEORTP_patFinalize(VIDEORTP_programAssociationTableBuilder_t* self);

    /**@} ProgramAssotiationTableBuilder global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PROGRAM_ASSOCIATION_TABLE_H */
