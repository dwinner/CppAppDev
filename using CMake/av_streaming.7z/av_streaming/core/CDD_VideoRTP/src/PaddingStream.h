#ifndef PADDING_STREAM_H_INCLUDED
#define PADDING_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "PaddingCalculator.h"
#include "PaddingElementaryStreamGenerator.h"
#include "PayloadDataCounter.h"
#include "TransportStreamPacketizer.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @defgroup PaddingStream
     * @{
     * @brief Adds padding to a transport stream.
     */

    /**
     * @brief Provides a transport stream containing padding data.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** @brief Counter to monitor used bandwidth */
        VIDEORTP_payloadDataCounter_t* counter;
        /** @brief Calculates amount of needed padding */
        VIDEORTP_paddingCalculator_t calculator;
        /** @brief Initial pipeline data genetrator */
        VIDEORTP_paddingElementaryStreamGenerator_t generator;
        /** @brief Wrap in transport stream */
        VIDEORTP_transportStreamPacketizer_t tsPacketizer;
        /** @brief When to recalculate padding */
        uint32_t timer;
        /** @} */
    } VIDEORTP_paddingStream_t;

    /**
     * @brief Initialize padding stream
     * @public @memberof VIDEORTP_paddingStream_t
     *
     * @param stream instance that the function works on
     * @param targetDataRate Desired target bandwidth (bytes per second)
     * @param counter Counter pipeline stage which measures video bandwidth
     * @return VIDEORTP_payloadProvider_t*
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_initPaddingStream(VIDEORTP_paddingStream_t* stream, uint32_t targetDataRate,
                                                           VIDEORTP_payloadDataCounter_t* counter);

    /**
     * @brief Cyclically updates the amount of padding
     * @public @memberof VIDEORTP_paddingStream_t
     *
     * @param stream instance that the function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicPaddingStream(VIDEORTP_paddingStream_t* stream, uint32_t timeSinceLastCall);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
