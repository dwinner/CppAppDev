/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PayloadDataCounter.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cntPrepareNextChunk
 *
 *   Function:   Forward this call to the predecessor stage
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: Instance of VIDEORTP_payloadDataCounter_t
 *               size_t maximumSize: Maximum available space in destination buffer
 *               VIDEORTP_payloadChunkInfo_t* metaData: Meta data about packet data
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-438
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadDataCounter_t */
static size_t VIDEORTP_cntPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_payloadDataCounter_t* self = (VIDEORTP_payloadDataCounter_t*) ((void*) vtable);

    return VIDEORTP_pipePrepareNextChunk(self->base, maximumSize, metaData);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cntCopyChunk
 *
 *   Function:   Forward this call to the predecessor stage and count written data
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: Instance of VIDEORTP_payloadDataCounter_t
 *               VIDEORTP_bufferWriter_t* payloadBuffer: Destination buffer writer
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-438
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadDataCounter_t */
static void VIDEORTP_cntCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_payloadDataCounter_t* self = (VIDEORTP_payloadDataCounter_t*) ((void*) vtable);

    size_t before = VIDEORTP_bufGetBytesWritten(payloadBuffer);
    VIDEORTP_pipeCopyChunk(self->base, payloadBuffer);
    self->counter += VIDEORTP_bufGetBytesWritten(payloadBuffer) - before;
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cntInit
 *
 *   Function:   Initialize the VIDEORTP_payloadDataCounter_t instance
 *
 *   Inputs:
 *               VIDEORTP_payloadDataCounter_t* self: Instance of VIDEORTP_payloadDataCounter_t
 *               VIDEORTP_payloadProvider_t* predecessor: Previous pipeline stage
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-438
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cntInit(VIDEORTP_payloadDataCounter_t* self, VIDEORTP_payloadProvider_t* predecessor)
{
    assert(self);
    assert(predecessor);

    self->vtable.prepareNextChunk = VIDEORTP_cntPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_cntCopyChunk;

    self->base = predecessor;
    self->counter = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cntResetCounter
 *
 *   Function:   Reset data counter
 *
 *   Inputs:
 *               VIDEORTP_payloadDataCounter_t* self: Instance of VIDEORTP_payloadDataCounter_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-438
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cntResetCounter(VIDEORTP_payloadDataCounter_t* self)
{
    assert(self);
    self->counter = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cntGetCounter
 *
 *   Function:   Return data counter
 *
 *   Inputs:
 *               VIDEORTP_payloadDataCounter_t* self: Instance of VIDEORTP_payloadDataCounter_t
 *
 *   Outputs:
 *               size_t Number of bytes transferred since the last reset
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-438
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
size_t VIDEORTP_cntGetCounter(VIDEORTP_payloadDataCounter_t* self)
{
    assert(self);
    return self->counter;
}
