/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */
/* ===========================================================================
 *
 *   Description about this module
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "AutosarPacketSink.h"

/* ===========================================================================
 *
 *   Private Typedefs
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Defines
 *
 * ========================================================================= */

static VIDEORTP_bufferWriter_t* VIDEORTP_asrPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable);

static VideoRTP_errorCode VIDEORTP_asrCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable);

/* ===========================================================================
 *
 *   Private Constants
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Macros
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Data Declarations (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Private Function Prototypes
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_asrInitPacketSink
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_asrPacketSink_t* self: VIDEORTP_asrPacketSink_t instance that the function works on
 *               PduIdType pduIdType : the unique AUTOSAR PDU ID
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-21
 *
 *   Traceability to SW Req: 16805717, 16805813, 16813244
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_asrInitPacketSink(VIDEORTP_asrPacketSink_t* self, PduIdType pduIdType)
{
    assert(self);

    self->m_txPduId = pduIdType;
    self->vtable.commitTransmissionBuffer = VIDEORTP_asrCommitTransmissionBuffer;
    self->vtable.prepareTransmissionBuffer = VIDEORTP_asrPrepareTransmissionBuffer;
    VIDEORTP_bufInit(&self->m_payloadWriter, self->m_payloadBuffer, sizeof(self->m_payloadBuffer));
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_asrDeinitPacketSink
 *
 *   Function:   The function closes the network connection
 *
 *   Inputs:
 *               VIDEORTP_asrPacketSink_t* self: VIDEORTP_asrPacketSink_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-21
 *
 *   Traceability to SW Req: 16805813
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_asrDeinitPacketSink(VIDEORTP_asrPacketSink_t* self)
{
    assert(self);
    VIDEORTP_unused(self);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_asrPrepareTransmissionBuffer
 *
 *   Function:   Returns a pointer to the BufferWriter
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable: VIDEORTP_packetTransmitter_t instance that the function works on
 *
 *   Outputs:
 *               VIDEORTP_BufferWriter_t*: Pointer to BufferWriter struct
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-21
 *
 *   Traceability to SW Req: 16805717, 16813244
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_asrPacketSink_t */
static VIDEORTP_bufferWriter_t* VIDEORTP_asrPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_asrPacketSink_t* self = (void*) vtable;
    VIDEORTP_bufClear(&(self->m_payloadWriter));
    return &self->m_payloadWriter;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_asrCommitTransmissionBuffer
 *
 *   Function:   The function transmits data over the network
 *
 *   Inputs:
 *               VIDEORTP_packetTransmitter_t* vtable: VIDEORTP_packetTransmitter_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-22, MAGAVSTR-842
 *
 *   Traceability to SW Req: 16805717, 16805813, 16813244
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_asrPacketSink_t */
static VideoRTP_errorCode VIDEORTP_asrCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    assert(vtable);
    VIDEORTP_asrPacketSink_t* self = (void*) vtable;

    /* SWS_COMTYPE_00011: Depending on the AUTOSAR version, this struct has two
    or three fields. Make sure the unused field is initialized if present. */
    PduInfoType pdu = { .SduDataPtr = NULL, .SduLength = 0 };
    pdu.SduDataPtr = VIDEORTP_bufGetBasePointer(&self->m_payloadWriter);
    pdu.SduLength = (PduLengthType) VIDEORTP_bufGetBytesWritten(&self->m_payloadWriter);

    /* There is nothing we can do here if the transmission fails.
    It's even possible that this packet will be dropped later. */
    Std_ReturnType err = PduR_CddTransmit(self->m_txPduId, &pdu);
    return (err == E_OK) ? VideoRTP_ok : VideoRTP_networkError;
}
