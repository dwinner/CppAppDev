/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */
#include "ProgramAssociationTableBuilder.h"
#include "crc32_mpeg2.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_patInit
 *
 *   Function:   Init the Program Association Table builder.
 *
 *   Inputs:
 *               VIDEORTP_programAssociationTableBuilder_t* self : the VIDEORTP_programAssociationTableBuilder_t instance that the
 * function is working on
 *               uint16_t tsId : Transport stream id
 *               VIDEORTP_bufferWriter_t* destBW : destination VIDEORTP_bufferWriter_t
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-76
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks: All reserved bits set to 1
 *
 * ========================================================================= */
void VIDEORTP_patInit(VIDEORTP_programAssociationTableBuilder_t* self, const uint16_t tsId, VIDEORTP_bufferWriter_t* destBW)
{
    assert(self);

    /* H.222 Table 2-31 */
    uint8_t tableId = 0x00;
    /* 2 bits reserved, 5 bits version number (to 0), 1 bit current_next_indicator (to 1) */
    uint8_t versionNumber = 0xC1;
    /* H.222 2.4.4.6 */
    uint8_t sectionNumber = 0x00;
    /* Number of the last section in the PAT */
    uint8_t lastSectionNumber = 0x00;

    self->section = NULL;
    self->programCount = 0;
    if (destBW != NULL)
    {
        self->section = destBW;
        VIDEORTP_bufferWriter_t* section = self->section;

        VIDEORTP_bufWriteInteger(section, tableId, sizeof(tableId));
        /* create child VIDEORTP_bufferWriter_t for sectionLength and move parent write point after child */
        self->lengthField = VIDEORTP_bufSpawnChildWriter(section, sizeof(uint16_t));
        /* writing remained program assotiation section fields to buffer in H.222 order */
        VIDEORTP_bufWriteInteger(section, tsId, sizeof(tsId));
        VIDEORTP_bufWriteInteger(section, versionNumber, sizeof(versionNumber));
        VIDEORTP_bufWriteInteger(section, sectionNumber, sizeof(sectionNumber));
        VIDEORTP_bufWriteInteger(section, lastSectionNumber, sizeof(lastSectionNumber));
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_patAddProgram
 *
 *   Function:   It shal write program number and program map pid using destination VIDEORTP_bufferWriter_t
 *
 *   Inputs:
 *               VIDEORTP_programAssociationTableBuilder_t* self : the VIDEORTP_programAssociationTableBuilder_t instance that the
 * function is working on uint16_t programNumber : Program number uint16_t programMapPid : Program map pid
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-76
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_patAddProgram(VIDEORTP_programAssociationTableBuilder_t* self, const uint16_t programNumber,
                            const uint16_t programMapPid)
{
    assert(self);
    if (self->section != NULL)
    {
        /* 3 bits reserved (set to 1), 13 bits is program_map_pid */
        uint16_t reservedAndProgramMapPid = 0xE000 | programMapPid;
        VIDEORTP_bufWriteInteger(self->section, programNumber, sizeof(programNumber));
        VIDEORTP_bufWriteInteger(self->section, reservedAndProgramMapPid, sizeof(reservedAndProgramMapPid));
        self->programCount++;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_patFinalize
 *
 *   Function:   It shall write the section length field to the destination buffer, calculate the CRC32 and write it to the
 * destination buffer
 *
 *   Inputs:
 *               VIDEORTP_programAssociationTableBuilder_t* self : the VIDEORTP_programAssociationTableBuilder_t instance that the
 * the function is working on
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-76
 *
 *   Traceability to SW Req: <if possible link the requirement(s)> MAGAVSTR-<number of the module requirement(s)>
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_patFinalize(VIDEORTP_programAssociationTableBuilder_t* self)
{
    assert(self);
    if (self->section != NULL)
    {
        /* 5 - size of all fields after section_length up to program data
        program data size is 2 fields by uint16_t */
        uint16_t section_length = 5 + self->programCount * 2 * sizeof(uint16_t) + sizeof(uint32_t);
        uint32_t CRC_32 = 0;
        if (section_length <= VIDEORTP_PAT_SECTION_MAX_SIZE)
        {
            /* 1 bit section syntax indivator
               1 bit is zero
               2 bits reserved
               12 bits section_length
             */
            section_length = 0xB000 | (0x0FFF & section_length);
            VIDEORTP_bufWriteInteger(&(self->lengthField), section_length, sizeof(section_length));
            CRC_32 = VIDEORTP_CRC32calculate((uint8_t*) VIDEORTP_bufGetBasePointer(self->section),
                                             VIDEORTP_bufGetBytesWritten(self->section));
        }
        else
        {
            /* Since we plan to use a small package, we are unlikely to meet this condition
            we pretend we don't have data and set invalid partition length and don't calculate crc_32 value */
            section_length = 0;
            VIDEORTP_bufWriteInteger(&(self->lengthField), section_length, sizeof(section_length));
        }

        VIDEORTP_bufWriteInteger(self->section, CRC_32, sizeof(CRC_32));
    }
}
