#ifndef STATIC_INPUT_STREAM_H_INCLUDED
#define STATIC_INPUT_STREAM_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "ElementaryStreamPacketizer.h"
#include "PayloadDataCounter.h"
#include "PayloadGate.h"
#include "PayloadUnitSequenceRepeater.h"
#include "TimestampGenerator.h"
#include "TransportStreamPacketizer.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @defgroup StaticInputStream
     * @{
     * @brief Wraps a pre-generated video in an MPEG transport stream.
     */

    /**
     * @brief Configuration of a static test video stream.
     */
    typedef struct
    {
        /** @brief Frames of input video */
        VIDEORTP_payloadUnit_t* payloadUnits;
        /** @brief Number of frames in input video */
        size_t payloadUnitCount;
        /** @brief Desired target frame rate */
        uint32_t fps;
        /** @brief MPEG PES packet type ID */
        uint8_t streamId;
        /** @brief MPEG-TS PID */
        uint16_t tsPid;
        /** @brief Delay PCR timestamps (= current time) by a few milliseconds */
        uint64_t pcrDelay;
    } VIDEORTP_staticInputStreamConfig_t;

    /**
     * @brief Provides a transport stream of a static (pre-generated) test video.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /** @brief Initial pipeline data generator (repeats frames from file) */
        VIDEORTP_payloadUnitSequenceRepeater_t repeater;
        /** @brief Count bandwidth from file */
        VIDEORTP_payloadDataCounter_t counter;
        /** @brief Generate timestamps because the file does not include timestamps */
        VIDEORTP_timestampGenerator_t timeGenerator;
        /** @brief Packetize frames */
        VIDEORTP_pesStreamPacketizer_t pesPacketizer;
        /** @brief Wrap in transport stream */
        VIDEORTP_transportStreamPacketizer_t tsPacketizer;
        /** @brief Enable on demand */
        VIDEORTP_payloadGate_t gate;

        /** @brief When to send the next video frame */
        uint32_t frameTimer;
        /** @brief How fast to send frames */
        uint32_t frameInterval;

        /** @brief When to inject the next PCR timestamp in the video stream */
        uint32_t pcrTimer;
        /** @brief Offset to add to PCR timestamps (Delivery Compensation Offset) */
        uint64_t pcrDelay;
        /** @} */
    } VIDEORTP_staticInputStream_t;

    /**
     * @brief The function prepares a pipeline for transferring H264 data from a file
     * @public @memberof VIDEORTP_staticInputStream_t
     *
     * @param stream Instance this function works on
     * @param config Stream configuration
     * @return Pointer to the output pipeline stage which should be connected to the next stage.
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_initStaticInputStream(VIDEORTP_staticInputStream_t* stream,
                                                               const VIDEORTP_staticInputStreamConfig_t* config);

    /**
     * @brief Cyclically checks if another frame is to be transmitted. Also includes the PCR.
     * @public @memberof VIDEORTP_staticInputStream_t
     *
     * @param stream Instance this function works on
     * @param timeSinceLastCall Time since the last call of this function
     */
    void VIDEORTP_cyclicStaticInputStream(VIDEORTP_staticInputStream_t* stream, uint32_t timeSinceLastCall);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
