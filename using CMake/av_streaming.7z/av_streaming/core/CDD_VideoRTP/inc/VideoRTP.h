#ifndef CDD_VIDEORTP_H_INCLUDED
#define CDD_VIDEORTP_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "../src/sysdef.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#include <PduR_Cdd.h>
#include <StbM.h>

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * @defgroup VideoRTP
 * @{
 * @brief The VideoRTP module streams H.264 videos via UDP/RTP packets.
 *
 * @warning The VideoRTP module is not thread-safe and cannot be used concurrently.
 *
 * @startuml VideoRTP_state
 * [*] --> Deinitialized
 * Deinitialized --> Initialized : VIDEORTP_init
 * Initialized --> Deinitialized : VIDEORTP_deinit
 *
 * state Initialized {
 * [*] -> MainReady
 * MainReady -> MainReady : VIDEORTP_cyclic
 * --
 * [*] -> Idle
 * Idle -> FrameStarted : VIDEORTP_startFrame
 * FrameStarted -> FrameStarted : VIDEORTP_appendFrame
 * FrameStarted -> Idle : sufficient data appended to frame
 * }
 * @enduml
 */

/**
 * @brief Defines RTP streaming mode
 *
 * VW LAH IP_AVT and RFC2250 use different payload types.
 * By default, send an synchronous stream as per VW LAH IP_AVT.
 * For debugging, it can be useful to temporarily switch to RFC2250.
 *
 * @see VIDEORTP_rtpStreamingMode_t
 */
#ifndef VIDEORTP_STREAMING_MODE
#define VIDEORTP_STREAMING_MODE VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS
#endif

/**
 * @brief Name of C header declaring the buffer release function.
 *
 * @see VIDEORTP_RELEASE_BUFFER_FUNCTION
 * @todo Replace with actual header from IPC module!
 */
#ifndef VIDEORTP_RELEASE_BUFFER_HEADER
/* #define VIDEORTP_RELEASE_BUFFER_HEADER <ipc.h> */
#endif

/**
 * @brief Name of buffer release function for IPC buffers
 *
 * This function can be used to release memory buffer provided to this module by
 * calling @ref VIDEORTP_startFrame or @ref VIDEORTP_appendFrame.
 *
 * @see VIDEORTP_RELEASE_BUFFER_HEADER
 * @todo Replace with actual function from IPC module!
 */
#ifndef VIDEORTP_RELEASE_BUFFER_FUNCTION
/* #define VIDEORTP_RELEASE_BUFFER_FUNCTION &IPC_OnBufferRelease */
#define VIDEORTP_RELEASE_BUFFER_FUNCTION NULL
#endif

/** Size of RTP synchronization source field */
#define VIDEORTP_RTCP_SSRC_SIZE 4

/** Size of RTCP name field */
#define VIDEORTP_RTCP_NAME_SIZE 4

/** Size of RTCP gmIdentity field */
#define VIDEORTP_RTCP_GM_IDENTITY_SIZE 10

/** Size of RTCP stream ID field */
#define VIDEORTP_RTCP_STREAM_ID_SIZE 8

    /**
     * @brief Streaming parameters
     */
    typedef struct VIDEORTP_AvMasterConfiguration
    {
        /** @brief Timestamp offset */
        uint32_t deliveryCompensationOffset;

        /** @brief MPEG stream PID */
        uint16_t videoPid;

        /** @brief MPEG program ID */
        uint16_t programId;

        /** @brief Interval to resend Program Association and Mapping Tables (milliseconds) */
        uint32_t patInterval;

        /** @brief PID of the MPEG Program Map Table */
        uint16_t pmtPid;

        /** @brief MPEG Transport Stream ID in Program Association Table */
        uint16_t streamId;
    } VIDEORTP_AvMasterConfiguration;

    /**
     * @brief RTP/RTCP session parameters
     */
    typedef struct VIDEORTP_sessionConfiguration
    {
        /** @brief The synchronization source identifier, i.e., the originator of this RTP or RTCP packet */
        uint8_t ssrc[VIDEORTP_RTCP_SSRC_SIZE];

        /** @brief This field contains a name chosen to uniquely identify this set of RTCP packets with respect to other RTCP
         * packets that the application might receive */
        uint8_t name[VIDEORTP_RTCP_NAME_SIZE];

        /** @brief This field is used to communicate the Grand Master currently being "listened to" by the talker for purposes of
         * relating media and IEEE 802.1AS time. Includes clock port and clock identity for AVB/RTCP packets. */
        uint8_t gmIdentity[VIDEORTP_RTCP_GM_IDENTITY_SIZE];

        /** @brief Ethernet stream ID (for traffic shaping etc. on lower network layers) */
        uint8_t streamId[VIDEORTP_RTCP_STREAM_ID_SIZE];

        /** @brief Initial RTP sequence counter RFC3550 section 5.1 */
        uint16_t initialSequenceCounter;

        /** @brief Initial RTP timestamp RFC3550 section 5.1 */
        uint32_t initialTimestamp;
    } VIDEORTP_sessionConfiguration;

    /**
     * @brief Configuration parameters for the Video RTP module
     */
    typedef struct VIDEORTP_initConfiguration
    {
        /** @brief Calling period of the module main function */
        uint32_t mainFunctionPeriod;

        /** @brief Desired bit data rate of video input stream (bits per second) */
        uint32_t targetDataRate;

        /** @brief Desired frame rate of video input stream (frames per second) */
        uint32_t targetFrameRate;

        /** @brief Socket connection to send RTP packets */
        PduIdType rtpPdu;

        /** @brief Socket connection to send AVB/RTCP packets */
        PduIdType rtcpPdu;

        /** @brief Source clock for current time (MPEG Program Clock Reference) */
        StbM_SynchronizedTimeBaseType timeBaseId;

        /** @brief Configuration of MPEG/RTP stream */
        VIDEORTP_AvMasterConfiguration avMasterConfiguration;

        /** @brief Configuration of RTP/RTCP session */
        VIDEORTP_sessionConfiguration sessionConfiguration;

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        /** @brief Ignore input from IPC and instead stream a test video if available */
        bool isTestVideoEnabled;
#endif
    } VIDEORTP_initConfiguration;

    /**
     * @brief Sampling timestamp of a video frame in different time bases
     *
     * MPEG and RTP/RTCP include several timestamp fields which represent the
     * same instant, i.e., the sampling time of a specific video frame, but they
     * are expressed in different time domains. To ensure that all timestamps
     * are consistent and accurate, the caller should collect the timestamps
     * immediately when sampling a video frame and forward them to this module.
     */
    typedef struct VIDEORTP_timestampInformation
    {
        /**
         * @brief Presentation time stamp (PTS; for MPEG and RTP).
         *
         * Specifies the time when a frame shall be rendered.
         * Usually this corresponds to the sampling timestamp of a video frame.
         */
        StbM_TimeStampType mpegPresentationTimestamp;

        /**
         * @brief Decoding time stamp (DTS; for MPEG and RTP).
         *
         * Specifies the time when a frame shall be passed to the decoder.
         * Depending on the encoder configuration, this will usually be equal to
         * or slightly smaller than the PTS. If out-of-order decoding is not
         * needed, this will always be equal to the PTS.
         */
        StbM_TimeStampType mpegDecodingTimestamp;

        /** @brief Corresponding presentation time stamp in IEEE802.1AS clock (for RTCP/IEEE1733) */
        uint32_t gptpTimestamp;
        /** @brief "Version number" of IEEE802.1AS time stamp (for RTCP/IEEE1733) */
        uint16_t gptpTimeBaseIndicator;
    } VIDEORTP_timestampInformation;

    /**
     * @brief Initialize the VideoRTP module and prepare for streaming.
     *
     * After the VideoRTP module has been initialized,
     * call @ref VIDEORTP_cyclic to send UDP/RTP packets.
     *
     * @param configuration Stream parameters and configuration
     */
    VideoRTP_errorCode VIDEORTP_init(const VIDEORTP_initConfiguration* configuration);

    /**
     * @brief Deinitialize the VideoRTP module.
     *
     * Call @ref VIDEORTP_init again to re-initialize the module.
     * No other VideoRTP function may be called until then.
     */
    VideoRTP_errorCode VIDEORTP_deinit(void);

    /**
     * @brief Cyclic processing.
     *
     * Perform cyclic operations, such as sending UDP/RTP packets which have accumulated so far.
     * This function may be called only if @ref VIDEORTP_init has completed.
     *
     * Previously added buffers (with @ref VIDEORTP_startFrame or @ref VIDEORTP_appendFrame) may be released.
     */
    VideoRTP_errorCode VIDEORTP_cyclic(void);

    /**
     * @brief Notify the VideoRTP module that a new video frame begins.
     *
     * The previous video frame (if any) will be marked as complete; appending more data is no longer possible.
     * @c VIDEORTP_appendFrame will append data to the new video frame.
     *
     * @warning The caller must ensure that the total size of all payload buffers
     * (whether added with @ref VIDEORTP_startFrame or @ref VIDEORTP_appendFrame)
     * exactly equals the specified @c frameSize.
     * Providing too much or too little data may corrupt the RTP stream!
     *
     * @param frameSize Total size of the frame. The sum of the size of all payload chunks.
     * @param frameTime Sampling timestamp of this frame.
     * @param bufferPayload Optional pointer to the first chunk of the new frame. May be @c NULL.
     * @param bufferSize If @c bufferPayload is not @c NULL, this specifies the size of the first chunk.
     * @return true if a new frame was allocated. If specified, the @c bufferPayload will be stored.
     *              It will be released later by calling @todo @c IPC_OnBufferRelease.
     * @return VideoRTP_errorCode if an error occurred. The @c bufferPayload will *not* be stored. It will *not* be released by this
     * module.
     */
    VideoRTP_errorCode VIDEORTP_startFrame(size_t frameSize, const VIDEORTP_timestampInformation* frameTime, void* bufferPayload,
                                           size_t bufferSize);

    /**
     * @brief Add more data to the current video frame.
     *
     * This function may be called only after a successfull call to @c VIDEORTP_startFrame.
     *
     * @param bufferPayload Mandatory pointer to the first chunk of the new frame. May not be @c NULL.
     * @param bufferSize specifies the size of the first chunk.
     * @return true if the buffer was appended to the current frame. The @c bufferPayload will be released later.
     * @return VideoRTP_errorCode if an error occurred. The @c bufferPayload will *not* be released.
     */
    VideoRTP_errorCode VIDEORTP_appendFrame(void* bufferPayload, size_t bufferSize);

    /** @} */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
