/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference.
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CDD_VideoRTP.c
 *           Config:  C:/GIT_Repo/L2H5050_Software/pkg/Applications/DaVinci/MIK.dpa
 *        SW-C Type:  CDD_VideoRTP
 *  Generation Time:  2022-07-29 09:15:49
 *
 *        Generator:  MICROSAR RTE Generator Version 4.26.0
 *                    RTE Core Version 1.26.0
 *          License:  CBD2100861
 *
 *      Description:  C-Code implementation template for SW-C <CDD_VideoRTP>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_Rule5.1, MD_MSR_Rule5.2 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CDD_VideoRTP.h"


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
#include "PduR_Cfg.h"
#include "VideoRTP.h"

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Rte_DT_SG_MIK_01_0: Enumeration of integer in interval [0...1] with enumerators
 *   CM_FaceRec2_Status_Challenge_Req_Cx0_SEND_NOTHING (0U)
 *   CM_FaceRec2_Status_Challenge_Req_Cx1_SEND_CHALLENGE (1U)
 * Rte_DT_SG_MIK_01_1: Enumeration of integer in interval [0...1] with enumerators
 *   CM_FaceRec_Auth_Challenge_Request_Cx1_SEND_CHALLENGE (1U)
 *   CM_FaceRec_Auth_Challenge_Request_Cx0_SEND_NOTHING (0U)
 * Rte_DT_SG_MIK_01_10: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_DriverChange_Cx0_No_driver_change_detected (0U)
 *   CM_MIK_DriverChange_Cx1_Driver_change_detected (1U)
 * Rte_DT_SG_MIK_01_11: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_DriverPresence_Cx0_No_driver_present (0U)
 *   CM_MIK_DriverPresence_Cx7_Error (7U)
 *   CM_MIK_DriverPresence_Cx1_Driver_present (1U)
 *   CM_MIK_DriverPresence_Cx6_Init (6U)
 *   CM_MIK_DriverPresence_Cx2_Driver_present_and_buckled (2U)
 * Rte_DT_SG_MIK_01_12: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_DriverSmoking_Cx5_Unknown (5U)
 *   CM_MIK_DriverSmoking_Cx0_No_driver_smoking (0U)
 *   CM_MIK_DriverSmoking_Cx6_Init (6U)
 *   CM_MIK_DriverSmoking_Cx7_Error (7U)
 *   CM_MIK_DriverSmoking_Cx1_Driver_smoking (1U)
 * Rte_DT_SG_MIK_01_13: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_DriverSmokingQual_Cxe_Init (14U)
 *   CM_MIK_DriverSmokingQual_Cxf_Error (15U)
 *   CM_MIK_DriverSmokingQual_Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_14: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_DriverSpeaking_Cx0_Driver_not_speaking (0U)
 *   CM_MIK_DriverSpeaking_Cx1_Driver_speaking (1U)
 * Rte_DT_SG_MIK_01_15: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_DriverTelephoneUsage_Cx5_Unknown (5U)
 *   CM_MIK_DriverTelephoneUsage_Cx7_Error (7U)
 *   CM_MIK_DriverTelephoneUsage_Cx1_Telephone_usage (1U)
 *   CM_MIK_DriverTelephoneUsage_Cx0_No_telephone_usage (0U)
 *   CM_MIK_DriverTelephoneUsage_Cx6_Init (6U)
 * Rte_DT_SG_MIK_01_16: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_DriverTelephoneUsageQual_Cxd_Unknown (13U)
 *   CM_MIK_DriverTelephoneUsageQual_Cxf_Error (15U)
 *   CM_MIK_DriverTelephoneUsageQual_Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_17: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_DriverYawning_Cx1_Driver_yawning (1U)
 *   CM_MIK_DriverYawning_Cx7_Error (7U)
 *   CM_MIK_DriverYawning_Cx5_Unknown (5U)
 *   CM_MIK_DriverYawning_Cx0_No_driver_yawning (0U)
 *   CM_MIK_DriverYawning_Cx6_Init (6U)
 * Rte_DT_SG_MIK_01_18: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_DriverYawningQual_Cxf_Error (15U)
 *   CM_MIK_DriverYawningQual_Cxe_Init (14U)
 *   CM_MIK_DriverYawningQual_Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_19: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_DrowsinessLevel_Cx4_Neither_alert_nor_sleepy (4U)
 *   CM_MIK_DrowsinessLevel_Cx2_Alert (2U)
 *   CM_MIK_DrowsinessLevel_Cxe_Init (14U)
 *   CM_MIK_DrowsinessLevel_Cx3_Fairly_alert (3U)
 *   CM_MIK_DrowsinessLevel_Cxd_Unknown (13U)
 *   CM_MIK_DrowsinessLevel_Cxf_Error (15U)
 *   CM_MIK_DrowsinessLevel_Cx1_Very_alert (1U)
 *   CM_MIK_DrowsinessLevel_Cx5_Signs_of_sleepiness (5U)
 *   CM_MIK_DrowsinessLevel_Cx8_Very_Sleepy (8U)
 *   CM_MIK_DrowsinessLevel_Cx6_Sleepy_no_effort (6U)
 *   CM_MIK_DrowsinessLevel_Cx7_Sleepy_some_effort (7U)
 *   CM_MIK_DrowsinessLevel_Cx0_Extremely_alert (0U)
 * Rte_DT_SG_MIK_01_20: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_DrowsinessLevelQual_Cxf_Error (15U)
 *   CM_MIK_DrowsinessLevelQual_Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_21: Enumeration of integer in interval [0...127] with enumerators
 *   CM_MIK_DurEyesCl_Cx7e_Init (126U)
 *   CM_MIK_DurEyesCl_Cx7c_Max_value_reached (124U)
 *   CM_MIK_DurEyesCl_Cx7d_Unknown (125U)
 *   CM_MIK_DurEyesCl_Cx7f_Error (127U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_22: Enumeration of integer in interval [0...511] with enumerators
 *   CM_MIK_DurEyesNotOnTfc_Cx1ff_Error (511U)
 *   CM_MIK_DurEyesNotOnTfc_Cx1fe_Init (510U)
 *   CM_MIK_DurEyesNotOnTfc_Cx1fc_Max_value_reached (508U)
 *   CM_MIK_DurEyesNotOnTfc_Cx1fd_Unknown (509U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_23: Enumeration of integer in interval [0...3] with enumerators
 *   CM_MIK_Fahrer_erkannt_Cx3_Fehler (3U)
 *   CM_MIK_Fahrer_erkannt_Cx1_Fahrer_nicht_erkannt (1U)
 *   CM_MIK_Fahrer_erkannt_Cx0_Init (0U)
 *   CM_MIK_Fahrer_erkannt_Cx2_Fahrer_erkannt (2U)
 * Rte_DT_SG_MIK_01_24: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_FakeDetected_Cx0_No_fake_detected (0U)
 *   CM_MIK_FakeDetected_Cx1_Fake_detected (1U)
 * Rte_DT_SG_MIK_01_25: Enumeration of integer in interval [0...4] with enumerators
 *   CM_MIK_ICV_AspectRatio_Cx0_init (0U)
 *   CM_MIK_ICV_AspectRatio_Cx3_AspectRatio_3_4 (3U)
 *   CM_MIK_ICV_AspectRatio_Cx1_AspectRatio_4_3 (1U)
 *   CM_MIK_ICV_AspectRatio_Cx4_AspectRatio_9_16 (4U)
 *   CM_MIK_ICV_AspectRatio_Cx2_AspectRatio_16_9 (2U)
 * Rte_DT_SG_MIK_01_26: Enumeration of integer in interval [0...126] with enumerators
 *   CM_MIK_ICV_Brightness_Cx7e_init (126U)
 *   Unit: [Unit_PerCent], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_27: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_ICV_ColorMode_Cx2_IR (2U)
 *   CM_MIK_ICV_ColorMode_Cx0_init (0U)
 *   CM_MIK_ICV_ColorMode_Cx1_RGB (1U)
 * Rte_DT_SG_MIK_01_28: Enumeration of integer in interval [0...126] with enumerators
 *   CM_MIK_ICV_Contrast_Cx7e_init (126U)
 *   Unit: [Unit_PerCent], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_29: Enumeration of integer in interval [0...3] with enumerators
 *   CM_MIK_ICV_FieldOfView_Cx1_show_Driver (1U)
 *   CM_MIK_ICV_FieldOfView_Cx0_init (0U)
 *   CM_MIK_ICV_FieldOfView_Cx2_show_CoDriver (2U)
 *   CM_MIK_ICV_FieldOfView_Cx3_show_fullCabine (3U)
 * Rte_DT_SG_MIK_01_30: Enumeration of integer in interval [15...31] with enumerators
 *   CM_MIK_ICV_FrameRate_Cx1f_init (31U)
 *   Unit: [Unit_SeconInver], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_31: Enumeration of integer in interval [0...3] with enumerators
 *   CM_MIK_ICV_FunctionState_Cx0_init (0U)
 *   CM_MIK_ICV_FunctionState_Cx3_error (3U)
 *   CM_MIK_ICV_FunctionState_Cx1_started (1U)
 *   CM_MIK_ICV_FunctionState_Cx2_shutDown (2U)
 * Rte_DT_SG_MIK_01_32: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_ICV_HDR_Cx2_off (2U)
 *   CM_MIK_ICV_HDR_Cx0_init (0U)
 *   CM_MIK_ICV_HDR_Cx1_on (1U)
 * Rte_DT_SG_MIK_01_33: Enumeration of integer in interval [0...5] with enumerators
 *   CM_MIK_ICV_Resolution_Cx1_Aufloesung_160x120 (1U)
 *   CM_MIK_ICV_Resolution_Cx3_Aufloesung_640x480 (3U)
 *   CM_MIK_ICV_Resolution_Cx2_Aufloesung_320x240 (2U)
 *   CM_MIK_ICV_Resolution_Cx0_Init (0U)
 *   CM_MIK_ICV_Resolution_Cx5_Aufloesung_1920x1080 (5U)
 *   CM_MIK_ICV_Resolution_Cx4_Aufloesung_1280x720 (4U)
 * Rte_DT_SG_MIK_01_34: Enumeration of integer in interval [0...4] with enumerators
 *   CM_MIK_ICV_VideoLength_Cx1_Lenght_15s (1U)
 *   CM_MIK_ICV_VideoLength_Cx3_Lenght_60s (3U)
 *   CM_MIK_ICV_VideoLength_Cx0_init (0U)
 *   CM_MIK_ICV_VideoLength_Cx4_customized (4U)
 *   CM_MIK_ICV_VideoLength_Cx2_Lenght_30s (2U)
 * Rte_DT_SG_MIK_01_35: Enumeration of integer in interval [0...6] with enumerators
 *   CM_MIK_ICV_Videostream_State_Cx4_standby (4U)
 *   CM_MIK_ICV_Videostream_State_Cx1_on (1U)
 *   CM_MIK_ICV_Videostream_State_Cx5_freezed (5U)
 *   CM_MIK_ICV_Videostream_State_Cx0_init (0U)
 *   CM_MIK_ICV_Videostream_State_Cx2_off (2U)
 *   CM_MIK_ICV_Videostream_State_Cx6_error (6U)
 *   CM_MIK_ICV_Videostream_State_Cx3_blurred (3U)
 * Rte_DT_SG_MIK_01_36: Enumeration of integer in interval [0...3] with enumerators
 *   CM_MIK_ICV_VideostreamResult_Cx2_freezed (2U)
 *   CM_MIK_ICV_VideostreamResult_Cx3_cancelled (3U)
 *   CM_MIK_ICV_VideostreamResult_Cx1_started (1U)
 *   CM_MIK_ICV_VideostreamResult_Cx0_init (0U)
 * Rte_DT_SG_MIK_01_37: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_LeftHandPos_Cx2_Center_console (2U)
 *   CM_MIK_LeftHandPos_Cxe_Init (14U)
 *   CM_MIK_LeftHandPos_Cxc_Far_right (12U)
 *   CM_MIK_LeftHandPos_Cx9_Light_switch (9U)
 *   CM_MIK_LeftHandPos_Cxf_Error (15U)
 *   CM_MIK_LeftHandPos_Cx6_Rear_view_mirror (6U)
 *   CM_MIK_LeftHandPos_Cx5_Lower_body (5U)
 *   CM_MIK_LeftHandPos_Cx3_Armrest (3U)
 *   CM_MIK_LeftHandPos_Cx4_Upper_body (4U)
 *   CM_MIK_LeftHandPos_Cx0_Unknown (0U)
 *   CM_MIK_LeftHandPos_Cx8_Driver_door (8U)
 *   CM_MIK_LeftHandPos_Cx1_Infotainment_display (1U)
 *   CM_MIK_LeftHandPos_Cxb_Far_left (11U)
 *   CM_MIK_LeftHandPos_Cx7_Sun_visor (7U)
 *   CM_MIK_LeftHandPos_Cxa_Steering_wheel (10U)
 * Rte_DT_SG_MIK_01_38: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_LeftHandPosQual_Cxd_Unknown (13U)
 *   CM_MIK_LeftHandPosQual_Cxf_Error (15U)
 *   CM_MIK_LeftHandPosQual_Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_39: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_Microsleep_Cx2_Microsleep_detected (2U)
 *   CM_MIK_Microsleep_Cx0_No_microsleep_detected (0U)
 *   CM_MIK_Microsleep_Cx7_Error (7U)
 *   CM_MIK_Microsleep_Cx6_Init (6U)
 *   CM_MIK_Microsleep_Cx1_Microsleep_imminent (1U)
 * Rte_DT_SG_MIK_01_4: Enumeration of integer in interval [0...31] with enumerators
 *   CM_MIK_BlinkRate_Cx1e_Init (30U)
 *   CM_MIK_BlinkRate_Cx1d_Unknown (29U)
 *   CM_MIK_BlinkRate_Cx1f_Error (31U)
 *   CM_MIK_BlinkRate_Cx1c_Max_value_reached (28U)
 *   Unit: [Unit_None], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_40: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_MicrosleepQual_Cxe_Init (14U)
 *   CM_MIK_MicrosleepQual_Cxd_Unknown (13U)
 *   CM_MIK_MicrosleepQual_Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_41: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_PassengerPresence_Cx0_No_passenger_present (0U)
 *   CM_MIK_PassengerPresence_Cx1_Passenger_present (1U)
 * Rte_DT_SG_MIK_01_42: Enumeration of integer in interval [0...127] with enumerators
 *   CM_MIK_PercentageEyesOnTraffic_Cx7f_Error (127U)
 *   CM_MIK_PercentageEyesOnTraffic_Cx7d_Unknown (125U)
 *   CM_MIK_PercentageEyesOnTraffic_Cx7e_Init (126U)
 *   Unit: [Unit_PerCent], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_43: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_PetPresence_Cx1_pet_present (1U)
 *   CM_MIK_PetPresence_Cx0_no_pet_present (0U)
 *   CM_MIK_PetPresence_Cx2_init (2U)
 * Rte_DT_SG_MIK_01_44: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_PetsMode_Active_Cx1_Function_enabled (1U)
 *   CM_MIK_PetsMode_Active_Cx0_Function_disabled (0U)
 * Rte_DT_SG_MIK_01_45: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_RightHandPos_Cx4_Upper_body (4U)
 *   CM_MIK_RightHandPos_Cx1_Infotainment_display (1U)
 *   CM_MIK_RightHandPos_Cxa_Steering_wheel (10U)
 *   CM_MIK_RightHandPos_Cx2_Center_console (2U)
 *   CM_MIK_RightHandPos_Cx7_Sun_visor (7U)
 *   CM_MIK_RightHandPos_Cx6_Rear_view_mirror (6U)
 *   CM_MIK_RightHandPos_Cxb_Far_left (11U)
 *   CM_MIK_RightHandPos_Cx5_Lower_body (5U)
 *   CM_MIK_RightHandPos_Cx8_Driver_door (8U)
 *   CM_MIK_RightHandPos_Cx0_Unknown (0U)
 *   CM_MIK_RightHandPos_Cx3_Armrest (3U)
 *   CM_MIK_RightHandPos_Cxe_Init (14U)
 *   CM_MIK_RightHandPos_Cx9_Light_switch (9U)
 *   CM_MIK_RightHandPos_Cxf_Error (15U)
 *   CM_MIK_RightHandPos_Cxc_Far_right (12U)
 * Rte_DT_SG_MIK_01_46: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_RightHandPosQual_Cxd_Unknown (13U)
 *   CM_MIK_RightHandPosQual_Cxf_Error (15U)
 *   CM_MIK_RightHandPosQual_Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_47: Enumeration of integer in interval [0...5] with enumerators
 *   CM_MIK_Selfie_FunctionState_Cx3_PhotoShot_Single (3U)
 *   CM_MIK_Selfie_FunctionState_Cx5_Cancel (5U)
 *   CM_MIK_Selfie_FunctionState_Cx2_VideoShot_Stop (2U)
 *   CM_MIK_Selfie_FunctionState_Cx4_PhotoShot_Continuous (4U)
 *   CM_MIK_Selfie_FunctionState_Cx0_init (0U)
 *   CM_MIK_Selfie_FunctionState_Cx1_VideoShot_Start (1U)
 * Rte_DT_SG_MIK_01_48: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_Selfie_Resolution_Cx0_init (0U)
 *   CM_MIK_Selfie_Resolution_Cx1_Res_5M_pixels (1U)
 *   CM_MIK_Selfie_Resolution_Cx2_Res_2M_pixels (2U)
 * Rte_DT_SG_MIK_01_49: Enumeration of integer in interval [0...31] with enumerators
 *   CM_MIK_SpaAttDstrAr_01_Cxa_Rear_view_mirror (10U)
 *   CM_MIK_SpaAttDstrAr_01_Cxb_Instrument_cluster (11U)
 *   CM_MIK_SpaAttDstrAr_01_Cx13_Far_right (19U)
 *   CM_MIK_SpaAttDstrAr_01_Cx1f_Error (31U)
 *   CM_MIK_SpaAttDstrAr_01_Cx4_Windshield_bottom_center (4U)
 *   CM_MIK_SpaAttDstrAr_01_Cx10_Driver_lap (16U)
 *   CM_MIK_SpaAttDstrAr_01_Cxe_Infotainment_display (14U)
 *   CM_MIK_SpaAttDstrAr_01_Cxd_Steering_wheel (13U)
 *   CM_MIK_SpaAttDstrAr_01_Cx1e_Init (30U)
 *   CM_MIK_SpaAttDstrAr_01_Cx6_Windshield_bottom_far_right (6U)
 *   CM_MIK_SpaAttDstrAr_01_Cxc_Dashboard (12U)
 *   CM_MIK_SpaAttDstrAr_01_Cx0_Unknown (0U)
 *   CM_MIK_SpaAttDstrAr_01_Cx1_Windshield_top_left (1U)
 *   CM_MIK_SpaAttDstrAr_01_Cx12_Far_left (18U)
 *   CM_MIK_SpaAttDstrAr_01_Cx7_Light_switch (7U)
 *   CM_MIK_SpaAttDstrAr_01_Cx11_Glovebox (17U)
 *   CM_MIK_SpaAttDstrAr_01_Cx2_Windshield_top_right (2U)
 *   CM_MIK_SpaAttDstrAr_01_Cx5_Windshield_bottom_right (5U)
 *   CM_MIK_SpaAttDstrAr_01_Cx3_Windshield_bottom_left (3U)
 *   CM_MIK_SpaAttDstrAr_01_Cx8_Sidemirror_left (8U)
 *   CM_MIK_SpaAttDstrAr_01_Cx9_Sidemirror_right (9U)
 *   CM_MIK_SpaAttDstrAr_01_Cxf_Center_console (15U)
 * Rte_DT_SG_MIK_01_5: Enumeration of integer in interval [0...1] with enumerators
 *   CM_MIK_CabinCare_Active_Cx0_Function_disabled (0U)
 *   CM_MIK_CabinCare_Active_Cx1_Function_enabled (1U)
 * Rte_DT_SG_MIK_01_50: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_SpaAttDstrProb_01_Cxe_Init (14U)
 *   CM_MIK_SpaAttDstrProb_01_Cxd_Unknown (13U)
 *   CM_MIK_SpaAttDstrProb_01_Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_51: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_Status_Cx6_Init (6U)
 *   CM_MIK_Status_Cx0_Inactive (0U)
 *   CM_MIK_Status_Cx1_Running (1U)
 *   CM_MIK_Status_Cx7_Error (7U)
 *   CM_MIK_Status_Cx2_Not_available (2U)
 * Rte_DT_SG_MIK_01_52: Enumeration of integer in interval [0...1023] with enumerators
 *   CM_MIK_TotDurEyesNotOnTfc_Cx3fe_Init (1022U)
 *   CM_MIK_TotDurEyesNotOnTfc_Cx3fd_Unknown (1021U)
 *   CM_MIK_TotDurEyesNotOnTfc_Cx3ff_Error (1023U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_53: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_UnusualHeadPose_Cx6_Init (6U)
 *   CM_MIK_UnusualHeadPose_Cx0_No_unusual_head_pose (0U)
 *   CM_MIK_UnusualHeadPose_Cx5_Unknown (5U)
 *   CM_MIK_UnusualHeadPose_Cx1_Unusual_head_pose (1U)
 *   CM_MIK_UnusualHeadPose_Cx7_Error (7U)
 * Rte_DT_SG_MIK_01_54: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_UnusualHeadPoseQual_Cxe_Init (14U)
 *   CM_MIK_UnusualHeadPoseQual_Cxf_Error (15U)
 *   CM_MIK_UnusualHeadPoseQual_Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_55: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_VisualDistractionLevel_Cx2_Distracted (2U)
 *   CM_MIK_VisualDistractionLevel_Cx0_Not_distracted (0U)
 *   CM_MIK_VisualDistractionLevel_Cx1_Slightly_distracted (1U)
 *   CM_MIK_VisualDistractionLevel_Cx3_Very_distracted (3U)
 *   CM_MIK_VisualDistractionLevel_Cx6_Init (6U)
 *   CM_MIK_VisualDistractionLevel_Cx7_Error (7U)
 *   CM_MIK_VisualDistractionLevel_Cx5_Unknown (5U)
 * Rte_DT_SG_MIK_01_56: Enumeration of integer in interval [0...15] with enumerators
 *   CM_MIK_VisualDistractionLevelQual_Cxe_Init (14U)
 *   CM_MIK_VisualDistractionLevelQual_Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_6: Enumeration of integer in interval [0...4] with enumerators
 *   CM_MIK_CabinCare_state_Cx2_Standby (2U)
 *   CM_MIK_CabinCare_state_Cx0_Off (0U)
 *   CM_MIK_CabinCare_state_Cx3_Active (3U)
 *   CM_MIK_CabinCare_state_Cx1_Initialization (1U)
 *   CM_MIK_CabinCare_state_Cx4_error (4U)
 * Rte_DT_SG_MIK_01_7: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_ChildPresence_Cx2_init (2U)
 *   CM_MIK_ChildPresence_Cx1_child_present (1U)
 *   CM_MIK_ChildPresence_Cx0_no_child_present (0U)
 * Rte_DT_SG_MIK_01_8: Enumeration of integer in interval [0...2] with enumerators
 *   CM_MIK_ChildStatus_Cx1_awake (1U)
 *   CM_MIK_ChildStatus_Cx2_sleep (2U)
 *   CM_MIK_ChildStatus_Cx0_init (0U)
 * Rte_DT_SG_MIK_01_9: Enumeration of integer in interval [0...7] with enumerators
 *   CM_MIK_DetectionMode_Cx3_None (3U)
 *   CM_MIK_DetectionMode_Cx6_Init (6U)
 *   CM_MIK_DetectionMode_Cx1_Head_pose (1U)
 *   CM_MIK_DetectionMode_Cx2_Combined (2U)
 *   CM_MIK_DetectionMode_Cx7_Error (7U)
 *   CM_MIK_DetectionMode_Cx0_Gaze (0U)
 *
 * Record Types:
 * =============
 * SG_MIK_01: Record with elements
 *   FaceRec2_Status_Challenge_Req of type Rte_DT_SG_MIK_01_0
 *   FaceRec_Auth_Challenge_Request of type Rte_DT_SG_MIK_01_1
 *   MIK_01_BZ of type uint8
 *   MIK_01_CRC of type uint8
 *   MIK_BlinkRate of type Rte_DT_SG_MIK_01_4
 *   MIK_CabinCare_Active of type Rte_DT_SG_MIK_01_5
 *   MIK_CabinCare_state of type Rte_DT_SG_MIK_01_6
 *   MIK_ChildPresence of type Rte_DT_SG_MIK_01_7
 *   MIK_ChildStatus of type Rte_DT_SG_MIK_01_8
 *   MIK_DetectionMode of type Rte_DT_SG_MIK_01_9
 *   MIK_DriverChange of type Rte_DT_SG_MIK_01_10
 *   MIK_DriverPresence of type Rte_DT_SG_MIK_01_11
 *   MIK_DriverSmoking of type Rte_DT_SG_MIK_01_12
 *   MIK_DriverSmokingQual of type Rte_DT_SG_MIK_01_13
 *   MIK_DriverSpeaking of type Rte_DT_SG_MIK_01_14
 *   MIK_DriverTelephoneUsage of type Rte_DT_SG_MIK_01_15
 *   MIK_DriverTelephoneUsageQual of type Rte_DT_SG_MIK_01_16
 *   MIK_DriverYawning of type Rte_DT_SG_MIK_01_17
 *   MIK_DriverYawningQual of type Rte_DT_SG_MIK_01_18
 *   MIK_DrowsinessLevel of type Rte_DT_SG_MIK_01_19
 *   MIK_DrowsinessLevelQual of type Rte_DT_SG_MIK_01_20
 *   MIK_DurEyesCl of type Rte_DT_SG_MIK_01_21
 *   MIK_DurEyesNotOnTfc of type Rte_DT_SG_MIK_01_22
 *   MIK_Fahrer_erkannt of type Rte_DT_SG_MIK_01_23
 *   MIK_FakeDetected of type Rte_DT_SG_MIK_01_24
 *   MIK_ICV_AspectRatio of type Rte_DT_SG_MIK_01_25
 *   MIK_ICV_Brightness of type Rte_DT_SG_MIK_01_26
 *   MIK_ICV_ColorMode of type Rte_DT_SG_MIK_01_27
 *   MIK_ICV_Contrast of type Rte_DT_SG_MIK_01_28
 *   MIK_ICV_FieldOfView of type Rte_DT_SG_MIK_01_29
 *   MIK_ICV_FrameRate of type Rte_DT_SG_MIK_01_30
 *   MIK_ICV_FunctionState of type Rte_DT_SG_MIK_01_31
 *   MIK_ICV_HDR of type Rte_DT_SG_MIK_01_32
 *   MIK_ICV_Resolution of type Rte_DT_SG_MIK_01_33
 *   MIK_ICV_VideoLength of type Rte_DT_SG_MIK_01_34
 *   MIK_ICV_Videostream_State of type Rte_DT_SG_MIK_01_35
 *   MIK_ICV_VideostreamResult of type Rte_DT_SG_MIK_01_36
 *   MIK_LeftHandPos of type Rte_DT_SG_MIK_01_37
 *   MIK_LeftHandPosQual of type Rte_DT_SG_MIK_01_38
 *   MIK_Microsleep of type Rte_DT_SG_MIK_01_39
 *   MIK_MicrosleepQual of type Rte_DT_SG_MIK_01_40
 *   MIK_PassengerPresence of type Rte_DT_SG_MIK_01_41
 *   MIK_PercentageEyesOnTraffic of type Rte_DT_SG_MIK_01_42
 *   MIK_PetPresence of type Rte_DT_SG_MIK_01_43
 *   MIK_PetsMode_Active of type Rte_DT_SG_MIK_01_44
 *   MIK_RightHandPos of type Rte_DT_SG_MIK_01_45
 *   MIK_RightHandPosQual of type Rte_DT_SG_MIK_01_46
 *   MIK_Selfie_FunctionState of type Rte_DT_SG_MIK_01_47
 *   MIK_Selfie_Resolution of type Rte_DT_SG_MIK_01_48
 *   MIK_SpaAttDstrAr_01 of type Rte_DT_SG_MIK_01_49
 *   MIK_SpaAttDstrProb_01 of type Rte_DT_SG_MIK_01_50
 *   MIK_Status of type Rte_DT_SG_MIK_01_51
 *   MIK_TotDurEyesNotOnTfc of type Rte_DT_SG_MIK_01_52
 *   MIK_UnusualHeadPose of type Rte_DT_SG_MIK_01_53
 *   MIK_UnusualHeadPoseQual of type Rte_DT_SG_MIK_01_54
 *   MIK_VisualDistractionLevel of type Rte_DT_SG_MIK_01_55
 *   MIK_VisualDistractionLevelQual of type Rte_DT_SG_MIK_01_56
 *   SignalVoid_MIK_01_0 of type uint8
 *   SignalVoid_MIK_01_1 of type uint8
 *   SignalVoid_MIK_01_2 of type uint8
 *   SignalVoid_MIK_01_3 of type uint8
 *   SignalVoid_MIK_01_4 of type uint8
 *   SignalVoid_MIK_01_5 of type uint8
 *   SignalVoid_MIK_01_6 of type uint8
 *   SignalVoid_MIK_01_7 of type uint8
 *   SignalVoid_MIK_01_8 of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Calibration Parameters:
 * =======================
 *   SW-C local Calibration Parameters:
 *   ----------------------------------
 *   boolean Rte_CData_VideoTransmissionOn(void)
 *
 *********************************************************************************************************************/


#define CDD_VideoRTP_START_SEC_CODE
#include "CDD_VideoRTP_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_MemMap */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CDD_VideoRTP_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CDD_VideoRTP_CODE) CDD_VideoRTP_Init(void) /* PRQA S 0624, 3206 */ /* MD_Rte_0624, MD_Rte_3206 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_Init
 *********************************************************************************************************************/

    VIDEORTP_initConfiguration dummyConfiguration = {
        .mainFunctionPeriod = 1,
        .targetDataRate = 6000000,
        .targetFrameRate = 30,
        .rtpPdu = PduRConf_PduRSrcPdu_PduRSrcPdu_c6b04b1f,
        .rtcpPdu = PduRConf_PduRSrcPdu_PduRSrcPdu_bfdc585b,
        .avMasterConfiguration = {
            .videoPid = 0x0100,
            .programId = 1,
            .patInterval = 250,
            .pmtPid = 0x1000,
            .streamId = 1,
        },
        .sessionConfiguration = {
            .ssrc = { 1, 2, 3, 4 },
        },
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        .isTestVideoEnabled = true,
#endif
    };

    VIDEORTP_init(&dummyConfiguration);

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CDD_VideoRTP_MainFunction
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 1ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_MainFunction_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CDD_VideoRTP_CODE) CDD_VideoRTP_MainFunction(void) /* PRQA S 0624, 3206 */ /* MD_Rte_0624, MD_Rte_3206 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_MainFunction
 *********************************************************************************************************************/
    if(Rte_CDD_VideoRTP_VideoTransmissionOn == TRUE)
    {
        VIDEORTP_cyclic();
    }
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CDD_VideoRTP_STOP_SEC_CODE
#include "CDD_VideoRTP_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_MemMap */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 MISRA 2012 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_0624:  MISRA rule: Rule8.3
     Reason:     This MISRA violation is a consequence from the RTE requirements [SWS_Rte_01007] [SWS_Rte_01150].
                 The typedefs are never used in the same context.
     Risk:       No functional risk. Only a cast to uint8* is performed.
     Prevention: Not required.

   MD_Rte_3206:  MISRA rule: Rule2.7
     Reason:     The parameter are not used by the code in all possible code variants.
     Risk:       No functional risk.
     Prevention: Not required.

*/
