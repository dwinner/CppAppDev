/**********************************************************************************************************************
 *  FILE REQUIRES USER MODIFICATIONS
 *  Template Scope: sections marked with Start and End comments
 *  -------------------------------------------------------------------------------------------------------------------
 *  This file includes template code that must be completed and/or adapted during BSW integration.
 *  The template code is incomplete and only intended for providing a signature and an empty implementation.
 *  It is neither intended nor qualified for use in series production without applying suitable quality measures.
 *  The template code must be completed as described in the instructions given within this file and/or in the.
 *  Technical Reference.
 *  The completed implementation must be tested with diligent care and must comply with all quality requirements which.
 *  are necessary according to the state of the art before its use.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 *  FILE DESCRIPTION
 *  -------------------------------------------------------------------------------------------------------------------
 *             File:  CDD_VideoRTP.c
 *           Config:  C:/GIT_Repo/L2H5050_Software/pkg/Applications/DaVinci/MIK.dpa
 *        SW-C Type:  CDD_VideoRTP
 *  Generation Time:  2022-06-13 14:26:58
 *
 *        Generator:  MICROSAR RTE Generator Version 4.26.0
 *                    RTE Core Version 1.26.0
 *          License:  CBD2100861
 *
 *      Description:  C-Code implementation template for SW-C <CDD_VideoRTP>
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of version logging area >>                DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/* PRQA S 0777, 0779 EOF */ /* MD_MSR_Rule5.1, MD_MSR_Rule5.2 */

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of version logging area >>                  DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

#include "Rte_CDD_VideoRTP.h"


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of include and declaration area >>        DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
#include "VideoRTP.h"
#include "PduR_Cfg.h"

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of include and declaration area >>          DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * Used AUTOSAR Data Types
 *
 **********************************************************************************************************************
 *
 * Primitive Types:
 * ================
 * boolean: Boolean (standard type)
 * uint8: Integer in interval [0...255] (standard type)
 *
 * Enumeration Types:
 * ==================
 * Rte_DT_SG_MIK_01_0: Enumeration of integer in interval [0...1] with enumerators
 *   Cx1_SEND_CHALLENGE (1U)
 *   Cx0_SEND_NOTHING (0U)
 * Rte_DT_SG_MIK_01_10: Enumeration of integer in interval [0...7] with enumerators
 *   Cx5_Unknown (5U)
 *   Cx7_Error (7U)
 *   Cx1_Telephone_usage (1U)
 *   Cx0_No_telephone_usage (0U)
 *   Cx6_Init (6U)
 * Rte_DT_SG_MIK_01_11: Enumeration of integer in interval [0...15] with enumerators
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_12: Enumeration of integer in interval [0...7] with enumerators
 *   Cx1_Driver_yawning (1U)
 *   Cx7_Error (7U)
 *   Cx5_Unknown (5U)
 *   Cx0_No_driver_yawning (0U)
 *   Cx6_Init (6U)
 * Rte_DT_SG_MIK_01_13: Enumeration of integer in interval [0...15] with enumerators
 *   Cxf_Error (15U)
 *   Cxe_Init (14U)
 *   Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_14: Enumeration of integer in interval [0...15] with enumerators
 *   Cx4_Neither_alert_nor_sleepy (4U)
 *   Cx2_Alert (2U)
 *   Cxe_Init (14U)
 *   Cx3_Fairly_alert (3U)
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Cx1_Very_alert (1U)
 *   Cx5_Signs_of_sleepiness (5U)
 *   Cx8_Very_Sleepy (8U)
 *   Cx6_Sleepy_no_effort (6U)
 *   Cx7_Sleepy_some_effort (7U)
 *   Cx0_Extremely_alert (0U)
 * Rte_DT_SG_MIK_01_15: Enumeration of integer in interval [0...15] with enumerators
 *   Cxf_Error (15U)
 *   Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_16: Enumeration of integer in interval [0...127] with enumerators
 *   Cx7e_Init (126U)
 *   Cx7c_Max_value_reached (124U)
 *   Cx7d_Unknown (125U)
 *   Cx7f_Error (127U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_17: Enumeration of integer in interval [0...511] with enumerators
 *   Cx1ff_Error (511U)
 *   Cx1fe_Init (510U)
 *   Cx1fc_Max_value_reached (508U)
 *   Cx1fd_Unknown (509U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_18: Enumeration of integer in interval [0...3] with enumerators
 *   Cx3_Fehler (3U)
 *   Cx1_Fahrer_nicht_erkannt (1U)
 *   Cx0_Init (0U)
 *   Cx2_Fahrer_erkannt (2U)
 * Rte_DT_SG_MIK_01_19: Enumeration of integer in interval [0...1] with enumerators
 *   Cx0_No_fake_detected (0U)
 *   Cx1_Fake_detected (1U)
 * Rte_DT_SG_MIK_01_20: Enumeration of integer in interval [0...15] with enumerators
 *   Cx2_Center_console (2U)
 *   Cxe_Init (14U)
 *   Cxc_Far_right (12U)
 *   Cx9_Light_switch (9U)
 *   Cxf_Error (15U)
 *   Cx6_Rear_view_mirror (6U)
 *   Cx5_Lower_body (5U)
 *   Cx3_Armrest (3U)
 *   Cx4_Upper_body (4U)
 *   Cx0_Unknown (0U)
 *   Cx8_Driver_door (8U)
 *   Cx1_Infotainment_display (1U)
 *   Cxb_Far_left (11U)
 *   Cx7_Sun_visor (7U)
 *   Cxa_Steering_wheel (10U)
 * Rte_DT_SG_MIK_01_21: Enumeration of integer in interval [0...15] with enumerators
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_22: Enumeration of integer in interval [0...7] with enumerators
 *   Cx2_Microsleep_detected (2U)
 *   Cx0_No_microsleep_detected (0U)
 *   Cx7_Error (7U)
 *   Cx6_Init (6U)
 *   Cx1_Microsleep_imminent (1U)
 * Rte_DT_SG_MIK_01_23: Enumeration of integer in interval [0...15] with enumerators
 *   Cxe_Init (14U)
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_24: Enumeration of integer in interval [0...1] with enumerators
 *   Cx0_No_passenger_present (0U)
 *   Cx1_Passenger_present (1U)
 * Rte_DT_SG_MIK_01_25: Enumeration of integer in interval [0...127] with enumerators
 *   Cx7f_Error (127U)
 *   Cx7d_Unknown (125U)
 *   Cx7e_Init (126U)
 *   Unit: [Unit_PerCent], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_26: Enumeration of integer in interval [0...15] with enumerators
 *   Cx4_Upper_body (4U)
 *   Cx1_Infotainment_display (1U)
 *   Cxa_Steering_wheel (10U)
 *   Cx2_Center_console (2U)
 *   Cx7_Sun_visor (7U)
 *   Cx6_Rear_view_mirror (6U)
 *   Cxb_Far_left (11U)
 *   Cx5_Lower_body (5U)
 *   Cx8_Driver_door (8U)
 *   Cx0_Unknown (0U)
 *   Cx3_Armrest (3U)
 *   Cxe_Init (14U)
 *   Cx9_Light_switch (9U)
 *   Cxf_Error (15U)
 *   Cxc_Far_right (12U)
 * Rte_DT_SG_MIK_01_27: Enumeration of integer in interval [0...15] with enumerators
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Cxe_Init (14U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_28: Enumeration of integer in interval [0...31] with enumerators
 *   Cxa_Rear_view_mirror (10U)
 *   Cxb_Instrument_cluster (11U)
 *   Cx13_Far_right (19U)
 *   Cx1f_Error (31U)
 *   Cx4_Windshield_bottom_center (4U)
 *   Cx10_Driver_lap (16U)
 *   Cxe_Infotainment_display (14U)
 *   Cxd_Steering_wheel (13U)
 *   Cx1e_Init (30U)
 *   Cx6_Windshield_bottom_far_right (6U)
 *   Cxc_Dashboard (12U)
 *   Cx0_Unknown (0U)
 *   Cx1_Windshield_top_left (1U)
 *   Cx12_Far_left (18U)
 *   Cx7_Light_switch (7U)
 *   Cx11_Glovebox (17U)
 *   Cx2_Windshield_top_right (2U)
 *   Cx5_Windshield_bottom_right (5U)
 *   Cx3_Windshield_bottom_left (3U)
 *   Cx8_Sidemirror_left (8U)
 *   Cx9_Sidemirror_right (9U)
 *   Cxf_Center_console (15U)
 * Rte_DT_SG_MIK_01_29: Enumeration of integer in interval [0...15] with enumerators
 *   Cxe_Init (14U)
 *   Cxd_Unknown (13U)
 *   Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_3: Enumeration of integer in interval [0...31] with enumerators
 *   Cx1e_Init (30U)
 *   Cx1d_Unknown (29U)
 *   Cx1f_Error (31U)
 *   Cx1c_Max_value_reached (28U)
 *   Unit: [Unit_None], Factor: 1, Offset: 0
 * Rte_DT_SG_MIK_01_30: Enumeration of integer in interval [0...7] with enumerators
 *   Cx6_Init (6U)
 *   Cx0_Inactive (0U)
 *   Cx1_Running (1U)
 *   Cx7_Error (7U)
 *   Cx2_Not_available (2U)
 * Rte_DT_SG_MIK_01_31: Enumeration of integer in interval [0...1023] with enumerators
 *   Cx3fe_Init (1022U)
 *   Cx3fd_Unknown (1021U)
 *   Cx3ff_Error (1023U)
 *   Unit: [Unit_Secon], Factor: 0.1, Offset: 0
 * Rte_DT_SG_MIK_01_32: Enumeration of integer in interval [0...7] with enumerators
 *   Cx6_Init (6U)
 *   Cx0_No_unusual_head_pose (0U)
 *   Cx5_Unknown (5U)
 *   Cx1_Unusual_head_pose (1U)
 *   Cx7_Error (7U)
 * Rte_DT_SG_MIK_01_33: Enumeration of integer in interval [0...15] with enumerators
 *   Cxe_Init (14U)
 *   Cxf_Error (15U)
 *   Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_34: Enumeration of integer in interval [0...7] with enumerators
 *   Cx2_Distracted (2U)
 *   Cx0_Not_distracted (0U)
 *   Cx1_Slightly_distracted (1U)
 *   Cx3_Very_distracted (3U)
 *   Cx6_Init (6U)
 *   Cx7_Error (7U)
 *   Cx5_Unknown (5U)
 * Rte_DT_SG_MIK_01_35: Enumeration of integer in interval [0...15] with enumerators
 *   Cxe_Init (14U)
 *   Cxf_Error (15U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_4: Enumeration of integer in interval [0...7] with enumerators
 *   Cx3_None (3U)
 *   Cx6_Init (6U)
 *   Cx1_Head_pose (1U)
 *   Cx2_Combined (2U)
 *   Cx7_Error (7U)
 *   Cx0_Gaze (0U)
 * Rte_DT_SG_MIK_01_5: Enumeration of integer in interval [0...1] with enumerators
 *   Cx0_No_driver_change_detected (0U)
 *   Cx1_Driver_change_detected (1U)
 * Rte_DT_SG_MIK_01_6: Enumeration of integer in interval [0...7] with enumerators
 *   Cx0_No_driver_present (0U)
 *   Cx7_Error (7U)
 *   Cx1_Driver_present (1U)
 *   Cx6_Init (6U)
 *   Cx2_Driver_present_and_buckled (2U)
 * Rte_DT_SG_MIK_01_7: Enumeration of integer in interval [0...7] with enumerators
 *   Cx5_Unknown (5U)
 *   Cx0_No_driver_smoking (0U)
 *   Cx6_Init (6U)
 *   Cx7_Error (7U)
 *   Cx1_Driver_smoking (1U)
 * Rte_DT_SG_MIK_01_8: Enumeration of integer in interval [0...15] with enumerators
 *   Cxe_Init (14U)
 *   Cxf_Error (15U)
 *   Cxd_Unknown (13U)
 *   Unit: [Unit_PerCent], Factor: 10, Offset: 0
 * Rte_DT_SG_MIK_01_9: Enumeration of integer in interval [0...1] with enumerators
 *   Cx0_Driver_not_speaking (0U)
 *   Cx1_Driver_speaking (1U)
 *
 * Record Types:
 * =============
 * SG_MIK_01: Record with elements
 *   FaceRec_Auth_Challenge_Request of type Rte_DT_SG_MIK_01_0
 *   MIK_01_BZ of type uint8
 *   MIK_01_CRC of type uint8
 *   MIK_BlinkRate of type Rte_DT_SG_MIK_01_3
 *   MIK_DetectionMode of type Rte_DT_SG_MIK_01_4
 *   MIK_DriverChange of type Rte_DT_SG_MIK_01_5
 *   MIK_DriverPresence of type Rte_DT_SG_MIK_01_6
 *   MIK_DriverSmoking of type Rte_DT_SG_MIK_01_7
 *   MIK_DriverSmokingQual of type Rte_DT_SG_MIK_01_8
 *   MIK_DriverSpeaking of type Rte_DT_SG_MIK_01_9
 *   MIK_DriverTelephoneUsage of type Rte_DT_SG_MIK_01_10
 *   MIK_DriverTelephoneUsageQual of type Rte_DT_SG_MIK_01_11
 *   MIK_DriverYawning of type Rte_DT_SG_MIK_01_12
 *   MIK_DriverYawningQual of type Rte_DT_SG_MIK_01_13
 *   MIK_DrowsinessLevel of type Rte_DT_SG_MIK_01_14
 *   MIK_DrowsinessLevelQual of type Rte_DT_SG_MIK_01_15
 *   MIK_DurEyesCl of type Rte_DT_SG_MIK_01_16
 *   MIK_DurEyesNotOnTfc of type Rte_DT_SG_MIK_01_17
 *   MIK_Fahrer_erkannt of type Rte_DT_SG_MIK_01_18
 *   MIK_FakeDetected of type Rte_DT_SG_MIK_01_19
 *   MIK_LeftHandPos of type Rte_DT_SG_MIK_01_20
 *   MIK_LeftHandPosQual of type Rte_DT_SG_MIK_01_21
 *   MIK_Microsleep of type Rte_DT_SG_MIK_01_22
 *   MIK_MicrosleepQual of type Rte_DT_SG_MIK_01_23
 *   MIK_PassengerPresence of type Rte_DT_SG_MIK_01_24
 *   MIK_PercentageEyesOnTraffic of type Rte_DT_SG_MIK_01_25
 *   MIK_RightHandPos of type Rte_DT_SG_MIK_01_26
 *   MIK_RightHandPosQual of type Rte_DT_SG_MIK_01_27
 *   MIK_SpaAttDstrAr_01 of type Rte_DT_SG_MIK_01_28
 *   MIK_SpaAttDstrProb_01 of type Rte_DT_SG_MIK_01_29
 *   MIK_Status of type Rte_DT_SG_MIK_01_30
 *   MIK_TotDurEyesNotOnTfc of type Rte_DT_SG_MIK_01_31
 *   MIK_UnusualHeadPose of type Rte_DT_SG_MIK_01_32
 *   MIK_UnusualHeadPoseQual of type Rte_DT_SG_MIK_01_33
 *   MIK_VisualDistractionLevel of type Rte_DT_SG_MIK_01_34
 *   MIK_VisualDistractionLevelQual of type Rte_DT_SG_MIK_01_35
 *   SignalVoid_MIK_01_0 of type uint8
 *   SignalVoid_MIK_01_1 of type uint8
 *   SignalVoid_MIK_01_2 of type uint8
 *   SignalVoid_MIK_01_3 of type uint8
 *   SignalVoid_MIK_01_4 of type uint8
 *   SignalVoid_MIK_01_5 of type uint8
 *   SignalVoid_MIK_01_6 of type uint8
 *   SignalVoid_MIK_01_7 of type uint8
 *   SignalVoid_MIK_01_8 of type uint8
 *   SignalVoid_MIK_01_9 of type uint8
 *   SignalVoid_MIK_01_10 of type uint8
 *   SignalVoid_MIK_01_11 of type uint8
 *   SignalVoid_MIK_01_12 of type uint8
 *   SignalVoid_MIK_01_13 of type uint8
 *   SignalVoid_MIK_01_14 of type uint8
 *   SignalVoid_MIK_01_15 of type uint8
 *   SignalVoid_MIK_01_16 of type uint8
 *
 *********************************************************************************************************************/


/**********************************************************************************************************************
 *
 * APIs which are accessible from all runnable entities of the SW-C
 *
 **********************************************************************************************************************
 * Calibration Parameters:
 * =======================
 *   SW-C local Calibration Parameters:
 *   ----------------------------------
 *   boolean Rte_CData_VideoTransmissionOn(void)
 *
 *********************************************************************************************************************/


#define CDD_VideoRTP_START_SEC_CODE
#include "CDD_VideoRTP_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_MemMap */

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CDD_VideoRTP_Init
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed once after the RTE is started
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_Init_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CDD_VideoRTP_CODE) CDD_VideoRTP_Init(void) /* PRQA S 0624, 3206 */ /* MD_Rte_0624, MD_Rte_3206 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_Init
 *********************************************************************************************************************/

    VIDEORTP_initConfiguration dummyConfiguration = {
        .rtpPdu = PduRConf_PduRSrcPdu_PduRSrcPdu_1,
        .rtcpPdu = PduRConf_PduRSrcPdu_PduRSrcPdu_2,
        .avMasterConfiguration = {
            .streamID = 0x0100,
            .programID = 1,
            #ifdef VIDEORTP_ENABLE_STATIC_INPUT
            .isTestVideoEnabled = true,
            #endif
        },
    };

    VIDEORTP_init(&dummyConfiguration);

/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}

/**********************************************************************************************************************
 *
 * Runnable Entity Name: CDD_VideoRTP_MainFunction
 *
 *---------------------------------------------------------------------------------------------------------------------
 *
 * Executed if at least one of the following trigger conditions occurred:
 *   - triggered on TimingEvent every 1ms
 *
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of documentation area >>                  DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_MainFunction_doc
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of documentation area >>                    DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

FUNC(void, CDD_VideoRTP_CODE) CDD_VideoRTP_MainFunction(void) /* PRQA S 0624, 3206 */ /* MD_Rte_0624, MD_Rte_3206 */
{
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of runnable implementation >>             DO NOT CHANGE THIS COMMENT!
 * Symbol: CDD_VideoRTP_MainFunction
 *********************************************************************************************************************/
    if(Rte_CDD_VideoRTP_VideoTransmissionOn == TRUE)
    {
        VIDEORTP_cyclic();
    }
/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of runnable implementation >>               DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/
}


#define CDD_VideoRTP_STOP_SEC_CODE
#include "CDD_VideoRTP_MemMap.h" /* PRQA S 5087 */ /* MD_MSR_MemMap */


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of function definition area >>            DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of function definition area >>              DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << Start of removed code area >>                   DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/


/**********************************************************************************************************************
 * DO NOT CHANGE THIS COMMENT!           << End of removed code area >>                     DO NOT CHANGE THIS COMMENT!
 *********************************************************************************************************************/

/**********************************************************************************************************************
 MISRA 2012 violations and justifications
 *********************************************************************************************************************/

/* module specific MISRA deviations:
   MD_Rte_0624:  MISRA rule: Rule8.3
     Reason:     This MISRA violation is a consequence from the RTE requirements [SWS_Rte_01007] [SWS_Rte_01150].
                 The typedefs are never used in the same context.
     Risk:       No functional risk. Only a cast to uint8* is performed.
     Prevention: Not required.

   MD_Rte_3206:  MISRA rule: Rule2.7
     Reason:     The parameter are not used by the code in all possible code variants.
     Risk:       No functional risk.
     Prevention: Not required.

*/
