#include "PayloadDataCounter.h"
#include "PayloadUnitRepeater.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

TEST(PayloadDataCounter, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor PayloadDataCounter");
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;

    const size_t bufferSize = 128;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    VIDEORTP_cntInit(&cnt, &rep);

    EXPECT_EQ(cnt.counter, 0);
}

TEST(PayloadDataCounter, COUNT)
{
    TEST_DESCRIPTION("TEST for check change counter of transmitted payload during transmission");
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;

    const size_t bufferSize = 128;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_cntInit(&cnt, &rep);

    uint8_t pattern = 1;
    VIDEORTP_bufWritePattern(&bw, pattern, bufferSize);

    const size_t destSize = 4;
    uint8_t destBuffer[destSize] = {};
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    for (int i = 0; i < 5; i++)
    {
        size_t expectCounter = 0;

        // Copy all data in parts
        for (size_t i = 0; i < bufferSize / destSize; i++)
        {
            // prepareNextChunk must not modify the data counter
            VIDEORTP_payloadChunkInfo_t metadata = {};
            EXPECT_EQ(VIDEORTP_cntGetCounter(&cnt), expectCounter);
            size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&cnt, destSize, &metadata);
            EXPECT_EQ(VIDEORTP_cntGetCounter(&cnt), expectCounter);
            EXPECT_EQ(nextChunkSize, destSize);

            // metadata must not be modified by counter stage
            VIDEORTP_payloadChunkInfo_t metadataRep = {};
            size_t nextChunkSizeRep = VIDEORTP_pipePrepareNextChunk(&rep, destSize, &metadataRep);
            EXPECT_EQ(nextChunkSizeRep, nextChunkSize);
            EXPECT_EQ(memcmp(&metadataRep, &metadata, sizeof(VIDEORTP_payloadChunkInfo_t)), 0);

            // Counter must be incremented after copyChunk
            VIDEORTP_pipeCopyChunk(&cnt, &destBW);
            expectCounter += destSize;
            EXPECT_EQ(VIDEORTP_cntGetCounter(&cnt), expectCounter);
            VIDEORTP_bufClear(&destBW);
        }

        EXPECT_EQ(VIDEORTP_cntGetCounter(&cnt), bufferSize);
        VIDEORTP_cntResetCounter(&cnt);
        EXPECT_EQ(VIDEORTP_cntGetCounter(&cnt), 0);
    }
}
