#include "AvbRtcpPacketBuilder.h"
#include "TestUtils.h"
#include "sysdef.h"
#include <gtest/gtest.h>

TEST(AvbRtcpPacketBuilder, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor AvbRtcpPacketBuilder");
    VIDEORTP_rtcpSessionConfiguration_t configuration = {};
    VIDEORTP_rtcpInitConfig(&configuration, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);

    uint8_t expectSSRC[VIDEORTP_RTCP_SSRC_SIZE] = { 0, 0, 0, 0 };
    uint8_t expectRTCPname[VIDEORTP_RTCP_NAME_SIZE] = { 0, 0, 0, 0 };
    uint8_t expectGMidentity[VIDEORTP_RTCP_GM_IDENTITY_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    uint8_t expectStreamId[VIDEORTP_RTCP_STREAM_ID_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0 };
    uint32_t expectDeliveryCompensationOffset = 0;

    EXPECT_EQ(memcmp(configuration.ssrc, expectSSRC, VIDEORTP_RTCP_SSRC_SIZE), 0);
    EXPECT_EQ(memcmp(configuration.rtcpName, expectRTCPname, VIDEORTP_RTCP_NAME_SIZE), 0);
    EXPECT_EQ(memcmp(configuration.gmIdentity, expectGMidentity, VIDEORTP_RTCP_GM_IDENTITY_SIZE), 0);
    EXPECT_EQ(memcmp(configuration.streamId, expectStreamId, VIDEORTP_RTCP_STREAM_ID_SIZE), 0);
    EXPECT_EQ(configuration.deliveryCompensationOffset, expectDeliveryCompensationOffset);
    EXPECT_EQ(configuration.streamingMode, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);
    EXPECT_EQ(configuration.payloadType, VIDEORTP_RTCP_IP_AVT_ISO_PAYLOAD_TYPE);
}

static size_t generateExpectRtcpHeader(uint8_t* expect, const VIDEORTP_rtcpSessionConfiguration_t config,
                                       const uint32_t asTimestamp = 0, const uint16_t asTimeBaseIndicator = 0,
                                       const uint32_t rtpTimestamp = 0)
{
    uint8_t temp[] = {
        VIDEORTP_RTCP_HEADER_START, // version = 2 (2 bits), padding = 0 (1 bit), report count = 0 (5 bits)

        // packet type
        VIDEORTP_RTCP_AVB_PACKET_TYPE,

        // length
        (uint8_t) (VIDEORTP_RTCP_LENGTH_VALUE >> 8),
        (uint8_t) VIDEORTP_RTCP_LENGTH_VALUE,

        // ssrc
        config.ssrc[0],
        config.ssrc[1],
        config.ssrc[2],
        config.ssrc[3],

        // name
        config.rtcpName[0],
        config.rtcpName[1],
        config.rtcpName[2],
        config.rtcpName[3],

        // gmTimeBaseIndicator
        (uint8_t) (asTimeBaseIndicator >> 8),
        (uint8_t) (asTimeBaseIndicator),

        // gmIdentity
        config.gmIdentity[0],
        config.gmIdentity[1],
        config.gmIdentity[2],
        config.gmIdentity[3],
        config.gmIdentity[4],
        config.gmIdentity[5],
        config.gmIdentity[6],
        config.gmIdentity[7],
        config.gmIdentity[8],
        config.gmIdentity[9],

        // streamId
        config.streamId[0],
        config.streamId[1],
        config.streamId[2],
        config.streamId[3],
        config.streamId[4],
        config.streamId[5],
        config.streamId[6],
        config.streamId[7],

        // asTimestamp
        (uint8_t) (asTimestamp >> 24),
        (uint8_t) (asTimestamp >> 16),
        (uint8_t) (asTimestamp >> 8),
        (uint8_t) (asTimestamp),

        // rtpTimestamp
        (uint8_t) (rtpTimestamp >> 24),
        (uint8_t) (rtpTimestamp >> 16),
        (uint8_t) (rtpTimestamp >> 8),
        (uint8_t) (rtpTimestamp),
    };
    memcpy(expect, temp, sizeof(temp));

    return sizeof(temp);
}

TEST(AvbRtcpPacketBuilder, EMPTY_BUILD)
{
    TEST_DESCRIPTION("TEST for check building of empty RTCP packet");
    VIDEORTP_avbRtcpPacketBuilder_t rtcpBuilder;
    VIDEORTP_rtcpSessionConfiguration_t configuration = {};
    VIDEORTP_rtcpInitConfig(&configuration, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);
    VIDEORTP_rtcpInit(&rtcpBuilder, &configuration);

    uint32_t rtpTimestamp = 20;
    uint32_t asTimestamp = 12350;
    uint16_t asTimeBaseIndicator = 45678;

    const size_t packetSize = 256;
    uint8_t packet[packetSize] = {};
    VIDEORTP_bufferWriter_t packetWriter;
    VIDEORTP_bufInit(&packetWriter, packet, packetSize);

    VIDEORTP_rtcpBuildPacket(&rtcpBuilder, rtpTimestamp, asTimestamp, asTimeBaseIndicator, &packetWriter);

    uint8_t expect[64] = {};
    size_t expectSize
        = generateExpectRtcpHeader(expect, *rtcpBuilder.configuration, asTimestamp, asTimeBaseIndicator, rtpTimestamp);

    EXPECT_EQ(memcmp(expect, packet, expectSize), 0);
}

static void updateConfig(uint8_t* dest, uint8_t* arr, size_t len)
{
    for (size_t i = 0; i < len; i++)
    {
        arr[i] += 1;
    }
    memcpy(dest, arr, len);
}

TEST(AvbRtcpPacketBuilder, LOOP_CONFIGURE)
{
    TEST_DESCRIPTION("TEST for check RTCP packet changing according with configuration");
    uint8_t gmIdentity[VIDEORTP_RTCP_GM_IDENTITY_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    uint8_t rtcpName[VIDEORTP_RTCP_NAME_SIZE] = { 'N', 'a', 'm', 'e' };
    uint8_t ssrc[VIDEORTP_RTCP_SSRC_SIZE] = { 1, 1, 1, 1 };
    uint8_t streamId[VIDEORTP_RTCP_STREAM_ID_SIZE] = { 2, 2, 2, 2, 2, 2, 2, 2 };
    uint16_t gmTimeBaseIndicator = 3;

    VIDEORTP_avbRtcpPacketBuilder_t rtcpBuilder;
    VIDEORTP_rtcpSessionConfiguration_t configuration = {};
    VIDEORTP_rtcpInitConfig(&configuration, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);
    VIDEORTP_rtcpInit(&rtcpBuilder, &configuration);

    uint32_t rtpTimestamp = 0;
    uint32_t asTimestamp = 60;

    const size_t packetSize = 256;
    uint8_t packet[packetSize] = {};
    VIDEORTP_bufferWriter_t packetWriter;

    static const size_t rtcpHeaderSize = 40;
    VIDEORTP_bufInit(&packetWriter, packet, packetSize);
    for (size_t i = 0; i < 16; i++)
    {
        /* update the initial data and copy it to the configuration */
        updateConfig(configuration.gmIdentity, gmIdentity, sizeof(gmIdentity));
        updateConfig(configuration.rtcpName, rtcpName, sizeof(rtcpName));
        updateConfig(configuration.ssrc, ssrc, sizeof(ssrc));
        updateConfig(configuration.streamId, streamId, sizeof(streamId));
        gmTimeBaseIndicator += 200;
        rtpTimestamp += 20;
        asTimestamp += 20;

        uint8_t expect[rtcpHeaderSize] = {};
        size_t expectSize
            = generateExpectRtcpHeader(expect, *rtcpBuilder.configuration, asTimestamp, gmTimeBaseIndicator, rtpTimestamp);
        EXPECT_EQ(expectSize, rtcpHeaderSize);

        EXPECT_TRUE(VIDEORTP_rtcpBuildPacket(&rtcpBuilder, rtpTimestamp, asTimestamp, gmTimeBaseIndicator, &packetWriter));
        EXPECT_EQ(memcmp(expect, packet, expectSize), 0);
        VIDEORTP_bufClear(&packetWriter);
    }
}

TEST(AvbRtcpPacketBuilder, LITTLE_BUFFER)
{
    TEST_DESCRIPTION("TEST for check RTCP paylod transmission by little parts");
    uint8_t gmIdentity[VIDEORTP_RTCP_GM_IDENTITY_SIZE] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    uint8_t rtcpName[VIDEORTP_RTCP_NAME_SIZE] = { 'N', 'a', 'm', 'e' };
    uint8_t ssrc[VIDEORTP_RTCP_SSRC_SIZE] = { 1, 1, 1, 1 };
    uint8_t streamId[VIDEORTP_RTCP_STREAM_ID_SIZE] = { 2, 2, 2, 2, 2, 2, 2, 2 };
    uint16_t gmTimeBaseIndicator = 3;

    VIDEORTP_avbRtcpPacketBuilder_t rtcpBuilder;
    VIDEORTP_rtcpSessionConfiguration_t configuration = {};
    VIDEORTP_rtcpInitConfig(&configuration, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);
    VIDEORTP_rtcpInit(&rtcpBuilder, &configuration);

    uint32_t rtpTimestamp = 0;
    uint32_t asTimestamp = 60;

    for (int packetSize = 0; packetSize < VIDEORTP_RTCP_PACKET_SIZE; packetSize++)
    {
        std::vector<uint8_t> packet(packetSize);
        VIDEORTP_bufferWriter_t packetWriter;
        VIDEORTP_bufInit(&packetWriter, packet.data(), packet.size());

        static const size_t rtcpHeaderSize = 40;
        for (size_t i = 0; i < 16; i++)
        {
            updateConfig(configuration.gmIdentity, gmIdentity, sizeof(gmIdentity));
            updateConfig(configuration.rtcpName, rtcpName, sizeof(rtcpName));
            updateConfig(configuration.ssrc, ssrc, sizeof(ssrc));
            updateConfig(configuration.streamId, streamId, sizeof(streamId));
            gmTimeBaseIndicator += 200;
            rtpTimestamp += 20;
            asTimestamp += 20;

            uint8_t expect[rtcpHeaderSize] = {};
            size_t expectSize
                = generateExpectRtcpHeader(expect, *rtcpBuilder.configuration, asTimestamp, gmTimeBaseIndicator, rtpTimestamp);
            EXPECT_EQ(expectSize, rtcpHeaderSize);
            EXPECT_GE(expectSize, packetSize);

            // Buffer less then header, data not writter
            EXPECT_FALSE(VIDEORTP_rtcpBuildPacket(&rtcpBuilder, rtpTimestamp, asTimestamp, gmTimeBaseIndicator, &packetWriter));
            VIDEORTP_bufClear(&packetWriter);
        }
    }
}
