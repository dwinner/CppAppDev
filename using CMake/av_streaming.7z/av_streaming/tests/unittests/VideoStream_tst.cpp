#include "Stubs/IpcCallbackMock.h"
#include <AutosarPacketSink.h>
#include <PayloadUnitSequenceRepeater.h>
#include <PduR_Cdd_stubs.h>
#include <VideoStream.h>

#include "TestUtils.h"
#include <gtest/gtest.h>
#include <vector>

class VideoStreamTest : public ::testing::Test
{
protected:
    AutosarPdu pdu;
    VIDEORTP_asrPacketSink_t socket;
    std::vector<uint8_t> buf;

    VIDEORTP_payloadUnit_t testFrame1 = { "Hello, World!", 13 };
    VIDEORTP_payloadUnit_t testFrame2 = { "Lorem Ipsum", 11 };

    VIDEORTP_videoStream_t stream = {};
    VIDEORTP_videoStreamConfig_t config = {};

    VideoStreamTest()
    {
        config.ipcInputConfig.tsPid = 0x100;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        config.staticInputConfig.tsPid = config.ipcInputConfig.tsPid;
        config.staticInputConfig.fps = 25;
#endif
        VIDEORTP_asrInitPacketSink(&socket, pdu.GetId());
    }

    size_t Receive(bool mayFail = true)
    {
        buf = pdu.GetTransmittedPacket();
        if (buf.empty() && mayFail)
            return 0;
        EXPECT_FALSE(buf.empty());

        // Check RTP packet (12 bytes header + n * 188 bytes TS packet)
        EXPECT_GT(buf.size(), 12);
        EXPECT_EQ((buf.size() - 12) % 188, 0);
        EXPECT_EQ(buf.at(0), 0x80);
        // the rest should be checked in RTP the packetizer test

        return buf.size();
    }

    // Check that the packet contains an MPEG-TS packet with video data
    void CheckVideoPacket(const VIDEORTP_payloadUnit_t& expected)
    {
        VIDEORTP_cyclicVideoStream(&stream, 10);

        while (Receive())
        {
            for (int i = 12; i + 188 <= buf.size(); i += 188)
            {
                ASSERT_EQ(buf.at(i + 0), 0x47) << "Invalid SYNC byte";

                // Payload unit start? (PID=0x0100)
                if (buf.at(i + 1) != 0x41 || buf.at(i + 2) != 0x00)
                    continue;

                // Verify payload
                // Skip TS header + PES header
                size_t header = 4 + 14;
                // Skip adaptation field with PCR and stuffing
                if (buf.at(i + 3) & 0x20)
                    header += 1 + buf.at(i + 4);
                ASSERT_EQ(0, memcmp(expected.buffer, buf.data() + i + header, expected.length));

                SUCCEED();
                return;
            }
        }

        FAIL() << "Video MPEG-TS packet not found";
    }

    void ReadFromIpc(const VIDEORTP_payloadUnit_t& expected)
    {
        IpcCallbackMock mockCallback;

        VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
        EXPECT_EQ(Receive(true), 0);

        ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, expected.length, 12345));
        ASSERT_TRUE(
            VIDEORTP_appendFrameVideoStream(&stream, expected.buffer, expected.length, IpcCallbackMock::ReleaseBufferCallback));
        EXPECT_CALL(mockCallback, ReleaseBuffer).Times(1);
        CheckVideoPacket(testFrame1);

        ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, expected.length, 23456));
        ASSERT_TRUE(
            VIDEORTP_appendFrameVideoStream(&stream, expected.buffer, expected.length, IpcCallbackMock::ReleaseBufferCallback));
        EXPECT_CALL(mockCallback, ReleaseBuffer).Times(1);
        VIDEORTP_deinitVideoStream(&stream);
    }
};

TEST_F(VideoStreamTest, UsesIpcInput)
{
    TEST_DESCRIPTION("Check that a video can be read from IPC");

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputDisabled)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is disabled");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = false;
    config.staticInputConfig.payloadUnits = &testFrame2;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputMissing)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is missing");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = nullptr;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputEmpty)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is disabled");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = &testFrame2;
    config.staticInputConfig.payloadUnitCount = 0;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, UsesStaticInput)
{
    TEST_DESCRIPTION("Check that a video can be read via static input stream");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = &testFrame1;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
    EXPECT_EQ(Receive(true), 0);

    CheckVideoPacket(testFrame1);

    IpcCallbackMock mockCallback;
    EXPECT_CALL(mockCallback, ReleaseBuffer).Times(0);

    // IPC is overridden by static input, so all data should be rejected.
    ASSERT_FALSE(VIDEORTP_startFrameVideoStream(&stream, testFrame2.length, 12345));
    ASSERT_FALSE(
        VIDEORTP_appendFrameVideoStream(&stream, testFrame2.buffer, testFrame2.length, IpcCallbackMock::ReleaseBufferCallback));

    VIDEORTP_deinitVideoStream(&stream);
}
