#include "ProgramMapTableBuilder.h"
#include "ProgramSectionPacketizer.h"
#include "TestUtils.h"
#include "TransportStreamHeaderBuilder.h"
#include "TransportStreamPacketizer.h"
#include <gtest/gtest.h>

TEST(TransportStreamHeaderBuilder, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor TransportStreamHeaderbuilder");
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, VIDEORTP_PCR_PID_PMT);

    EXPECT_EQ(tshb.pid, VIDEORTP_PCR_PID_PMT);
    EXPECT_FALSE(tshb.payloadUnitStartIndicator);
    EXPECT_EQ(tshb.timestampPacketCounter, 0);
    EXPECT_EQ(tshb.continuityCounter, 0);
}

TEST(TransportStreamHeaderBuilder, HEADER_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check include of PCR to packet");
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, VIDEORTP_PCR_PID_PMT);

    EXPECT_EQ(tshb.pid, VIDEORTP_PCR_PID_PMT);

    uint64_t timestamp = 10;
    VIDEORTP_tsInjectPcr(&tshb, timestamp);

    size_t nextChunkSize = 100;
    size_t headerSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
    EXPECT_EQ(headerSize, 12);
    VIDEORTP_payloadChunkInfo_t metadata = { 0, VIDEORTP_TS_PACKET_SIZE, true, false };

    EXPECT_GE(nextChunkSize, 0);
    VIDEORTP_tsSetPacketMetaData(&tshb, &metadata);

    size_t headerWriterCapacity = VIDEORTP_TS_PACKET_SIZE - nextChunkSize;
    EXPECT_GE(headerWriterCapacity, headerSize);
    VIDEORTP_bufferWriter_t headerWriter = VIDEORTP_bufSpawnChildWriter(&bw, headerWriterCapacity);

    VIDEORTP_tsBuildHeader(&tshb, &headerWriter);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));

    std::vector<uint8_t> expect(headerWriterCapacity);
    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect.data(), expect.size());
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID
    VIDEORTP_bufWriteInteger(&expectedBW,
                             VIDEORTP_TS_INDICATOR_AND_PID_MASK & (VIDEORTP_PCR_PID_PMT | (metadata.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldContorl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));
    // adaptation field length == 83
    VIDEORTP_bufWriteInteger(&expectedBW, headerWriterCapacity - VIDEORTP_TS_MINIMUM_HEADER_SIZE - 1, sizeof(uint8_t));
    // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10, sizeof(uint8_t));
    // PCR with reserved
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE);
    // stuffing
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(&expectedBW));

    int cmp = memcmp(expect.data(), buffer, 88);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamHeaderBuilder, HEADER_WITHOUT_PCR)
{
    TEST_DESCRIPTION("TEST for check not include of PCR to TS packet");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, pid);

    EXPECT_EQ(tshb.pid, pid);

    // Imagine the data size is 100, then the header size would be 188-100 = 88
    size_t nextChunkSize = 100;
    size_t headerSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
    EXPECT_EQ(headerSize, VIDEORTP_TS_MINIMUM_HEADER_SIZE);
    VIDEORTP_payloadChunkInfo_t metadata = { 0, VIDEORTP_TS_PACKET_SIZE, true, false };

    EXPECT_GE(nextChunkSize, 0);
    VIDEORTP_tsSetPacketMetaData(&tshb, &metadata);

    size_t headerWriterCapacity = VIDEORTP_TS_PACKET_SIZE - nextChunkSize;
    EXPECT_GE(headerWriterCapacity, headerSize);
    VIDEORTP_bufferWriter_t headerWriter = VIDEORTP_bufSpawnChildWriter(&bw, headerWriterCapacity);

    VIDEORTP_tsBuildHeader(&tshb, &headerWriter);

    std::vector<uint8_t> expect(headerWriterCapacity);
    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect.data(), expect.size());
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID & packet start flag
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metadata.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldContorl = 0b01, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));

    int cmp = memcmp(expect.data(), buffer, headerSize);
    EXPECT_EQ(cmp, 0);
}

static void TestStuffing(size_t size, const void* expected)
{
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0);

    EXPECT_GE(size, VIDEORTP_tsGetMinimumHeaderSize(&tshb));
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_TRUE(memcmp(buffer, expected, size) == 0) << "Invalid TS header of size " << size;
}

TEST(TransportStreamHeaderBuilder, STUFFING)
{
    TEST_DESCRIPTION("TEST for check correctly adding stuffing to TS packet");
    // "Empty" packets (adaptation field only; no payload) are not supported, yet.
    // Payload is always present; otherwise there would be no need for a TS packet.

    // TS header only
    TestStuffing(4, "\x47\x00\x00\x10");

    // TS header + dummy adaptation field
    TestStuffing(5,
                 "\x47\x00\x00\x30"
                 "\x00");

    // TS header + empty adaptation field
    TestStuffing(6,
                 "\x47\x00\x00\x30"
                 "\x01\x00");

    // TS header + empty adaptation field + stuffing
    TestStuffing(7,
                 "\x47\x00\x00\x30"
                 "\x02\x00"
                 "\xff");
    TestStuffing(8,
                 "\x47\x00\x00\x30"
                 "\x03\x00"
                 "\xff\xff");
    TestStuffing(9,
                 "\x47\x00\x00\x30"
                 "\x04\x00"
                 "\xff\xff\xff");
    TestStuffing(10,
                 "\x47\x00\x00\x30"
                 "\x05\x00"
                 "\xff\xff\xff\xff");
    TestStuffing(11,
                 "\x47\x00\x00\x30"
                 "\x06\x00"
                 "\xff\xff\xff\xff\xff");
    TestStuffing(12,
                 "\x47\x00\x00\x30"
                 "\x07\x00"
                 "\xff\xff\xff\xff\xff\xff");
    TestStuffing(13,
                 "\x47\x00\x00\x30"
                 "\x08\x00"
                 "\xff\xff\xff\xff\xff\xff\xff");
    TestStuffing(14,
                 "\x47\x00\x00\x30"
                 "\x09\x00"
                 "\xff\xff\xff\xff\xff\xff\xff\xff");
}

static void TestPcrStuffing(size_t size, const void* expected)
{
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0);
    VIDEORTP_tsInjectPcr(&tshb, 0);

    EXPECT_GE(size, VIDEORTP_tsGetMinimumHeaderSize(&tshb));
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_TRUE(memcmp(buffer, expected, size) == 0) << "Invalid TS header with PCR of size " << size;
}

TEST(TransportStreamHeaderBuilder, STUFFING_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check correctly adding stuffing to TS packet when include PCR");
    // TS header + adaptation field + PCR only
    TestPcrStuffing(12,
                    "\x47\x00\x00\x30"
                    "\x07\x10"
                    "\x00\x00\x00\x00\x7E\x00");

    // TS header + adaptation field + PCR + stuffing
    TestPcrStuffing(13,
                    "\x47\x00\x00\x30"
                    "\x08\x10"
                    "\x00\x00\x00\x00\x7E\x00"
                    "\xff");
    TestPcrStuffing(14,
                    "\x47\x00\x00\x30"
                    "\x09\x10"
                    "\x00\x00\x00\x00\x7E\x00"
                    "\xff\xff");
}

TEST(TransportStreamHeaderBuilder, CHECK_COUNTERS)
{
    TEST_DESCRIPTION("TEST for check correctly increase timestamp and continuity counters into TS packet");
    const size_t size = VIDEORTP_TS_WITH_PCR;
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0);

    for (uint8_t i = 0; i < 255; i++)
    {
        uint8_t expectTimstampPacketCounter = i % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
        EXPECT_EQ(expectTimstampPacketCounter % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD,
                  tshb.timestampPacketCounter % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD);

        VIDEORTP_tsInjectPcr(&tshb, 0);

        size_t minHeaderSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
        if (i % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD != 0) // VW extension: PCR only allowed every 6th packet
            EXPECT_EQ(minHeaderSize, VIDEORTP_TS_MINIMUM_HEADER_SIZE); // without PCR
        else
            EXPECT_EQ(minHeaderSize, VIDEORTP_TS_WITH_PCR); // with PCR

        VIDEORTP_tsBuildHeader(&tshb, &bw);
        EXPECT_GE(VIDEORTP_bufGetBytesWritten(&bw), VIDEORTP_TS_WITH_PCR);
        uint8_t continuityCounter = VIDEORTP_TS_CONTINUITY_COUNTER_MASK & buffer[3];
        EXPECT_EQ(i % VIDEORTP_TS_CONTINUITY_COUNTER_MOD, continuityCounter);

        VIDEORTP_bufClear(&bw);
    }
}
