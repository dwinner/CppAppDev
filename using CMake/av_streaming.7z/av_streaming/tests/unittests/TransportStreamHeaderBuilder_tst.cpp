#include "ProgramMapTableBuilder.h"
#include "ProgramSectionPacketizer.h"
#include "TestUtils.h"
#include "TransportStreamHeaderBuilder.h"
#include "TransportStreamPacketizer.h"
#include <gtest/gtest.h>

TEST(TransportStreamHeaderBuilder, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor TransportStreamHeaderbuilder");
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, VIDEORTP_PCR_PID_PMT, nullptr, nullptr);

    EXPECT_EQ(tshb.pid, VIDEORTP_PCR_PID_PMT);
    EXPECT_FALSE(tshb.payloadUnitStartIndicator);
    EXPECT_EQ(tshb.timestampPacketCounter, 0);
    EXPECT_EQ(tshb.continuityCounter, VIDEORTP_TS_CONTINUITY_COUNTER_MOD - 1);
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));
}

TEST(TransportStreamHeaderBuilder, HEADER_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check include of PCR to packet");
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    uint64_t timestamp = 10;
    VIDEORTP_tsInitHeaderBuilder(&tshb, VIDEORTP_PCR_PID_PMT, DummyPcrFunction, &timestamp);

    EXPECT_EQ(tshb.pid, VIDEORTP_PCR_PID_PMT);

    VIDEORTP_tsInjectPcr(&tshb);
    VIDEORTP_tsPrepareHeader(&tshb);

    size_t nextChunkSize = 100;
    size_t headerSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
    EXPECT_EQ(headerSize, 12);
    VIDEORTP_payloadChunkInfo_t metadata = { { 0, 0, 0, 0 }, VIDEORTP_TS_PACKET_SIZE, true, false };

    EXPECT_GE(nextChunkSize, 0);
    VIDEORTP_tsSetPacketMetaData(&tshb, &metadata);

    size_t headerWriterCapacity = VIDEORTP_TS_PACKET_SIZE - nextChunkSize;
    EXPECT_GE(headerWriterCapacity, headerSize);
    VIDEORTP_bufferWriter_t headerWriter = VIDEORTP_bufSpawnChildWriter(&bw, headerWriterCapacity);

    VIDEORTP_tsBuildHeader(&tshb, &headerWriter);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));

    std::vector<uint8_t> expect(headerWriterCapacity);
    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect.data(), expect.size());
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID
    VIDEORTP_bufWriteInteger(&expectedBW,
                             VIDEORTP_TS_INDICATOR_AND_PID_MASK & (VIDEORTP_PCR_PID_PMT | (metadata.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldControl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));
    // adaptation field length == 83
    VIDEORTP_bufWriteInteger(&expectedBW, headerWriterCapacity - VIDEORTP_TS_MINIMUM_HEADER_SIZE - 1, sizeof(uint8_t));
    // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10, sizeof(uint8_t));
    // PCR with reserved
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE);
    // stuffing
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(&expectedBW));

    int cmp = memcmp(expect.data(), buffer, 88);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamHeaderBuilder, HEADER_WITHOUT_PCR)
{
    TEST_DESCRIPTION("TEST for check not include of PCR to TS packet");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const size_t bufferSize = 256;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, pid, DummyPcrFunction, nullptr);

    EXPECT_EQ(tshb.pid, pid);

    VIDEORTP_tsPrepareHeader(&tshb);

    // Imagine the data size is 100, then the header size would be 188-100 = 88
    size_t nextChunkSize = 100;
    size_t headerSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
    EXPECT_EQ(headerSize, VIDEORTP_TS_MINIMUM_HEADER_SIZE);
    VIDEORTP_payloadChunkInfo_t metadata = { { 0, 0, 0, 0 }, VIDEORTP_TS_PACKET_SIZE, true, false };

    EXPECT_GE(nextChunkSize, 0);
    VIDEORTP_tsSetPacketMetaData(&tshb, &metadata);

    size_t headerWriterCapacity = VIDEORTP_TS_PACKET_SIZE - nextChunkSize;
    EXPECT_GE(headerWriterCapacity, headerSize);
    VIDEORTP_bufferWriter_t headerWriter = VIDEORTP_bufSpawnChildWriter(&bw, headerWriterCapacity);

    VIDEORTP_tsBuildHeader(&tshb, &headerWriter);

    std::vector<uint8_t> expect(headerWriterCapacity);
    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect.data(), expect.size());
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID & packet start flag
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metadata.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldControl = 0b01, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));

    int cmp = memcmp(expect.data(), buffer, headerSize);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamHeaderBuilder, EMPTY_PCR_FUNCTION)
{
    TEST_DESCRIPTION("Check that PCR will not be written without callback");

    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, nullptr, nullptr);
    VIDEORTP_tsInjectPcr(&tshb);
    VIDEORTP_tsPrepareHeader(&tshb);

    VIDEORTP_tsBuildHeader(&tshb, &bw);

    // PCR not present
    EXPECT_FALSE(buffer[5] & 0x10);
}

extern "C"
{
    static uint64_t PcrErrorFunction(void*)
    {
        return VIDEORTP_InvalidTimestamp;
    }
}

TEST(TransportStreamHeaderBuilder, PCR_FUNCTION_ERROR)
{
    TEST_DESCRIPTION("Check that PCR will not be written if the callback returns an error");

    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, PcrErrorFunction, nullptr);
    VIDEORTP_tsInjectPcr(&tshb);
    VIDEORTP_tsPrepareHeader(&tshb);

    VIDEORTP_tsBuildHeader(&tshb, &bw);

    // PCR not present
    EXPECT_FALSE(buffer[5] & 0x10);
}

extern "C"
{
    static uint64_t PcrCounterFunction(void* context)
    {
        int& counter = *static_cast<int*>(context);
        counter++;
        return counter;
    }
}

TEST(TransportStreamHeaderBuilder, PCR_FUNCTION_ONLY_CALLED_IF_NEEDED)
{
    TEST_DESCRIPTION("Check that PCR function will be called only when a PCR timestamp is needed");

    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    int pcrFunctionCounter = 0;

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, PcrCounterFunction, &pcrFunctionCounter);
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));

    // First call, packet counter == 0, PCR is allowed
    VIDEORTP_tsInjectPcr(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 0) << "PCR function must not be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_tsPrepareHeader(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 1) << "PCR function must be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_bufClear(&bw);
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_TRUE(buffer[5] & 0x10) << "PCR must be present";
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));

    // Packet counter > 0, PCR is not allowed, PCR function should not be called
    for (int i = 0; i < VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD - 1; ++i)
    {
        VIDEORTP_tsInjectPcr(&tshb);
        EXPECT_EQ(pcrFunctionCounter, 1) << "PCR function must not be called";
        EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

        VIDEORTP_tsPrepareHeader(&tshb);
        EXPECT_EQ(pcrFunctionCounter, 1) << "PCR function must not be called";
        EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

        VIDEORTP_bufClear(&bw);
        VIDEORTP_tsBuildHeader(&tshb, &bw);
        EXPECT_FALSE(buffer[5] & 0x10) << "PCR must not be present";
        EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));
    }

    // First call, packet counter == 0 mod 6, PCR is allowed
    VIDEORTP_tsInjectPcr(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 1) << "PCR function must not be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_tsPrepareHeader(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 2) << "PCR function must be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_bufClear(&bw);
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_TRUE(buffer[5] & 0x10) << "PCR must be present";
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));

    EXPECT_EQ(pcrFunctionCounter, 2);
}

TEST(TransportStreamHeaderBuilder, PCR_INJECT_ONCE)
{
    TEST_DESCRIPTION("Check that PCR request is injected only once");

    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    int pcrFunctionCounter = 0;

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, PcrCounterFunction, &pcrFunctionCounter);
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_tsInjectPcr(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 0) << "PCR function must not be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_tsPrepareHeader(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 1) << "PCR function must be called";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb));

    VIDEORTP_tsPrepareHeader(&tshb);
    EXPECT_EQ(pcrFunctionCounter, 2) << "PCR function must be called again";
    EXPECT_TRUE(VIDEORTP_tsIsPcrPending(&tshb)); // still pending

    VIDEORTP_bufClear(&bw);
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_TRUE(buffer[5] & 0x10) << "PCR must be present";
    EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));

    // PCR should not be injected any more
    for (int i = 0; i < VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD * 2; ++i)
    {
        EXPECT_EQ(pcrFunctionCounter, 2);
        VIDEORTP_tsPrepareHeader(&tshb);
        VIDEORTP_bufClear(&bw);
        VIDEORTP_tsBuildHeader(&tshb, &bw);
        EXPECT_FALSE(buffer[5] & 0x10) << "PCR must not be present";
        EXPECT_FALSE(VIDEORTP_tsIsPcrPending(&tshb));
    }

    EXPECT_EQ(pcrFunctionCounter, 2);
}

#define VIDEORTP_ErrorTimestamp (VIDEORTP_InvalidTimestamp - 1)
static uint64_t ReadPcr(const uint8_t* header)
{
    // adaptation field
    if ((header[3] & 0x20) == 0)
        return VIDEORTP_InvalidTimestamp; // adaptation field not present

    // adaptation field length
    if (header[4] < 1)
        return VIDEORTP_InvalidTimestamp; // adaptation field flags not present

    // PCR flag
    if ((header[5] & 0x10) == 0)
        return VIDEORTP_InvalidTimestamp; // PCR not present

    // flags + PCR field
    if (header[4] < 7)
        return VIDEORTP_ErrorTimestamp; // adaptation field too small for PCR

    uint64_t base = ((uint64_t) header[6] << 25) | ((uint64_t) header[7] << 17) | ((uint64_t) header[8] << 9)
        | ((uint64_t) header[9] << 1) | ((uint64_t) header[10] >> 7);
    uint16_t ext = ((uint16_t) (header[10] & 1) << 8) | ((uint16_t) header[11]);

    // Reserved
    if ((header[10] & 0x7E) != 0x7E)
        return VIDEORTP_ErrorTimestamp; // invalid reserved bits

    // PCR extension
    if (ext >= 300)
        return VIDEORTP_ErrorTimestamp; // invalid PCR extension

    return base * 300 + ext;
}

static uint64_t TestPcr(uint64_t pcr)
{
    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, DummyPcrFunction, &pcr);
    VIDEORTP_tsInjectPcr(&tshb);
    VIDEORTP_tsPrepareHeader(&tshb);

    VIDEORTP_tsBuildHeader(&tshb, &bw);
    return ReadPcr(buffer);
}

TEST(TransportStreamHeaderBuilder, WRITE_PCR)
{
    TEST_DESCRIPTION("Check that PCR will be written correctly");

    // Test all bits of the PCR base
    for (int i = 0; i < 33; ++i)
    {
        // Test all bits of the PCR extension
        uint64_t exts[] = { 0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 299, 300 };
        for (auto ext : exts)
        {
            uint64_t expectedPcr = (UINT64_C(300) << i) + ext;
            uint64_t actualPcr = TestPcr(expectedPcr);
            EXPECT_EQ(expectedPcr, actualPcr);
        }
    }
}

TEST(TransportStreamHeaderBuilder, PCR_OVERFLOW)
{
    TEST_DESCRIPTION("Test behavior of PCR on overflow");

    // Test PCR overflow (33 bit base + ~9 bit extension)
    uint64_t pcrMod = UINT64_C(300) << 33;
    EXPECT_EQ(TestPcr(pcrMod - 1), pcrMod - 1);
    EXPECT_EQ(TestPcr(pcrMod), 0);
}

static void TestStreamPcrPid(uint16_t pid, bool pcrValid)
{
    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    int pcrFunctionCounter = 0;

    VIDEORTP_tsInitHeaderBuilder(&tshb, pid, PcrCounterFunction, &pcrFunctionCounter);
    VIDEORTP_tsInjectPcr(&tshb);
    ASSERT_EQ(VIDEORTP_tsIsPcrPending(&tshb), pcrValid);

    // Check that PCR was queried
    VIDEORTP_tsPrepareHeader(&tshb);
    ASSERT_EQ(pcrFunctionCounter, pcrValid ? 1 : 0);

    uint8_t buffer[50] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));
    VIDEORTP_tsBuildHeader(&tshb, &bw);

    // Check that PCR was actually written to buffer
    uint64_t pcr = ReadPcr(buffer);
    ASSERT_EQ(pcr, pcrValid ? 1 : VIDEORTP_InvalidTimestamp);
}

TEST(TransportStreamHeaderBuilder, PCR_STREAM_PID)
{
    TEST_DESCRIPTION("Check that PCR is not injected into invalid streams");

    struct PcrStreamPidTest
    {
        uint16_t first, last;
        bool pcrValid;
    } tests[] = {
        // H.222.0, Table 2-3, Note 1
        { 0x0000, 0x0001, true },
        { 0x0002, 0x000F, false },
        { 0x0010, 0x1FFE, true },
        { 0x1FFF, 0x1FFF, false },
    };

    for (const auto& test : tests)
    {
        for (uint32_t i = test.first; i <= test.last; ++i)
        {
            ASSERT_NO_FATAL_FAILURE(TestStreamPcrPid(i, test.pcrValid))
                << "PCR should " << (test.pcrValid ? "" : "not ") << "be included in PID 0x" << std::hex << i;
        }
    }
}

static void TestStuffing(size_t size, const void* expected)
{
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, DummyPcrFunction, nullptr);
    VIDEORTP_tsPrepareHeader(&tshb);

    EXPECT_GE(size, VIDEORTP_tsGetMinimumHeaderSize(&tshb));
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_EQ(memcmp(buffer, expected, size), 0) << "Invalid TS header of size " << size;
}

TEST(TransportStreamHeaderBuilder, INVALID_SIZE)
{
    TEST_DESCRIPTION("Check that small packets will not be written");

    for (size_t i = 0; i < 4; ++i)
    {
        EXPECT_DEATH(TestStuffing(i, "xxxx"), "totalHeaderLength >= VIDEORTP_tsGetMinimumHeaderSize");
    }
}

TEST(TransportStreamHeaderBuilder, STUFFING)
{
    TEST_DESCRIPTION("Check that stuffing bytes are added correctly to TS packets");

    // TS header only
    TestStuffing(4, "\x47\x00\x00\x10");

    // TS header + empty adaptation field
    TestStuffing(5,
                 "\x47\x00\x00\x30"
                 "\x00");

    // TS header + adaptation field length + flags + stuffing
    uint8_t header[VIDEORTP_TS_PACKET_SIZE - 1]
        = "\x47\x00\x00\x30" // adaptation field and payload
          "#\x00";
    memset(header + 6, 0xFF, sizeof(header) - 6);
    for (size_t i = 6; i <= sizeof(header); ++i)
    {
        header[4] = i - 5; // set adaptation field length
        TestStuffing(i, header);
    }
}

TEST(TransportStreamHeaderBuilder, STUFFING_ONLY)
{
    TEST_DESCRIPTION("Check that dummy packets are generated correctly");

    // Packets without payload or any header field are basically useless.

    // TS header + adaptation field length + flags + stuffing
    uint8_t header[VIDEORTP_TS_PACKET_SIZE]
        = "\x47\x00\x00\x2F" // adaptation field only with old continuity counter
          "\xB7\x00";
    memset(header + 6, 0xFF, sizeof(header) - 6);
    TestStuffing(sizeof(header), header);
}

static void TestPcrStuffing(size_t size, const void* expected)
{
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, DummyPcrFunction, nullptr);
    VIDEORTP_tsInjectPcr(&tshb);
    VIDEORTP_tsPrepareHeader(&tshb);

    EXPECT_GE(size, VIDEORTP_tsGetMinimumHeaderSize(&tshb));
    VIDEORTP_tsBuildHeader(&tshb, &bw);
    EXPECT_EQ(memcmp(buffer, expected, size), 0) << "Invalid TS header with PCR of size " << size;
}

TEST(TransportStreamHeaderBuilder, INVALID_SIZE_WITH_PCR)
{
    TEST_DESCRIPTION("Check that small packets with PRC will not be written");

    for (size_t i = 0; i < 12; ++i)
    {
        EXPECT_DEATH(TestPcrStuffing(i, "xxxxxxxxxxxx"), "totalHeaderLength >= VIDEORTP_tsGetMinimumHeaderSize");
    }
}

TEST(TransportStreamHeaderBuilder, STUFFING_WITH_PCR)
{
    TEST_DESCRIPTION("Check that stuffing bytes are added correctly to TS packets including PCR");

    // TS header + adaptation field length + flags + PCR + stuffing
    uint8_t header[VIDEORTP_TS_PACKET_SIZE - 1]
        = "\x47\x00\x00\x30" // adaptation field and payload
          "#\x10"
          "\x00\x00\x00\x00\x7E\x00";
    memset(header + 12, 0xFF, sizeof(header) - 12);
    for (size_t i = 12; i <= sizeof(header); ++i)
    {
        header[4] = i - 5; // set adaptation field length
        TestPcrStuffing(i, header);
    }
}

TEST(TransportStreamHeaderBuilder, STUFFING_ONLY_WITH_PCR)
{
    TEST_DESCRIPTION("Check that stuffing packets only including the PCR are generated correctly");

    // Occasionally "empty" packets (no payload; adaptation field only) can
    // be useful to transmit a PCR even if no payload is to be transferred.

    // TS header + adaptation field length + flags + PCR + stuffing
    uint8_t header[VIDEORTP_TS_PACKET_SIZE]
        = "\x47\x00\x00\x2F" // adaptation field only with old continuity counter
          "\xB7\x10"
          "\x00\x00\x00\x00\x7E\x00";
    memset(header + 12, 0xFF, sizeof(header) - 12);
    TestPcrStuffing(sizeof(header), header);
}

TEST(TransportStreamHeaderBuilder, CHECK_COUNTERS)
{
    TEST_DESCRIPTION("TEST for check correctly increase timestamp and continuity counters into TS packet");
    const size_t size = VIDEORTP_TS_WITH_PCR;
    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, size);

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, DummyPcrFunction, nullptr);

    for (uint8_t i = 0; i < 255; i++)
    {
        uint8_t expectTimstampPacketCounter = i % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD;
        EXPECT_EQ(expectTimstampPacketCounter % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD,
                  tshb.timestampPacketCounter % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD);

        VIDEORTP_tsInjectPcr(&tshb);
        VIDEORTP_tsPrepareHeader(&tshb);

        size_t minHeaderSize = VIDEORTP_tsGetMinimumHeaderSize(&tshb);
        if (i % VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD != 0) // VW extension: PCR only allowed every 6th packet
            EXPECT_EQ(minHeaderSize, VIDEORTP_TS_MINIMUM_HEADER_SIZE); // without PCR
        else
            EXPECT_EQ(minHeaderSize, VIDEORTP_TS_WITH_PCR); // with PCR

        VIDEORTP_tsBuildHeader(&tshb, &bw);
        EXPECT_GE(VIDEORTP_bufGetBytesWritten(&bw), VIDEORTP_TS_WITH_PCR);
        uint8_t continuityCounter = VIDEORTP_TS_CONTINUITY_COUNTER_MASK & buffer[3];
        EXPECT_EQ(i % VIDEORTP_TS_CONTINUITY_COUNTER_MOD, continuityCounter);

        VIDEORTP_bufClear(&bw);
    }
}

TEST(TransportStreamHeaderBuilder, COUNT_PAYLOAD_ONLY)
{
    TEST_DESCRIPTION("Check that the continuity counter is not incremented unless payload is present");

    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE] = {};
    VIDEORTP_bufferWriter_t bw;

    VIDEORTP_transportStreamHeaderBuilder_t tshb;
    VIDEORTP_tsInitHeaderBuilder(&tshb, 0, DummyPcrFunction, nullptr);

    struct
    {
        uint8_t size;
        uint8_t counter;
    } headers[] = {
        // no payload - keep initial counter
        { VIDEORTP_TS_PACKET_SIZE, 15 },

        // count normally
        { VIDEORTP_TS_PACKET_SIZE - 3, 0 },
        { VIDEORTP_TS_PACKET_SIZE - 2, 1 },
        { VIDEORTP_TS_PACKET_SIZE - 1, 2 },

        // no payload - do not increment counter
        { VIDEORTP_TS_PACKET_SIZE, 2 },
        { VIDEORTP_TS_PACKET_SIZE, 2 },
        { VIDEORTP_TS_PACKET_SIZE, 2 },

        // count normally
        { VIDEORTP_TS_PACKET_SIZE - 1, 3 },
        { VIDEORTP_TS_PACKET_SIZE - 2, 4 },
        { VIDEORTP_TS_PACKET_SIZE - 3, 5 },
    };

    for (auto& header : headers)
    {
        VIDEORTP_bufInit(&bw, buffer, header.size);
        VIDEORTP_tsPrepareHeader(&tshb);
        VIDEORTP_tsBuildHeader(&tshb, &bw);
        EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), header.size);
        uint8_t continuityCounter = VIDEORTP_TS_CONTINUITY_COUNTER_MASK & buffer[3];
        EXPECT_EQ(continuityCounter, header.counter);
    }
}
