#include "BufferWriter.h"
#include "PayloadUnitSequenceRepeater.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include "stdint.h"
#include <gtest/gtest.h>

TEST(PayloadUnitSequenceRepeater, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor payload unit sequence repeater");
    CheckedGenerator<VIDEORTP_payloadUnitSequenceRepeater_t> seq;
    uint8_t buffer[1024];
    const uint8_t pattern1 = 1;
    const size_t payloadListSize = 2;

    memset(buffer, pattern1, 1024);

    VIDEORTP_payloadUnit_t u1;
    u1.length = 0;
    u1.buffer = &buffer;

    VIDEORTP_payloadUnit_t u2;
    u2.length = 0;
    u2.buffer = &buffer;

    VIDEORTP_payloadUnit_t units[payloadListSize];
    units[0] = u1;
    units[1] = u1;

    VIDEORTP_seqInit(&seq, units, payloadListSize);

    uint8_t destBuffer[1024];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, 1024);

    VIDEORTP_payloadChunkInfo_t metaData;
    // test for check restart sequence;

    for (int i = 0; i < 10; i++)
    {
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&seq, 1024, &metaData);
        EXPECT_EQ(nextChunkSize, 0);
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(PayloadUnitSequenceRepeater, PATTERN_BIG_DEST_BUFFER)
{
    TEST_DESCRIPTION("TEST for check the filling of a large buffer with data");
    CheckedGenerator<VIDEORTP_payloadUnitSequenceRepeater_t> seq;
    uint8_t buffer[1024];
    const uint8_t pattern1 = 1;
    const size_t payloadListSize = 2;

    memset(buffer, pattern1, 1024);

    VIDEORTP_payloadUnit_t u1;
    u1.length = 1024;
    u1.buffer = &buffer;

    VIDEORTP_payloadUnit_t u2;
    u2.length = 1024;
    u2.buffer = &buffer;

    VIDEORTP_payloadUnit_t units[payloadListSize];
    units[0] = u1;
    units[1] = u1;

    VIDEORTP_seqInit(&seq, units, 2);

    uint8_t destBuffer[1024 * 10 * 2];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, 1024 * 10 * 2);

    VIDEORTP_payloadChunkInfo_t metaData;
    // test for check restart sequence;

    for (int i = 0; i < 10; i++)
    {
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&seq, 1024, &metaData);
        EXPECT_TRUE(metaData.isPayloadUnitStart);
        EXPECT_TRUE(metaData.isPayloadUnitEnd);
        EXPECT_EQ(metaData.payloadUnitSize, 1024);
        EXPECT_EQ(nextChunkSize, 1024);
        VIDEORTP_pipeCopyChunk(&seq, &destBW);

        uint8_t* chunkStartPointer = (uint8_t*) VIDEORTP_bufGetBasePointer(&destBW);
        for (size_t bufferPosition = 0; bufferPosition < nextChunkSize; bufferPosition++)
        {
            EXPECT_EQ(chunkStartPointer[bufferPosition], pattern1);
        }
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(PayloadUnitSequenceRepeater, PATTERN_LITTLE_DEST_BUFFER)
{
    TEST_DESCRIPTION("TEST for check the filling of a small buffer with data");
    CheckedGenerator<VIDEORTP_payloadUnitSequenceRepeater_t> seq;
    uint8_t buffer1[1024];
    uint8_t buffer2[1024];

    uint8_t pattern[2];
    pattern[0] = 1;
    pattern[1] = 2;
    const uint8_t bwCapacity = 32;
    const size_t patternLength = bwCapacity * 4;

    const size_t payloadListSize = 2;

    VIDEORTP_payloadUnit_t u1;
    u1.length = patternLength;
    u1.buffer = &buffer1;

    VIDEORTP_payloadUnit_t u2;
    u2.length = patternLength;
    u2.buffer = &buffer2;

    VIDEORTP_payloadUnit_t units[payloadListSize];
    units[0] = u1;
    units[1] = u2;

    memset(buffer1, pattern[0], patternLength);
    memset(buffer2, pattern[1], patternLength);
    VIDEORTP_seqInit(&seq, units, 2);

    uint8_t destBuffer[1024];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, bwCapacity);

    VIDEORTP_payloadChunkInfo_t metaDataExpected[] = {
        { VIDEORTP_InvalidTimestamp, patternLength, true, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, true },
    };

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = 0;
    // repeat sometimes PrepareNextChunk and CopyChunk
    for (int repeat = 0; repeat < 30; repeat++)
    {
        for (int i = 0; i < 4; i++)
        {
            nextChunkSize = VIDEORTP_pipePrepareNextChunk(&seq, bwCapacity, &metaData);
            EXPECT_EQ(metaData.sampleTimestamp, metaDataExpected[i].sampleTimestamp);
            EXPECT_EQ(metaData.payloadUnitSize, metaDataExpected[i].payloadUnitSize);
            EXPECT_EQ(metaData.isPayloadUnitStart, metaDataExpected[i].isPayloadUnitStart);
            EXPECT_EQ(metaData.isPayloadUnitEnd, metaDataExpected[i].isPayloadUnitEnd);
            EXPECT_EQ(nextChunkSize, bwCapacity);
            VIDEORTP_pipeCopyChunk(&seq, &destBW);

            uint8_t* chunkStartPointer = (uint8_t*) VIDEORTP_bufGetBasePointer(&destBW);
            for (size_t bufferPosition = 0; bufferPosition < nextChunkSize; bufferPosition++)
            {
                EXPECT_EQ(chunkStartPointer[bufferPosition], pattern[repeat % 2]);
            }

            VIDEORTP_bufClear(&destBW);
        }
    }
}

TEST(PayloadUnitSequenceRepeater, PATTERN_LONG_BUFFER)
{
    TEST_DESCRIPTION("TEST for check whether the buffer is filled with data patterns");
    CheckedGenerator<VIDEORTP_payloadUnitSequenceRepeater_t> seq;
    uint8_t buffer0[1024];
    uint8_t buffer1[1024];
    uint8_t buffer2[1024];
    uint8_t buffer3[1024];
    uint8_t buffer4[1024];

    uint8_t pattern[5];

    pattern[0] = 1;
    pattern[1] = 1;
    pattern[2] = 2;
    pattern[3] = 3;
    pattern[4] = 4;

    const uint8_t bwCapacity = 32;

    size_t patternLength[5];
    patternLength[0] = bwCapacity * 6;
    patternLength[1] = bwCapacity * 4;
    patternLength[2] = bwCapacity * 3;
    patternLength[3] = bwCapacity * 2;
    patternLength[4] = bwCapacity * 7;

    const size_t payloadListSize = 5;

    VIDEORTP_payloadUnit_t u0;
    u0.length = patternLength[0];
    u0.buffer = &buffer0;

    VIDEORTP_payloadUnit_t u1;
    u1.length = patternLength[1];
    u1.buffer = &buffer1;

    VIDEORTP_payloadUnit_t u2;
    u2.length = patternLength[2];
    u2.buffer = &buffer2;

    VIDEORTP_payloadUnit_t u3;
    u3.length = patternLength[3];
    u3.buffer = &buffer3;

    VIDEORTP_payloadUnit_t u4;
    u4.length = patternLength[4];
    u4.buffer = &buffer4;

    VIDEORTP_payloadUnit_t units[payloadListSize];
    units[0] = u0;
    units[1] = u1;
    units[2] = u2;
    units[3] = u3;
    units[4] = u4;

    memset(buffer0, pattern[0], patternLength[0]);
    memset(buffer1, pattern[1], patternLength[1]);
    memset(buffer2, pattern[2], patternLength[2]);
    memset(buffer3, pattern[3], patternLength[3]);
    memset(buffer4, pattern[4], patternLength[4]);

    VIDEORTP_seqInit(&seq, units, payloadListSize);

    uint8_t destBuffer[1024];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, bwCapacity);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = 0;
    // repeat sometimes PrepareNextChunk and CopyChunk
    for (int repeat = 0; repeat < 5; repeat++)
    {
        for (int i = 0; i < patternLength[repeat] / bwCapacity; i++)
        {
            nextChunkSize = VIDEORTP_pipePrepareNextChunk(&seq, bwCapacity, &metaData);
            EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);

            EXPECT_EQ(metaData.payloadUnitSize, patternLength[repeat]);

            if (i == 0)
            {
                EXPECT_EQ(metaData.isPayloadUnitStart, true);
                EXPECT_EQ(metaData.isPayloadUnitEnd, false);
            }
            else if (i < patternLength[repeat] / bwCapacity - 1)
            {
                EXPECT_EQ(metaData.isPayloadUnitStart, false);
                EXPECT_EQ(metaData.isPayloadUnitEnd, false);
            }
            else if (i == patternLength[repeat] / bwCapacity - 1)
            {
                EXPECT_EQ(metaData.isPayloadUnitStart, false);
                EXPECT_EQ(metaData.isPayloadUnitEnd, true);
            }

            EXPECT_EQ(nextChunkSize, bwCapacity);
            VIDEORTP_pipeCopyChunk(&seq, &destBW);

            uint8_t* chunkStartPointer = (uint8_t*) VIDEORTP_bufGetBasePointer(&destBW);
            for (size_t bufferPosition = 0; bufferPosition < nextChunkSize; bufferPosition++)
            {
                EXPECT_EQ(chunkStartPointer[bufferPosition], pattern[repeat]);
            }

            VIDEORTP_bufClear(&destBW);
        }
    }
}
