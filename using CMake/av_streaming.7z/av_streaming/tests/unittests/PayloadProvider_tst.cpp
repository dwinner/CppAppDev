#include "DemoGeneratorPipelineStage.h"
#include "DemoHeaderPipelineStage.h"
#include "PayloadProvider.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include <gtest/gtest.h>
#include <vector>

TEST(PayloadProviderTest, FLAGS)
{
    TEST_DESCRIPTION("TEST for check PayloadChunkInfo flags after initialization");
    VIDEORTP_payloadChunkInfo_t info;
    VIDEORTP_initPayloadChunkInfo(&info, 10, 10, 100);
    EXPECT_EQ(info.payloadUnitSize, 100);
    EXPECT_EQ(info.sampleTimestamp, INVALID_SAMPLE_TIMESTAMP);

    VIDEORTP_initPayloadChunkInfo(&info, 0, 10, 100);
    EXPECT_TRUE(info.isPayloadUnitStart);
    EXPECT_FALSE(info.isPayloadUnitEnd);

    VIDEORTP_initPayloadChunkInfo(&info, 50, 10, 100);
    EXPECT_FALSE(info.isPayloadUnitStart);
    EXPECT_FALSE(info.isPayloadUnitEnd);

    VIDEORTP_initPayloadChunkInfo(&info, 90, 10, 100);
    EXPECT_FALSE(info.isPayloadUnitStart);
    EXPECT_TRUE(info.isPayloadUnitEnd);

    VIDEORTP_initPayloadChunkInfo(&info, 0, 100, 100);
    EXPECT_TRUE(info.isPayloadUnitStart);
    EXPECT_TRUE(info.isPayloadUnitEnd);
}

TEST(PayloadProviderTest, GENERATOR)
{
    TEST_DESCRIPTION("TEST for check correct PayloadProvider interface processing");
    CheckedGenerator<DemoGeneratorPipelineStage> dataGenerator;
    DemoGeneratorPipelineStage_init(&dataGenerator, 0xA5);

    static const uint8_t expected[] = {
        0xa5, 0xa5, 0xa5, 0xa5, // pattern
        0xa5, 0xa5, 0xa5, 0xa5, // pattern
    };

    TestPipelineResult(&dataGenerator, expected, sizeof(expected));
}

TEST(PayloadProviderTest, HEADER)
{
    TEST_DESCRIPTION("TEST for check correct PayloadProvider interface processing with predecessor");
    CheckedGenerator<DemoGeneratorPipelineStage> dataGenerator;
    DemoGeneratorPipelineStage_init(&dataGenerator, 0xA5);

    CheckedStage<DemoHeaderPipelineStage> headerGenerator;
    DemoHeaderPipelineStage_init(&headerGenerator, &dataGenerator, 0xc0cac01a);

    static const uint8_t expected[] = {
        0xc0, 0xca, 0xc0, 0x1a, // magic number
        0x00, 0x00, 0x00, 0x0c, // size
        0xa5, 0xa5, 0xa5, 0xa5, // pattern
        0xa5, 0xa5, 0xa5, 0xa5, // pattern
        0xa5, 0xa5, 0xa5, 0xa5, // pattern
    };

    TestPipelineResult(&headerGenerator, expected, sizeof(expected));
}

TEST(PayloadProviderTest, HEADER_OVERFLOW)
{
    TEST_DESCRIPTION(
        "TEST for check correct PayloadProvider interface processing with predecessor when destination buffer size less then "
        "necessary");
    CheckedGenerator<DemoGeneratorPipelineStage> dataGenerator;
    DemoGeneratorPipelineStage_init(&dataGenerator, 0xA5);

    CheckedStage<DemoHeaderPipelineStage> headerGenerator;
    DemoHeaderPipelineStage_init(&headerGenerator, &dataGenerator, 0xc0cac01a);

    VIDEORTP_payloadProvider_t* pipeline = &headerGenerator;
    VIDEORTP_payloadChunkInfo_t chunkInfo;

    // Enough space for header and pattern
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 1000, &chunkInfo), 1000);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 100, &chunkInfo), 100);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 10, &chunkInfo), 10);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 9, &chunkInfo), 9);

    // Not enough space for pattern
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 8, &chunkInfo), 0);

    // Not enough space for header
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 7, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 6, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 5, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 4, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 3, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 2, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 1, &chunkInfo), 0);
    EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipeline, 0, &chunkInfo), 0);
}
