#include "PayloadUnitRepeater.h"
#include "ProgramMapTableBuilder.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

TEST(PayloadUnitRepeater, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor PayloadUnitRepeater");
    uint8_t buffer[1024];
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, 1024);

    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    // Check empty buffer
    const uint8_t bwCapacity = 32;
    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, bwCapacity, &metaData);
    EXPECT_EQ(nextChunkSize, 0);
}

TEST(PayloadUnitRepeater, PATTERN_BIG_DEST_BUFFER)
{
    TEST_DESCRIPTION("TEST for check repetition of pattern if destination buffer size equal transmit payload size");
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    uint8_t buffer[1024];
    VIDEORTP_bufferWriter_t bw;
    const uint8_t pattern = 1;
    const size_t patternLength = 128;
    VIDEORTP_bufInit(&bw, buffer, 1024);
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_bufWritePattern(&bw, pattern, patternLength);

    uint8_t destBuffer[1024];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, 1024);

    // The whole buffer can be read in one big chunk
    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, 1024, &metaData);
    EXPECT_EQ(nextChunkSize, patternLength);
    EXPECT_TRUE(metaData.isPayloadUnitStart);
    EXPECT_TRUE(metaData.isPayloadUnitEnd);
    EXPECT_EQ(metaData.payloadUnitSize, patternLength);
}

TEST(PayloadUnitRepeater, PATTERN_LITTLE_DEST_BUFFER)
{
    TEST_DESCRIPTION("TEST for check repetition of pattern if destination buffer size less then transmit payload size");
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    uint8_t buffer[1024];
    VIDEORTP_bufferWriter_t bw;
    const uint8_t pattern = 1;
    const uint8_t bwCapacity = 32;
    const size_t patternLength = bwCapacity * 4;
    VIDEORTP_bufInit(&bw, buffer, 1024);
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_bufWritePattern(&bw, pattern, patternLength);

    uint8_t destBuffer[1024];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, bwCapacity);

    VIDEORTP_payloadChunkInfo_t metaDataExpected[] = {
        { VIDEORTP_InvalidTimestamp, patternLength, true, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, false },
        { VIDEORTP_InvalidTimestamp, patternLength, false, true },
    };

    // Read the same payload unit repeatedly
    for (int repeat = 0; repeat < 5; repeat++)
    {
        // Read all chunks of this payload unit
        for (int i = 0; i < sizeof(metaDataExpected) / sizeof(*metaDataExpected); i++)
        {
            VIDEORTP_payloadChunkInfo_t metaData;
            size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, bwCapacity, &metaData);
            EXPECT_EQ(metaData.sampleTimestamp, metaDataExpected[i].sampleTimestamp);
            EXPECT_EQ(metaData.payloadUnitSize, metaDataExpected[i].payloadUnitSize);
            EXPECT_EQ(metaData.isPayloadUnitStart, metaDataExpected[i].isPayloadUnitStart);
            EXPECT_EQ(metaData.isPayloadUnitEnd, metaDataExpected[i].isPayloadUnitEnd);
            EXPECT_EQ(nextChunkSize, bwCapacity);
            VIDEORTP_pipeCopyChunk(&rep, &destBW);
            VIDEORTP_bufClear(&destBW);
        }
    }
}

void createPMTsection(VIDEORTP_bufferWriter_t* bw, uint8_t* buffer, size_t bwCapacity)
{
    VIDEORTP_bufInit(bw, buffer, bwCapacity);

    const uint16_t programNumber = 0x0010;
    const uint16_t streamPid = 0x0100;
    const uint16_t streamType = 0x1B;
    VIDEORTP_programMapTableBuilder_t pmtBuilder;
    VIDEORTP_pmtInit(&pmtBuilder, programNumber, 0x0100, bw);
    VIDEORTP_pmtAddElementaryStreamPid(&pmtBuilder, streamPid, streamType);
    VIDEORTP_pmtFinalize(&pmtBuilder);
}

TEST(PayloadUnitRepeater, PMT_SECTION)
{
    TEST_DESCRIPTION("TEST to check whether the payload is repeated in a large destination buffer");
    const size_t bwCapacity = 32;
    uint8_t buffer[32];
    VIDEORTP_bufferWriter_t bw;
    createPMTsection(&bw, buffer, bwCapacity);

    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    const size_t destBWcapacity = 512;
    uint8_t destBuffer[destBWcapacity];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destBWcapacity);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = 0;

    size_t compareSize = VIDEORTP_bufGetBytesWritten(&bw);

    for (int i = 0; i < 10; i++)
    {
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, destBWcapacity, &metaData);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, compareSize);
        EXPECT_EQ(metaData.isPayloadUnitStart, true);
        EXPECT_EQ(metaData.isPayloadUnitEnd, true);
        EXPECT_EQ(nextChunkSize, compareSize);
        VIDEORTP_pipeCopyChunk(&rep, &destBW);

        int compare = memcmp(buffer, destBuffer, sizeof(compareSize));
        EXPECT_EQ(compare, 0);
        VIDEORTP_bufClear(&destBW);
    }

    // We have a large buffer and we can check for data repetitions
    for (size_t i = 0; i < 10; i++)
    {
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, destBWcapacity, &metaData);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, compareSize);
        EXPECT_EQ(metaData.isPayloadUnitStart, true);
        EXPECT_EQ(metaData.isPayloadUnitEnd, true);
        EXPECT_EQ(nextChunkSize, compareSize);
        VIDEORTP_pipeCopyChunk(&rep, &destBW);

        int compare = memcmp(buffer, destBuffer + i * nextChunkSize, sizeof(compareSize));
        EXPECT_EQ(compare, 0);
    }
}

TEST(PayloadUnitRepeater, PMT_SECTION_LITTLE_BUFFER)
{
    TEST_DESCRIPTION("TEST to check payload repetition by parts if destination buffer size less then payload size");
    const size_t bwCapacity = 32;
    uint8_t buffer[32];
    VIDEORTP_bufferWriter_t bw;
    createPMTsection(&bw, buffer, bwCapacity);

    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    const size_t destBWcapacity = 16;
    uint8_t destBuffer[destBWcapacity];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destBWcapacity);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = 0;

    size_t dataSize = VIDEORTP_bufGetBytesWritten(&bw);

    for (int i = 0; i < 10; i++)
    {
        // This section must be repeated on real
        size_t expectedChunkSize = destBWcapacity;
        // destBWcapacity =  bwCapacity / 2, dataSize = 21 therefore we check data 2 times

        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, destBWcapacity, &metaData);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, dataSize);
        EXPECT_TRUE(metaData.isPayloadUnitStart);
        EXPECT_FALSE(metaData.isPayloadUnitEnd);
        EXPECT_EQ(nextChunkSize, expectedChunkSize);
        VIDEORTP_pipeCopyChunk(&rep, &destBW);
        int compare = memcmp(buffer, destBuffer, sizeof(destBWcapacity));
        EXPECT_EQ(compare, 0);
        VIDEORTP_bufClear(&destBW);

        expectedChunkSize = dataSize - destBWcapacity;
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, destBWcapacity, &metaData);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, dataSize);
        EXPECT_FALSE(metaData.isPayloadUnitStart);
        EXPECT_TRUE(metaData.isPayloadUnitEnd);
        EXPECT_EQ(nextChunkSize, expectedChunkSize);
        VIDEORTP_pipeCopyChunk(&rep, &destBW);
        compare = memcmp(buffer + destBWcapacity, destBuffer, expectedChunkSize);
        EXPECT_EQ(compare, 0);
        VIDEORTP_bufClear(&destBW);
    }

    const size_t littleBWcapacity = 5;
    uint8_t littleBuffer[littleBWcapacity];
    VIDEORTP_bufferWriter_t littleBW;
    VIDEORTP_bufInit(&littleBW, littleBuffer, littleBWcapacity);

    size_t sizeCount = 0;
    do
    {
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&rep, littleBWcapacity, &metaData);

        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, dataSize);
        EXPECT_EQ(metaData.isPayloadUnitStart, sizeCount == 0);
        EXPECT_EQ(metaData.isPayloadUnitEnd, sizeCount + nextChunkSize == dataSize);

        VIDEORTP_pipeCopyChunk(&rep, &littleBW);
        int compare = memcmp(buffer + sizeCount, littleBuffer, nextChunkSize);
        EXPECT_EQ(compare, 0);
        VIDEORTP_bufClear(&littleBW);
        sizeCount += nextChunkSize;
    } while (sizeCount < dataSize);
    EXPECT_EQ(sizeCount, dataSize);
}
