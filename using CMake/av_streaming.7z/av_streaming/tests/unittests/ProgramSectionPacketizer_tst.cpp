#include "BufferWriter.h"
#include "PayloadUnitRepeater.h"
#include "ProgramMapTableBuilder.h"
#include "ProgramSectionPacketizer.h"
#include "Stubs/CheckedStage.h"
#include "Stubs/MinimumChunkSize.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

void initPipe(uint8_t* buffer, size_t bufSize, VIDEORTP_bufferWriter_t* pmtBW, VIDEORTP_programMapTableBuilder_t* pmt,
              CheckedGenerator<VIDEORTP_payloadUnitRepeater_t>* rep, CheckedStage<VIDEORTP_programSectionPacketizer_t>* pipe)
{
    VIDEORTP_bufInit(pmtBW, buffer, bufSize);
    VIDEORTP_pmtInit(pmt, 0x1000, 0x0100, pmtBW);
    VIDEORTP_pmtAddElementaryStreamPid(pmt, 0x10, 0x1b);
    VIDEORTP_pmtFinalize(pmt);
    VIDEORTP_repInit(rep, pmtBW);
    VIDEORTP_sectInit(pipe, rep);
}

void pipeOperation(VIDEORTP_bufferWriter_t* destBW, size_t destBufSize, VIDEORTP_payloadProvider_t* pipe,
                   VIDEORTP_payloadChunkInfo_t* metaData, VIDEORTP_payloadChunkInfo_t* expectMetaData, const void* expextBuf)
{
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(pipe, destBufSize, metaData);

    EXPECT_EQ(expectMetaData->sampleTimestamp, metaData->sampleTimestamp);
    EXPECT_EQ(expectMetaData->payloadUnitSize, metaData->payloadUnitSize);
    EXPECT_EQ(expectMetaData->isPayloadUnitStart, metaData->isPayloadUnitStart);
    EXPECT_EQ(expectMetaData->isPayloadUnitEnd, metaData->isPayloadUnitEnd);

    VIDEORTP_pipeCopyChunk(pipe, destBW);

    int cmp = memcmp(expextBuf, VIDEORTP_bufGetBasePointer(destBW), nextChunkSize);
    EXPECT_EQ(cmp, 0);
    VIDEORTP_bufClear(destBW);
}

TEST(ProgramSectionPacketizer, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor ProgramSectionPacketizer");
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t pmtBW;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> pipe;

    initPipe(buffer, bufferSize, &pmtBW, &pmt, &rep, &pipe);

    EXPECT_EQ(&rep, pipe.predecessor);
}

TEST(ProgramSectionPacketizer, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all ProgramSectionPacketizer functions");
    EXPECT_EXIT(VIDEORTP_sectInit(NULL, NULL), testing::ExitedWithCode(3), "");
}

TEST(ProgramSectionPacketizer, COPY_PATTERN)
{
    TEST_DESCRIPTION("TEST for check payload packing into equal destination buffer");
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> pipe;

    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_bufWritePattern(&bw, 2, 5);
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_sectInit(&pipe, &rep);

    const size_t destBufSize = 256;
    uint8_t destBuffer[destBufSize];
    memset(destBuffer, 0, destBufSize);
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destBufSize);

    VIDEORTP_payloadChunkInfo_t metaData;
    VIDEORTP_payloadChunkInfo_t expectMetaData = { VIDEORTP_InvalidTimestamp, VIDEORTP_bufGetBytesWritten(&bw), true, true };

    uint8_t expextBuf[destBufSize];
    expextBuf[0] = 0x00;
    memset(expextBuf + 1, 2, 5);
    memset(expextBuf + 6, 0xFF, destBufSize - 6);

    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &expectMetaData, expextBuf);
}

TEST(ProgramSectionPacketizer, COPY_PATTERN_CHUNKS)
{
    TEST_DESCRIPTION("TEST for check payload packing by chunks");
    const size_t bufferSize = 35;
    uint8_t buffer[bufferSize]
        = { 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8 };
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> pipe;

    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_bufGetWritableChunk(&bw, bufferSize);
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_sectInit(&pipe, &rep);

    const size_t destBufSize = 5;
    uint8_t destBuffer[destBufSize];
    memset(destBuffer, 0, destBufSize);
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destBufSize);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pipe, destBufSize, &metaData);
    EXPECT_EQ(destBufSize, nextChunkSize);

    VIDEORTP_payloadChunkInfo_t metaDataExpected[] = {
        { VIDEORTP_InvalidTimestamp, VIDEORTP_bufGetBytesWritten(&bw), true, false },
        { VIDEORTP_InvalidTimestamp, VIDEORTP_bufGetBytesWritten(&bw), false, false },
        { VIDEORTP_InvalidTimestamp, VIDEORTP_bufGetBytesWritten(&bw), false, true },
    };

    /*first 5th bytes filled with 2
    but for pipe this is first packet and isPayloadDataStart==true
    so pipe must add 0x00 (pointer) before data and copy 4 bytes (because destBufSize==5, 1 byte is pointer) from the buffer
    (we see shift 0x02 to next packet and etc) */
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[0], "\x00\x02\x02\x02\x02");
    // isPayloadDataStart==false and isPayloadDataEnd == false so only copy data
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x02\x03\x03\x03\x03");
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x03\x04\x04\x04\x04");
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x04\x05\x05\x05\x05");
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x05\x06\x06\x06\x06");
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x06\x07\x07\x07\x07");
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[1], "\x07\x08\x08\x08\x08");
    // isPayloadDataEnd==true so copy the remaining data and fill the remaining space with padding
    // in this case, 1 byte is left of the data (0x08) and 4 bytes must be padded (0xFF)
    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &metaDataExpected[2], "\x08\xFF\xFF\xFF\xFF");
}

TEST(ProgramSectionPacketizer, COPY_PMT)
{
    TEST_DESCRIPTION("TEST for check PMT payload packing into equal destination buffer");
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t pmtBW;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> pipe;

    initPipe((uint8_t*) buffer, bufferSize, &pmtBW, &pmt, &rep, &pipe);

    const size_t destBufSize = 256;
    uint8_t destBuffer[destBufSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destBufSize);

    VIDEORTP_payloadChunkInfo_t metaData;

    VIDEORTP_payloadChunkInfo_t expectMetaData = {
        VIDEORTP_InvalidTimestamp,
        VIDEORTP_bufGetBytesWritten(&pmtBW),
        true,
        true,
    };

    uint8_t expextBuf[destBufSize];
    expextBuf[0] = VIDEORTP_SECT_DEFAULT_POINTER;
    // 21 is pmt section size, 1 is pointer
    memcpy(expextBuf + 1, buffer, 21);
    memset(expextBuf + 22, VIDEORTP_SECT_PADDING, destBufSize - 22);

    pipeOperation(&destBW, destBufSize, &pipe, &metaData, &expectMetaData, expextBuf);
}

TEST(ProgramSectionPacketizer, EMPTY_SECTION)
{
    TEST_DESCRIPTION("TEST for check that empty payload not packing");
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 0);

    CheckedStage<VIDEORTP_programSectionPacketizer_t> sect;
    VIDEORTP_sectInit(&sect, &gen);

    for (int i = 0; i < 10; ++i)
    {
        // Cannot add pointer if there is no section data
        VIDEORTP_payloadChunkInfo_t info;
        EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(&sect, i, &info), 0);
    }
}

static const uint8_t SECTION_LENGTH = 5;
static const uint8_t SECTION_DATA = 0xAA;
static const uint8_t GUARD_DATA = 0xBB;

static void CheckSection(VIDEORTP_payloadProvider_t* pipeline, size_t length)
{
    VIDEORTP_payloadChunkInfo_t info;
    size_t chunk = VIDEORTP_pipePrepareNextChunk(pipeline, length, &info);
    EXPECT_EQ(chunk, length) << "length = " << length;
    ASSERT_GE(chunk, VIDEORTP_SECT_POINTER_SIZE + SECTION_LENGTH) << "length = " << length;

    // pointer + section + padding + guard
    std::vector<uint8_t> expected(chunk, VIDEORTP_SECT_PADDING);
    for (int i = 0; i < VIDEORTP_SECT_POINTER_SIZE; ++i)
        expected[i] = VIDEORTP_SECT_DEFAULT_POINTER;
    for (int i = 0; i < SECTION_LENGTH; ++i)
        expected[VIDEORTP_SECT_POINTER_SIZE + i] = SECTION_DATA;
    for (int i = 0; i < 10; ++i)
        expected.push_back(GUARD_DATA); // should not be overwritten

    // destination buffer
    std::vector<uint8_t> buffer(expected.size(), GUARD_DATA);
    VIDEORTP_bufferWriter_t dest;
    VIDEORTP_bufInit(&dest, buffer.data(), buffer.size());

    // should only write pointer + section + padding
    // guard byte at the end must not be modified
    VIDEORTP_pipeCopyChunk(pipeline, &dest);
    EXPECT_EQ(buffer, expected) << "length = " << length;
}

TEST(ProgramSectionPacketizer, MINIMUM_SIZE)
{
    TEST_DESCRIPTION("TEST for check minimum section size");
    // input section size
    uint8_t srcBuf[SECTION_LENGTH];
    VIDEORTP_bufferWriter_t src;
    VIDEORTP_bufInit(&src, &srcBuf, sizeof(srcBuf));
    VIDEORTP_bufWritePattern(&src, SECTION_DATA, sizeof(srcBuf));

    // repeat section
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &src);

    // always write full section (simulate minimum space for header)
    MinimumChunkSize repSize(&rep, sizeof(srcBuf));

    // add pointer field
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sect;
    VIDEORTP_sectInit(&sect, &repSize);

    VIDEORTP_payloadProvider_t* pipe = &sect;

    // 1 byte pointer + 5 byte section + some padding
    for (int i = SECTION_LENGTH + 1; i < SECTION_LENGTH + 10; ++i)
    {
        CheckSection(pipe, i);
    }

    // not enough space for pointer and section
    // do not write pointer without section
    for (int i = 0; i < SECTION_LENGTH + 1; ++i)
    {
        VIDEORTP_payloadChunkInfo_t info;
        EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(pipe, i, &info), 0) << "i = " << i;
    }
}
