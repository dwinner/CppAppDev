#include <gtest/gtest.h>

#include "VideoRtpUtil.h"

#include "TestUtils.h"

TEST(TimerTest, ResetsWhenElapsed)
{
    TEST_DESCRIPTION("TEST for check timer resets when elapsed");
    uint32_t timer = 50;
    EXPECT_TRUE(VIDEORTP_timerTick(&timer, 50, 100));
    EXPECT_EQ(timer, 0);
}

TEST(TimerTest, DoesNotElapseTooEarly)
{
    TEST_DESCRIPTION("TEST for check timer not resets when not elapsed");
    uint32_t timer = 0;
    for (int i = 1; i < 100; ++i)
    {
        EXPECT_FALSE(VIDEORTP_timerTick(&timer, 1, 100));
        EXPECT_EQ(timer, i);
    }
    EXPECT_TRUE(VIDEORTP_timerTick(&timer, 1, 100));
    EXPECT_EQ(timer, 0);
}

TEST(TimerTest, AccumulatesTicks)
{
    TEST_DESCRIPTION("TEST for check timer tick accumulation");
    uint32_t timer = 0;
    EXPECT_FALSE(VIDEORTP_timerTick(&timer, 10, 100));
    EXPECT_EQ(timer, 10);
    EXPECT_FALSE(VIDEORTP_timerTick(&timer, 20, 100));
    EXPECT_EQ(timer, 30);
    EXPECT_FALSE(VIDEORTP_timerTick(&timer, 69, 100));
    EXPECT_EQ(timer, 99);
    EXPECT_TRUE(VIDEORTP_timerTick(&timer, 1, 100));
    EXPECT_EQ(timer, 0);
}

TEST(TimerTest, CarriesOver)
{
    TEST_DESCRIPTION("TEST for check the cycling of timer");
    for (int i = 1; i < 100; ++i)
    {
        uint32_t timer = 99;
        EXPECT_TRUE(VIDEORTP_timerTick(&timer, i + 1, 100));
        EXPECT_EQ(timer, i);
    }
}

TEST(TimerTest, DiscardsBacklog)
{
    TEST_DESCRIPTION("TEST for check timer resets if elapsed several resets intervals");
    for (int i = 100; i < 250; ++i)
    {
        uint32_t timer = 99;
        EXPECT_TRUE(VIDEORTP_timerTick(&timer, i + 1, 100));
        EXPECT_EQ(timer, 0);
    }
}
