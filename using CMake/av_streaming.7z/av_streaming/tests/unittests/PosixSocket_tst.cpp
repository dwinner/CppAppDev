#include <gtest/gtest.h>

#include "BufferWriter.h"
#include "PacketTransmitter.h"
#include "PosixSocket.h"
#include "TestUtils.h"

// Helper class which opens a socket connection
class PosixSocketTransferTest : public ::testing::Test
{
protected:
    char addr[20] { "127.0.0.1" };
    uint16_t port { 30000 };
    VIDEORTP_posixSocket_t sock {};
    SOCKET recvSock { INVALID_SOCKET };
    char recvBuf[VIDEORTP_MAX_TX_PAYLOAD_SIZE + 1] {};

    void SetUp() override
    {
        // initialize sender socket
        // TODO: The constructor should do that!
        VIDEORTP_sockInit(&sock, addr, port);
        ASSERT_NE(sock.m_sockData.m_socket, INVALID_SOCKET) << "Failed to create sender socket";

        // initialize receiver socket on the same address
        recvSock = socket(sock.m_sockData.m_sockaddr.si_family, SOCK_DGRAM, IPPROTO_UDP);
        ASSERT_NE(recvSock, INVALID_SOCKET) << "Failed to create receiver socket";
        std::cout << recvSock << std::endl;
        int ret;
        if (sock.m_sockData.m_sockaddr.si_family == AF_INET)
        {
            ret = bind(recvSock, (SOCKADDR*) &sock.m_sockData.m_sockaddr.Ipv4, sizeof(sockaddr_in));
        }
        else
        {
            ret = bind(recvSock, (SOCKADDR*) &sock.m_sockData.m_sockaddr.Ipv6, sizeof(sockaddr_in6));
        }
        ASSERT_EQ(ret, 0) << "Failed to initialize receiver socket";
    }

    // read a packet from the destination socket
    int Receive()
    {
        memset(recvBuf, 0, sizeof(recvBuf));
        int len = recv(recvSock, recvBuf, VIDEORTP_MAX_TX_PAYLOAD_SIZE, 0);
        EXPECT_GT(len, 0);
        return len;
    }

    void TearDown() override
    {
        // close sockets
        closesocket(recvSock);
        VIDEORTP_sockDeinit(&sock);
    }
};

TEST_F(PosixSocketTransferTest, ClearsNewTransmissionBuffers)
{
    TEST_DESCRIPTION("TEST for check the clearing of new transfer buffers");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);

    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', 10));

    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);
}

TEST_F(PosixSocketTransferTest, CanTransferSmallPackets)
{
    TEST_DESCRIPTION("TEST for check transmitting small data");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // send first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    VIDEORTP_txCommitTransmissionBuffer(&sock.vtable);

    // receive first message
    EXPECT_EQ(Receive(), strlen(msg1));
    EXPECT_STREQ(msg1, recvBuf);

    // send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    VIDEORTP_txCommitTransmissionBuffer(&sock.vtable);

    // receive second message
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf);
}

TEST_F(PosixSocketTransferTest, DiscardsUncommittedBuffer)
{
    TEST_DESCRIPTION("TEST for check that preparing buffer discard old message");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // prepare first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    // don't send it

    // discard first message and send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    VIDEORTP_txCommitTransmissionBuffer(&sock.vtable);

    // receive second message only
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf);
}

TEST_F(PosixSocketTransferTest, SupportsMinimalMtu)
{
    TEST_DESCRIPTION("TEST for check size according mininum MTU");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);

    // maximum transfer size = minimum MTU size - UDP header - IPv6 header [IP_AVT_1562]
    EXPECT_LE(VIDEORTP_MAX_TX_PAYLOAD_SIZE, 1232);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(buffer), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
}

TEST_F(PosixSocketTransferTest, CanTransferLargePackets)
{
    TEST_DESCRIPTION("TEST for check transmitting large data");
    // send packet
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
    VIDEORTP_txCommitTransmissionBuffer(&sock.vtable);

    // receive packet
    EXPECT_EQ(Receive(), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
    EXPECT_TRUE(ContainsPattern(recvBuf, 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
}
