#include <stdint.h>

#include <algorithm>
#include <iterator>
#include <vector>

#include <gtest/gtest.h>

#include "BufferWriter.h"
#include "PipelineStageWithMultiplePredecessors.h"
#include "Stubs/CheckedStage.h"
#include "TestPatternGenerator.h"

#include "TestUtils.h"

TEST(PipelineStageWithMultiplePredecessors, COUNTER)
{
    TEST_DESCRIPTION("TEST for check how much predecessors added and check returned predecessor by index");
    CheckedStage<VIDEORTP_pipelineStageWithMultiplePredecessors_t> pipe;
    VIDEORTP_pipeInitStageWithMultiplePredecessors(&pipe);

    // generate predecessors
    CheckedGenerator<VIDEORTP_testPatternGenerator> generators[VIDEORTP_MAX_PREDECESSOR_COUNT];

    for (size_t i = 0; i < VIDEORTP_MAX_PREDECESSOR_COUNT; i++)
    {
        EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessorCount(&pipe), i);

        // check failure if invalid predesessor index
        EXPECT_EXIT(VIDEORTP_pipeGetMultiplePredecessor(&pipe, i), testing::ExitedWithCode(3), "");
        VIDEORTP_testPatternGenInit(&generators[i], 8);
        VIDEORTP_pipeAddMultiplePredecessor(&pipe, &generators[i]);
        // check that predecessor index is valid
        EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessor(&pipe, i), &generators[i]);

        EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessorCount(&pipe), i + 1);
    }
    EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessorCount(&pipe), VIDEORTP_MAX_PREDECESSOR_COUNT);
    // check large index
    EXPECT_EXIT(VIDEORTP_pipeGetMultiplePredecessor(&pipe, VIDEORTP_MAX_PREDECESSOR_COUNT + VIDEORTP_MAX_PREDECESSOR_COUNT),
                testing::ExitedWithCode(3), "");
}

TEST(PipelineStageWithMultiplePredecessors, MANY_PREDECESSORS)
{
    TEST_DESCRIPTION("TEST for check last predecessor changes if added many predecessors");

    CheckedStage<VIDEORTP_pipelineStageWithMultiplePredecessors_t> pipe;
    VIDEORTP_pipeInitStageWithMultiplePredecessors(&pipe);

    // generate predecessors
    CheckedGenerator<VIDEORTP_testPatternGenerator> generators[VIDEORTP_MAX_PREDECESSOR_COUNT + VIDEORTP_MAX_PREDECESSOR_COUNT];

    for (size_t i = 0; i < VIDEORTP_MAX_PREDECESSOR_COUNT; i++)
    {
        VIDEORTP_testPatternGenInit(&generators[i], 8);
        VIDEORTP_pipeAddMultiplePredecessor(&pipe, &generators[i]);
    }

    for (size_t i = VIDEORTP_MAX_PREDECESSOR_COUNT; i < VIDEORTP_MAX_PREDECESSOR_COUNT + VIDEORTP_MAX_PREDECESSOR_COUNT; i++)
    {
        VIDEORTP_testPatternGenInit(&generators[i], 8);
        VIDEORTP_pipeAddMultiplePredecessor(&pipe, &generators[i]);
        /* the new predecessor is stored at the end of the array */
        EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessor(&pipe, VIDEORTP_MAX_PREDECESSOR_COUNT - 1), &generators[i]);
    }
}

TEST(PipelineStageWithMultiplePredecessors, RUN_PREDECESSOR)
{
    TEST_DESCRIPTION("TEST for check predecessors run queue");

    CheckedStage<VIDEORTP_pipelineStageWithMultiplePredecessors_t> pipe;
    VIDEORTP_pipeInitStageWithMultiplePredecessors(&pipe);
    const size_t maxPredecessorsCount = VIDEORTP_MAX_PREDECESSOR_COUNT / 2;

    // generate predecessors
    CheckedGenerator<VIDEORTP_testPatternGenerator> generators[maxPredecessorsCount];
    size_t patternBaseLength = 8;
    for (size_t i = 0; i < maxPredecessorsCount; i++)
    {
        VIDEORTP_testPatternGenInit(&generators[i], patternBaseLength * (i + 1));
        VIDEORTP_pipeAddMultiplePredecessor(&pipe, &generators[i]);
    }
    // check redecessor count
    EXPECT_EQ(VIDEORTP_pipeGetMultiplePredecessorCount(&pipe), maxPredecessorsCount);

    const size_t destSize = 256;
    std::vector<uint8_t> destBuffer(destSize);
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer.data(), destBuffer.size());

    // check each predecessor
    for (int predCount = 0; predCount < maxPredecessorsCount; predCount++)
    {
        VIDEORTP_payloadProvider_t* predecessor = VIDEORTP_pipeGetMultiplePredecessor(&pipe, predCount);
        // check predecessor instance
        EXPECT_EQ(&generators[predCount], predecessor);

        for (int i = 0; i < predCount + 1; i++)
        {
            size_t payloadSize = generators[predCount].payloadUnitSize;

            VIDEORTP_payloadChunkInfo_t metadata;
            size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(predecessor, destSize, &metadata);

            // the buffer is always larger than the payload size
            // because compare pattern size with nextChunkSize
            EXPECT_EQ(payloadSize, nextChunkSize);

            // Filling expect buffer by current pattern
            std::vector<uint8_t> expect(payloadSize, generators[predCount].currentPattern);

            VIDEORTP_pipeCopyChunk(predecessor, &destBW);
            EXPECT_EQ(memcmp(destBuffer.data(), expect.data(), payloadSize), 0);
            // clear bw for next test iteration
            VIDEORTP_bufClear(&destBW);
        }
    }
}
