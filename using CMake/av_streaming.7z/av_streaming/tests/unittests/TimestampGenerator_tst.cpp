#include "PayloadUnitRepeater.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include "TimestampGenerator.h"
#include <gtest/gtest.h>

TEST(TimestampGenerator, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor TimestampGenerator");
    CheckedStage<VIDEORTP_timestampGenerator_t> gen;
    size_t timestamp = 20;
    size_t framerate = 24;

    const size_t bufferSize = 128;
    uint8_t buffer[bufferSize] = {};
    uint8_t pattern = 1;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_bufWritePattern(&bw, pattern, bufferSize);

    VIDEORTP_tgenInit(&gen, timestamp, framerate, &rep);

    EXPECT_EQ(gen.currentPayloadNumber, 0);
    EXPECT_EQ(gen.framerate, framerate);
    EXPECT_EQ(gen.startTimestamp, timestamp);
    EXPECT_EQ(gen.isPayloadUnitEnd, false);
    EXPECT_EQ(static_cast<VIDEORTP_timestampGenerator_t&>(gen).base, &rep);
}

uint64_t getTimestamp(uint64_t startTimestamp, uint64_t currentPayloadNumber, uint64_t framerate)
{
    return startTimestamp + currentPayloadNumber * VIDEORTP_CLOCK_RATE / framerate;
}

TEST(TimestampGenerator, CHECK_METADATA)
{
    TEST_DESCRIPTION("TEST for check metadata update if payload equal destination buffer size");
    CheckedStage<VIDEORTP_timestampGenerator_t> gen;
    size_t timestamp = 20;
    size_t framerate = 24;

    const size_t bufferSize = 128;
    uint8_t buffer[bufferSize] = {};
    uint8_t pattern = 1;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);
    VIDEORTP_bufWritePattern(&bw, pattern, bufferSize);

    VIDEORTP_tgenInit(&gen, timestamp, framerate, &rep);

    const size_t destSize = bufferSize;
    uint8_t destBuffer[destSize] = {};
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    uint8_t expect[destSize] = {};
    memset(expect, 1, destSize);

    // Packet copied completely
    // metadata.isPayloadUnitStart and metadata.isPayloadUnitEnd must be true
    // gen.currentPayloadNumber must be incremented after each copyChunk
    for (int i = 0; i < 10; i++)
    {
        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&gen, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, destSize);
        EXPECT_EQ(gen.currentPayloadNumber, i);
        EXPECT_TRUE(metadata.isPayloadUnitStart);
        EXPECT_TRUE(metadata.isPayloadUnitEnd);
        EXPECT_EQ(getTimestamp(timestamp, i, framerate), metadata.sampleTimestamp);

        VIDEORTP_pipeCopyChunk(&gen, &destBW);

        EXPECT_EQ(gen.currentPayloadNumber, i + 1);
        EXPECT_EQ(memcmp(expect, destBuffer, destSize), 0);
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(TimestampGenerator, CHECK_METADATA_CHUNKS)
{
    TEST_DESCRIPTION("TEST for check metadata update if payload great then destination buffer size");
    CheckedStage<VIDEORTP_timestampGenerator_t> gen;
    size_t timestamp = 20;
    size_t framerate = 24;

    const uint8_t bufferSize = 128;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    VIDEORTP_tgenInit(&gen, timestamp, framerate, &rep);

    // Fill array data from 0 to 127
    for (uint8_t i = 0; i < bufferSize; i++)
    {
        VIDEORTP_bufWriteInteger(&bw, i, sizeof(i));
    }

    const uint8_t destSize = bufferSize / 2;
    uint8_t destBuffer[destSize] = {};
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    uint8_t expect1[bufferSize] = {};
    for (uint8_t i = 0; i < destSize; i++)
    {
        expect1[i] = i;
    }

    uint8_t expect2[bufferSize] = {};
    for (uint8_t i = 0; i < destSize; i++)
    {
        expect2[i] = i + destSize;
    }

    // The packet devided into 2 parts
    // for 1st: metadata.isPayloadUnitStart must be true, metadata.isPayloadUnitEnd must be false
    // for 2nd: metadata.isPayloadUnitStart must be false, metadata.isPayloadUnitEnd must be true
    // gen.currentPayloadNumber must be incremented after each 2nd copyChunk
    for (int i = 0; i < 10; i++)
    {
        VIDEORTP_payloadChunkInfo_t metadata;
        /* first chunk */
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&gen, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, destSize);
        EXPECT_EQ(gen.currentPayloadNumber, i);
        EXPECT_TRUE(metadata.isPayloadUnitStart);
        EXPECT_FALSE(metadata.isPayloadUnitEnd);
        EXPECT_EQ(getTimestamp(timestamp, i, framerate), metadata.sampleTimestamp);
        VIDEORTP_pipeCopyChunk(&gen, &destBW);
        EXPECT_EQ(gen.currentPayloadNumber, i);
        EXPECT_EQ(memcmp(expect1, destBuffer, destSize), 0);
        VIDEORTP_bufClear(&destBW);

        /* second chunk */
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&gen, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, destSize);
        EXPECT_EQ(gen.currentPayloadNumber, i);
        EXPECT_FALSE(metadata.isPayloadUnitStart);
        EXPECT_TRUE(metadata.isPayloadUnitEnd);
        EXPECT_EQ(getTimestamp(timestamp, i, framerate), metadata.sampleTimestamp);
        VIDEORTP_pipeCopyChunk(&gen, &destBW);
        EXPECT_EQ(gen.currentPayloadNumber, i + 1);
        EXPECT_EQ(memcmp(expect2, destBuffer, destSize), 0);
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(TimestampGenerator, MULTIPLE_PREPARE_CHUNK)
{
    TEST_DESCRIPTION("TEST for check metadata not update if call prepareNextChunkt without copyChunk several times");
    CheckedStage<VIDEORTP_timestampGenerator_t> gen;
    size_t timestamp = 20;
    size_t framerate = 24;

    const size_t bufferSize = 16;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_repInit(&rep, &bw);

    VIDEORTP_tgenInit(&gen, timestamp, framerate, &rep);

    // Fill array data from 0 to 15
    for (uint8_t i = 0; i < bufferSize; i++)
    {
        VIDEORTP_bufWriteInteger(&bw, i, sizeof(i));
    }

    const uint8_t destSize = 128;
    uint8_t destBuffer[destSize] = {};
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    uint8_t expect[destSize] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 };

    VIDEORTP_payloadChunkInfo_t metadata;
    size_t nextChunkSize = 0;
    size_t expectCurrentPayloadNumber = 0;
    int count = 10;
    // After calling prepareNextChunk multiple times, expect timestamp and currentPayloadNumber to not change
    for (int i = 0; i < count; i++)
    {
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&gen, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, bufferSize);
        EXPECT_EQ(gen.currentPayloadNumber, expectCurrentPayloadNumber);
        EXPECT_TRUE(metadata.isPayloadUnitStart);
        EXPECT_TRUE(metadata.isPayloadUnitEnd);
        EXPECT_EQ(getTimestamp(timestamp, expectCurrentPayloadNumber, framerate), metadata.sampleTimestamp);
    }

    // After one calling copyChunk, expect the counter incremented
    expectCurrentPayloadNumber++;
    VIDEORTP_pipeCopyChunk(&gen, &destBW);
    VIDEORTP_bufClear(&destBW);
    EXPECT_EQ(memcmp(expect, destBuffer, destSize), 0);
    nextChunkSize = VIDEORTP_pipePrepareNextChunk(&gen, destSize, &metadata);
    EXPECT_EQ(nextChunkSize, bufferSize);
    EXPECT_EQ(gen.currentPayloadNumber, expectCurrentPayloadNumber);
    EXPECT_TRUE(metadata.isPayloadUnitStart);
    EXPECT_TRUE(metadata.isPayloadUnitEnd);
    EXPECT_EQ(getTimestamp(timestamp, expectCurrentPayloadNumber, framerate), metadata.sampleTimestamp);
}
