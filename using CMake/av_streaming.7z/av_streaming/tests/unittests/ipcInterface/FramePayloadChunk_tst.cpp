#include "Stubs/IpcCallbackMock.h"
#include "TestUtils.h"
#include "ipcFrame.h"
#include "ipcFramePayloadChunk.h"
#include <gtest/gtest.h>
#include <numeric>

TEST(FramePayloadChunkTest, ExecutesReleaseCallback)
{
    TEST_DESCRIPTION("Test that release callbacks will be executed");

    IpcCallbackMock ipcMock;
    uint8_t buffer[64] = "";
    VIDEORTP_ipcFramePayloadChunk_t chunk;

    // Execute callback
    VIDEORTP_ipcFrameChunkInit(&chunk, buffer, sizeof(buffer), ReleaseBufferCallback);
    EXPECT_CALL(ipcMock, ReleaseBuffer(buffer));
    VIDEORTP_ipcFrameChunkReleaseBuffer(&chunk);

    // No callback specified; do not execute previous callback
    VIDEORTP_ipcFrameChunkInit(&chunk, buffer, sizeof(buffer), NULL);
    VIDEORTP_ipcFrameChunkReleaseBuffer(&chunk);
}

TEST(FramePayloadChunkTest, PROCESSING)
{
    TEST_DESCRIPTION("TEST for simulate payload frame chunk lifecycle");
    IpcCallbackMock ipcMock;

    const size_t bufferSize = 64;
    uint8_t buffer[bufferSize];
    std::iota(buffer, buffer + sizeof(buffer), 1);

    VIDEORTP_ipcFramePayloadChunk_t chunk;
    VIDEORTP_ipcFrameChunkInit(&chunk, buffer, bufferSize, ReleaseBufferCallback);

    EXPECT_EQ(chunk.basePointer, buffer);
    EXPECT_EQ(chunk.readPointer, buffer);
    EXPECT_EQ(chunk.next, nullptr);
    EXPECT_EQ(chunk.totalSize, bufferSize);
    EXPECT_TRUE(chunk.releaseBufferCb == ReleaseBufferCallback);

    EXPECT_EQ(bufferSize, VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));

    const size_t destSize = 64;
    uint8_t destBuffer[destSize];
    EXPECT_EQ(bufferSize, VIDEORTP_ipcFrameChunkGetData(&chunk, destBuffer, destSize));
    EXPECT_EQ(0, memcmp(buffer, destBuffer, bufferSize));

    EXPECT_CALL(ipcMock, ReleaseBuffer(buffer));
    VIDEORTP_ipcFrameChunkReleaseBuffer(&chunk);
}

TEST(FramePayloadChunkTest, SupportsPartialReads)
{
    TEST_DESCRIPTION("Test that payload frame chunk supports partial reads");

    uint8_t buffer[64];
    std::iota(buffer, buffer + sizeof(buffer), 1);

    VIDEORTP_ipcFramePayloadChunk_t chunk;
    VIDEORTP_ipcFrameChunkInit(&chunk, buffer, sizeof(buffer), NULL);
    EXPECT_EQ(sizeof(buffer), VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));

    uint8_t destBuffer[25];

    // first chunk
    EXPECT_EQ(25, VIDEORTP_ipcFrameChunkGetData(&chunk, destBuffer, sizeof(destBuffer)));
    EXPECT_EQ(sizeof(buffer) - 25, VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));
    EXPECT_EQ(0, memcmp(buffer, destBuffer, 25));

    // second chunk
    EXPECT_EQ(25, VIDEORTP_ipcFrameChunkGetData(&chunk, destBuffer, sizeof(destBuffer)));
    EXPECT_EQ(sizeof(buffer) - 50, VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));
    EXPECT_EQ(0, memcmp(buffer + 25, destBuffer, 25));

    // last chunk
    EXPECT_EQ(14, VIDEORTP_ipcFrameChunkGetData(&chunk, destBuffer, sizeof(destBuffer)));
    EXPECT_EQ(0, VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));
    EXPECT_EQ(0, memcmp(buffer + 50, destBuffer, 14));

    // already at the end
    EXPECT_EQ(0, VIDEORTP_ipcFrameChunkGetData(&chunk, destBuffer, sizeof(destBuffer)));
    EXPECT_EQ(0, VIDEORTP_ipcFrameChunkGetRemainingSize(&chunk));

    VIDEORTP_ipcFrameChunkReleaseBuffer(&chunk);
}
