#include "Stubs/IpcCallbackMock.h"
#include "TestUtils.h"
#include "ipcFramePayloadChunk.h"
#include "ipcPayloadChunkFactory.h"
#include <gtest/gtest.h>
#include <set>

TEST(payloadChunkfactory, PROCESSING)
{
    TEST_DESCRIPTION("TEST for spawn and destroy payload chunks logic");
    VIDEORTP_ipcPayloadChunkFactory_t factory;
    VIDEORTP_payloadChunkFactoryInit(&factory);

    const size_t chunkSize = 128;
    uint8_t chunkBuffer[chunkSize] = "";

    EXPECT_DEATH(VIDEORTP_payloadChunkFactoryDestroy(&factory, NULL), "");

    // Check that we can create and destroy elements
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT * 3; i++)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, chunkSize, NULL);
        VIDEORTP_payloadChunkFactoryDestroy(&factory, chunk);
    }

    // Check that the factory returns each chunk exactly once (no duplicates; order does not matter)
    std::set<VIDEORTP_ipcFramePayloadChunk_t*> chunks;
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, chunkSize, NULL);
        /* check the element is not included to set (VIDEORTP_payloadChunkFactoryCreate return different links) */
        EXPECT_EQ(chunks.find(chunk), chunks.end());
        EXPECT_TRUE(chunks.insert(chunk).second);
        /* check that the element has been added to the set */
        EXPECT_NE(chunks.find(chunk), chunks.end());
    }
    EXPECT_EQ(chunks.size(), VIDEORTP_FACTORY_MAX_CHUNK_COUNT);

    // Check if it returns null if no more frames are available
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, chunkSize, NULL);
        EXPECT_EQ(chunk, nullptr);
    }
}

TEST(payloadChunkfactory, DoesNotReleaseBuffersEarly)
{
    TEST_DESCRIPTION("TEST for check failing spawn condition");

    VIDEORTP_ipcPayloadChunkFactory_t factory;
    VIDEORTP_payloadChunkFactoryInit(&factory);

    const size_t chunkSize = 128;
    uint8_t chunkBuffer[chunkSize] = "";

    //  Allocates all possible chunks
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk
            = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, chunkSize, IpcCallbackMock::InvalidReleaseBufferCallback);
        EXPECT_NE(chunk, nullptr);
    }

    // If creation fails, ownership is not transferred, and the releaseCallback must not be called.
    VIDEORTP_ipcFramePayloadChunk_t* chunk
        = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, chunkSize, IpcCallbackMock::InvalidReleaseBufferCallback);
    EXPECT_EQ(chunk, nullptr);
}

TEST(payloadChunkfactory, DoesNotReleaseForeignBuffers)
{
    TEST_DESCRIPTION("TEST for check failing spawn condition");
    IpcCallbackMock ipcMock;

    VIDEORTP_ipcPayloadChunkFactory_t factory;
    VIDEORTP_payloadChunkFactoryInit(&factory);

    uint8_t chunkBuffer[VIDEORTP_FACTORY_MAX_CHUNK_COUNT] = "";

    std::vector<VIDEORTP_ipcFramePayloadChunk_t*> chunks;
    // Exhaust memory
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        VIDEORTP_ipcFramePayloadChunk_t* chunk
            = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer + i, 1, IpcCallbackMock::ReleaseBufferCallback);
        chunks.push_back(chunk);
        EXPECT_NE(chunk, nullptr);
    }

    // Ensure the factory never releases a buffer it does not "own"
    VIDEORTP_ipcFramePayloadChunk_t* chunk
        = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, 1, IpcCallbackMock::InvalidReleaseBufferCallback);
    EXPECT_EQ(chunk, nullptr);

    // Return all elements to pool
    for (int i = 0; i < VIDEORTP_FACTORY_MAX_CHUNK_COUNT; i++)
    {
        EXPECT_CALL(ipcMock, ReleaseBuffer(chunkBuffer + i));
        VIDEORTP_payloadChunkFactoryDestroy(&factory, chunks[i]);
    }

    // Try create again
    chunk = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, 1, NULL);
    EXPECT_NE(chunk, nullptr);
}

TEST(payloadChunkfactory, ZeroChunkSize)
{
    TEST_DESCRIPTION("TEST for check spawn payload chunks if payload is null");
    // create dummy buffer
    uint8_t chunkBuffer[1] = "";

    VIDEORTP_ipcPayloadChunkFactory_t factory;
    VIDEORTP_payloadChunkFactoryInit(&factory);

    // create chunk with zero size buffer
    VIDEORTP_ipcFramePayloadChunk_t* chunk = nullptr;
    // Buffer not null, but chunk size is zero -> OK
    chunk = VIDEORTP_payloadChunkFactoryCreate(&factory, chunkBuffer, 0, NULL);
    EXPECT_NE(chunk, nullptr);
    // Buffer is null -> assert
    EXPECT_DEATH(VIDEORTP_payloadChunkFactoryCreate(&factory, NULL, 0, NULL), "");
    EXPECT_DEATH(VIDEORTP_payloadChunkFactoryCreate(&factory, NULL, 10, NULL), "");
}
