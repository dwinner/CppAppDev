#include "IpcFrameProvider.h"
#include "Stubs/CheckedStage.h"
#include "Stubs/IpcCallbackMock.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

class IpcFrameProviderTest : public ::testing::Test
{
protected:
    CheckedGenerator<VIDEORTP_ipcFrameProvider_t> frameProvider {};
    const size_t frameSize = 512;
    const VIDEORTP_timestamp dummySamplingTime = { 123, 123 };
    const VIDEORTP_timestamp* frameSamplingTime = &dummySamplingTime;
    size_t destSize = 512;

    std::vector<uint8_t> payloadBuffer;
    uint8_t pattern;

    VIDEORTP_payloadChunkInfo_t metadata;
    IpcCallbackMock ipcMock;
    void SetUp() override
    {
        // initialize payloadBuffer
        payloadBuffer.resize(frameSize);
        pattern = 1;
        for (size_t i = 0; i < payloadBuffer.size(); ++i)
            payloadBuffer[i] = pattern + i / 3;

        // initialize frameProvider
        VIDEORTP_ipcInit(&frameProvider);
        EXPECT_EQ(0, frameProvider.nextChunkSize);
        EXPECT_EQ(nullptr, frameProvider.newestFrame);
        ASSERT_EQ(VIDEORTP_pipePrepareNextChunk(&frameProvider, 128, &metadata), 0);
    }

    bool AppendFrame(const void* bufferPayload, const size_t bufferSize)
    {
        return VIDEORTP_ipcAppendFrame(&frameProvider, bufferPayload, bufferSize, ReleaseBufferCallback);
    }

    bool ContainsElementInQueue(VIDEORTP_ipcFrameQueue_t* queue, VIDEORTP_ipcFrame_t* element)
    {
        bool res = false;
        tst_slistContains(queue, element, res);
        return res;
    }

    VIDEORTP_ipcFrame_t* StartFrameWithCheckPrevious(const uint8_t* payloadBuffer, const size_t payloadBufferSize,
                                                     VIDEORTP_ipcFrame_t* previousFrame)
    {
        // Check that previousFrame is current newestFrame
        EXPECT_EQ(previousFrame, frameProvider.newestFrame);
        // create new frame
        EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
        // check that newestFrame is changed
        EXPECT_NE(previousFrame, frameProvider.newestFrame);
        // check that newestFrame is queue tail
        EXPECT_EQ(frameProvider.newestFrame, frameProvider.frameQueue.tail);
        return frameProvider.newestFrame;
    }

    void CopyAndCheckData(const void* expectedPayload)
    {
        // Initialize destination buffer
        std::vector<uint8_t> destBuffer(destSize);
        VIDEORTP_bufferWriter_t destBW;
        VIDEORTP_bufInit(&destBW, destBuffer.data(), destSize);

        // Read into destination buffer
        ASSERT_EQ(VIDEORTP_pipePrepareNextChunk(&frameProvider, destSize, &metadata), destSize);
        VIDEORTP_pipeCopyChunk(&frameProvider, &destBW);
        ASSERT_EQ(VIDEORTP_bufGetBytesWritten(&destBW), destSize);
        EXPECT_EQ(0, memcmp(expectedPayload, destBuffer.data(), destSize));
    }
};

TEST_F(IpcFrameProviderTest, Deinit)
{
    TEST_DESCRIPTION("Test that frame provider deinit with release buffer");
    // Create frames
    for (int i = 0; i < 5; i++)
    {
        ASSERT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, &dummySamplingTime));
        tst_frameWithTwoChunks(&frameProvider, 1, frameSize, payloadBuffer.data(), ReleaseBufferCallback);
        // Check queue
        EXPECT_EQ(frameProvider.newestFrame, frameProvider.frameQueue.tail);
    }
    // Deinit
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(10);
    // This function should return all frames to the pool,
    // and should also call the release callback for each chunk
    VIDEORTP_ipcDeinit(&frameProvider);
    EXPECT_EQ(NULL, frameProvider.frameQueue.head);
    EXPECT_EQ(NULL, frameProvider.frameQueue.tail);
}

TEST_F(IpcFrameProviderTest, ResetsFramePointerOnOverflow)
{
    TEST_DESCRIPTION("Test that the frame insertion pointer is reset when all frame buffers are exhausted");
    uint8_t buffer[] = "test";

    // Consume all buffers
    for (size_t i = 0; i < VIDEORTP_FACTORY_FRAME_MAX_COUNT; i++)
    {
        VIDEORTP_timestamp sample = { i };
        EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, sizeof(buffer) * 2, &sample));
        EXPECT_TRUE(VIDEORTP_ipcAppendFrame(&frameProvider, buffer, sizeof(buffer), ReleaseBufferCallback));
        EXPECT_NE(frameProvider.newestFrame, nullptr);
    }

    // No more space left
    EXPECT_FALSE(VIDEORTP_ipcStartFrame(&frameProvider, sizeof(buffer), &dummySamplingTime));
    EXPECT_EQ(frameProvider.newestFrame, nullptr);

    // Clean up all buffers
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(VIDEORTP_FACTORY_FRAME_MAX_COUNT);
    VIDEORTP_ipcDeinit(&frameProvider);
    EXPECT_EQ(frameProvider.frameQueue.head, nullptr);
    EXPECT_EQ(frameProvider.frameQueue.tail, nullptr);
}

TEST_F(IpcFrameProviderTest, CanStartFrames)
{
    TEST_DESCRIPTION("Test that frames can be started and will be linked in order");
    const size_t bufferSize = 128;
    VIDEORTP_ipcFrame_t* previousFrame = NULL;

    // Check head queue
    EXPECT_EQ(NULL, frameProvider.frameQueue.head);
    previousFrame = StartFrameWithCheckPrevious(NULL, bufferSize, previousFrame);
    EXPECT_EQ(previousFrame, frameProvider.frameQueue.head);

    previousFrame = StartFrameWithCheckPrevious(NULL, 0, previousFrame);
    previousFrame = StartFrameWithCheckPrevious(payloadBuffer.data(), 0, previousFrame);
    previousFrame = StartFrameWithCheckPrevious(payloadBuffer.data(), bufferSize, previousFrame);
    previousFrame = StartFrameWithCheckPrevious(NULL, bufferSize, previousFrame);
}

TEST_F(IpcFrameProviderTest, CanAppendDataToFrames)
{
    TEST_DESCRIPTION("Test that payload chunks can be appended to a frame");

    // Copy payload data to frame
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize / 2));
    EXPECT_TRUE(AppendFrame(payloadBuffer.data() + frameSize / 2, frameSize / 2));

    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(2);
    CopyAndCheckData(payloadBuffer.data());
}

TEST_F(IpcFrameProviderTest, PreservesTimestamps)
{
    TEST_DESCRIPTION("Test that timestamps are returned without modification");

    VIDEORTP_timestamp ts = { 123, 456, 789, 42 };

    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, &ts));
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize));

    ASSERT_EQ(VIDEORTP_pipePrepareNextChunk(&frameProvider, destSize, &metadata), destSize);
    ASSERT_EQ(metadata.sampleTimestamp, ts);
}

TEST_F(IpcFrameProviderTest, ReturnsFramesToPipeline)
{
    TEST_DESCRIPTION("Test transmission of frames to next pipeline stage");
    std::vector<std::vector<uint8_t>> payloads;
    for (int i = 0; i < 10; i++)
    {
        // set payload data
        payloads.push_back(std::vector<uint8_t>(frameSize));
        uint8_t* payloadBuffer = payloads.back().data();
        memset(payloadBuffer, pattern++, frameSize / 2);
        memset(payloadBuffer + frameSize / 2, pattern++, frameSize / 2);

        // Copy payload data to frame
        tst_frameWithTwoChunks(&frameProvider, 1, frameSize, payloadBuffer, ReleaseBufferCallback);
    }

    // Copy frame data to dest Buffer
    for (int i = 0; i < 10; i++)
    {
        uint8_t* payloadBuffer = payloads.at(i).data();
        EXPECT_CALL(ipcMock, ReleaseBuffer).Times(2);
        CopyAndCheckData(payloadBuffer);
    }
}

TEST_F(IpcFrameProviderTest, ReturnsDataInSmallChunks)
{
    TEST_DESCRIPTION(
        "TEST for check correct frames transmission to next pipeline stage if destination buffer size less then frame size (chunks "
        "have same pattern)");

    destSize = 16;

    for (int frameCount = 0; frameCount < 3; frameCount++)
    {
        // Copy payload data to frame
        tst_frameWithTwoChunks(&frameProvider, 1, frameSize, payloadBuffer.data(), ReleaseBufferCallback);

        EXPECT_CALL(ipcMock, ReleaseBuffer).Times(2);
        for (int i = 0; i < frameSize / destSize; i++)
        {
            CopyAndCheckData(payloadBuffer.data() + i * destSize);
        }
    }
}

TEST_F(IpcFrameProviderTest, ReturnsDataFromDifferentFrames)
{
    TEST_DESCRIPTION("Test that multiple different frames can be returned to the pipeline");
    // Buffer with payload data from ipc
    const size_t payloadBufferSize = 512;
    uint8_t payloadBuffer1[payloadBufferSize];
    uint8_t payloadBuffer2[payloadBufferSize];

    destSize = 16;

    for (int frameCount = 0; frameCount < VIDEORTP_FACTORY_FRAME_MAX_COUNT; frameCount++)
    {
        tst_frameWithTwoChunks(&frameProvider, pattern, frameSize, payloadBuffer1, ReleaseBufferCallback);
        pattern += 2;
        tst_frameWithTwoChunks(&frameProvider, pattern, frameSize, payloadBuffer2, ReleaseBufferCallback);
        pattern += 2;

        for (int frame = 0; frame < 2; frame++)
        {
            EXPECT_CALL(ipcMock, ReleaseBuffer).Times(2);
            uint8_t* payloadBuffer = frame == 0 ? payloadBuffer1 : payloadBuffer2;
            for (int i = 0; i < frameSize / destSize; i++)
            {
                CopyAndCheckData(payloadBuffer + i * destSize);
            }
        }
    }
}

TEST_F(IpcFrameProviderTest, FramesSupportManyChunks)
{
    TEST_DESCRIPTION("TEST correct transmission to next pipeline stage if frame has many chunks");
    const size_t chunkSize = 16;

    destSize = 128;

    for (int repeats = 0; repeats < 5; repeats++)
    {
        // Spawn chunks and copy payload data to frame
        memset(payloadBuffer.data(), pattern++, chunkSize);
        EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
        for (int i = 0; i < frameSize; i += chunkSize)
        {
            memset(payloadBuffer.data() + i, pattern++, chunkSize);
            EXPECT_TRUE(AppendFrame(payloadBuffer.data() + i, chunkSize));
        }

        // Copy data to destination buffer
        EXPECT_CALL(ipcMock, ReleaseBuffer).Times(frameSize / chunkSize);
        for (int i = 0; i < frameSize / destSize; i++)
        {
            CopyAndCheckData(payloadBuffer.data() + i * destSize);
        }
    }
}

TEST_F(IpcFrameProviderTest, FRAMES_QUEUE_MANY_CHUNKS_INVALID)
{
    TEST_DESCRIPTION("TEST for simulate case when factory can't spawn payload chunks");
    uint8_t padding = 1;
    size_t chunksCount = 0;
    for (int repeats = 0; repeats < 5; repeats++)
    {
        const size_t chunkSize = frameSize / VIDEORTP_FACTORY_MAX_CHUNK_COUNT;
        EXPECT_LE(chunkSize, frameSize);
        // Spawn chunks and copy payload data to frame
        memset(payloadBuffer.data(), padding++, chunkSize);
        if (chunksCount >= VIDEORTP_FACTORY_MAX_CHUNK_COUNT)
        {
            // Frame was created but chunk not added
            EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
            EXPECT_FALSE(AppendFrame(payloadBuffer.data(), chunkSize));
        }
        else
        {
            EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
            EXPECT_TRUE(AppendFrame(payloadBuffer.data(), chunkSize));
        }
        chunksCount++;
        for (int i = chunkSize; i < frameSize - chunkSize; i += chunkSize)
        {
            memset(payloadBuffer.data() + i, padding++, chunkSize);
            if (chunksCount >= VIDEORTP_FACTORY_MAX_CHUNK_COUNT)
            {
                EXPECT_FALSE(AppendFrame(payloadBuffer.data() + i, chunkSize));
            }
            else
            {
                EXPECT_TRUE(AppendFrame(payloadBuffer.data() + i, chunkSize));
            }
            chunksCount++;
        }
    }
}

TEST_F(IpcFrameProviderTest, FRAMES_WITH_NULL_START)
{
    TEST_DESCRIPTION("TEST for check correct start frame when first chunks is null");
    const size_t chunkSize = 16;

    // Spawn chunks and copy payload data to frame
    memset(payloadBuffer.data(), pattern++, chunkSize);
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    for (int i = 0; i < frameSize; i += chunkSize)
    {
        memset(payloadBuffer.data() + i, pattern++, chunkSize);
        EXPECT_TRUE(AppendFrame(payloadBuffer.data() + i, chunkSize));
    }

    destSize = 128;

    // Copy frame data to destBuffer
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(frameSize / chunkSize);
    for (int i = 0; i < frameSize / destSize; i++)
    {
        CopyAndCheckData(payloadBuffer.data() + i * destSize);
    }
}

TEST_F(IpcFrameProviderTest, SkipsEmptyFrames)
{
    TEST_DESCRIPTION("TEST for check correct start frame when first chunks is empty");
    memset(payloadBuffer.data(), 1, frameSize);
    std::vector<VIDEORTP_ipcFrame_t*> frames;

    // Buffer null, buffer size zero
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_FALSE(AppendFrame(nullptr, 0));
    EXPECT_NE(frameProvider.newestFrame, nullptr);
    frames.push_back(frameProvider.newestFrame);

    // Buffer null, buffer size non zero
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_FALSE(AppendFrame(nullptr, frameSize));
    EXPECT_NE(frameProvider.newestFrame, nullptr);
    frames.push_back(frameProvider.newestFrame);

    // Buffer non null, buffer size zero
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_FALSE(AppendFrame(payloadBuffer.data(), 0));
    EXPECT_NE(frameProvider.newestFrame, nullptr);
    frames.push_back(frameProvider.newestFrame);

    // Make sure all frames are added
    for (VIDEORTP_ipcFrame_t* frame : frames)
    {
        EXPECT_TRUE(ContainsElementInQueue(&frameProvider.frameQueue, frame));
    }

    // TODO: Error handling is not defined, yet! See MAGAVSTR-745.
    // Other pipeline stages may need to be reset to recover.
    // For now, just make sure that abandoned frames are cleaned up.

    EXPECT_EQ(0, VIDEORTP_pipePrepareNextChunk(&frameProvider, frameSize, &metadata));
    // Check that removed frames without data
    for (int i = 0; i < 2; i++)
    {
        EXPECT_FALSE(ContainsElementInQueue(&frameProvider.frameQueue, frames[i]));
    }
    // Check that the last (incomplete) frame remains. Data can still be added.
    EXPECT_TRUE(ContainsElementInQueue(&frameProvider.frameQueue, frames[2]));

    // Add complete frame
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize));
    EXPECT_NE(frameProvider.newestFrame, nullptr);
    // Must returns complete frame
    EXPECT_EQ(frameSize, VIDEORTP_pipePrepareNextChunk(&frameProvider, frameSize, &metadata));
    // Check that removed last non complete frame
    EXPECT_FALSE(ContainsElementInQueue(&frameProvider.frameQueue, frames[2]));
}

TEST_F(IpcFrameProviderTest, PendingFrame)
{
    TEST_DESCRIPTION("TEST correct transmission to next pipeline if frame is not finished");
    // Start frame
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    // Append part of data
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize / 2));
    // Frame is not complete, but not abandoned; expected that data will be returned partially
    destSize /= 2;
    EXPECT_CALL(ipcMock, ReleaseBuffer);
    CopyAndCheckData(payloadBuffer.data());
    // Resume and append rest of frame
    EXPECT_TRUE(AppendFrame(payloadBuffer.data() + frameSize / 2, frameSize / 2));
    EXPECT_CALL(ipcMock, ReleaseBuffer);
    CopyAndCheckData(payloadBuffer.data() + frameSize / 2);
}

TEST_F(IpcFrameProviderTest, ReleasesFinishedFrame)
{
    TEST_DESCRIPTION("Test that fully copied frames are released");

    // Create frame
    EXPECT_EQ(frameProvider.newestFrame, nullptr);
    ASSERT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    ASSERT_NE(frameProvider.newestFrame, nullptr);

    // Ensure the frame was allocated correctly
    auto* frame = frameProvider.newestFrame;
    EXPECT_FALSE(ContainsElementInQueue(&frameProvider.frameFactory.freeQueue, frame));
    EXPECT_TRUE(ContainsElementInQueue(&frameProvider.frameQueue, frame));

    // Append data to that frame
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize));
    EXPECT_EQ(frameProvider.newestFrame, frame);

    // The frame will be released when all chunks were read completely
    EXPECT_CALL(ipcMock, ReleaseBuffer);
    CopyAndCheckData(payloadBuffer.data());
    EXPECT_FALSE(ContainsElementInQueue(&frameProvider.frameQueue, frame));
    EXPECT_TRUE(ContainsElementInQueue(&frameProvider.frameFactory.freeQueue, frame));

    // No "dangling" pointers
    EXPECT_EQ(frameProvider.newestFrame, nullptr);
    // No frames waiting in the queue
    EXPECT_EQ(tst_slistSize(&frameProvider.frameQueue), 0);
    // There is no "active" frame to add data to
    EXPECT_FALSE(AppendFrame(payloadBuffer.data(), 1));
}

TEST_F(IpcFrameProviderTest, AbandonedFrame)
{
    TEST_DESCRIPTION("TEST for check correct transmission frame to next pipeline if frame is not finished and started next frame");

    EXPECT_EQ(frameProvider.newestFrame, nullptr);
    // frame with zero size
    EXPECT_FALSE(VIDEORTP_ipcStartFrame(&frameProvider, 0, frameSamplingTime));
    // frame with empty buffer
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    EXPECT_FALSE(AppendFrame(payloadBuffer.data(), 0));
    EXPECT_NE(frameProvider.newestFrame, nullptr);
    VIDEORTP_ipcFrame_t* invalidFrame = frameProvider.newestFrame;

    // frame with data
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize, frameSamplingTime));
    // failing append chunk
    EXPECT_TRUE(AppendFrame(payloadBuffer.data(), frameSize));
    EXPECT_FALSE(AppendFrame(payloadBuffer.data(), frameSize));
    EXPECT_TRUE(ContainsElementInQueue(&frameProvider.frameQueue, invalidFrame));

    // TODO: Error handling is not defined, yet! See MAGAVSTR-745.
    // Other pipeline stages may need to be reset to recover.
    // For now, just make sure that abandoned frames are cleaned up.

    // Expect that first frame will be missed and copied only second frame
    EXPECT_EQ(frameSize, VIDEORTP_pipePrepareNextChunk(&frameProvider, destSize, &metadata));
    // check that invalid frame was deleted
    EXPECT_FALSE(ContainsElementInQueue(&frameProvider.frameQueue, invalidFrame));
    // Copy data
    EXPECT_CALL(ipcMock, ReleaseBuffer);
    CopyAndCheckData(payloadBuffer.data());
}

TEST_F(IpcFrameProviderTest, DoesNotLeakChunksOnError)
{
    TEST_DESCRIPTION("Test that there are no memory leaks on error");

    // It should not release buffers it does not own
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(0);

    // All chunks are bigger than the whole frame so they will be rejected

    EXPECT_TRUE(VIDEORTP_ipcStartFrame(&frameProvider, frameSize / 2, frameSamplingTime));
    EXPECT_FALSE(AppendFrame(payloadBuffer.data(), frameSize));
    EXPECT_EQ(tst_slistSize(&frameProvider.chunkFactory.freeQueue), VIDEORTP_FACTORY_MAX_CHUNK_COUNT);
}
