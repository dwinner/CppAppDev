#include "SinglyLinkedList.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

class SinglyLinkedListTest : public ::testing::Test
{
protected:
    struct Data
    {
        int i;
        Data* next;
    };

    struct List
    {
        Data* head;
        Data* tail;
    };

    List list;

    SinglyLinkedListTest()
    {
        VIDEORTP_slistInit(&list);
    }

    void push(int i)
    {
        Data* newElement = new Data;
        newElement->i = i;
        VIDEORTP_slistPushBack(&list, newElement);
        EXPECT_EQ(newElement->next, nullptr);

        EXPECT_FALSE(VIDEORTP_slistIsEmpty(&list));
        EXPECT_NE(list.head, nullptr);
        EXPECT_NE(list.tail, nullptr);
    }

    void peek(int i)
    {
        EXPECT_FALSE(VIDEORTP_slistIsEmpty(&list));
        EXPECT_NE(list.head, nullptr);
        EXPECT_NE(list.tail, nullptr);

        Data* element;
        VIDEORTP_slistPeekFront(&list, &element);
        EXPECT_NE(element, nullptr);

        EXPECT_EQ(element->i, i);
    }

    void pop(int i)
    {
        EXPECT_FALSE(VIDEORTP_slistIsEmpty(&list));
        EXPECT_NE(list.head, nullptr);
        EXPECT_NE(list.tail, nullptr);

        Data* element;
        VIDEORTP_slistPopFront(&list, &element);
        EXPECT_NE(element, nullptr);

        EXPECT_EQ(element->i, i);
        delete element;
    }

    void checkEmpty()
    {
        EXPECT_TRUE(VIDEORTP_slistIsEmpty(&list));
        EXPECT_EQ(list.head, nullptr);
        EXPECT_EQ(list.tail, nullptr);

        Data* element;
        VIDEORTP_slistPopFront(&list, &element);
        EXPECT_EQ(element, nullptr);
    }
};

TEST_F(SinglyLinkedListTest, EmptyListHasNoElements)
{
    TEST_DESCRIPTION("TEST for check empty list");
    checkEmpty();
}

TEST_F(SinglyLinkedListTest, StoresSingleElement)
{
    TEST_DESCRIPTION("TEST for check store one element");
    push(1);
    pop(1);
    checkEmpty();

    push(2);
    pop(2);
    push(3);
    pop(3);
    checkEmpty();
}

TEST_F(SinglyLinkedListTest, StoresTwoElementsInOrder)
{
    TEST_DESCRIPTION("TEST for check store two elements");
    push(1);
    push(2);
    pop(1);
    pop(2);
    checkEmpty();
}

TEST_F(SinglyLinkedListTest, StoresMultipleElementsInOrder)
{
    TEST_DESCRIPTION("TEST for check store several elements");
    for (int i = 1; i <= 20; ++i)
        push(i);
    for (int i = 1; i <= 20; ++i)
        pop(i);
    checkEmpty();
}

TEST_F(SinglyLinkedListTest, PeekingReturnsNullOnEmptyList)
{
    TEST_DESCRIPTION("TEST for check correct peek front on empty list");
    Data* element;
    VIDEORTP_slistPeekFront(&list, &element);
    ASSERT_EQ(element, nullptr);
}

TEST_F(SinglyLinkedListTest, PeekingDoesNotChangeList)
{
    TEST_DESCRIPTION("TEST for check that peek does not change list");
    push(1);
    peek(1);
    peek(1);
    peek(1);
    pop(1);

    checkEmpty();
}

TEST_F(SinglyLinkedListTest, PeekingReturnsFirstElement)
{
    TEST_DESCRIPTION("TEST for check that peek return correct element");
    push(1);
    peek(1);

    push(2);
    peek(1);

    pop(1);
    peek(2);

    push(3);
    peek(2);

    pop(2);
    peek(3);

    pop(3);
    checkEmpty();
}
