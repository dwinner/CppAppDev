#include "Stubs/IpcCallbackMock.h"
#include "TestUtils.h"
#include "ipcFrame.h"
#include "ipcFrameFactory.h"
#include "ipcFramePayloadChunk.h"
#include <gtest/gtest.h>
#include <numeric>

TEST(IpcFrameTest, Deinit)
{
    TEST_DESCRIPTION("Test that frame deinit work correctly");
    IpcCallbackMock ipcMock;
    const size_t frameSize = 128;
    const size_t chunkSize = 32;
    const int pattern = 1;
    std::vector<std::vector<uint8_t>> chunkArrays;
    VIDEORTP_ipcFrame_t frame;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
    tst_ipcInitFrameAndFactory(&frame, frameSize, &chunkFactory);
    tst_ipcFillFrameChunksPattern(&frame, chunkSize, pattern, chunkArrays, ReleaseBufferCallback);
    EXPECT_NE(nullptr, frame.payloadChunkQueue.head);
    EXPECT_NE(nullptr, frame.payloadChunkQueue.tail);
    int callbackCalling = frameSize / chunkSize;
    callbackCalling += frameSize % chunkSize == 0 ? 0 : 1;
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(callbackCalling);
    VIDEORTP_ipcFrameDeinit(&frame);
    EXPECT_EQ(nullptr, frame.payloadChunkQueue.head);
    EXPECT_EQ(nullptr, frame.payloadChunkQueue.tail);
}

TEST(IpcFrameTest, RejectsEmptyChunks)
{
    TEST_DESCRIPTION("Test that frame prevents adding empty chunks");

    VIDEORTP_ipcFrame_t frame;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
    tst_ipcInitFrameAndFactory(&frame, 100, &chunkFactory);

    EXPECT_FALSE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, nullptr, 0, nullptr));
}

TEST(IpcFrameTest, ReleasesProcessedChunks)
{
    TEST_DESCRIPTION("Test that frame releases processed chunks");
    IpcCallbackMock ipcMock;
    const size_t frameSize = 128;

    // Try create frames with another chunks count
    for (int chunkSize = 8; chunkSize < frameSize; chunkSize += 8)
    {
        uint8_t pattern = 1;

        VIDEORTP_ipcFrame_t frame;
        VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
        tst_ipcInitFrameAndFactory(&frame, frameSize, &chunkFactory);

        uint8_t expectBuffer[frameSize];
        std::vector<std::vector<uint8_t>> chunkArrays;
        // Add pattern chunks to frame
        tst_ipcFillFrameChunksPattern(&frame, chunkSize, pattern, chunkArrays, ReleaseBufferCallback);
        // Generate expected array
        tst_getExpectPatternChunk(expectBuffer, frameSize, chunkSize, pattern);
        pattern += frameSize / chunkSize;

        const size_t destSize = frameSize;
        uint8_t destBuffer[destSize];

        // How many times callback will be called
        // Same with chunks count
        int callbackCalling = frameSize / chunkSize;
        callbackCalling += frameSize % chunkSize == 0 ? 0 : 1;
        // Copy frame to destBuffer
        EXPECT_CALL(ipcMock, ReleaseBuffer).Times(callbackCalling);
        EXPECT_EQ(frameSize, VIDEORTP_ipcFrameGetData(&frame, destBuffer, destSize));
        // Check all bytes out
        EXPECT_EQ(0, VIDEORTP_ipcFrameGetRemainingBytes(&frame));
        EXPECT_EQ(0, VIDEORTP_ipcFrameGetAvailableBytes(&frame));
        // check data
        EXPECT_EQ(0, memcmp(expectBuffer, destBuffer, destSize));
    }
}

TEST(IpcFrameTest, CanReadWhileWriting)
{
    TEST_DESCRIPTION("Test that frames can be read while being written");

    uint8_t buffer[20] = "";
    std::iota(buffer, buffer + sizeof(buffer), 'a');

    VIDEORTP_ipcFrame_t frame;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
    tst_ipcInitFrameAndFactory(&frame, sizeof(buffer), &chunkFactory);

    // No data available yet
    uint8_t dest[sizeof(buffer)] = "";
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetData(&frame, dest, sizeof(dest)));

    // Read first chunk at once
    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer + 0, 5, nullptr));
    EXPECT_EQ(5, VIDEORTP_ipcFrameGetData(&frame, dest, 10));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetData(&frame, dest + 5, 10));

    // Read second chunk in smaller pieces
    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer + 5, 5, nullptr));
    EXPECT_EQ(3, VIDEORTP_ipcFrameGetData(&frame, dest + 5, 3));
    EXPECT_EQ(2, VIDEORTP_ipcFrameGetData(&frame, dest + 8, 3));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetData(&frame, dest + 10, 3));

    // Add more data but only read a bit of that chunk
    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer + 10, 5, nullptr));
    EXPECT_EQ(3, VIDEORTP_ipcFrameGetData(&frame, dest + 10, 3));

    // Add and read the rest
    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer + 15, 5, nullptr));
    EXPECT_EQ(7, VIDEORTP_ipcFrameGetData(&frame, dest + 13, 7));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetData(&frame, dest, 10));

    // Cannot add more data after the whole frame has been processed.
    EXPECT_FALSE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer + 0, 5, nullptr));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetData(&frame, dest, 10));

    EXPECT_EQ(0, memcmp(buffer, dest, sizeof(buffer)));
}

TEST(IpcFrameTest, RejectsExcessChunks)
{
    TEST_DESCRIPTION("Test that frames cannot overflow");
    IpcCallbackMock ipcMock;

    const size_t frameSize = 128;
    uint8_t pattern = 1;
    VIDEORTP_ipcFrame_t frame;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
    tst_ipcInitFrameAndFactory(&frame, frameSize, &chunkFactory);

    size_t chunkSize = frameSize;
    // Note: Nested vectors are okay because the buffers of the inner
    // vectors are moved (not reallocated) when the outer vector grows.
    std::vector<std::vector<uint8_t>> chunkArrays;
    for (int i = 0; i < 10; i++)
    {
        // create chunk
        chunkArrays.emplace_back(chunkSize, pattern++);

        if (i == 0)
        {
            // Frame filled comletely with first chunk
            EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, chunkArrays.back().data(), chunkSize, ReleaseBufferCallback));
            // !!! Destoy call ReleaseCallback !!!
            EXPECT_CALL(ipcMock, ReleaseBuffer).Times(1);
            VIDEORTP_payloadChunkFactoryDestroy(&chunkFactory, frame.payloadChunkQueue.head);
        }
        else
        {
            // Frame overflow. The buffer must not be released because the frame does not own it.
            EXPECT_CALL(ipcMock, ReleaseBuffer).Times(0);
            EXPECT_FALSE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, chunkArrays.back().data(), chunkSize, ReleaseBufferCallback));
        }
    }
}

TEST(IpcFrameTest, RejectsExcessData)
{
    TEST_DESCRIPTION("Test that frame prevents adding too much data");
    IpcCallbackMock ipcMock;

    uint8_t buffer1[50] = "11111";
    uint8_t buffer2[50] = "22222";
    uint8_t dest[50] = "";

    VIDEORTP_ipcFrame_t frame;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
    tst_ipcInitFrameAndFactory(&frame, sizeof(dest), &chunkFactory);

    // The first chunk fills the buffer; the second chunk overflows the frame.
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(0);
    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer1, sizeof(buffer1), ReleaseBufferCallback));
    EXPECT_FALSE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer2, sizeof(buffer2), ReleaseBufferCallback));

    // Read data
    EXPECT_CALL(ipcMock, ReleaseBuffer(buffer1));
    EXPECT_EQ(sizeof(dest), VIDEORTP_ipcFrameGetData(&frame, dest, sizeof(dest)));

    // Cannot add more data after the whole frame has been processed.
    // The buffer must not be released.
    EXPECT_CALL(ipcMock, ReleaseBuffer).Times(0);
    EXPECT_FALSE(VIDEORTP_ipcFrameAddPayloadChunk(&frame, buffer2, sizeof(buffer2), ReleaseBufferCallback));
}
