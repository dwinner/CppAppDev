#include "RtpPacketizer.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

class RtpHeaderBuilderTest : public ::testing::Test
{
protected:
    VIDEORTP_rtcpSessionConfiguration_t configuration;
    VIDEORTP_rtpHeaderBuilder_t builder;
    uint8_t hdr[32];

    RtpHeaderBuilderTest()
    {
        InitBuilder();
    }

    void InitBuilder(VIDEORTP_rtpStreamingMode_t mode = VIDEORTP_rtpStreamingMode_RFC2250, uint16_t sequenceNumber = 1)
    {
        VIDEORTP_rtcpInitConfig(&configuration, mode);
        configuration.ssrc[0] = 1;
        configuration.ssrc[1] = 2;
        configuration.ssrc[2] = 3;
        configuration.ssrc[3] = 4;

        VIDEORTP_rtpHeaderBuilderInit(&builder, &configuration, sequenceNumber);
    }

    void BuildHeader()
    {
        memset(hdr, 0xCC, sizeof(hdr));
        VIDEORTP_bufferWriter_t writer;
        VIDEORTP_bufInit(&writer, hdr, sizeof(hdr));
        VIDEORTP_rtpBuildHeader(&builder, &writer);
        ASSERT_EQ(VIDEORTP_bufGetBytesWritten(&writer), 12);
    }
};

TEST_F(RtpHeaderBuilderTest, WritesFlagsAndPayloadType)
{
    TEST_DESCRIPTION("TEST for checks flags and payload type");
    for (int i = 0x7F; i > 0; i >>= 1)
    {
        configuration.payloadType = i;

        BuildHeader();
        EXPECT_EQ(hdr[0], 128) << "Invalid packet type";
        EXPECT_EQ(hdr[1] & 0x7F, i) << "Invalid payload type";
    }
}

TEST_F(RtpHeaderBuilderTest, IpAvtIsoNeverSetsMarkerBit)
{
    TEST_DESCRIPTION("TEST for check that the market bit is not set");
    InitBuilder(VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);

    for (int i = 0; i < 10; ++i)
    {
        BuildHeader();
        EXPECT_EQ(hdr[1] & 0x80, 0) << "Invalid marker bit";
        EXPECT_EQ(hdr[1] & 0x7F, 0x7F) << "Invalid payload type";
    }
}

TEST_F(RtpHeaderBuilderTest, IpAvtSynNeverSetsMarkerBit)
{
    TEST_DESCRIPTION("TEST for check that the market bit is not set");
    InitBuilder(VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS);

    for (int i = 0; i < 10; ++i)
    {
        BuildHeader();
        EXPECT_EQ(hdr[1] & 0x80, 0) << "Invalid marker bit";
        EXPECT_EQ(hdr[1] & 0x7F, 0x7A) << "Invalid payload type";
    }
}

TEST_F(RtpHeaderBuilderTest, Rfc2250SetsMarkerBitOnFirstPacket)
{
    TEST_DESCRIPTION("TEST for check that the bit marker is installed in the first packet");
    InitBuilder(VIDEORTP_rtpStreamingMode_RFC2250);

    BuildHeader();
    EXPECT_EQ(hdr[1] & 0x80, 0x80) << "Invalid marker bit";
    EXPECT_EQ(hdr[1] & 0x7F, 33) << "Invalid payload type";

    for (int i = 0; i < 10; ++i)
    {
        BuildHeader();
        EXPECT_EQ(hdr[1] & 0x80, 0) << "Invalid marker bit";
        EXPECT_EQ(hdr[1] & 0x7F, 33) << "Invalid payload type";
    }
}

TEST_F(RtpHeaderBuilderTest, SequenceCounterIncrements)
{
    TEST_DESCRIPTION("TEST for check the increment of the sequence counter");
    InitBuilder(VIDEORTP_rtpStreamingMode_RFC2250, 0);
    for (int i = 0; i < 5; ++i)
    {
        BuildHeader();
        EXPECT_EQ(hdr[2], 0);
        EXPECT_EQ(hdr[3], i);
    }
}

TEST_F(RtpHeaderBuilderTest, SequenceCounterIsBigEndian)
{
    TEST_DESCRIPTION("TEST for check the increment of the sequence counter is big endian");
    InitBuilder(VIDEORTP_rtpStreamingMode_RFC2250, 0xDEFF);

    BuildHeader();
    EXPECT_EQ(hdr[2], 0xDE);
    EXPECT_EQ(hdr[3], 0xFF);

    BuildHeader();
    EXPECT_EQ(hdr[2], 0xDF);
    EXPECT_EQ(hdr[3], 0x00);
}

TEST_F(RtpHeaderBuilderTest, SequenceCounterWrapsAround)
{
    TEST_DESCRIPTION("TEST for check the sequence counter is wrapping around");
    InitBuilder(VIDEORTP_rtpStreamingMode_RFC2250, 0xFFFF);

    BuildHeader();
    EXPECT_EQ(hdr[2], 0xFF);
    EXPECT_EQ(hdr[3], 0xFF);

    BuildHeader();
    EXPECT_EQ(hdr[2], 0x00);
    EXPECT_EQ(hdr[3], 0x00);
}

TEST_F(RtpHeaderBuilderTest, WritesTimestamp)
{
    TEST_DESCRIPTION("TEST for check is write timestamp");
    VIDEORTP_payloadChunkInfo_t info = { 0x12345678 * UINT64_C(300) }; // 90kHz -> 27MHz
    VIDEORTP_rtpAddPacketMetaData(&builder, &info);

    BuildHeader();

    EXPECT_EQ(hdr[4], 0x12);
    EXPECT_EQ(hdr[5], 0x34);
    EXPECT_EQ(hdr[6], 0x56);
    EXPECT_EQ(hdr[7], 0x78);
}

TEST_F(RtpHeaderBuilderTest, UsesLastValidTimestamp)
{
    TEST_DESCRIPTION("TEST for check is last valid timestamp");
    EXPECT_EQ(VIDEORTP_rtpGetPacketTimestamp(&builder), static_cast<uint32_t>(VIDEORTP_InvalidTimestamp / 300));

    VIDEORTP_payloadChunkInfo_t info = { 0x12345678 * UINT64_C(300) }; // 90kHz -> 27MHz
    VIDEORTP_rtpAddPacketMetaData(&builder, &info);
    EXPECT_EQ(VIDEORTP_rtpGetPacketTimestamp(&builder), 0x12345678);

    BuildHeader();

    EXPECT_EQ(hdr[4], 0x12);
    EXPECT_EQ(hdr[5], 0x34);
    EXPECT_EQ(hdr[6], 0x56);
    EXPECT_EQ(hdr[7], 0x78);

    info = { VIDEORTP_InvalidTimestamp };
    VIDEORTP_rtpAddPacketMetaData(&builder, &info);
    EXPECT_EQ(VIDEORTP_rtpGetPacketTimestamp(&builder), 0x12345678);

    info = { 0x23456789 * UINT64_C(300) };
    VIDEORTP_rtpAddPacketMetaData(&builder, &info);
    EXPECT_EQ(VIDEORTP_rtpGetPacketTimestamp(&builder), 0x12345678);

    BuildHeader();

    EXPECT_EQ(hdr[4], 0x12);
    EXPECT_EQ(hdr[5], 0x34);
    EXPECT_EQ(hdr[6], 0x56);
    EXPECT_EQ(hdr[7], 0x78);
}

TEST_F(RtpHeaderBuilderTest, WritesSynchronizationSource)
{
    TEST_DESCRIPTION("TEST for check the synchronization source record");
    configuration.ssrc[0] = 0xAA;
    configuration.ssrc[1] = 0xBB;
    configuration.ssrc[2] = 0xCC;
    configuration.ssrc[3] = 0xDD;

    BuildHeader();

    EXPECT_EQ(hdr[8], 0xAA);
    EXPECT_EQ(hdr[9], 0xBB);
    EXPECT_EQ(hdr[10], 0xCC);
    EXPECT_EQ(hdr[11], 0xDD);
}
