#include "TestUtils.h"
#include "crc32_mpeg2.h"
#include <gtest/gtest.h>

TEST(CRC32_MPEG, ASSERT)
{
    TEST_DESCRIPTION("TEST to check for error if payload is nullptr");
    EXPECT_EXIT(VIDEORTP_CRC32calculate(NULL, 0);, testing::ExitedWithCode(3), "");
}

// compare results with https://crccalc.com/?method=CRC-32/MPEG-2&datatype=hex&outtype=0
TEST(CRC32_MPEG, CALCULATE)
{
    TEST_DESCRIPTION("TEST to check the calculation of CRC32/MPEG");
    EXPECT_EQ(VIDEORTP_CRC32calculate("", 0), 0xFFFFFFFF);
    EXPECT_EQ(VIDEORTP_CRC32calculate("x", 1), 0x88B44FEB);

    uint8_t buffer_zero[] = { 0x00, 0x00, 0x00, 0x00 };
    uint32_t crc_zero = VIDEORTP_CRC32calculate(buffer_zero, sizeof(buffer_zero));
    EXPECT_EQ(crc_zero, 0xC704DD7B);

    uint8_t buffer_full[] = { 0xFF, 0xFF, 0xFF, 0xFF };
    uint32_t crc_full = VIDEORTP_CRC32calculate(buffer_full, sizeof(buffer_full));
    EXPECT_EQ(crc_full, 0x00000000);

    uint8_t buffer_value[] = "123456789";
    uint32_t table_crc_value = VIDEORTP_CRC32calculate(buffer_value, sizeof(buffer_value) - 1); // without end string char
    EXPECT_EQ(table_crc_value, 0x0376E6E7);
}
