#include "PaddingElementaryStreamGenerator.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include <gmock/gmock.h>
#include <gtest/gtest.h>

using ::testing::_;
using ::testing::Return;
using namespace tests;

TEST(PaddingElementaryStreamGeneratorModule, INIT)
{
    TEST_DESCRIPTION("TEST for check the initialization of the elementary stream generator");
    CheckedGenerator<VIDEORTP_paddingElementaryStreamGenerator_t> pesGen;
    VIDEORTP_padInit(&pesGen);
    EXPECT_EQ(pesGen.padding, 0);
    EXPECT_EQ(pesGen.chunkSize, 0);

    // Padding generator is created "empty"
    for (int maximumSize = 0; maximumSize < 50; maximumSize++)
    {
        VIDEORTP_payloadChunkInfo_t metaData {};
        auto ret = VIDEORTP_pipePrepareNextChunk(&pesGen, maximumSize, &metaData);
        EXPECT_EQ(ret, 0);
    }
}

TEST(PaddingElementaryStreamGeneratorModule, IF_TOO_LITTLE_REQUESTED_THEN_NOTHING_PREPARED)
{
    TEST_DESCRIPTION("TEST for check if too little is requested, then nothing is repeated");
    CheckedGenerator<VIDEORTP_paddingElementaryStreamGenerator_t> pesGen;
    VIDEORTP_padInit(&pesGen);
    pesGen.padding = 100;

    // Need space for PES header and at least one byte of padding
    for (int maximumSize = 0; maximumSize < 7; maximumSize++)
    {
        VIDEORTP_payloadChunkInfo_t metaData {};

        auto ret = VIDEORTP_pipePrepareNextChunk(&pesGen, maximumSize, &metaData);

        EXPECT_EQ(ret, 0);
    }
}

TEST(PaddingElementaryStreamGeneratorModule, IF_TOO_MUCH_REQUESTED_THEN_NOTHING_PREPARED)
{
    TEST_DESCRIPTION("TEST for check if too much is being requested, then nothing is repeated");
    CheckedGenerator<VIDEORTP_paddingElementaryStreamGenerator_t> pesGen;
    VIDEORTP_padInit(&pesGen);
    pesGen.padding = 33;

    // Do not generate "too much" padding
    const size_t maximumSize = 34;
    VIDEORTP_payloadChunkInfo_t metaData {};
    auto ret = VIDEORTP_pipePrepareNextChunk(&pesGen, maximumSize, &metaData);

    EXPECT_EQ(ret, 0);
}

TEST(PaddingElementaryStreamGeneratorModule, IF_VALID_REQUESTED_THEN_PREPARE_IT)
{
    TEST_DESCRIPTION("TEST for check if a valid request is requested, prepare it");
    CheckedGenerator<VIDEORTP_paddingElementaryStreamGenerator_t> pesGen;
    VIDEORTP_padInit(&pesGen);
    pesGen.padding = 42;

    for (size_t maximumSize = 7; maximumSize < 43; maximumSize++)
    {
        VIDEORTP_payloadChunkInfo_t metaData {};
        auto ret = VIDEORTP_pipePrepareNextChunk(&pesGen, maximumSize, &metaData);
        EXPECT_EQ(ret, maximumSize);

        // PES padding packets are self-contained
        EXPECT_TRUE(metaData.isPayloadUnitStart);
        EXPECT_TRUE(metaData.isPayloadUnitEnd);
        EXPECT_EQ(metaData.payloadUnitSize, maximumSize);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
    }
}

TEST(PaddingElementaryStreamGeneratorModule, TEST_SERIALIZED_DATA)
{
    TEST_DESCRIPTION("TEST for check serialized data");
    const size_t chunkSize = 0x8;
    const size_t reservedSize = 0x42;
    std::vector<uint8_t> memBuf;
    memBuf.resize(chunkSize);
    // PES padding packet with 2 bytes of padding
    std::vector<uint8_t> testBuf { 0x00, 0x00, 0x01, 0xBE, 0x00, 0x2, 0xFF, 0xFF };

    CheckedGenerator<VIDEORTP_paddingElementaryStreamGenerator_t> pesGen;
    VIDEORTP_padInit(&pesGen);
    pesGen.padding = reservedSize;

    VIDEORTP_payloadChunkInfo_t metaData {};
    (void) VIDEORTP_pipePrepareNextChunk(&pesGen, chunkSize, &metaData);

    VIDEORTP_bufferWriter_t payloadBuffer {};
    VIDEORTP_bufInit(&payloadBuffer, memBuf.data(), memBuf.size());
    VIDEORTP_pipeCopyChunk(&pesGen, &payloadBuffer);

    EXPECT_EQ(memBuf, testBuf);
    EXPECT_EQ(pesGen.padding, reservedSize - chunkSize);
}
