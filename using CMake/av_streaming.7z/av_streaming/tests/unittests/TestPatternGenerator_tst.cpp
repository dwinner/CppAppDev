#include "PayloadProvider.h"
#include "Stubs/CheckedStage.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include <gtest/gtest.h>
#include <vector>

TEST(TestPatternGenerator, DATAGENERATOR01)
{
    TEST_DESCRIPTION("TEST for check metadata when generated data transmit to next pipeline");
    VIDEORTP_payloadChunkInfo_t metaData;
    size_t maxDataSize = 500;
    size_t chunkSize = 100;

    std::vector<uint8_t> buffer(maxDataSize);
    VIDEORTP_bufferWriter_t writer;
    VIDEORTP_bufInit(&writer, buffer.data(), buffer.size());

    CheckedGenerator<VIDEORTP_testPatternGenerator> testPatternGenerator;
    VIDEORTP_testPatternGenInit(&testPatternGenerator, maxDataSize);

    for (int i = 0; i < 5; i++)
    {
        chunkSize = VIDEORTP_pipePrepareNextChunk(&testPatternGenerator, chunkSize, &metaData);
        VIDEORTP_pipeCopyChunk(&testPatternGenerator, &writer);
        EXPECT_EQ(chunkSize, 100);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, maxDataSize);
        EXPECT_EQ(metaData.isPayloadUnitStart, i == 0);
        EXPECT_EQ(metaData.isPayloadUnitEnd, i == 4);
    }
}

TEST(TestPatternGenerator, INCREMENT_PATTERN)
{
    TEST_DESCRIPTION("TEST for check pattern changes after each transmission to next pipeline");
    size_t maxDataSize = 10;

    std::vector<uint8_t> buffer(maxDataSize);
    VIDEORTP_bufferWriter_t writer;
    VIDEORTP_bufInit(&writer, buffer.data(), buffer.size());

    CheckedGenerator<VIDEORTP_testPatternGenerator> testPatternGenerator;
    VIDEORTP_testPatternGenInit(&testPatternGenerator, maxDataSize);

    for (int i = 0; i < 300; i++)
    {
        VIDEORTP_payloadChunkInfo_t metaData;
        auto chunkSize = VIDEORTP_pipePrepareNextChunk(&testPatternGenerator, maxDataSize, &metaData);
        EXPECT_EQ(chunkSize, maxDataSize);
        EXPECT_EQ(metaData.sampleTimestamp, VIDEORTP_InvalidTimestamp);
        EXPECT_EQ(metaData.payloadUnitSize, maxDataSize);
        EXPECT_EQ(metaData.isPayloadUnitStart, true);
        EXPECT_EQ(metaData.isPayloadUnitEnd, true);

        VIDEORTP_bufClear(&writer);
        VIDEORTP_pipeCopyChunk(&testPatternGenerator, &writer);

        std::vector<uint8_t> expected(maxDataSize, (uint8_t) (i & 0xFF));
        EXPECT_EQ(buffer, expected);
    }
}
