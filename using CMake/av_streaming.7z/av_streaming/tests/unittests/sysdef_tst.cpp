#include "TestUtils.h"
#include "sysdef.h"
#include <gtest/gtest.h>

TEST(UtilTest, MinMax)
{
    TEST_DESCRIPTION("Test calculation of minimum and maximum values");

    EXPECT_EQ(VIDEORTP_sysGetMin(1, 2), 1);
    EXPECT_EQ(VIDEORTP_sysGetMax(1, 2), 2);

    EXPECT_EQ(VIDEORTP_sysGetMin(2, 1), 1);
    EXPECT_EQ(VIDEORTP_sysGetMax(2, 1), 2);

    EXPECT_EQ(VIDEORTP_sysGetMin(2, 2), 2);
    EXPECT_EQ(VIDEORTP_sysGetMax(2, 2), 2);
}
