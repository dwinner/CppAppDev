#include "ProgramAssociationTableBuilder.h"
#include "TestUtils.h"
#include "crc32_mpeg2.h"
#include <gtest/gtest.h>
#include <string.h>

const size_t bufferSize = VIDEORTP_PAT_MAX_SIZE;
const uint8_t headerSize = 8;
const uint16_t id = 0x0001;

void createAndCheckEmptyHeader(uint8_t buffer[], VIDEORTP_bufferWriter_t* bw,
                               VIDEORTP_programAssociationTableBuilder_t* tableBuilder)
{
    VIDEORTP_bufInit(bw, buffer, bufferSize);
    VIDEORTP_patInit(tableBuilder, id, bw);
    EXPECT_EQ(tableBuilder->section, bw);
    EXPECT_EQ(tableBuilder->programCount, 0);

    uint8_t expected[] = {
        0x00, // table_id = program_assotiation_section (is 0x00 in H.222)
        0x00, // // 1 bit section_syntax_indicator, 1 bit is 0, 2 bits reserved, 4 bits section_length (now is 0)
        0x00, // 8 bits section_length
        (uint8_t) (id >> 8), // 1st half transport_stream_id
        (uint8_t) (0xFF & id), // 2nd half transport_stream_id
        0xC1, // 2 bits reserved, 5 bits version number (is 0), 1 bit current_next_indicator (is 1)
        0x00, // section_number
        0x00, // last_section_number
    };

    int compare = memcmp(expected, buffer, headerSize);
    EXPECT_EQ(compare, 0);
}

TEST(ProgramAssociationTableBuilder, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor PAT builder");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);
}

TEST(ProgramAssociationTableBuilder, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all PAT builder functions");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;

    EXPECT_DEATH(VIDEORTP_patInit(&tableBuilder, 0, NULL), "Assertion failed");
    EXPECT_DEATH(VIDEORTP_patInit(NULL, 0, &bw), "Assertion failed");
    EXPECT_DEATH(VIDEORTP_patAddProgram(NULL, 0, 0), "Assertion failed");
    EXPECT_DEATH(VIDEORTP_patFinalize(NULL), "Assertion failed");
}

TEST(ProgramAssociationTableBuilder, ADD_PROGRAM)
{
    TEST_DESCRIPTION("TEST for check adding program to PAT builder");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);

    uint16_t programNumber = 0x0001;
    uint16_t program_pid = 0x0010;
    VIDEORTP_patAddProgram(&tableBuilder, programNumber, program_pid);

    uint8_t expect[] = {
        (uint8_t) (programNumber >> 8), // 1st half programNumber (0x00)
        (uint8_t) (0xFF & programNumber), // 2nd half programNumber (0x10)
        (uint8_t) (0xE0 | (program_pid >> 8)), // 1st half program_pid (0x00)
        (uint8_t) (0xFF & program_pid), // 2nd half program_pid (0x10)
    };
    int compare = memcmp(expect, buffer + headerSize, sizeof(expect));
    EXPECT_EQ(compare, 0);
}

TEST(ProgramAssociationTableBuilder, FINALIZE)
{
    TEST_DESCRIPTION("TEST for check builded PAT with one program");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);

    uint16_t programNumber = 0x0001;
    uint16_t program_pid = 0x0010;
    VIDEORTP_patAddProgram(&tableBuilder, programNumber, program_pid);

    VIDEORTP_patFinalize(&tableBuilder);

    uint16_t section_length = 5 + tableBuilder.programCount * 2 * sizeof(uint16_t) + sizeof(uint32_t);
    section_length = 0xB000 | (0x0FFF & section_length);
    uint8_t expect[] = {
        0x00, // table_id = program_assotiation_section (is 0x00)
        (uint8_t) (0xBF
                   & (section_length
                      >> 8)), // // 1 bit section_syntax_indicator, 1 bit is 0, 2 bits reserved, 1st half section_length
        (uint8_t) (0xFF & section_length), // 8 bits section_length
        (uint8_t) (id >> 8), // 1st half transport_stream_id
        (uint8_t) (0xFF & id), // 2nd half transport_stream_id
        0xC1, // 2 bits reserved, 5 bits version number (is 0), 1 bit current_next_indicator (is 1)
        0x00, // section_number
        0x00, // last_section_number
        (uint8_t) (programNumber >> 8), // 1st half programNumber
        (uint8_t) (0xFF & programNumber), // 2nd half programNumber
        (uint8_t) (0xE0 | (program_pid >> 8)), // 1st half program_pid
        (uint8_t) (0xFF & program_pid), // 2nd half program_pid
    };
    int compare = memcmp(expect, buffer, sizeof(expect));
    EXPECT_EQ(compare, 0);
    uint32_t crc32 = 0;
    memcpy(&crc32, buffer + sizeof(expect), sizeof(uint32_t));
    VIDEORTP_sysReverseData((uint8_t*) &crc32, sizeof(crc32)); // because memcpy reverse data
    uint32_t expect_crc32 = VIDEORTP_CRC32calculate(expect, sizeof(expect));

    EXPECT_NE(crc32, 0);
    EXPECT_EQ(crc32, expect_crc32);
}

TEST(ProgramAssociationTableBuilder, FINALIZE_FEW_PROGRAMS)
{
    TEST_DESCRIPTION("TEST for check builded PAT with several programs");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);

    uint16_t program_number1 = 0x0001;
    uint16_t program_pid1 = 0x0010;
    VIDEORTP_patAddProgram(&tableBuilder, program_number1, program_pid1);

    uint16_t program_number2 = 0x0001;
    uint16_t program_pid2 = 0x0011;
    VIDEORTP_patAddProgram(&tableBuilder, program_number2, program_pid2);

    VIDEORTP_patFinalize(&tableBuilder);

    uint16_t section_length = 5 + tableBuilder.programCount * 2 * sizeof(uint16_t) + sizeof(uint32_t);
    section_length = 0xB000 | (0x0FFF & section_length);
    uint8_t expect[] = {
        0x00, // table_id = program_assotiation_section (is 0x00)
        (uint8_t) (section_length >> 8), // // 1 bit section_syntax_indicator, 1 bit is 0, 2 bits reserved, 1st half section_length
        (uint8_t) (0xFF & section_length), // 8 bits section_length
        (uint8_t) (id >> 8), // 1st half transport_stream_id
        (uint8_t) (0xFF & id), // 2nd half transport_stream_id
        0xC1, // 2 bits reserved, 5 bits version number (is 0), 1 bit current_next_indicator (is 1)
        0x00, // section_number
        0x00, // last_section_number
        (uint8_t) (program_number1 >> 8), // 1st half programNumber
        (uint8_t) (0xFF & program_number1), // 2nd half programNumber
        (uint8_t) (0xE0 | (program_pid1 >> 8)), // 1st half program_pid
        (uint8_t) (0xFF & program_pid1), // 2nd half program_pid
        (uint8_t) (program_number2 >> 8), // 1st half programNumber
        (uint8_t) (0xFF & program_number2), // 2nd half programNumber
        (uint8_t) (0xE0 | (program_pid2 >> 8)), // 1st half program_pid
        (uint8_t) (0xFF & program_pid2), // 2nd half program_pid
    };
    int compare = memcmp(expect, buffer, sizeof(expect));
    EXPECT_EQ(compare, 0);
    uint32_t crc32 = 0;
    memcpy(&crc32, buffer + sizeof(expect), sizeof(uint32_t));
    VIDEORTP_sysReverseData((uint8_t*) &crc32, sizeof(crc32)); // because memcpy reverse data
    uint32_t expect_crc32 = VIDEORTP_CRC32calculate(expect, sizeof(expect));

    EXPECT_NE(crc32, 0);
    EXPECT_EQ(crc32, expect_crc32);
}

TEST(ProgramAssociationTableBuilder, FINALIZE_MAX_PROGRAMS)
{
    TEST_DESCRIPTION("Check maximum program count");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);

    for (int i = 0; i < (bufferSize - 12) / 4; ++i)
    {
        VIDEORTP_patAddProgram(&tableBuilder, i + 0x1111, i + 0x0111);
    }

    VIDEORTP_patFinalize(&tableBuilder);

    uint16_t length = ((buffer[1] & 0x0F) << 8) | buffer[2];
    EXPECT_EQ(length, VIDEORTP_PMT_SECTION_MAX_LENGTH);
}

TEST(ProgramAssociationTableBuilder, FINALIZE_OVERFLOW_PROGRAMS)
{
    TEST_DESCRIPTION("Check overflowing PAT buffer");
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_programAssociationTableBuilder_t tableBuilder;
    createAndCheckEmptyHeader(buffer, &bw, &tableBuilder);

    for (int i = 0; i < (bufferSize - 12) / 4 + 1; ++i)
    {
        VIDEORTP_patAddProgram(&tableBuilder, i + 0x1111, i + 0x0111);
    }

    VIDEORTP_patFinalize(&tableBuilder);

    uint16_t length = ((buffer[1] & 0x0F) << 8) | buffer[2];
    EXPECT_EQ(length, 0);
}

TEST(ProgramAssociationTableBuilder, PROTOTYPE)
{
    TEST_DESCRIPTION("TEST for check PAT originally generated by prototype and decoded by Wireshark");
    // PAT originally created by prototype/FFmpeg and decoded by Wireshark
    const unsigned char expected[] = {
        // Table ID: Program Association Table (PAT) (0x00)
        0x00,
        // 1... .... .... .... = Syntax indicator: 1
        // .011 .... .... .... = Reserved: 0x3
        // .... 0000 0000 1101 = Length: 13
        0xb0,
        0x0d,
        // Transport Stream ID: 0x0001
        0x00,
        0x01,
        // 11.. .... = Reserved: 0x3
        // ..00 000. = Version Number: 0x00
        // .... ...1 = Current/Next Indicator: Currently applicable
        0xc1,
        // Section Number: 0
        0x00,
        // Last Section Number: 0
        0x00,
        // Program 0x0001 -> PID 0x1000
        //     Program Number: 0x0001
        0x00,
        0x01,
        //     111. .... .... .... = Reserved: 0x7
        //     ...1 0000 0000 0000 = Program Map PID: 0x1000
        0xf0,
        0x00,
        // CRC 32: 0x2ab104b2 [correct]
        0x2a,
        0xb1,
        0x04,
        0xb2,
    };

    uint8_t buffer[20] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_programAssociationTableBuilder_t builder;
    VIDEORTP_patInit(&builder, 0x0001, &bw);
    VIDEORTP_patAddProgram(&builder, 0x0001, 0x1000);
    VIDEORTP_patFinalize(&builder);

    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), sizeof(expected));
    EXPECT_EQ(memcmp(expected, VIDEORTP_bufGetBasePointer(&bw), sizeof(expected)), 0);
}
