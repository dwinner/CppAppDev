#include "H264FileReader.h"
#include "TestUtils.h"
#include <gtest/gtest.h>
#include <memory>

TEST(Analyzing_H264, H264_READER)
{
    TEST_DESCRIPTION("TEST for check correct reading .h264 file");
    const auto h264TestFile = "test_noloop.h264";
    using namespace std;

    unique_ptr<H264FileReader> h264FileReader = make_unique<H264FileReader>(h264TestFile);
    unique_ptr<valarray<unique_ptr<Nalu>>> nalUnits = h264FileReader->GetNalUnits();
    size_t nalUnitsCount = nalUnits->size();

    EXPECT_GT(nalUnitsCount, 0);

    // check the expected NALU count
    const size_t expectedNaluCount = 145;
    EXPECT_EQ(nalUnitsCount, expectedNaluCount);

    for (size_t nalIdx = 0; nalIdx < nalUnitsCount; nalIdx++)
    {
        unique_ptr<Nalu> naluItem = move((*nalUnits)[nalIdx]);
        std::valarray<uint8_t> content = naluItem->GetContent();

        // Check the marker has 00 00 00 01 in the 1st 4 elements
        uint8_t byte1 = content[0];
        uint8_t byte2 = content[1];
        uint8_t byte3 = content[2];
        uint8_t byte4 = content[3];

        const auto zeroByte = static_cast<uint8_t>(0);
        const auto oneByte = static_cast<uint8_t>(1);

        EXPECT_EQ(byte1, zeroByte);
        EXPECT_EQ(byte2, zeroByte);
        EXPECT_EQ(byte3, zeroByte);
        EXPECT_EQ(byte4, oneByte);

        // Check NALU type
        EXPECT_EQ(content[4] & 0x9F, 9) << "Frame " << nalIdx << " must start with an AUD NALU";
    }
}
