#include <stdint.h>
#include <stdio.h>

#include <algorithm>
#include <vector>

#include <gtest/gtest.h>

#include "BufferWriter.h"
#include "ElementaryStreamPacketizer.h"
#include "PayloadDataCounter.h"
#include "Stubs/CheckedStage.h"
#include "Stubs/MinimumChunkSize.h"
#include "TestPatternGenerator.h"
#include "TimestampGenerator.h"

#include "TestUtils.h"

// PTS and DTS overflow at this timestamp
const uint64_t PTS_DTS_OVERFLOW = UINT64_C(300) << 33;

TEST(ElementaryStreamPacketizer, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor ElementaryStreamPacketizer");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 64);

    VIDEORTP_pesInitPacketizer(&pes, &gen, VIDEORTP_PES_PADDING_STREAM);

    EXPECT_EQ(pes.streamID, VIDEORTP_PES_PADDING_STREAM);
    EXPECT_EQ(pes.timePTS, VIDEORTP_InvalidTimestamp);
    EXPECT_EQ(pes.timeDTS, VIDEORTP_InvalidTimestamp);
    EXPECT_EQ(pes.pesSize, 0);
}

static uint8_t* ptsDtsToArray(uint64_t timeTS, uint8_t timestampType)
{
    uint8_t* dest = (uint8_t*) malloc(5);
    if (dest != NULL)
    {
        dest[0] = ((timeTS >> 29) & 0x0e) | 0x01 | timestampType;
        dest[1] = ((timeTS >> 22) & 0xff);
        dest[2] = ((timeTS >> 14) & 0xfe) | 0x01;
        dest[3] = ((timeTS >> 7) & 0xff);
        dest[4] = ((timeTS << 1) & 0xfe) | 0x01;
    }

    return dest;
}

// Create PES packet without DTS and check header
static void pesProcessingWithoutDTS(CheckedStage<VIDEORTP_pesStreamPacketizer_t>* pes, uint8_t streamId, uint16_t payloadLength,
                                    VIDEORTP_bufferWriter_t* destBW)
{
    VIDEORTP_pipeCopyChunk(pes, destBW);

    uint8_t* timePTS = ptsDtsToArray(pes->timePTS, 0x20);
    EXPECT_EQ(ParsePts(timePTS), PTS_ONLY | pes->timePTS);

    // remaining packet size after PES_packet_length field
    uint16_t pesLength = payloadLength > 0 ? VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS - 6 + payloadLength : 0;

    uint8_t expect[] = {
        0x00,
        0x00,
        0x01, // packet_start_code_prefix
        streamId, // stream_id
        (uint8_t) (pesLength >> 8),
        (uint8_t) pesLength, // PES_packet_length
        0x80, // '10', PES_scrambling_control, PES_priority, data_alignment_inicator, original_or_copy
        0x80, // PTS_DTS_flags..PES_extension_flag */
        5, //  PES_header_data_length
        timePTS[0],
        timePTS[1],
        timePTS[2],
        timePTS[3],
        timePTS[4], // PTS
    }; // PES Header reference

    EXPECT_GE(VIDEORTP_bufGetBytesWritten(destBW), sizeof(expect));
    EXPECT_EQ(memcmp(expect, VIDEORTP_bufGetBasePointer(destBW), sizeof(expect)), 0);
    free(timePTS);
}

// Create PES packet with DTS and check header
static void pesProcessingWithDTS(CheckedStage<VIDEORTP_pesStreamPacketizer_t>* pes, uint8_t streamId, uint16_t payloadLength,
                                 VIDEORTP_bufferWriter_t* destBW)
{
    VIDEORTP_pipeCopyChunk(pes, destBW);

    uint8_t* timePTS = ptsDtsToArray(pes->timePTS, 0x30);
    uint8_t* timeDTS = ptsDtsToArray(pes->timeDTS, 0x10);
    EXPECT_EQ(ParsePts(timePTS), PTS_AND_DTS | pes->timePTS);
    EXPECT_EQ(ParsePts(timeDTS), DTS_ONLY | pes->timeDTS);

    uint8_t destBuf[256];
    memcpy(destBuf, VIDEORTP_bufGetBasePointer(destBW), VIDEORTP_bufGetBytesWritten(destBW));

    // remaining packet size after PES_packet_length field
    uint16_t pesLength = payloadLength > 0 ? VIDEORTP_PES_HEADER_SIZE_WITH_DTS - 6 + payloadLength : 0;

    uint8_t expect[] = {
        0x00,
        0x00,
        0x01, // packet_start_code_prefix
        streamId, // stream_id
        (uint8_t) (pesLength >> 8),
        (uint8_t) pesLength, // PES_packet_length
        0x80, // '10', PES_scrambling_control, PES_priority, data_alignment_inicator, original_or_copy
        0xC0, // PTS_DTS_flags..PES_extension_flag */
        10, //  PES_header_data_length
        timePTS[0],
        timePTS[1],
        timePTS[2],
        timePTS[3],
        timePTS[4], // PTS
        timeDTS[0],
        timeDTS[1],
        timeDTS[2],
        timeDTS[3],
        timeDTS[4] // DTS
    }; // PES Header reference

    EXPECT_GE(VIDEORTP_bufGetBytesWritten(destBW), sizeof(expect));
    EXPECT_EQ(memcmp(expect, VIDEORTP_bufGetBasePointer(destBW), sizeof(expect)), 0);

    free(timePTS);
    free(timeDTS);
}

TEST(ElementaryStreamPacketizer, EQUAL_PTS_AND_DTS)
{
    TEST_DESCRIPTION("TEST for check case when PTS equal DTS");
    std::vector<uint8_t> buffer(50);
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer.data(), buffer.size());

    // test each bit
    for (int i = 0; i < 33; ++i)
    {
        const uint64_t ts = UINT64_C(1) << i;

        CheckedGenerator<VIDEORTP_testPatternGenerator> pattern;
        CheckedGenerator<VIDEORTP_timestampGenerator_t> timestamp;
        CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;

        VIDEORTP_testPatternGenInit(&pattern, 100);
        VIDEORTP_tgenInit(&timestamp, ts * 300, 30, &pattern);
        VIDEORTP_pesInitPacketizer(&pes, &timestamp, 0xe0);

        VIDEORTP_payloadChunkInfo_t info = {};
        size_t nextPacketSize = VIDEORTP_pipePrepareNextChunk(&pes, buffer.size(), &info);
        EXPECT_EQ(nextPacketSize, buffer.size());
        EXPECT_TRUE(info.isPayloadUnitStart);
        EXPECT_EQ(info.sampleTimestamp.mpegPresentationTimestamp, timestamp.startTimestamp);
        EXPECT_EQ(info.sampleTimestamp.mpegDecodingTimestamp, timestamp.startTimestamp);

        VIDEORTP_bufClear(&bw);
        VIDEORTP_pipeCopyChunk(&pes, &bw);

        EXPECT_EQ(buffer[7], 0x80); // PTS only
        EXPECT_EQ(buffer[8], 5); // length
        EXPECT_EQ(ParsePts(&buffer[9]), (PTS_ONLY | ts));
    }
}

TEST(ElementaryStreamPacketizer, DIFFERENT_PTS_AND_DTS)
{
    TEST_DESCRIPTION("TEST for check case when PTS not equal DTS");
    std::vector<uint8_t> buffer(50);
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer.data(), buffer.size());

    // test each bit
    for (int i = 0; i < 33; ++i)
    {
        const uint64_t ts = UINT64_C(1) << i;

        CheckedGenerator<VIDEORTP_testPatternGenerator> pattern;
        CheckedGenerator<VIDEORTP_timestampGenerator_t> timestamp;
        CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;

        VIDEORTP_testPatternGenInit(&pattern, 100);
        VIDEORTP_tgenInit(&timestamp, UINT64_C(9999999) * 300, 30, &pattern);
        VIDEORTP_tgenSetDecodingTimestamp(&timestamp, ts * 300);
        VIDEORTP_pesInitPacketizer(&pes, &timestamp, 0xe0);

        VIDEORTP_payloadChunkInfo_t info = {};
        size_t nextPacketSize = VIDEORTP_pipePrepareNextChunk(&pes, buffer.size(), &info);
        EXPECT_EQ(nextPacketSize, buffer.size());
        EXPECT_TRUE(info.isPayloadUnitStart);
        EXPECT_EQ(info.sampleTimestamp.mpegPresentationTimestamp, timestamp.startTimestamp);
        EXPECT_EQ(info.sampleTimestamp.mpegDecodingTimestamp, ts * 300);

        VIDEORTP_bufClear(&bw);
        VIDEORTP_pipeCopyChunk(&pes, &bw);

        EXPECT_EQ(buffer[7], 0xC0); // PTS and DTS
        EXPECT_EQ(buffer[8], 10); // length
        EXPECT_EQ(ParsePts(&buffer[9]), PTS_AND_DTS | 9999999);
        EXPECT_EQ(ParsePts(&buffer[14]), DTS_ONLY | ts);
    }
}

TEST(ElementaryStreamPacketizer, ONE_BIG_PACKET)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when destination buffer size equal payload size");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_PADDING_STREAM;
    const size_t dataSize = 512;

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 0, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    const size_t destSize = 188;
    uint8_t destBuffer[destSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    VIDEORTP_payloadChunkInfo_t metadata;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, destSize, &metadata);
    EXPECT_EQ(nextChunkSize, destSize);

    uint8_t expectData[dataSize];
    memset(expectData, gen.currentPattern, dataSize);
    pesProcessingWithoutDTS(&pes, streamId, dataSize, &destBW);
    EXPECT_EQ(
        memcmp(expectData, destBuffer + VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS, destSize - VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS), 0);
}

TEST(ElementaryStreamPacketizer, SEVERAL_LITTLE_PACKET)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when destination buffer size great then payload size");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_PADDING_STREAM;
    const size_t dataSize = 64;

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 0, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    const size_t destSize = 188;
    uint8_t destBuffer[destSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    for (int i = 0; i < 5; i++)
    {
        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, dataSize + VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS);

        uint8_t expectData[dataSize];
        memset(expectData, gen.currentPattern, dataSize);

        pesProcessingWithoutDTS(&pes, streamId, dataSize, &destBW);
        EXPECT_EQ(memcmp(expectData, destBuffer + VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS, sizeof(expectData)), 0)
            << "iteration: " << i;

        VIDEORTP_bufClear(&destBW);
    }
}

TEST(ElementaryStreamPacketizer, PACKET_WITH_DTS)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when packet include DTS");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_PADDING_STREAM;
    const size_t dataSize = 64;

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 1000, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    const size_t destSize = 188;
    uint8_t destBuffer[destSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);
    for (int i = 0; i < 16; i++)
    {
        VIDEORTP_tgenSetDecodingTimestamp(&tgen, 300);

        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, destSize, &metadata);
        EXPECT_NE(metadata.sampleTimestamp.mpegPresentationTimestamp, metadata.sampleTimestamp.mpegDecodingTimestamp);
        size_t expectHeaderSize = VIDEORTP_PES_HEADER_SIZE_WITH_DTS;
        EXPECT_EQ(nextChunkSize, dataSize + expectHeaderSize);

        pesProcessingWithDTS(&pes, streamId, dataSize, &destBW);
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(ElementaryStreamPacketizer, PTS_OVERFLOW)
{
    TEST_DESCRIPTION("Check behavior of PTS on overflow");

    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    CheckedGenerator<VIDEORTP_timestampGenerator_t> tgen;
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;

    VIDEORTP_testPatternGenInit(&gen, 64);
    VIDEORTP_tgenInit(&tgen, PTS_DTS_OVERFLOW - 300, VIDEORTP_CLOCK_RATE / 300, &gen);
    VIDEORTP_pesInitPacketizer(&pes, &tgen, VIDEORTP_PES_PADDING_STREAM);

    uint8_t destBuffer[188] = "";
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, sizeof(destBuffer));
    VIDEORTP_payloadChunkInfo_t metadata;

    // First frame: Just before PTS overflow
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegPresentationTimestamp, PTS_DTS_OVERFLOW - 300);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9) & ~PTS_ONLY, PTS_DTS_OVERFLOW / 300 - 1);

    // Second frame: PTS overflowed to 0
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegPresentationTimestamp, PTS_DTS_OVERFLOW);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9) & ~PTS_ONLY, 0);

    // Third frame: Continue normally after PTS overflow
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegPresentationTimestamp, PTS_DTS_OVERFLOW + 300);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9) & ~PTS_ONLY, 1);
}

TEST(ElementaryStreamPacketizer, DTS_OVERFLOW)
{
    TEST_DESCRIPTION("Check behavior of DTS on overflow");

    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    CheckedGenerator<VIDEORTP_timestampGenerator_t> tgen;
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;

    VIDEORTP_testPatternGenInit(&gen, 64);
    VIDEORTP_tgenInit(&tgen, 123456, 60, &gen);
    VIDEORTP_pesInitPacketizer(&pes, &tgen, VIDEORTP_PES_PADDING_STREAM);

    uint8_t destBuffer[188] = "";
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, sizeof(destBuffer));
    VIDEORTP_payloadChunkInfo_t metadata;

    // First frame: Just before DTS overflow
    VIDEORTP_tgenSetDecodingTimestamp(&tgen, PTS_DTS_OVERFLOW - 300);
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegDecodingTimestamp, PTS_DTS_OVERFLOW - 300);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9 + 5) & ~DTS_ONLY, PTS_DTS_OVERFLOW / 300 - 1);

    // Second frame: DTS overflowed to 0
    VIDEORTP_tgenSetDecodingTimestamp(&tgen, PTS_DTS_OVERFLOW);
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegDecodingTimestamp, PTS_DTS_OVERFLOW);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9 + 5) & ~DTS_ONLY, 0);

    // Third frame: Continue normally after DTS overflow
    VIDEORTP_tgenSetDecodingTimestamp(&tgen, PTS_DTS_OVERFLOW + 300);
    ASSERT_GT(VIDEORTP_pipePrepareNextChunk(&pes, sizeof(destBuffer), &metadata), 0);
    ASSERT_EQ(metadata.sampleTimestamp.mpegDecodingTimestamp, PTS_DTS_OVERFLOW + 300);
    VIDEORTP_bufClear(&destBW);
    VIDEORTP_pipeCopyChunk(&pes, &destBW);
    ASSERT_GT(VIDEORTP_bufGetBytesWritten(&destBW), 9 + 5 + 5);
    EXPECT_EQ(ParsePts(destBuffer + 9 + 5) & ~DTS_ONLY, 1);
}

TEST(ElementaryStreamPacketizer, PES_PACKET_LENGTH_ZERO)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when packet length is zero");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_VIDEO_STREAM_0;
    const size_t dataSize = 0xFFFFF; // exceeds PES_packet_length field

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 0x23456789, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    const size_t destSize = 188;
    uint8_t destBuffer[destSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    for (int i = 0; i < 5; i++)
    {
        VIDEORTP_tgenSetDecodingTimestamp(&tgen, 0x12345678);

        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, destSize);
        if (i == 0)
        {
            // If packet type VIDEORTP_PES_VIDEO_STREAM_0
            // then pes packet lenght must be zero
            pesProcessingWithDTS(&pes, streamId, 0, &destBW);
        }
        else
        {
            uint8_t expectBuffer[destSize];
            memset(expectBuffer, gen.currentPattern, destSize);
            VIDEORTP_pipeCopyChunk(&pes, &destBW);
            int cmp = memcmp(expectBuffer, destBuffer, destSize);
            EXPECT_EQ(cmp, 0);
        }
        VIDEORTP_bufClear(&destBW);
    }
}

TEST(ElementaryStreamPacketizer, BUFFER_SIZE_LESS_THEN_HEADER)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when destination buffer size less then necessary");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_PADDING_STREAM;
    const size_t dataSize = 64;

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 0, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    for (int i = 0; i < VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS; i++)
    {
        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, i, &metadata);
        EXPECT_EQ(nextChunkSize, 0) << "iteration " << i;
    }
}

TEST(ElementaryStreamPacketizer, LITTLE_BUFFER)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline when destination buffer size less then payload size");
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    CheckedStage<VIDEORTP_payloadDataCounter_t> cnt;
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;

    uint8_t streamId = VIDEORTP_PES_PADDING_STREAM;
    const size_t dataSize = 128;

    VIDEORTP_testPatternGenInit(&gen, dataSize);
    VIDEORTP_tgenInit(&tgen, 0, 60, &gen);
    VIDEORTP_cntInit(&cnt, &tgen);
    VIDEORTP_pesInitPacketizer(&pes, &cnt, streamId);

    const size_t destSize = 64;
    uint8_t destBuffer[destSize];
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, destBuffer, destSize);

    size_t DataCount = 0;
    for (int i = 0; i < 16; i++)
    {
        // How much data of the current frame is left?
        const size_t total = VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS + dataSize;
        const size_t remaining = total - DataCount;
        EXPECT_GT(remaining, 0);

        // Get next packet size
        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&pes, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, std::min(remaining, destSize));

        // Check that flags are set correctly
        EXPECT_EQ(DataCount == 0, metadata.isPayloadUnitStart);
        DataCount += nextChunkSize;
        EXPECT_LE(DataCount, total);
        EXPECT_EQ(DataCount == total, metadata.isPayloadUnitEnd);

        // Check payload contents
        uint8_t expectData[destSize];
        memset(expectData, gen.currentPattern, sizeof(expectData));
        if (metadata.isPayloadUnitStart)
        {
            // Add and check PES header if first packet
            pesProcessingWithoutDTS(&pes, streamId, dataSize, &destBW);
            EXPECT_EQ(memcmp(expectData, destBuffer + VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS,
                             nextChunkSize - VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS),
                      0)
                << "iteration: " << i;
        }
        else
        {
            // No header, only data if other packet
            VIDEORTP_pipeCopyChunk(&pes, &destBW);
            EXPECT_EQ(memcmp(expectData, destBuffer, nextChunkSize), 0) << "iteration: " << i;
        }

        if (metadata.isPayloadUnitEnd)
        {
            // This frame is complete. Start the next frame.
            DataCount = 0;
        }

        VIDEORTP_bufClear(&destBW);
    }
}

TEST(ElementaryStreamPacketizer, PAYLOAD_HEADER)
{
    TEST_DESCRIPTION("TEST for check transmission payload to next pipeline with different destination buffer size");
    const size_t MINIMUM_SIZE = 10;

    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 100);

    CheckedGenerator<VIDEORTP_timestampGenerator_t> tgen;
    VIDEORTP_tgenInit(&tgen, 0, 30, &gen);

    // simulate minimum space for additional header
    MinimumChunkSize size(&tgen, MINIMUM_SIZE);

    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    VIDEORTP_pesInitPacketizer(&pes, &size, 123);

    VIDEORTP_payloadChunkInfo_t info;
    size_t i = 0;

    // Not enough space for PES header and minimum payload.
    // Do not write PES header without content.
    // (The predecessor might not support that.)
    for (; i < VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS + MINIMUM_SIZE; ++i)
    {
        EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(&pes, i, &info), 0) << "size = " << i;
    }

    // Enough space for PES header and payload
    for (; i < VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS + MINIMUM_SIZE * 2; ++i)
    {
        EXPECT_EQ(VIDEORTP_pipePrepareNextChunk(&pes, i, &info), i) << "size = " << i;
    }
}

TEST(ElementaryStreamPacketizer, PROTOTYPE)
{
    TEST_DESCRIPTION("TEST for check PES originally generated by prototype and decoded by Wireshark");
    // PES packet originally created by prototype and decoded by Wireshark
    std::vector<uint8_t> expected {
        // Packetized Elementary Stream
        //     prefix: 000001
        0x00, 0x00, 0x01,
        //     stream: video-stream (0xe0)
        0xe0,
        // PES extension
        //     length: 8014
        0x1f, 0x4e,
        //     1... .... must-be-one: True
        //     .0.. .... must-be-zero: False
        //     ..00 .... = scrambling-control: not-scrambled (0)
        //     .... 0... priority: False
        //     .... .0.. data-alignment: False
        //     .... ..0. copyright: False
        //     .... ...0 original: False
        0x80,
        //     1... .... pts-flag: True
        //     .0.. .... dts-flag: False
        //     ..0. .... escr-flag: False
        //     ...0 .... es-rate-flag: False
        //     .... 0... dsm-trick-mode-flag: False
        //     .... .0.. additional-copy-info-flag: False
        //     .... ..0. crc-flag: False
        //     .... ...0 extension-flag: False
        0x80,
        //     header-data-length: 5
        0x05,
        // PES header data: 21001bbba1
        //     presentation time stamp (PTS): 5.000000000 seconds
        0x21, 0x00, 0x1b, 0xbb, 0xa1,
        // PES data: 0000000109f0000000010605ffff6ddc... (8006 bytes total)
    };
    expected.resize(8020);

    EXPECT_EQ(5 * 90000 | PTS_ONLY, ParsePts(&expected[9]));

    // Dummy H264 frame
    CheckedGenerator<VIDEORTP_testPatternGenerator> pattern;
    VIDEORTP_testPatternGenInit(&pattern, 8006);

    // Set timestamp to 5 sec (90 kHz clock)
    CheckedGenerator<VIDEORTP_timestampGenerator_t> timestamp;
    VIDEORTP_tgenInit(&timestamp, 5 * 90000 * 300, 30, &pattern);

    // Video Stream 0
    CheckedStage<VIDEORTP_pesStreamPacketizer_t> pes;
    VIDEORTP_pesInitPacketizer(&pes, &timestamp, 0xe0);

    // Write full frame into buffer
    std::vector<uint8_t> buffer(expected.size(), 0xDD);
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer.data(), buffer.size());

    VIDEORTP_payloadChunkInfo_t info = {};
    while (VIDEORTP_bufGetAvailableSpace(&bw) > 0)
    {
        // Read 184 bytes at a time (TS packet size - TS header size)
        size_t nextPacketSize = VIDEORTP_pipePrepareNextChunk(&pes, 184, &info);
        ASSERT_GT(nextPacketSize, 0);
        EXPECT_LE(nextPacketSize, 184);
        EXPECT_LE(nextPacketSize, VIDEORTP_bufGetAvailableSpace(&bw));

        EXPECT_EQ(info.payloadUnitSize, 8006);
        EXPECT_EQ(info.isPayloadUnitStart, VIDEORTP_bufGetBytesWritten(&bw) == 0);
        VIDEORTP_pipeCopyChunk(&pes, &bw);
        EXPECT_EQ(info.isPayloadUnitEnd, VIDEORTP_bufGetBytesWritten(&bw) == buffer.size());
    }

    // Check result
    EXPECT_TRUE(info.isPayloadUnitEnd);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), expected.size());
    EXPECT_EQ(buffer, expected);
}
