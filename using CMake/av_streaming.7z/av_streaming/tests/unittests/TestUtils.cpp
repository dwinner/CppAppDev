#include "TestUtils.h"
#include <gtest/gtest.h>

void TestPipelineResult(VIDEORTP_payloadProvider_t* pipeline, const void* expected, size_t expectedSize)
{
    VIDEORTP_payloadChunkInfo_t chunkInfo;
    size_t size = VIDEORTP_pipePrepareNextChunk(pipeline, expectedSize, &chunkInfo);
    EXPECT_EQ(size, expectedSize); // fill whole buffer

    std::vector<uint8_t> buffer(expectedSize);
    VIDEORTP_bufferWriter_t writer;
    VIDEORTP_bufInit(&writer, buffer.data(), buffer.size());

    VIDEORTP_pipeCopyChunk(pipeline, &writer);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&writer), buffer.size());
    EXPECT_EQ(memcmp(buffer.data(), expected, buffer.size()), 0);
}

// Counterpart to 'memset'
bool ContainsPattern(const void* ptr, uint8_t pattern, size_t len)
{
    for (const uint8_t* p = static_cast<const uint8_t*>(ptr); len > 0; ++p, --len)
    {
        if (*p != pattern)
            return false;
    }
    return true;
}

void FillBufferInc(uint8_t* buffer, size_t len, uint8_t start)
{
    for (size_t i = 0; i < len;)
        buffer[i++] = start++;
}

bool CheckBufferInc(const uint8_t* buffer, size_t len, uint8_t start)
{
    for (size_t i = 0; i < len;)
    {
        if (buffer[i++] != start++)
            return false;
    }
    return true;
}

// Returns the PTS/DTS timestamp (H.222.0, 2.4.3.6).
// The most significant nibble specifies the type.
uint64_t ParsePts(const uint8_t data[5])
{
    // data[0] = '00xx' PTS[32..30] marker_bit
    // data[1] = PTS[29..22]
    // data[2] = PTS[21..15] marker_bit
    // data[3] = PTS[14..7]
    // data[4] = PTS[6..0] marker_bit

    if ((data[0] & 0xC0) != 0 || (data[0] & 1) == 0 || (data[2] & 1) == 0 || (data[4] & 1) == 0)
        return VIDEORTP_InvalidTimestamp;

    uint64_t timestamp = 0;
    timestamp |= ((uint64_t) data[0] & 0x30) << 56;
    timestamp |= ((uint64_t) data[0] & 0x0E) << 29;
    timestamp |= ((uint64_t) data[1] & 0xFF) << 22;
    timestamp |= ((uint64_t) data[2] & 0xFE) << 14;
    timestamp |= ((uint64_t) data[3] & 0xFF) << 7;
    timestamp |= ((uint64_t) data[4] & 0xFE) >> 1;
    return timestamp;
}

void VIDEORTP_sysReverseData(void* data, size_t dataSize)
{
    size_t from_start = 0;
    size_t from_end = dataSize - 1;
    uint8_t* _data = (uint8_t*) data;
    do
    {
        uint8_t buf = _data[from_start];
        _data[from_start] = _data[from_end];
        _data[from_end] = buf;
    } while (++from_start < --from_end);
}

void tst_IpcCheckMetadata(VIDEORTP_payloadChunkInfo_t* metadata, bool isPayloadUnitStart, bool isPayloadUnitEnd,
                          size_t payloadUnitSize, const VIDEORTP_timestamp& sampleTimestamp)
{
    EXPECT_EQ(metadata->isPayloadUnitStart, isPayloadUnitStart);
    EXPECT_EQ(metadata->isPayloadUnitEnd, isPayloadUnitEnd);
    EXPECT_EQ(metadata->payloadUnitSize, payloadUnitSize);
    EXPECT_EQ(metadata->sampleTimestamp, sampleTimestamp);
}

void tst_frameWithTwoChunks(VIDEORTP_ipcFrameProvider_t* frameProvider, uint8_t pattern, size_t frameSize, uint8_t* payloadBuffer,
                            VIDEORTP_releaseBufferCb_t bufferReleaseCallback)
{
    VIDEORTP_timestamp frameSamplingTime = {};
    size_t payloadBufferSize = frameSize;
    // set payload data
    memset(payloadBuffer, pattern++, payloadBufferSize / 2);
    memset(payloadBuffer + payloadBufferSize / 2, pattern++, payloadBufferSize / 2);

    // Copy payload data to frame
    EXPECT_TRUE(VIDEORTP_ipcStartFrame(frameProvider, frameSize, &frameSamplingTime));
    EXPECT_TRUE(VIDEORTP_ipcAppendFrame(frameProvider, payloadBuffer, frameSize / 2, bufferReleaseCallback));
    EXPECT_TRUE(
        VIDEORTP_ipcAppendFrame(frameProvider, payloadBuffer + payloadBufferSize / 2, frameSize / 2, bufferReleaseCallback));
}

void tst_ipcInitFrameAndFactory(VIDEORTP_ipcFrame_t* frame, const size_t frameSize, VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory)
{
    VIDEORTP_timestamp samplingTime = { 10, 20, 30, 40 };

    VIDEORTP_payloadChunkFactoryInit(chunkFactory);
    VIDEORTP_ipcFrameInit(frame, chunkFactory, frameSize, &samplingTime);

    EXPECT_EQ(samplingTime.mpegPresentationTimestamp, VIDEORTP_ipcFrameGetSamplingTime(frame));
    EXPECT_EQ(samplingTime.mpegDecodingTimestamp, VIDEORTP_ipcFrameGetDecodingTime(frame));
    EXPECT_EQ(samplingTime, frame->timestamp);
    EXPECT_EQ(frameSize, VIDEORTP_ipcFrameGetTotalSize(frame));
    EXPECT_EQ(frameSize, VIDEORTP_ipcFrameGetRemainingBytes(frame));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetAvailableBytes(frame));
    EXPECT_EQ(0, frame->bytesIn);
    EXPECT_EQ(0, frame->bytesOut);
    EXPECT_EQ(nullptr, frame->next);
}

void tst_ipcAddChunk(VIDEORTP_ipcFrame_t* frame, size_t chunkSize, uint8_t pattern, std::vector<std::vector<uint8_t>>& chunkBuffers,
                     void (*releaseCallback)(void*))
{
    chunkBuffers.push_back(std::vector<uint8_t>(chunkSize));
    memset(chunkBuffers.back().data(), pattern, chunkSize);

    EXPECT_TRUE(VIDEORTP_ipcFrameAddPayloadChunk(frame, chunkBuffers.back().data(), chunkSize, releaseCallback));
}

void tst_getExpectPatternChunk(uint8_t* expectBuffer, size_t frameSize, size_t chunkSize, uint8_t startPattern)
{
    for (int i = 0; i < frameSize / chunkSize; i++)
    {
        memset(expectBuffer + i * chunkSize, startPattern++, chunkSize);
    }
    if (frameSize % chunkSize > 0)
    {
        memset(expectBuffer + frameSize / chunkSize * chunkSize, startPattern++, frameSize % chunkSize);
    }
}

void tst_ipcFillFrameChunksPattern(VIDEORTP_ipcFrame_t* frame, size_t chunkSize, uint8_t startPattern,
                                   std::vector<std::vector<uint8_t>>& chunkBuffers, void (*releaseCallback)(void*))
{
    EXPECT_EQ(VIDEORTP_ipcFrameGetTotalSize(frame), VIDEORTP_ipcFrameGetRemainingBytes(frame));
    EXPECT_EQ(0, VIDEORTP_ipcFrameGetAvailableBytes(frame));
    for (int i = 0; i < VIDEORTP_ipcFrameGetTotalSize(frame) / chunkSize; i++)
    {
        EXPECT_EQ(i * chunkSize, VIDEORTP_ipcFrameGetAvailableBytes(frame));
        tst_ipcAddChunk(frame, chunkSize, startPattern++, chunkBuffers, releaseCallback);
        EXPECT_EQ((i + 1) * chunkSize, VIDEORTP_ipcFrameGetAvailableBytes(frame));
    }
    size_t emptySize = VIDEORTP_ipcFrameGetTotalSize(frame) - VIDEORTP_ipcFrameGetAvailableBytes(frame);
    if (emptySize > 0)
    {
        tst_ipcAddChunk(frame, emptySize, startPattern++, chunkBuffers, releaseCallback);
    }
    EXPECT_EQ(VIDEORTP_ipcFrameGetTotalSize(frame), VIDEORTP_ipcFrameGetRemainingBytes(frame));
    EXPECT_EQ(VIDEORTP_ipcFrameGetTotalSize(frame), VIDEORTP_ipcFrameGetAvailableBytes(frame));
}

extern "C" uint64_t DummyPcrFunction(void* context)
{
    if (context)
        return *static_cast<uint64_t*>(context);
    else
        return 0;
}
