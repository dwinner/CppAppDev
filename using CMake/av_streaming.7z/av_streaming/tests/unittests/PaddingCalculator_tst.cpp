#include "PaddingCalculator.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

class PaddingGeneratorTest : public ::testing::Test
{
protected:
    VIDEORTP_paddingCalculator_t pad;

    PaddingGeneratorTest()
    {
        VIDEORTP_padCalcInit(&pad);
    }

    size_t Calc(size_t payloadCounter, uint64_t spentMs)
    {
        return VIDEORTP_padCalcPadding(&pad, payloadCounter, spentMs);
    }
};

TEST_F(PaddingGeneratorTest, ReturnsNoPaddingWithoutMeasurement)
{
    TEST_DESCRIPTION("TEST for check correct padding calculation if measurements is zero");
    EXPECT_EQ(Calc(0, 0), 0);
}

TEST_F(PaddingGeneratorTest, ReturnsFullPaddingWithoutData)
{
    TEST_DESCRIPTION("TEST for check correct padding calculation if haven't data");
    EXPECT_EQ(Calc(0, 10), VIDEORTP_TARGET_DATARATE / 100);
}

TEST_F(PaddingGeneratorTest, ReturnsHalfPaddingWithHalfData)
{
    TEST_DESCRIPTION("TEST for check correct padding calculation when data give half target datarate");
    EXPECT_EQ(Calc(VIDEORTP_TARGET_DATARATE / 200, 10), VIDEORTP_TARGET_DATARATE / 200);
}

TEST_F(PaddingGeneratorTest, ReturnsNoPaddingWithFullData)
{
    TEST_DESCRIPTION("TEST for check correct padding calculation when data give full target datarate");
    EXPECT_EQ(Calc(VIDEORTP_TARGET_DATARATE / 100, 10), 0);
}

TEST_F(PaddingGeneratorTest, ReturnsNoPaddingWithTooMuchData)
{
    TEST_DESCRIPTION("TEST for check correct padding calculation when data give datarate great then target");
    EXPECT_EQ(Calc(VIDEORTP_TARGET_DATARATE / 99, 10), 0);
}
