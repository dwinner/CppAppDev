#include "RtpPacketizer.h"
#include "Stubs/CheckedStage.h"
#include "Stubs/MinimumChunkSize.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include "TimestampGenerator.h"
#include <deque>
#include <gtest/gtest.h>

// Assigns a predefined timestamp to each chunk
class MockTimestampGenerator : public ::tests::MockPayloadProvider
{
    VIDEORTP_payloadProvider_t* predecessor;
    std::deque<uint64_t> timestamps;

protected:
    size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData) override
    {
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(predecessor, maximumSize, metaData);
        if (!timestamps.empty())
        {
            metaData->sampleTimestamp.mpegPresentationTimestamp = timestamps.front();
            // Not used for this test. RTP should use the presentation timestamp.
            metaData->sampleTimestamp.mpegDecodingTimestamp = 0;
            // GPTP timestamps are not needed for this test
            metaData->sampleTimestamp.gptpTimestamp = 0;
            metaData->sampleTimestamp.gptpTimeBaseIndicator = 0;
        }
        return nextChunkSize;
    }

    void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer) override
    {
        VIDEORTP_pipeCopyChunk(predecessor, payloadBuffer);
        if (!timestamps.empty())
            timestamps.pop_front();
    }

public:
    MockTimestampGenerator(VIDEORTP_payloadProvider_t* predecessor)
        : predecessor(predecessor)
    {
    }

    void Append(uint64_t ts)
    {
        timestamps.push_back(ts);
    }
};

class RtpPacketizerTest : public ::testing::Test
{
protected:
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    MinimumChunkSize minSize { &gen, 188 }; // MPEG-TS is fixed to 188 bytes
    MockTimestampGenerator tgen { &minSize };
    VIDEORTP_rtpPaketizer_t packetizer;

    VIDEORTP_rtcpSessionConfiguration_t configuration;

    std::vector<uint8_t> packetBuffer;
    VIDEORTP_bufferWriter_t packetWriter;

    RtpPacketizerTest()
    {
        VIDEORTP_testPatternGenInit(&gen, 188);
        VIDEORTP_rtcpInitConfig(&configuration, VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS);
        VIDEORTP_rtpPacketizerInit(&packetizer, &tgen, &configuration);
    }

    bool BuildPacket(size_t bufferSize)
    {
        packetBuffer.resize(bufferSize, 0xFF);
        VIDEORTP_bufInit(&packetWriter, packetBuffer.data(), packetBuffer.size());
        gen.currentPattern = 0;
        return VIDEORTP_rtpBuildPacket(&packetizer, &packetWriter) == VideoRTP_ok;
    }

    void CheckPacket(size_t expectedTsPackets)
    {
        ASSERT_GT(VIDEORTP_bufGetBytesWritten(&packetWriter), 12);

        // Payload consists of multiple packets of 188 bytes each
        ASSERT_EQ(VIDEORTP_bufGetBytesWritten(&packetWriter), 12 + expectedTsPackets * 188);
        for (size_t i = 12; i < VIDEORTP_bufGetBytesWritten(&packetWriter); i++)
        {
            ASSERT_EQ(packetBuffer[i], (i - 12) / 188);
        }
        for (size_t i = VIDEORTP_bufGetBytesWritten(&packetWriter); i < packetBuffer.size(); i++)
        {
            ASSERT_EQ(packetBuffer[i], 0xFF);
        }
    }

    void TestPacketTimestamp(size_t tsPackets, uint32_t expectedTimestamp)
    {
        ASSERT_TRUE(BuildPacket(12 + tsPackets * 188));
        CheckPacket(tsPackets);

        ASSERT_GT(VIDEORTP_bufGetBytesWritten(&packetWriter), 12);
        uint32_t actualTimestamp = (packetBuffer[4] << 24) | (packetBuffer[5] << 16) | (packetBuffer[6] << 8) | packetBuffer[7];
        ASSERT_NE(actualTimestamp, static_cast<uint32_t>(VIDEORTP_InvalidTimestamp / 300))
            << "Invalid timestamp written to RTP packet";
        ASSERT_EQ(actualTimestamp, expectedTimestamp) << "RTP timstamp does not match";
    }

    void AppendTimestamp(uint64_t ts = VIDEORTP_InvalidTimestamp)
    {
        if (ts == VIDEORTP_InvalidTimestamp)
            tgen.Append(VIDEORTP_InvalidTimestamp);
        else
            tgen.Append(ts * 300);
    }
};

TEST_F(RtpPacketizerTest, WritesNoHeader)
{
    TEST_DESCRIPTION("TEST for check that the header is not being recorded");
    ASSERT_FALSE(BuildPacket(0));
    ASSERT_FALSE(BuildPacket(1));
    ASSERT_FALSE(BuildPacket(11));
}

TEST_F(RtpPacketizerTest, WritesNoTsPacket)
{
    TEST_DESCRIPTION("TEST for check that the TS-packet is not being recorded");
    ASSERT_FALSE(BuildPacket(12 + 188 - 1));
}

TEST_F(RtpPacketizerTest, WritesSingleTsPacket)
{
    TEST_DESCRIPTION("TEST for check the recording of a single TS packet");
    ASSERT_TRUE(BuildPacket(12 + 188));
    CheckPacket(1);
}

TEST_F(RtpPacketizerTest, WritesWholeTsPacketsOnly)
{
    TEST_DESCRIPTION("TEST for check the recording of only whole TS packets");
    ASSERT_TRUE(BuildPacket(12 + 188 + 1));
    CheckPacket(1);
}

TEST_F(RtpPacketizerTest, WritesMultipleTsPackets)
{
    TEST_DESCRIPTION("TEST for check the recording of multiple TS packets");
    ASSERT_TRUE(BuildPacket(12 + 2 * 188));
    CheckPacket(2);
}

TEST_F(RtpPacketizerTest, FillsMtuPacket)
{
    TEST_DESCRIPTION("TEST for check the filling of the MTU package");
    ASSERT_TRUE(BuildPacket(1232));
    CheckPacket(6);
}

TEST_F(RtpPacketizerTest, WritesHeader)
{
    TEST_DESCRIPTION("TEST for check write header");
    configuration.ssrc[0] = 0x11;
    configuration.ssrc[1] = 0x22;
    configuration.ssrc[2] = 0x33;
    configuration.ssrc[3] = 0x44;
    configuration.payloadType = 0x55;
    AppendTimestamp(0x12345678);

    ASSERT_TRUE(BuildPacket(12 + 188));

    EXPECT_EQ(packetBuffer[0], 0x80);
    EXPECT_EQ(packetBuffer[1], 0x55);
    EXPECT_EQ(packetBuffer[2], 0x00);
    EXPECT_EQ(packetBuffer[3], 0x01);
    EXPECT_EQ(packetBuffer[4], 0x12);
    EXPECT_EQ(packetBuffer[5], 0x34);
    EXPECT_EQ(packetBuffer[6], 0x56);
    EXPECT_EQ(packetBuffer[7], 0x78);
    EXPECT_EQ(packetBuffer[8], 0x11);
    EXPECT_EQ(packetBuffer[9], 0x22);
    EXPECT_EQ(packetBuffer[10], 0x33);
    EXPECT_EQ(packetBuffer[11], 0x44);
}

TEST_F(RtpPacketizerTest, UsesTimestamps)
{
    TEST_DESCRIPTION("TEST for check the use of a timestamp");
    AppendTimestamp(0x12345678);
    AppendTimestamp(0x23456789);

    TestPacketTimestamp(1, 0x12345678);
    TestPacketTimestamp(1, 0x23456789);
}

TEST_F(RtpPacketizerTest, UsesFirstTimestampOnly)
{
    TEST_DESCRIPTION("TEST for check the use of only the first timestamp");
    AppendTimestamp(0x12345678);
    AppendTimestamp(0x23456789);

    TestPacketTimestamp(3, 0x12345678);
}

TEST_F(RtpPacketizerTest, UsesNewTimestampForEachPacket)
{
    TEST_DESCRIPTION("TEST for check the use of a new timestamp for each package");
    AppendTimestamp(0x12345678);
    AppendTimestamp(0x23456789);

    AppendTimestamp(0x34567890);
    AppendTimestamp(0x45678901);

    TestPacketTimestamp(2, 0x12345678);
    TestPacketTimestamp(2, 0x34567890);
}

TEST_F(RtpPacketizerTest, IgnoresInvalidTimestamps)
{
    TEST_DESCRIPTION("TEST for check if invalid timestamps are ignored");
    AppendTimestamp();
    AppendTimestamp(0x23456789);

    AppendTimestamp();
    AppendTimestamp(0x45678901);

    TestPacketTimestamp(2, 0x23456789);
    TestPacketTimestamp(3, 0x45678901);
}

TEST_F(RtpPacketizerTest, FallsBackToLastValidTimestamp)
{
    TEST_DESCRIPTION("TEST for check the use of the last valid timestamp");
    AppendTimestamp(0x12345678);
    TestPacketTimestamp(1, 0x12345678);

    TestPacketTimestamp(1, 0x12345678);
    TestPacketTimestamp(2, 0x12345678);
    TestPacketTimestamp(3, 0x12345678);
}

TEST_F(RtpPacketizerTest, FallsBackToLastPacketTimestamp)
{
    TEST_DESCRIPTION("TEST for check the use of the timestamp of the last package");
    AppendTimestamp(0x12345678);
    AppendTimestamp(0x23456789);
    TestPacketTimestamp(2, 0x12345678);

    // TODO: Which timestamp to use as fallback?
    // 0x12345678 from last sent RTP packet or
    // 0x23456789 from last seen TS packet?

    TestPacketTimestamp(1, 0x12345678);
    TestPacketTimestamp(2, 0x12345678);
    TestPacketTimestamp(3, 0x12345678);
}
