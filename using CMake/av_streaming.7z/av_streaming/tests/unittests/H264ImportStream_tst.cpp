#include "H264FileReader.h"
#include "TestUtils.h"
#include "sysdef.h"
#include "test_noloop.h264_bin.h"
#include <gtest/gtest.h>
#include <memory>

TEST(H264_Import_Stream_Module, IMPORTING_CHECK)
{
    TEST_DESCRIPTION("TEST for check correct generation source code from .h264 file");

    const auto h264TestFile = "test_noloop.h264";
    using namespace std;

    unique_ptr<H264FileReader> h264FileReader = make_unique<H264FileReader>(h264TestFile);
    unique_ptr<valarray<unique_ptr<Nalu>>> nalUnits = h264FileReader->GetNalUnits();
    size_t nalUnitsCount = nalUnits->size();

    ASSERT_EQ(nalUnitsCount, VIDEORTP_PAYLOAD_UNIT_COUNT);

    for (size_t i = 0; i < VIDEORTP_PAYLOAD_UNIT_COUNT; i++)
    {
        struct VIDEORTP_payloadUnit_t payloadItem = VIDEORTP_payloadUnits[i];
        auto* actualContent = (uint8_t*) payloadItem.buffer;
        size_t actualLength = payloadItem.length;

        unique_ptr<Nalu> naluItem = move((*nalUnits)[i]);
        size_t expectedLength = naluItem->GetLength();
        std::valarray<uint8_t> expectedContent = naluItem->GetContent();

        EXPECT_EQ(actualLength, expectedLength);

        for (size_t j = 0; j < actualLength; j++)
        {
            uint8_t actualDataItem = actualContent[j];
            uint8_t expectedDataItem = expectedContent[j];
            EXPECT_EQ(actualDataItem, expectedDataItem);
        }
    }
}
