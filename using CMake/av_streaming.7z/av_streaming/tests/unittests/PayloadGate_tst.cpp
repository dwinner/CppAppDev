#include "PayloadGate.h"
#include "Stubs/GMockPayloadProvider.h"
#include "TestUtils.h"
#include <gmock/gmock.h>
#include <gtest/gtest.h>

using ::testing::_;
using ::testing::Return;
using namespace tests;

TEST(PayloadGateModule, INIT)
{
    TEST_DESCRIPTION("TEST for check the initialization of the payload gate");
    VIDEORTP_payloadGate_t pg;
    VIDEORTP_payloadProvider_t pp;
    VIDEORTP_gateInit(&pg, &pp);
    EXPECT_EQ(pg.predecessor, &pp);
    EXPECT_EQ(pg.enabled, false);
    EXPECT_EQ(pg.lastChunk, false);
}

TEST(PayloadGateModule, ENABLE)
{
    TEST_DESCRIPTION("TEST for check the activation of the payload gate");
    VIDEORTP_payloadGate_t pg;
    VIDEORTP_payloadProvider_t pp;
    VIDEORTP_gateInit(&pg, &pp);
    VIDEORTP_gateEnable(&pg);
    EXPECT_EQ(pg.enabled, true);
}

TEST(PayloadGateModule, FORWARD_PREPARE_IF_ENABLED)
{
    TEST_DESCRIPTION("TEST for check payload forwarding if payload gate is enabled");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);
    VIDEORTP_gateEnable(&pg);

    size_t maximumSize = 43;
    const size_t chunkSize = 44;
    VIDEORTP_payloadChunkInfo_t metaData {};
    VIDEORTP_payloadChunkInfo_t* pMetaData = &metaData;

    EXPECT_CALL(mock, PrepareNextChunk(maximumSize, pMetaData)).WillOnce(Return(chunkSize));

    auto ret = VIDEORTP_pipePrepareNextChunk(&pg.base, maximumSize, pMetaData);

    EXPECT_EQ(ret, chunkSize);
    EXPECT_EQ(pg.enabled, true);
    EXPECT_EQ(pg.lastChunk, false);
}

TEST(PayloadGateModule, NEVER_FORWARD_PREPARE_IF_DISABLED)
{
    TEST_DESCRIPTION("TEST for check that no payloads are being sent if the payload gate is not enabled");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);

    size_t maximumSize = 43;
    VIDEORTP_payloadChunkInfo_t metaData {};
    VIDEORTP_payloadChunkInfo_t* pMetaData = &metaData;

    EXPECT_CALL(mock, PrepareNextChunk(_, _)).Times(0);

    VIDEORTP_pipePrepareNextChunk(&pg.base, maximumSize, pMetaData);

    EXPECT_EQ(pg.enabled, false);
}

TEST(PayloadGateModule, SET_LASTCHUNK_AFTER_PREPARE)
{
    TEST_DESCRIPTION("TEST for check install the last fragment after preparation");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);
    VIDEORTP_gateEnable(&pg);

    size_t maximumSize = 43;
    const size_t chunkSize = 100;
    VIDEORTP_payloadChunkInfo_t metaData {};
    VIDEORTP_payloadChunkInfo_t* pMetaData = &metaData;

    EXPECT_CALL(mock, PrepareNextChunk(maximumSize, pMetaData))
        .WillOnce(
            [&](size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
            {
                metaData->isPayloadUnitEnd = true;
                return chunkSize;
            });

    auto ret = VIDEORTP_pipePrepareNextChunk(&pg.base, maximumSize, pMetaData);

    EXPECT_EQ(ret, chunkSize);
    EXPECT_EQ(pg.enabled, true);
    EXPECT_EQ(pg.lastChunk, true);
}

TEST(PayloadGateModule, IF_PREPARE_INVALID_THEN_FLAGS_NOT_CHANGED)
{
    TEST_DESCRIPTION("TEST for check that the flags are not set");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;

    VIDEORTP_gateInit(&pg, &mock);
    VIDEORTP_gateEnable(&pg);

    const size_t maximumSize = 43;
    const size_t chunkSize = 0;
    VIDEORTP_payloadChunkInfo_t metaData {};
    VIDEORTP_payloadChunkInfo_t* pMetaData = &metaData;

    EXPECT_CALL(mock, PrepareNextChunk(_, _))
        .WillOnce(
            [&](size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
            {
                metaData->isPayloadUnitEnd = true;
                return chunkSize;
            });

    auto ret = VIDEORTP_pipePrepareNextChunk(&pg.base, maximumSize, pMetaData);

    EXPECT_EQ(ret, chunkSize);
    EXPECT_EQ(pg.enabled, true);
    EXPECT_EQ(pg.lastChunk, false);
}

TEST(PayloadGateModule, FORWARD_COPY_IF_ENABLED)
{
    TEST_DESCRIPTION("TEST for check direct copying if payload gate is enabled");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);
    VIDEORTP_gateEnable(&pg);

    VIDEORTP_bufferWriter_t bufferWriter;

    EXPECT_CALL(mock, CopyChunk(&bufferWriter));

    VIDEORTP_pipeCopyChunk(&pg.base, &bufferWriter);

    EXPECT_EQ(pg.enabled, true);
}

TEST(PayloadGateModule, NEVER_FORWARD_COPY_IF_DISABLED)
{
    TEST_DESCRIPTION("TEST for check forward copy does not work if payload gate is disabled");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);

    VIDEORTP_bufferWriter_t bufferWriter;

    EXPECT_CALL(mock, CopyChunk(_)).Times(0);

    VIDEORTP_pipeCopyChunk(&pg.base, &bufferWriter);

    EXPECT_EQ(pg.enabled, false);
}

TEST(PayloadGateModule, DISABLE_AFTER_COPY_LAST_CHUNK)
{
    TEST_DESCRIPTION("TEST for check disable after copying the last fragment");
    VIDEORTP_payloadGate_t pg;
    GMockPayloadProvider mock;
    VIDEORTP_gateInit(&pg, &mock);
    VIDEORTP_gateEnable(&pg);

    VIDEORTP_bufferWriter_t bufferWriter;

    EXPECT_CALL(mock, CopyChunk(&bufferWriter));

    pg.lastChunk = true;
    VIDEORTP_pipeCopyChunk(&pg.base, &bufferWriter);

    EXPECT_EQ(pg.enabled, false);
    EXPECT_EQ(pg.lastChunk, false);
}
