#include <stdint.h>

#include <algorithm>
#include <iterator>
#include <string>
#include <vector>

#include "TestUtils.h"
#include <gtest/gtest.h>

#include "BufferWriter.h"
#include "PCAPWriter.h"
#include "PacketTransmitter.h"
#include "sysdef.h"

#include "libs/pcap_file_generator/libpcap_file_generator.h"

struct
{
    uint16_t checksum;
    uint16_t lenght;
    uint16_t destination_port;
    uint16_t source_port;
} typedef s_UDP;

struct
{
    uint16_t type;
    uint8_t source[6];
    uint8_t destination[6];
} typedef s_Ethernet;

struct
{
    uint32_t destination;
    uint32_t source;
    uint16_t header_checksum;
    uint8_t protocol;
    uint8_t timeToLive;
    uint16_t fragment_offset;
    uint16_t identification;
    uint16_t total_lenght;
    uint8_t defferentiated_services;
    uint8_t version_and_header_lenght;
} typedef s_IPv4;

struct
{
    uint8_t destination[16];
    uint8_t source[16];
    uint8_t hop_limit;
    uint8_t next_header;
    uint16_t payload_lenght;
    uint32_t version_and_traffic_class;
} typedef s_IPv6;

struct
{
    s_Ethernet ethernet;
    s_IPv4 ipv4;
    s_UDP udp;
} typedef s_Frame_IPv4;

struct
{
    s_Ethernet ethernet;
    s_IPv6 ipv6;
    s_UDP udp;
} typedef s_Frame_IPv6;

static s_Ethernet tst_parceEthernet(uint8_t* frame, size_t offset)
{
    s_Ethernet ethernet;
    memcpy(&ethernet, frame + offset, sizeof(s_Ethernet));
    VIDEORTP_sysReverseData(&ethernet, sizeof(s_Ethernet));
    VIDEORTP_sysReverseData(&(ethernet.source), sizeof(ethernet.source));
    VIDEORTP_sysReverseData(&(ethernet.destination), sizeof(ethernet.destination));

    return ethernet;
}

static s_IPv4 tst_parceIPv4(uint8_t* frame, size_t offset)
{
    s_IPv4 ipv4;
    memcpy(&ipv4, frame + offset, sizeof(s_IPv4));
    VIDEORTP_sysReverseData(&ipv4, sizeof(s_IPv4));
    return ipv4;
}

static s_IPv6 tst_parceIPv6(uint8_t* frame, size_t offset)
{
    s_IPv6 ipv6;
    memcpy(&ipv6, frame + offset, sizeof(s_IPv6));
    VIDEORTP_sysReverseData(&ipv6, sizeof(s_IPv6));
    VIDEORTP_sysReverseData(&(ipv6.source), sizeof(ipv6.source));
    VIDEORTP_sysReverseData(&(ipv6.destination), sizeof(ipv6.destination));
    return ipv6;
}

static s_UDP tst_parceUDP(uint8_t* frame, size_t offset)
{
    s_UDP udp;
    memcpy(&udp, frame + offset, sizeof(s_UDP));
    VIDEORTP_sysReverseData(&udp, sizeof(s_UDP));
    return udp;
}

static s_Frame_IPv4 tst_parceFrameIPv4(uint8_t* frame)
{
    s_Frame_IPv4 fr;

    size_t read_point = 0;
    s_Ethernet ethernet = tst_parceEthernet(frame, read_point);
    read_point += sizeof(s_Ethernet);

    s_IPv4 ipv4 = tst_parceIPv4(frame, read_point);
    read_point += sizeof(s_IPv4);

    s_UDP udp = tst_parceUDP(frame, read_point);

    fr.udp = udp;
    fr.ipv4 = ipv4;
    fr.ethernet = ethernet;

    return fr;
}

static s_Frame_IPv6 tst_parceFrameIPv6(uint8_t* frame)
{
    s_Frame_IPv6 fr;

    size_t read_point = 0;
    s_Ethernet ethernet = tst_parceEthernet(frame, read_point);
    read_point += sizeof(s_Ethernet);

    s_IPv6 ipv6 = tst_parceIPv6(frame, read_point);
    read_point += sizeof(s_IPv6);

    s_UDP udp = tst_parceUDP(frame, read_point);

    fr.udp = udp;
    fr.ipv6 = ipv6;
    fr.ethernet = ethernet;

    return fr;
}

// check one frame
void checkFrame(pcaprec_hdr_and_data_t* p_rec_data, uint8_t* expectData, size_t expectDatSize)
{
    s_Frame_IPv6 s_frame = tst_parceFrameIPv6(p_rec_data->packet_data);

    uint64_t datagramSize = s_frame.udp.lenght - sizeof(s_UDP);
    ASSERT_EQ(datagramSize, expectDatSize);

    size_t read_point = sizeof(s_Frame_IPv6);
    read_point = 62; // at this point start datagram data

    ASSERT_GT(p_rec_data->pcp_rec_hdr.incl_len, read_point);
    ASSERT_EQ(p_rec_data->pcp_rec_hdr.incl_len - read_point, expectDatSize);

    const uint8_t* datagram = p_rec_data->packet_data + read_point;
    EXPECT_EQ(0, memcmp(datagram, expectData, expectDatSize));
}

// check pcap file
void checkFile(char* pcapFilePath, std::vector<std::vector<uint8_t>> expectData)
{
    PCAPFILE* pfr = lpcap_open(pcapFilePath);

    ASSERT_FALSE(pfr == NULL);

    pcap_hdr_t phdr;
    bool canReadHeader = lpcap_read_header(pfr, &phdr);
    EXPECT_TRUE(canReadHeader);
    if (canReadHeader)
    {
        int rese_rec_read = 0;
        pcaprec_hdr_and_data_t p_rec_data;

        rese_rec_read = lpcap_read_frame_record(pfr, &p_rec_data);
        size_t count = 0;
        while (rese_rec_read > 0)
        {
            checkFrame(&p_rec_data, expectData.at(count).data(), expectData.at(count).size());
            rese_rec_read = lpcap_read_frame_record(pfr, &p_rec_data);
            count++;
        }
    }
}

TEST(PCAPWriterModule, PCAP_WRITE_FILE)
{
    TEST_DESCRIPTION("TEST for check payload ritten to .pcap file");
    std::string fileName(".\\IP6.pcap");
    VIDEORTP_pcapWriter_t pcapWriter;
    pcapWriter.fileName = const_cast<char*>(fileName.data());
    VIDEORTP_pcapInit(&pcapWriter);

    std::vector<std::vector<uint8_t>> expectData;
    uint8_t pattern = 100;
    for (int i = 1100; i < 1233; i++)
    {
        std::vector<uint8_t> buffer(i, pattern++);
        for (size_t i = 0; i < buffer.size(); ++i)
            buffer[i] += i;
        expectData.push_back(buffer);
        VIDEORTP_bufferWriter_t* bufferWriter = VIDEORTP_txPrepareTransmissionBuffer(&(pcapWriter.vtable));
        VIDEORTP_bufGetAvailableSpace(bufferWriter);
        VIDEORTP_bufWriteData(bufferWriter, buffer.data(), buffer.size());
        VIDEORTP_txCommitTransmissionBuffer(&(pcapWriter.vtable));
    }

    VIDEORTP_pcapDeinit(&pcapWriter);
    // HARD CODE FOR TEST
    EXPECT_EQ(0, 0);
    checkFile(const_cast<char*>(fileName.data()), expectData);
}
