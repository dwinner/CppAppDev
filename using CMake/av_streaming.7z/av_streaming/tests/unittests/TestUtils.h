#ifndef TEST_UTILS_H
#define TEST_UTILS_H

#include "IpcFrameProvider.h"
#include "PayloadProvider.h"
#include <iostream>
#include <stddef.h>
#include <vector>

/** PCR PID for PMT */
#define VIDEORTP_PCR_PID_PMT UINT16_C(0x0100)
/** PCR PID for Null Packet */
#define VIDEORTP_PCR_PID_NULL UINT16_C(0x1FFF)

// macro for test Description
#define TEST_DESCRIPTION(desc) RecordProperty("description", desc)

static const VIDEORTP_timestamp INVALID_SAMPLE_TIMESTAMP = { VIDEORTP_InvalidTimestamp, VIDEORTP_InvalidTimestamp, 0, 0 };

inline bool operator==(const VIDEORTP_timestamp& lhs, const VIDEORTP_timestamp& rhs)
{
    return lhs.mpegPresentationTimestamp == rhs.mpegPresentationTimestamp && lhs.mpegDecodingTimestamp == rhs.mpegDecodingTimestamp
        && lhs.gptpTimestamp == rhs.gptpTimestamp && lhs.gptpTimeBaseIndicator == rhs.gptpTimeBaseIndicator;
}

inline bool operator!=(const VIDEORTP_timestamp& lhs, const VIDEORTP_timestamp& rhs)
{
    return !(lhs == rhs);
}

// Debug output of VIDEORTP_timestamp for GoogleTest
inline std::ostream& operator<<(std::ostream& os, const VIDEORTP_timestamp& ts)
{
    return os << "PTS=" << ts.mpegPresentationTimestamp << ", DTS=" << ts.mpegDecodingTimestamp << ", GPTP=" << ts.gptpTimestamp
              << " (base=" << ts.gptpTimeBaseIndicator << ")";
}

void TestPipelineResult(VIDEORTP_payloadProvider_t* pipeline, const void* expected, size_t expectedSize);
bool ContainsPattern(const void* ptr, uint8_t pattern, size_t len);
void FillBufferInc(uint8_t* buffer, size_t len, uint8_t start = 0);
bool CheckBufferInc(const uint8_t* buffer, size_t len, uint8_t start = 0);

static const uint64_t DTS_ONLY = UINT64_C(0x10) << 56;
static const uint64_t PTS_ONLY = UINT64_C(0x20) << 56;
static const uint64_t PTS_AND_DTS = UINT64_C(0x30) << 56;
uint64_t ParsePts(const uint8_t data[5]);

void VIDEORTP_sysReverseData(void* data, size_t dataSize);

void tst_IpcCheckMetadata(VIDEORTP_payloadChunkInfo_t* metadata, bool isPayloadUnitStart, bool isPayloadUnitEnd,
                          size_t payloadUnitSize, const VIDEORTP_timestamp& sampleTimestamp);
void tst_frameWithTwoChunks(VIDEORTP_ipcFrameProvider_t* frameProvider, uint8_t pattern, size_t frameSize, uint8_t* payloadBuffer,
                            VIDEORTP_releaseBufferCb_t bufferReleaseCallback);

void tst_ipcInitFrameAndFactory(VIDEORTP_ipcFrame_t* frame, const size_t frameSize,
                                VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory);

void tst_ipcAddChunk(VIDEORTP_ipcFrame_t* frame, size_t chunkSize, uint8_t pattern, std::vector<std::vector<uint8_t>>& chunkBuffers,
                     void (*releaseCallback)(void*));

void tst_getExpectPatternChunk(uint8_t* expectBuffer, size_t frameSize, size_t chunkSize, uint8_t startPattern);

void tst_ipcFillFrameChunksPattern(VIDEORTP_ipcFrame_t* frame, size_t chunkSize, uint8_t startPattern,
                                   std::vector<std::vector<uint8_t>>& chunkBuffers, void (*releaseCallback)(void*));

#define tst_slistContains(queue, element, res)                                                                                     \
    do                                                                                                                             \
    {                                                                                                                              \
        (res) = false;                                                                                                             \
        auto current = (queue)->head;                                                                                              \
        while (current != NULL)                                                                                                    \
        {                                                                                                                          \
            if (current == (element))                                                                                              \
            {                                                                                                                      \
                (res) = true;                                                                                                      \
                break;                                                                                                             \
            }                                                                                                                      \
            current = current->next;                                                                                               \
        }                                                                                                                          \
    } while (0)

template <typename T> size_t tst_slistSize(T* queue)
{
    size_t count = 0;
    for (decltype(T::head) i = queue->head; i != nullptr; i = i->next)
    {
        count++;
    }
    return count;
}

extern "C" uint64_t DummyPcrFunction(void* context);

#endif /* TEST_UTILS_H */
