#include "PayloadGate.h"
#include "PayloadUnitRepeater.h"
#include "ProgramMapTableBuilder.h"
#include "ProgramSectionPacketizer.h"
#include "Stubs/CheckedStage.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include "TimestampGenerator.h"
#include "TransportStreamHeaderBuilder.h"
#include "TransportStreamPacketizer.h"
#include <gtest/gtest.h>

void tsInitPipe(uint8_t* pmtBuffer, size_t pmtBufferSize, VIDEORTP_bufferWriter_t* pmtBW, VIDEORTP_programMapTableBuilder_t* pmt,
                CheckedGenerator<VIDEORTP_payloadUnitRepeater_t>* rep, CheckedStage<VIDEORTP_programSectionPacketizer_t>* pipe)
{
    VIDEORTP_bufInit(pmtBW, pmtBuffer, pmtBufferSize);
    VIDEORTP_pmtInit(pmt, 0x1000, 0x0100, pmtBW);
    VIDEORTP_pmtAddElementaryStreamPid(pmt, 0x10, 0x1B);
    VIDEORTP_pmtFinalize(pmt);
    VIDEORTP_repInitRaw(rep, VIDEORTP_bufGetBasePointer(pmtBW), VIDEORTP_bufGetBytesWritten(pmtBW));
    VIDEORTP_sectInit(pipe, rep);
}

TEST(TransportStreamPacketizer, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor TransportStreamPacketizer");

    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    VIDEORTP_bufferWriter_t pmtBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid, nullptr, nullptr);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    EXPECT_EQ(&sec, tsp.predecessor);
}

TEST(TransportStreamPacketizer, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all functions");
    EXPECT_EXIT(VIDEORTP_tsInitPacketizer(NULL, NULL, 0, nullptr, nullptr), testing::ExitedWithCode(3), "");
}

TEST(TransportStreamPacketizer, PACKET_SIZE)
{
    TEST_DESCRIPTION("TEST for check correct transport stream packet size according to destination buffer size");
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    VIDEORTP_bufferWriter_t pmtBw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;
    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    for (int i = 0; i <= sizeof(buffer); ++i)
    {
        VIDEORTP_payloadChunkInfo_t info;
        uint64_t timestamp = 12345;
        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &sec, 123, DummyPcrFunction, &timestamp);

        // MPEG-TS packets have a fixed size.
        // Writing less to a small buffer is not possible.
        // Writing more to a large buffer is not allowed.
        size_t expectedChunkSize = i < VIDEORTP_TS_PACKET_SIZE ? 0 : VIDEORTP_TS_PACKET_SIZE;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, i, &info);
        EXPECT_EQ(expectedChunkSize, nextChunkSize) << "for buffer size = " << i;

        // CheckedStage will verify this
        if (expectedChunkSize > 0)
        {
            VIDEORTP_bufClear(&bw);
            VIDEORTP_pipeCopyChunk(&sec, &bw);
        }

        // Increasing the header size does not affect the packet size
        VIDEORTP_tsInitPacketizer(&tsp, &sec, 123, DummyPcrFunction, &timestamp);
        VIDEORTP_tsInjectPcr(&tsp.builder);
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, i, &info);
        EXPECT_EQ(expectedChunkSize, nextChunkSize) << "for buffer size = " << i;

        // CheckedStage will verify this
        if (expectedChunkSize > 0)
        {
            VIDEORTP_bufClear(&bw);
            VIDEORTP_pipeCopyChunk(&sec, &bw);
        }
    }
}

static void CheckTsPacketEmpty(VIDEORTP_payloadProvider_t* vtable)
{
    VIDEORTP_payloadChunkInfo_t info;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(vtable, VIDEORTP_TS_PACKET_SIZE, &info);
    ASSERT_EQ(0, nextChunkSize);
}

TEST(TransportStreamPacketizer, EMPTY_PAYLOAD)
{
    TEST_DESCRIPTION("TEST for check correct behaviour if payload is empty");
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 0);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
    VIDEORTP_tsInitPacketizer(&tsp, &gen, 123, DummyPcrFunction, nullptr);

    ASSERT_NO_FATAL_FAILURE(CheckTsPacketEmpty(&tsp));
}

// Check that the TS packetizer concatenated header, stuffing, and payload
// data correctly. The contents of the header will be tested separately.
static void CheckTsPacketPayload(VIDEORTP_payloadProvider_t* vtable, size_t headerSize, size_t maxPayloadSize,
                                 uint8_t payloadPattern, VIDEORTP_payloadChunkInfo_t* metadata = nullptr)
{
    static const uint8_t UNDEFINED = 0xDD;

    VIDEORTP_payloadChunkInfo_t dummy;
    if (!metadata)
        metadata = &dummy;

    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE];
    memset(buffer, UNDEFINED, sizeof(buffer));
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(vtable, sizeof(buffer), metadata);
    ASSERT_EQ(sizeof(buffer), nextChunkSize) << "Invalid packet size";
    VIDEORTP_pipeCopyChunk(vtable, &bw);

    for (size_t i = 0; i < sizeof(buffer); ++i)
        ASSERT_NE(buffer[i], UNDEFINED) << "Packet byte " << i << " was not written";

    if (headerSize < VIDEORTP_TS_MINIMUM_HEADER_SIZE)
        headerSize = VIDEORTP_TS_MINIMUM_HEADER_SIZE;
    size_t payloadSize = std::min(sizeof(buffer) - headerSize, maxPayloadSize);
    ASSERT_LE(headerSize + payloadSize, VIDEORTP_TS_PACKET_SIZE);
    size_t stuffingSize = VIDEORTP_TS_PACKET_SIZE - payloadSize - headerSize;
    int i = 0;

    // Check TS Header
    ASSERT_EQ(buffer[0], VIDEORTP_TS_SYNC_BYTE) << "Invalid sync byte";
    for (; i < headerSize; ++i)
    {
        ASSERT_NE(buffer[i], payloadPattern) << "Invalid header at byte " << i;
        ASSERT_NE(buffer[i], VIDEORTP_TS_PACKET_STUFFING_BYTE) << "Invalid header at byte " << i;
    }

    // Check adaptation field header in front of remaining stuffing bytes
    if (headerSize > 4 || stuffingSize > 0)
        ASSERT_EQ(buffer[4], VIDEORTP_TS_PACKET_SIZE - payloadSize - 5) << "Invalid adaptation field length";
    if (headerSize < 6 && stuffingSize > 1)
        ASSERT_EQ(buffer[5], 0) << "Invalid adaptation field flags";
    if (i < 6)
        i = 6;

    // Check stuffing between header and payload
    for (; i < sizeof(buffer) - payloadSize; ++i)
    {
        ASSERT_EQ(buffer[i], VIDEORTP_TS_PACKET_STUFFING_BYTE) << "Invalid stuffing at byte " << i;
    }

    // Check payload
    for (; i < sizeof(buffer); ++i)
    {
        ASSERT_EQ(buffer[i], payloadPattern) << "Invalid payload at byte " << i;
    }
}

TEST(TransportStreamPacketizer, PADDING)
{
    TEST_DESCRIPTION("TEST for check correct include payload, stuffing and padding to TS packet");
    static const uint8_t PAYLOAD = 0xEE;

    // With PCR
    for (int i = 1; i < VIDEORTP_TS_PACKET_SIZE + 10; ++i)
    {
        CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
        VIDEORTP_testPatternGenInit(&gen, i);
        gen.currentPattern = PAYLOAD;

        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &gen, 123, DummyPcrFunction, nullptr);

        VIDEORTP_tsInjectPcr(&tsp.builder);
        ASSERT_NO_FATAL_FAILURE(CheckTsPacketPayload(&tsp, VIDEORTP_TS_WITH_PCR, i, PAYLOAD))
            << "Invalid padding of size " << i << " with PCR";
    }

    // Without PCR
    for (int i = 1; i < VIDEORTP_TS_PACKET_SIZE + 10; ++i)
    {
        CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
        VIDEORTP_testPatternGenInit(&gen, i);
        gen.currentPattern = PAYLOAD;

        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &gen, 123, DummyPcrFunction, nullptr);

        ASSERT_NO_FATAL_FAILURE(CheckTsPacketPayload(&tsp, VIDEORTP_TS_MINIMUM_HEADER_SIZE, i, PAYLOAD))
            << "Invalid padding of size " << i;
    }
}

TEST(TransportStreamPacketizer, PATTERN_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to include PCR when payload");
    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 64;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);
    VIDEORTP_repInitRaw(&rep, VIDEORTP_bufGetBasePointer(&patternBw), VIDEORTP_bufGetBytesWritten(&patternBw));

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    uint64_t timestamp = 10;
    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid, DummyPcrFunction, &timestamp);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    VIDEORTP_tsInjectPcr(builder);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));
    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldControl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 7, sizeof(uint8_t)); // adaptation field length
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_PCR_FLAG_TRUE,
                             sizeof(uint8_t)); // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE); // PCR with reserved
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, patternBufferSize); // data
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PATTERN_WITHOUT_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 64;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);
    VIDEORTP_repInitRaw(&rep, VIDEORTP_bufGetBasePointer(&patternBw), VIDEORTP_bufGetBytesWritten(&patternBw));

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    uint64_t timestamp = 10;
    VIDEORTP_tsInitPacketizer(&tsp, &sec, VIDEORTP_PCR_PID_NULL, DummyPcrFunction, &timestamp);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    VIDEORTP_tsInjectPcr(builder);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldControl = 0b01, continuityCounter = 0
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, patternBufferSize); // data
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PATTERN_WITHOUT_PCR_CHUNKS)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload separated to parts");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 256;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);
    VIDEORTP_repInitRaw(&rep, VIDEORTP_bufGetBasePointer(&patternBw), VIDEORTP_bufGetBytesWritten(&patternBw));

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    uint64_t timestamp = 10;
    VIDEORTP_tsInitPacketizer(&tsp, &sec, VIDEORTP_PCR_PID_NULL, DummyPcrFunction, &timestamp);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    VIDEORTP_tsInjectPcr(builder);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);
    EXPECT_TRUE(metaData.isPayloadUnitStart);
    EXPECT_FALSE(metaData.isPayloadUnitEnd);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldControl = 0b01, continuityCounter = 0
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, VIDEORTP_bufGetAvailableSpace(&expectedBW)); // data

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);

    VIDEORTP_bufClear(&expectedBW);
    VIDEORTP_bufClear(&bw);
    nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);
    EXPECT_FALSE(metaData.isPayloadUnitStart);
    EXPECT_TRUE(metaData.isPayloadUnitEnd);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x11,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldControl = 0b01, continuityCounter = 1
    VIDEORTP_bufWritePattern(&expectedBW, pattern,
                             73); // data, VIDEORTP_TS_PACKET_SIZE - 4 (ts header) - 1 (pointer was in previous chunk)
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding
    cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PMT_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload is PMT");
    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    memset(pmtBuffer, 0, pmtBufferSize);
    VIDEORTP_bufferWriter_t pmtBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    uint64_t timestamp = 10;
    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid, DummyPcrFunction, &timestamp);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    VIDEORTP_tsInjectPcr(builder);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));
    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldControl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));
    // adaptation field length == 7, 1 is sizeof(adaptafionFieldLength)
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_WITH_PCR - VIDEORTP_TS_MINIMUM_HEADER_SIZE - 1, sizeof(uint8_t));
    // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_PCR_FLAG_TRUE, sizeof(uint8_t));
    // PCR with reserved
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE);
    // pointer
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t));
    // payload
    VIDEORTP_bufWriteData(&expectedBW, pmtBuffer, VIDEORTP_bufGetBytesWritten(&pmtBw));
    // padding
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(&expectedBW));

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, EMPTY_PACKETS_WITHOUT_PCR)
{
    TEST_DESCRIPTION("Check that empty/stuffing packets can be generated until a PCR can be inserted");

    static const uint8_t PAYLOAD = 0xEE;

    // Generates 2 TS packets per payload unit (due to TS header)
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 50);
    gen.currentPattern = PAYLOAD;

    // Add timestamps to payload units
    CheckedStage<VIDEORTP_timestampGenerator_t> tgen;
    VIDEORTP_tgenInit(&tgen, 1000, 50, &gen);

    // Stop after each payload unit
    CheckedStage<VIDEORTP_payloadGate_t> gate;
    VIDEORTP_gateInit(&gate, &tgen, 1);

    // Wrap in TS packets
    uint64_t pcr = 9999;
    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
    VIDEORTP_tsInitPacketizer(&tsp, &gate, 1234, DummyPcrFunction, &pcr);

    // PCR may be included in packets which are multiples of 6 [IP_AVT_423]

    // Request inclusion of PCR. This is not possible because there is no payload.
    // Dummy packets cannot be generated because the stream has not started, yet.
    VIDEORTP_tsInjectPcr(&tsp.builder);
    ASSERT_NO_FATAL_FAILURE(CheckTsPacketEmpty(&tsp));

    // Read first packet with data. The PCR can be included now.
    VIDEORTP_gateEnable(&gate);
    VIDEORTP_payloadChunkInfo_t metadataReference;
    ASSERT_NO_FATAL_FAILURE(CheckTsPacketPayload(&tsp, VIDEORTP_TS_WITH_PCR, 50, PAYLOAD, &metadataReference));

    // No more payload data and no PCR requested.
    ASSERT_NO_FATAL_FAILURE(CheckTsPacketEmpty(&tsp));

    for (int repeat = 0; repeat < 3; ++repeat)
    {
        VIDEORTP_payloadChunkInfo_t metadataClone;

        // Request inclusion of PCR again. The following packets are not a multiple of 6.
        // Empty/stuffing packets without payload will be generated on demand.
        VIDEORTP_tsInjectPcr(&tsp.builder);
        for (int i = 1; i < VIDEORTP_TS_TIMESTAMP_PACKET_COUNTER_MOD; ++i)
        {
            ASSERT_NO_FATAL_FAILURE(CheckTsPacketPayload(&tsp, VIDEORTP_TS_MINIMUM_HEADER_SIZE, 0, PAYLOAD, &metadataClone))
                << "invalid dummy packet " << i;
            ASSERT_EQ(metadataReference.payloadUnitSize, metadataClone.payloadUnitSize);
            ASSERT_EQ(metadataReference.sampleTimestamp, metadataClone.sampleTimestamp);
            ASSERT_FALSE(metadataClone.isPayloadUnitStart);
            ASSERT_FALSE(metadataClone.isPayloadUnitEnd);
        }

        // PCR can be included now because the packet is a proper multiple of 6.
        // There still is no payload data, however.
        ASSERT_NO_FATAL_FAILURE(CheckTsPacketPayload(&tsp, VIDEORTP_TS_WITH_PCR, 0, PAYLOAD));
        ASSERT_EQ(metadataReference.payloadUnitSize, metadataClone.payloadUnitSize);
        ASSERT_EQ(metadataReference.sampleTimestamp, metadataClone.sampleTimestamp);
        ASSERT_FALSE(metadataClone.isPayloadUnitStart);
        ASSERT_FALSE(metadataClone.isPayloadUnitEnd);

        // No more payload data and no PCR requested.
        ASSERT_NO_FATAL_FAILURE(CheckTsPacketEmpty(&tsp));
    }
}
