#include "PayloadUnitRepeater.h"
#include "ProgramMapTableBuilder.h"
#include "ProgramSectionPacketizer.h"
#include "Stubs/CheckedStage.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include "TransportStreamHeaderBuilder.h"
#include "TransportStreamPacketizer.h"
#include <gtest/gtest.h>

void tsInitPipe(uint8_t* pmtBuffer, size_t pmtBufferSize, VIDEORTP_bufferWriter_t* pmtBW, VIDEORTP_programMapTableBuilder_t* pmt,
                CheckedGenerator<VIDEORTP_payloadUnitRepeater_t>* rep, CheckedStage<VIDEORTP_programSectionPacketizer_t>* pipe)
{
    VIDEORTP_bufInit(pmtBW, pmtBuffer, pmtBufferSize);
    VIDEORTP_pmtInit(pmt, 0x1000, 0x0100, pmtBW);
    VIDEORTP_pmtAddElementaryStreamPid(pmt, 0x10, 0x1B);
    VIDEORTP_pmtFinalize(pmt);
    VIDEORTP_repInit(rep, pmtBW);
    VIDEORTP_sectInit(pipe, rep);
}

TEST(TransportStreamPacketizer, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor TransportStreamPacketizer");

    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    VIDEORTP_bufferWriter_t pmtBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    EXPECT_EQ(&sec, tsp.predecessor);
}

TEST(TransportStreamPacketizer, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all functions");
    EXPECT_EXIT(VIDEORTP_tsInitPacketizer(NULL, NULL, 0), testing::ExitedWithCode(3), "");
}

TEST(TransportStreamPacketizer, PACKET_SIZE)
{
    TEST_DESCRIPTION("TEST for check correct transport stream packet size according to destination buffer size");
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    VIDEORTP_bufferWriter_t pmtBw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;
    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    for (int i = 0; i <= sizeof(buffer); ++i)
    {
        VIDEORTP_payloadChunkInfo_t info;
        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &sec, 123);

        // MPEG-TS packets have a fixed size.
        // Writing less to a small buffer is not possible.
        // Writing more to a large buffer is not allowed.
        size_t expectedChunkSize = i < VIDEORTP_TS_PACKET_SIZE ? 0 : VIDEORTP_TS_PACKET_SIZE;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, i, &info);
        EXPECT_EQ(expectedChunkSize, nextChunkSize) << "for buffer size = " << i;

        // CheckedStage will verify this
        if (expectedChunkSize > 0)
        {
            VIDEORTP_bufClear(&bw);
            VIDEORTP_pipeCopyChunk(&sec, &bw);
        }

        // Increasing the header size does not affect the packet size
        VIDEORTP_tsInitPacketizer(&tsp, &sec, 123);
        VIDEORTP_tsInjectPcr(&tsp.builder, 12345);
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, i, &info);
        EXPECT_EQ(expectedChunkSize, nextChunkSize) << "for buffer size = " << i;

        // CheckedStage will verify this
        if (expectedChunkSize > 0)
        {
            VIDEORTP_bufClear(&bw);
            VIDEORTP_pipeCopyChunk(&sec, &bw);
        }
    }
}

TEST(TransportStreamPacketizer, EMPTY_PAYLOAD)
{
    TEST_DESCRIPTION("TEST for check correct behaviour if payload is empty");
    CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
    VIDEORTP_testPatternGenInit(&gen, 0);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
    VIDEORTP_tsInitPacketizer(&tsp, &gen, 123);

    VIDEORTP_payloadChunkInfo_t info;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, VIDEORTP_TS_PACKET_SIZE, &info);
    EXPECT_EQ(0, nextChunkSize);
}

// Check that the TS packetizer concatenated header, stuffing, and payload
// data correctly. The contents of the header will be tested separately.
static void CheckTsPacketPayload(VIDEORTP_payloadProvider_t* vtable, size_t minHeaderSize, size_t maxPayloadSize,
                                 uint8_t payloadPattern)
{
    static const uint8_t UNDEFINED = 0xDD;

    uint8_t buffer[VIDEORTP_TS_PACKET_SIZE];
    memset(buffer, UNDEFINED, sizeof(buffer));
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_payloadChunkInfo_t info;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(vtable, sizeof(buffer), &info);
    EXPECT_EQ(sizeof(buffer), nextChunkSize);
    VIDEORTP_pipeCopyChunk(vtable, &bw);

    size_t payloadSize = std::min(sizeof(buffer) - minHeaderSize, maxPayloadSize);
    int i = 0;
    for (; i < sizeof(buffer) - payloadSize; ++i)
    {
        EXPECT_NE(buffer[i], UNDEFINED) << "Packet byte was not written!"
                                        << " i = " << i << " header = " << minHeaderSize << " payload = " << maxPayloadSize;
        EXPECT_NE(buffer[i], payloadPattern) << "Invalid header!"
                                             << " i = " << i << " header = " << minHeaderSize << " payload = " << maxPayloadSize;
    }
    for (; i < sizeof(buffer); ++i)
    {
        // payload only
        EXPECT_EQ(buffer[i], payloadPattern) << "Invalid payload!"
                                             << " i = " << i << " header = " << minHeaderSize << " payload = " << maxPayloadSize;
    }
}

TEST(TransportStreamPacketizer, PADDING)
{
    TEST_DESCRIPTION("TEST for check correct include payload, stuffing and padding to TS packet");
    static const uint8_t PAYLOAD = 0xEE;

    // With PCR
    for (int i = 1; i < VIDEORTP_TS_PACKET_SIZE + 10; ++i)
    {
        CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
        VIDEORTP_testPatternGenInit(&gen, i);
        gen.currentPattern = PAYLOAD;

        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &gen, 123);

        VIDEORTP_tsInjectPcr(&tsp.builder, 0);
        CheckTsPacketPayload(&tsp, 12, i, PAYLOAD);
    }

    // Without PCR
    for (int i = 1; i < VIDEORTP_TS_PACKET_SIZE + 10; ++i)
    {
        CheckedGenerator<VIDEORTP_testPatternGenerator> gen;
        VIDEORTP_testPatternGenInit(&gen, i);
        gen.currentPattern = PAYLOAD;

        CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;
        VIDEORTP_tsInitPacketizer(&tsp, &gen, 123);

        CheckTsPacketPayload(&tsp, 4, i, PAYLOAD);
    }
}

TEST(TransportStreamPacketizer, PATTERN_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to include PCR when payload");
    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 64;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_repInit(&rep, &patternBw);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    uint64_t timestamp = 10;
    VIDEORTP_tsInjectPcr(builder, timestamp);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));
    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldContorl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 7, sizeof(uint8_t)); // adaptation field length
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_PCR_FLAG_TRUE,
                             sizeof(uint8_t)); // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE); // PCR with reserved
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, patternBufferSize); // data
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PATTERN_WITHOUT_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 64;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_repInit(&rep, &patternBw);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    VIDEORTP_tsInitPacketizer(&tsp, &sec, VIDEORTP_PCR_PID_NULL);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    uint64_t timestamp = 10;
    VIDEORTP_tsInjectPcr(builder, timestamp);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldContorl = 0b01, continuityCounter = 0
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, patternBufferSize); // data
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PATTERN_WITHOUT_PCR_CHUNKS)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload separated to parts");
    uint16_t pid = VIDEORTP_PCR_PID_NULL;
    const uint8_t pattern = 2;
    const size_t patternBufferSize = 256;
    uint8_t patternBuffer[patternBufferSize];
    memset(patternBuffer, 0, patternBufferSize);
    VIDEORTP_bufferWriter_t patternBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    VIDEORTP_bufInit(&patternBw, patternBuffer, patternBufferSize);
    VIDEORTP_repInit(&rep, &patternBw);
    VIDEORTP_bufWritePattern(&patternBw, pattern, patternBufferSize);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_sectInit(&sec, &rep);
    VIDEORTP_tsInitPacketizer(&tsp, &sec, VIDEORTP_PCR_PID_NULL);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    uint64_t timestamp = 10;
    VIDEORTP_tsInjectPcr(builder, timestamp);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);
    EXPECT_TRUE(metaData.isPayloadUnitStart);
    EXPECT_FALSE(metaData.isPayloadUnitEnd);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x10,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldContorl = 0b01, continuityCounter = 0
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t)); // pointer
    VIDEORTP_bufWritePattern(&expectedBW, pattern, VIDEORTP_bufGetAvailableSpace(&expectedBW)); // data

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);

    VIDEORTP_bufClear(&expectedBW);
    VIDEORTP_bufClear(&bw);
    nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);
    EXPECT_FALSE(metaData.isPayloadUnitStart);
    EXPECT_TRUE(metaData.isPayloadUnitEnd);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t)); // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t)); // PID
    VIDEORTP_bufWriteInteger(&expectedBW, 0x11,
                             sizeof(uint8_t)); // scrambled = 0b00, adaptationFieldContorl = 0b01, continuityCounter = 1
    VIDEORTP_bufWritePattern(&expectedBW, pattern,
                             73); // data, VIDEORTP_TS_PACKET_SIZE - 4 (ts header) - 1 (pointer was in previous chunk)
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE,
                             VIDEORTP_bufGetAvailableSpace(&expectedBW)); // padding
    cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}

TEST(TransportStreamPacketizer, PMT_WITH_PCR)
{
    TEST_DESCRIPTION("TEST for check correct condition to not include PCR when payload is PMT");
    uint16_t pid = VIDEORTP_PCR_PID_PMT;
    const size_t pmtBufferSize = 64;
    uint8_t pmtBuffer[pmtBufferSize];
    memset(pmtBuffer, 0, pmtBufferSize);
    VIDEORTP_bufferWriter_t pmtBw;
    const size_t bufferSize = 512;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    VIDEORTP_programMapTableBuilder_t pmt;
    CheckedStage<VIDEORTP_programSectionPacketizer_t> sec;

    tsInitPipe(pmtBuffer, pmtBufferSize, &pmtBw, &pmt, &rep, &sec);

    CheckedStage<VIDEORTP_transportStreamPacketizer_t> tsp;

    VIDEORTP_tsInitPacketizer(&tsp, &sec, pid);
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    VIDEORTP_transportStreamHeaderBuilder_t* builder = &tsp.builder;
    uint64_t timestamp = 10;
    VIDEORTP_tsInjectPcr(builder, timestamp);

    VIDEORTP_payloadChunkInfo_t metaData;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&tsp, bufferSize, &metaData);

    EXPECT_EQ(nextChunkSize, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_pipeCopyChunk(&tsp, &bw);

    uint64_t programClockReferenceBase = timestamp / 300; // expect value is 0, 33 bytes
    uint64_t originalProgramClockReferenceExtension = timestamp % 300; // expect value is 10, 9 bytes
    uint8_t reserved = 0x3F; // 6 bits by 1
    uint64_t temp
        = VIDEORTP_TS_PCR_MASK & (originalProgramClockReferenceExtension | (reserved << 9) | (programClockReferenceBase << 15));
    uint8_t expect[VIDEORTP_TS_PACKET_SIZE];
    memset(expect, 0, VIDEORTP_TS_PACKET_SIZE);

    VIDEORTP_bufferWriter_t expectedBW;
    VIDEORTP_bufInit(&expectedBW, expect, VIDEORTP_TS_PACKET_SIZE);
    // sync byte
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_SYNC_BYTE, sizeof(uint8_t));
    // PID
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_INDICATOR_AND_PID_MASK & (pid | (metaData.isPayloadUnitStart << 14)),
                             sizeof(uint16_t));
    // scrambled = 0b00, adaptationFieldContorl = 0b11, continuityCounter = 0
    VIDEORTP_bufWriteInteger(&expectedBW, 0x30, sizeof(uint8_t));
    // adaptation field length == 7, 1 is sizeof(adaptafionFieldLength)
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_WITH_PCR - VIDEORTP_TS_MINIMUM_HEADER_SIZE - 1, sizeof(uint8_t));
    // adaptation field flags wiht PCR_flag == true
    VIDEORTP_bufWriteInteger(&expectedBW, VIDEORTP_TS_PCR_FLAG_TRUE, sizeof(uint8_t));
    // PCR with reserved
    VIDEORTP_bufWriteInteger(&expectedBW, temp, VIDEORTP_TS_PCR_SIZE);
    // pointer
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_SECT_DEFAULT_POINTER, sizeof(uint8_t));
    // payload
    VIDEORTP_bufWriteData(&expectedBW, pmtBuffer, VIDEORTP_bufGetBytesWritten(&pmtBw));
    // padding
    VIDEORTP_bufWritePattern(&expectedBW, VIDEORTP_TS_PACKET_STUFFING_BYTE, VIDEORTP_bufGetAvailableSpace(&expectedBW));

    int cmp = memcmp(expect, buffer, VIDEORTP_TS_PACKET_SIZE);
    EXPECT_EQ(cmp, 0);
}
