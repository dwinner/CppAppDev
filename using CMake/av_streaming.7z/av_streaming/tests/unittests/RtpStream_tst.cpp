#include "ConstantsOEM.h"
#include "RtpStream.h"
#include "Stubs/CheckedStage.h"
#include "Stubs/GMockPacketTransmitter.h"
#include "TestPatternGenerator.h"
#include "TestUtils.h"
#include "TimestampGenerator.h"
#include <gtest/gtest.h>

class RtpStreamTest : public ::testing::Test
{
protected:
    CheckedGenerator<VIDEORTP_testPatternGenerator> dgen;
    CheckedGenerator<VIDEORTP_timestampGenerator_t> tgen;

    VIDEORTP_rtcpSessionConfiguration_t config;
    VIDEORTP_rtpStream_t stream;

    RtpStreamTest()
    {
        VIDEORTP_testPatternGenInit(&dgen, 188);
        VIDEORTP_tgenInit(&tgen, 0, 25, &dgen);

        VIDEORTP_rtcpInitConfig(&config, VIDEORTP_rtpStreamingMode_RFC2250);
        VIDEORTP_initRtpStream(&stream, &tgen, &config);
    }
};

TEST_F(RtpStreamTest, SendsRtpAndRtcpPackets)
{
    TEST_DESCRIPTION("Test that RTP stream writes RTP and RTCP packets");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    // Send RTP and RTCP packet immediately
    EXPECT_CALL(rtp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtp, CommitTransmissionBuffer).Times(1);
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(1);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);
}

TEST_F(RtpStreamTest, CallsPrepareBeforeCommit)
{
    TEST_DESCRIPTION("Check that a transmission buffer is prepared before it is committed");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    ASSERT_EQ(VIDEORTP_bufGetBasePointer(&rtp.writer), nullptr);
    EXPECT_CALL(rtp, CommitTransmissionBuffer)
        .WillOnce(
            [&]()
            {
                EXPECT_NE(VIDEORTP_bufGetBasePointer(&rtp.writer), nullptr);
                return VideoRTP_ok;
            });

    ASSERT_EQ(VIDEORTP_bufGetBasePointer(&rtcp.writer), nullptr);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer)
        .WillOnce(
            [&]()
            {
                EXPECT_NE(VIDEORTP_bufGetBasePointer(&rtcp.writer), nullptr);
                return VideoRTP_ok;
            });

    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);
}

TEST_F(RtpStreamTest, DoesNotSendRtcpPacketsWithoutRtpPackets)
{
    TEST_DESCRIPTION("Test that RTCP packets will not be sent without a prior RTP packet");

    // RTCP packets need timestamps which will be taken from RTP packets.
    // Therefore it is not possible to send RTCP packets without RTP packets.

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);
    dgen.payloadUnitSize = 0;

    EXPECT_CALL(rtp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtp, CommitTransmissionBuffer).Times(0);
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(0);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(0);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_queueEmpty);
}

TEST_F(RtpStreamTest, ReturnsRtpNetworkErrors)
{
    TEST_DESCRIPTION("Test that network errors are returned to the caller when sending RTP packets");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    EXPECT_CALL(rtp, CommitTransmissionBuffer).WillOnce(testing::Return(VideoRTP_networkError));
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_networkError);
}

TEST_F(RtpStreamTest, ReturnsRtcpNetworkErrors)
{
    TEST_DESCRIPTION("Test that network errors are returned to the caller when sending RTCP packets");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    EXPECT_CALL(rtcp, CommitTransmissionBuffer).WillOnce(testing::Return(VideoRTP_networkError));
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_networkError);
}

TEST_F(RtpStreamTest, RtcpIsOptional)
{
    TEST_DESCRIPTION("Test that RTCP is optional");

    tests::DummyMockPacketTransmitter rtp(1500);

    // Send RTP packet only
    EXPECT_CALL(rtp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtp, CommitTransmissionBuffer).Times(1);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, nullptr), VideoRTP_ok);
}

TEST_F(RtpStreamTest, RtpBufferIsTooSmall)
{
    TEST_DESCRIPTION("Test behavior if RTP buffer is too small");

    tests::DummyMockPacketTransmitter rtp(10);

    // Cannot complete RTP packet
    EXPECT_CALL(rtp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtp, CommitTransmissionBuffer).Times(0);
    ASSERT_NE(VIDEORTP_sendRtpPacket(&stream, &rtp, nullptr), VideoRTP_ok);
}

TEST_F(RtpStreamTest, RtcpBufferIsTooSmall)
{
    TEST_DESCRIPTION("Test behavior if RTCP buffer is too small");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(10);

    // Cannot complete RTCP packet
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(0);

    // TODO: Should this return an error instead?
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);
}

TEST_F(RtpStreamTest, SendsOneRtpPacketPerCall)
{
    TEST_DESCRIPTION("Test that one RTP packet will be generated per call");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    for (int i = 0; i < 10; ++i)
    {
        EXPECT_CALL(rtp, PrepareTransmissionBuffer).Times(1);
        EXPECT_CALL(rtp, CommitTransmissionBuffer).Times(1);
        ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);
    }
}

TEST_F(RtpStreamTest, SendsRtcpPacketsAfterDelay)
{
    TEST_DESCRIPTION("Test that RTCP packets will be sent after a delay");

    tests::DummyMockPacketTransmitter rtp(1500), rtcp(1500);

    // Send first RTCP packet immediately
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(1);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);

    // No more RTCP packets until the timer expires
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(0);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(0);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);

    VIDEORTP_cyclicRtpStream(&stream, VIDEORTP_RTCP_INTERVAL - 1);

    // RTCP timer still has not expired
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(0);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(0);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);

    VIDEORTP_cyclicRtpStream(&stream, 1);

    // Send RTCP packet again
    EXPECT_CALL(rtcp, PrepareTransmissionBuffer).Times(1);
    EXPECT_CALL(rtcp, CommitTransmissionBuffer).Times(1);
    ASSERT_EQ(VIDEORTP_sendRtpPacket(&stream, &rtp, &rtcp), VideoRTP_ok);
}
