#ifndef TST_STREAM_PARSER_H
#define TST_STREAM_PARSER_H

#include <stdbool.h>
#include <stdint.h>

typedef struct rtpHeader
{
    uint8_t start;
    bool markerbitFlag;
    uint8_t payloadType;
    uint16_t autoShift;
    uint16_t sequenceNumber;
    uint32_t timestamp;
    uint8_t ssrc[4];
} rtpHeader;

typedef struct tsHeader
{
    size_t length;
    uint8_t synchByte;
    uint16_t pid;
    bool payloadUnitStart;
    uint8_t adaptationFieldContorl;
    uint8_t continuityCounter;
    uint8_t adaptationFieldLength;
    uint8_t adaptationFieldFlags;
    uint64_t PCR;
} tsHeader;

typedef struct pesHeader
{
    size_t length;
    uint8_t startCode[3];
    uint8_t streamId;
    uint16_t packetLenght;
    uint8_t pesFlags;
    uint8_t PTS_DTS_flags;
    uint8_t headerLength;
    uint64_t PTS;
    uint64_t DTS;
} pesHeader;

size_t tst_parseStream(const uint8_t* buf, size_t bufferSize, size_t payloadSize);
rtpHeader tst_checkRTP(const uint8_t* buf);
uint64_t tst_parsePesTimestaps(const uint8_t* data);
tsHeader tst_parseTS(const uint8_t* buf);
pesHeader tst_parsePES(const uint8_t* buf);

#endif /* TST_STREAM_PARSER_H */
