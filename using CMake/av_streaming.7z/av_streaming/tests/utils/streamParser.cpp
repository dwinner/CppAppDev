
#include "streamParser.h"
#include <gtest/gtest.h>

#include "../VideoStream/VideoTestStream.h"
#include "BufferWriter.h"
#include "PaddingCalculator.h"
#include "PayloadDataCounter.h"
#include "PayloadUnitRepeater.h"
#include "ProgramMapTableBuilder.h"
#include "TransportStreamPacketizer.h"
#include "unittests/TestUtils.h"

static uint64_t tsPacketCounter = 0;

static std::vector<const uint8_t*> getTsPtr(const uint8_t* buf, size_t bufferSize)
{
    std::vector<const uint8_t*> tsptr;
    for (int i = 0; i < bufferSize; i++)
    {
        uint16_t pid = 0x1FFF & ((((uint16_t) buf[1]) << 8) | (0x00FF & ((uint16_t) buf[2])));
        if ((buf[i] == VIDEORTP_TS_SYNC_BYTE) && (pid == VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID))
        {
            tsptr.push_back(buf + i);
        }
    }
    return tsptr;
}

static const uint8_t* getPesPtr(const uint8_t* buf, size_t bufferSize)
{
    for (int i = 0; i < bufferSize - 3; i++)
    {
        if ((buf[i] == 0x00) /* start code */
            && (buf[i + 1] == 0x00) /* start code */
            && (buf[i + 2] == 0x01) /* start code */
            && (buf[i + 6] == 0x80) /* pes flags */
        )
        {
            return buf + i;
        }
    }

    return nullptr;
}

size_t tst_parseStream(const uint8_t* buf, size_t bufferSize, size_t payloadSize)
{
    rtpHeader rtp = tst_checkRTP(buf);
    bufferSize -= 12;

    std::vector<const uint8_t*> tsptr = getTsPtr(buf, bufferSize);
    std::vector<tsHeader> tsHeaders;

    size_t payloadCounter = 0;

    std::vector<const uint8_t*> pesptr;
    std::vector<pesHeader> pesHeaders;
    for (int i = 0; i < tsptr.size(); i++)
    {
        tsHeader tsh = tst_parseTS(tsptr.at(i));
        tsHeaders.push_back(tsh);
        bufferSize -= tsh.length;
        if (tsh.payloadUnitStart)
        {
            const uint8_t* pes = getPesPtr(tsptr.at(i), VIDEORTP_TS_PACKET_SIZE);
            if (pes != nullptr)
            {
                pesHeader pesh = tst_parsePES(pes);
                pesHeaders.push_back(pesh);
            }
        }
    }
    return 0;
}

rtpHeader tst_checkRTP(const uint8_t* buf)
{
    rtpHeader header = {};
    header.start = buf[0];
    header.markerbitFlag = 0x1 & (buf[1] >> 7);
    header.payloadType = buf[1] & 0x7F;
    header.autoShift = buf[2];

    memcpy(&header.sequenceNumber, buf + 3, sizeof(uint16_t));
    VIDEORTP_sysReverseData(&header.sequenceNumber, sizeof(uint16_t));

    memcpy(&header.timestamp, buf + 4, sizeof(uint32_t));
    VIDEORTP_sysReverseData(&header.timestamp, sizeof(uint32_t));

    memcpy(header.ssrc, buf + 8, VIDEORTP_RTCP_SSRC_SIZE);

    EXPECT_EQ(header.start, 0x80); /* VPXCC and CSRC */
    EXPECT_EQ(header.markerbitFlag, 0); /* markerbit and payloadType */
    EXPECT_EQ(header.payloadType, 0x21); /* markerbit and payloadType */

    EXPECT_EQ(header.ssrc[0], 1);
    EXPECT_EQ(header.ssrc[1], 2);
    EXPECT_EQ(header.ssrc[2], 3);
    EXPECT_EQ(header.ssrc[3], 4);

    return header;
}

uint64_t tst_parsePesTimestaps(const uint8_t* data)
{
    if ((data[0] & 0xC0) != 0 || (data[0] & 1) == 0 || (data[2] & 1) == 0 || (data[4] & 1) == 0)
        return VIDEORTP_InvalidTimestamp;

    uint64_t timestamp = 0;
    timestamp |= ((uint64_t) data[0] & 0x30) << 56;
    timestamp |= ((uint64_t) data[0] & 0x0E) << 29;
    timestamp |= ((uint64_t) data[1] & 0xFF) << 22;
    timestamp |= ((uint64_t) data[2] & 0xFE) << 14;
    timestamp |= ((uint64_t) data[3] & 0xFF) << 7;
    timestamp |= ((uint64_t) data[4] & 0xFE) >> 1;
    return timestamp;
}

tsHeader tst_parseTS(const uint8_t* buf)
{
    tsHeader header = {};

    header.length = 0;
    header.synchByte = buf[0];
    EXPECT_EQ(buf[0], VIDEORTP_TS_SYNC_BYTE); /* ts sync byte */

    header.payloadUnitStart = (buf[1] >> 6) & 0x01;
    header.pid = 0x1FFF & ((((uint16_t) buf[1]) << 8) | (0x00FF & ((uint16_t) buf[2])));
    // EXPECT_EQ(header.pid, VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID);
    if (header.payloadUnitStart)
    {
        tsPacketCounter++;
    }

    header.adaptationFieldContorl = 0x3 & (buf[3] >> 4);
    header.continuityCounter = 0x0F & buf[3];

    header.length += 4;
    if (header.adaptationFieldContorl == 3)
    {
        header.adaptationFieldLength = buf[4];
        header.length += header.adaptationFieldLength;

        header.adaptationFieldFlags = buf[6];
        if (header.adaptationFieldFlags == VIDEORTP_TS_PCR_FLAG_TRUE)
        {
            /* TODO PCR included */
            header.PCR;
            memcpy(&header.PCR, buf + 6, VIDEORTP_TS_PCR_SIZE);
            EXPECT_NE(header.PCR, 0);
        }
        header.length += header.adaptationFieldLength;
    }
    else if (header.adaptationFieldContorl == 1)
    {
        /* TODO no stuffing, no other */
    }

    return header;
}

pesHeader tst_parsePES(const uint8_t* buf)
{
    pesHeader header = {};
    header.length = 10;

    uint8_t tmp[20];
    memcpy(tmp, buf, 20);

    memcpy(header.startCode, buf, 3);
    uint8_t expectStartCode[] = { 0, 0, 1 };
    EXPECT_EQ(0, memcmp(header.startCode, expectStartCode, 3));

    header.streamId = buf[3];
    // EXPECT_EQ(streamId, VIDEORTP_PES_VIDEO_STREAM_0); /* stream id */

    header.packetLenght = (((uint16_t) buf[4]) << 8) | (0x00FF & ((uint16_t) buf[5]));

    header.pesFlags = buf[6];
    // EXPECT_EQ(buf[6], 0x80); /* pes flags */

    header.PTS_DTS_flags = buf[7];

    header.headerLength = buf[8];
    header.PTS = tst_parsePesTimestaps(buf + 9);
    header.DTS;

    /* TODO parce PTS */

    if (header.PTS_DTS_flags == 0xC0) /* with dts */
    {
        header.DTS = tst_parsePesTimestaps(buf + 10);
        header.length += 5;
        /* TODO parce DTS */
    }

    return header;
}
