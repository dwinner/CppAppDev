#include "GMockPacketTransmitter.h"

using namespace tests;

namespace
{
extern "C" VIDEORTP_bufferWriter_t* MockPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    return static_cast<MockPacketTransmitter*>(vtable)->PrepareTransmissionBuffer();
}
extern "C" VideoRTP_errorCode MockCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    return static_cast<MockPacketTransmitter*>(vtable)->CommitTransmissionBuffer();
}
}

MockPacketTransmitter::MockPacketTransmitter()
{
    prepareTransmissionBuffer = MockPrepareTransmissionBuffer;
    commitTransmissionBuffer = MockCommitTransmissionBuffer;
}

VIDEORTP_bufferWriter_t* MockPacketTransmitter::PrepareTransmissionBuffer()
{
    return nullptr;
}

VideoRTP_errorCode MockPacketTransmitter::CommitTransmissionBuffer()
{
    return VideoRTP_error;
}

DummyMockPacketTransmitter::DummyMockPacketTransmitter(size_t bufferSize)
    : buffer(bufferSize)
{
    ON_CALL(*this, PrepareTransmissionBuffer)
        .WillByDefault(
            [this]()
            {
                VIDEORTP_bufInit(&writer, buffer.data(), buffer.size());
                return &writer;
            });

    ON_CALL(*this, CommitTransmissionBuffer)
        .WillByDefault(
            []()
            {
                return VideoRTP_ok;
            });

    EXPECT_CALL(*this, PrepareTransmissionBuffer).Times(::testing::AnyNumber());
    EXPECT_CALL(*this, CommitTransmissionBuffer).Times(::testing::AnyNumber());
}
