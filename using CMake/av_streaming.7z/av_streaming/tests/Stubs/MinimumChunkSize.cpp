#include "MinimumChunkSize.h"
#include <gtest/gtest.h>

MinimumChunkSize::MinimumChunkSize(VIDEORTP_payloadProvider_t* predecessor, size_t minimumSize)
    : predecessor(predecessor)
    , minimumSize(minimumSize)
{
}

size_t MinimumChunkSize::PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(predecessor, maximumSize, metaData);

    if (nextChunkSize < minimumSize)
        return 0;
    else
        return nextChunkSize;
}

void MinimumChunkSize::CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer)
{
    VIDEORTP_pipeCopyChunk(predecessor, payloadBuffer);
}
