#ifndef MINIMUMCHUNKSIZE_H_INCLUDED
#define MINIMUMCHUNKSIZE_H_INCLUDED

#include "GMockPayloadProvider.h"

// Pretend that the next stage needs a minimum buffer, e.g., to add a header
struct MinimumChunkSize : tests::MockPayloadProvider
{
    explicit MinimumChunkSize(VIDEORTP_payloadProvider_t* predecessor, size_t minimum);

    size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData) override;
    void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer) override;

    VIDEORTP_payloadProvider_t* predecessor;
    size_t minimumSize;
};

#endif
