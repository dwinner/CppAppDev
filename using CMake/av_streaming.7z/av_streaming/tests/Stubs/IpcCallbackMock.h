#ifndef IPC_CALLBACK_MOCK_H
#define IPC_CALLBACK_MOCK_H

#include <gmock/gmock.h>

struct IpcCallbackInterface
{
    virtual ~IpcCallbackInterface() = default;
    virtual void ReleaseBuffer(void*) = 0;
};

class IpcCallbackMock : public IpcCallbackInterface
{
    static IpcCallbackMock* mock;

    IpcCallbackMock(const IpcCallbackMock&) = delete;
    IpcCallbackMock& operator=(const IpcCallbackMock&) = delete;

public:
    // Register mock automatically. Only one mock can exist at a time.
    IpcCallbackMock()
    {
        assert(mock == nullptr);
        mock = this;
    }
    ~IpcCallbackMock()
    {
        assert(mock == this);
        mock = nullptr;
    }

    MOCK_METHOD1(ReleaseBuffer, void(void*));

    static void ReleaseBufferCallback(void* buffer);
    static void InvalidReleaseBufferCallback(void*);
};

#endif
