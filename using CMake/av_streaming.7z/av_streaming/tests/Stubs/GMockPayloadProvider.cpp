#include "GMockPayloadProvider.h"

using namespace tests;

namespace
{
extern "C" void MockCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    static_cast<MockPayloadProvider*>(vtable)->CopyChunk(payloadBuffer);
}
extern "C" size_t MockPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                       VIDEORTP_payloadChunkInfo_t* metaData)
{
    return static_cast<MockPayloadProvider*>(vtable)->PrepareNextChunk(maximumSize, metaData);
}
}

MockPayloadProvider::MockPayloadProvider()
{
    copyChunk = MockCopyChunk;
    prepareNextChunk = MockPrepareNextChunk;
}

size_t MockPayloadProvider::PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    return 0;
}

void MockPayloadProvider::CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer)
{
}
