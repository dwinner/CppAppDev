#include "IpcCallbackMock.h"

IpcCallbackMock* IpcCallbackMock::mock = nullptr;

void IpcCallbackMock::ReleaseBufferCallback(void* buffer)
{
    ASSERT_NE(mock, nullptr);
    mock->ReleaseBuffer(buffer);
}

void IpcCallbackMock::InvalidReleaseBufferCallback(void*)
{
    ASSERT_TRUE(false);
}
