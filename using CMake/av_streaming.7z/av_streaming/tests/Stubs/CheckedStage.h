#ifndef CALLSEQUENCECHECKER_H_INCLUDED
#define CALLSEQUENCECHECKER_H_INCLUDED

#include "GMockPayloadProvider.h"

// This is a (dirty?) trick to wrap pipeline stages with little typing.
//
// For a normal pipeline stage, you might write:
//
//      MyPipelineStage foo;
//      InitMyPipelineStage(&foo);
//      VIDEORTP_pipePrepareNextChunk(&foo.vtable, ...); // need vtable here
//
// To check parameters etc. in unit tests, you might insert another pipeline stage:
//
//      MyPipelineStage foo;
//      InitMyPipelineStage(&foo);
//      MyCheckerPipelineStage checkedFoo(&foo.vtable); // need vtable here
//      VIDEORTP_pipePrepareNextChunk(&checkedFoo, ...); // need checkedFoo here
//
// To save some typing, you can use this class instead and write:
//
//      MyChecker<MyPipelineStage> foo; // Only need template here
//      InitMyPipelineStage(&foo);
//      VIDEORTP_pipePrepareNextChunk(&foo, ...);
//
// Due to multiple inheritance, &foo can be implicitly converted to either the
// wrapper class or the wrapped class depending on the context where it is used:
//
// - When calling a specific pipeline API like an init function, WrappedStage*
//   can be converted to PIPELINE_STAGE*. This is the wrapped (inner) object.
//
// - When calling a generic pipeline API which needs the vtable, WrappedStage*
//   can be converted to VIDEORTP_payloadProvider_t* via MockPayloadProvider*.
//   This returns the wrapper (outer) object which checks parameters etc. and
//   then forwards all calls to the wrapped (inner) object.
template <typename PIPELINE_STAGE> struct WrappedStage : PIPELINE_STAGE, tests::MockPayloadProvider
{
    VIDEORTP_payloadProvider_t* GetWrappedPipelineStage()
    {
        // This assumes that the VIDEORTP_payloadProvider_t vtable is always the first data member of the C struct
        // TODO: Use SFINAE magic to replace reinterpret_cast with direct access to base/vtable/vTable/... field
        return reinterpret_cast<VIDEORTP_payloadProvider_t*>(static_cast<PIPELINE_STAGE*>(this));
    }

    size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData) override
    {
        return ::VIDEORTP_pipePrepareNextChunk(GetWrappedPipelineStage(), maximumSize, metaData);
    }

    void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer) override
    {
        ::VIDEORTP_pipeCopyChunk(GetWrappedPipelineStage(), payloadBuffer);
    }

private:
    // This is a precaution to prevent anyone from accidentally using the
    // vtable of the wrapped stage because that would bypass the wrapper.
    // (Yes, this is a hack and there is probably a better solution.)
    typedef void vtable, vTable, base;
};

// Check call sequence and parameters of pipeline stages
template <typename PIPELINE_STAGE> struct CheckedStage : WrappedStage<PIPELINE_STAGE>
{
    size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData) override;
    void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer) override;

private:
    size_t CheckPrepareNextChunkIdempotence(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData);
    size_t CheckPrepareNextChunkMetadata(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData);

    size_t m_nextChunkSize = 0; // chunk size promised by wrapped pipeline stage
};

template <typename PIPELINE_STAGE>
size_t CheckedStage<PIPELINE_STAGE>::CheckPrepareNextChunkIdempotence(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    // prepareNextChunk should be idempotent. Unless the user calls copyChunk or changes
    // other "relevant" state, prepareNextChunk should always return the same value.
    //
    // In theory, it could return a different result every time, e.g., when reading
    // from an external interface which asynchronously provides data. For our unit
    // tests, however, we assume that all tests are deterministic, so prepareNextChunk
    // should return the same result when called twice in a row.
    //
    // Furthermore, we assume that the internal state of the pipeline stage will be
    // identical after the second call and that there will be no additional side-effects.
    // While this might not always be true (e.g., there could be a cache or other internal
    // book-keeping which does not have externally visible effects), we assume that our
    // pipeline stages are reasonably "simple" and don't implement fancy stuff like that.
    // This allows us to detect some cases when prepareNextChunk changes state that it
    // was not supposed to change.

    size_t firstResult = WrappedStage<PIPELINE_STAGE>::PrepareNextChunk(maximumSize, metaData);
    PIPELINE_STAGE stateAfterFirstCall(*this);
    VIDEORTP_payloadChunkInfo_t metaDataAfterFirstCall(*metaData);
    size_t secondResult = WrappedStage<PIPELINE_STAGE>::PrepareNextChunk(maximumSize, metaData);

    EXPECT_EQ(firstResult, secondResult);
    EXPECT_EQ(memcmp(&metaDataAfterFirstCall, metaData, sizeof(metaDataAfterFirstCall)), 0);
    EXPECT_EQ(memcmp(&stateAfterFirstCall, static_cast<PIPELINE_STAGE*>(this), sizeof(stateAfterFirstCall)), 0);

    return secondResult;
}

template <typename PIPELINE_STAGE>
size_t CheckedStage<PIPELINE_STAGE>::CheckPrepareNextChunkMetadata(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    // This is an "output" parameter, so its contents are undefined on input.
    memset(metaData, 0xCC, sizeof(*metaData));

    // Note: prepareNextChunk may be called repeatedly without actually copying anything
    size_t nextChunkSize = CheckPrepareNextChunkIdempotence(maximumSize, metaData);

    if (nextChunkSize == 0)
    {
        // Contents are actually undefined if prepareNextChunk returns 0.
        // It would be nice if we could assert or trap when reading from this
        // struct, but that doesn't seem to be possible in C or C++.
        // The next best thing is writing actual garbage to that memory.
        memset(metaData, 0xCC, sizeof(*metaData));
    }
    else
    {
        // If prepareNextChunk returns a nonzero size, it must have initialized all metadata fields.
        // Typically, only the "final" pipeline stage which provides the actual payload will do that.
        // Intermediate pipeline stages rely on their respective predecessors to initialize the fields.
        EXPECT_NE(metaData->sampleTimestamp, UINT64_C(0xCCCCCCCCCCCCCCCC)) << "sampleTimestamp is not initialized";
        EXPECT_NE(metaData->payloadUnitSize, UINT32_C(0xCCCCCCCC)) << "payloadUnitSize is not initialized";
        EXPECT_NE((uint8_t&) metaData->isPayloadUnitStart, (uint8_t) 0xCC) << "isPayloadUnitStart is not initialized";
        EXPECT_NE((uint8_t&) metaData->isPayloadUnitEnd, (uint8_t) 0xCC) << "isPayloadUnitEnd is not initialized";
    }

    return nextChunkSize;
}

template <typename PIPELINE_STAGE>
size_t CheckedStage<PIPELINE_STAGE>::PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    // The pipeline is intended to build "small" network packets.
    // In practice, packets will be smaller than 1500 bytes (ethernet MTU).
    // Anything much larger than that probably indicates an overflow or underflow.
    EXPECT_LE(maximumSize, 0x3fff) << "Unreasonable maximum size";

    m_nextChunkSize = CheckPrepareNextChunkMetadata(maximumSize, metaData);
    EXPECT_LE(m_nextChunkSize, maximumSize) << "Cannot write more data than allowed";
    return m_nextChunkSize;
}

template <typename PIPELINE_STAGE> void CheckedStage<PIPELINE_STAGE>::CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer)
{
    EXPECT_GT(m_nextChunkSize, 0) << "copyChunk may be called only if prepareNextChunk returned a nonzero value";
    EXPECT_LE(m_nextChunkSize, VIDEORTP_bufGetAvailableSpace(payloadBuffer))
        << "The destination buffer must be large enough for this chunk";

    // Write actual payload
    size_t before = VIDEORTP_bufGetBytesWritten(payloadBuffer);
    WrappedStage<PIPELINE_STAGE>::CopyChunk(payloadBuffer);
    size_t after = VIDEORTP_bufGetBytesWritten(payloadBuffer);

    // If this method was not supposed to be called anyway, the check above already failed.
    // In that case, the next check is redundant and can be skipped to reduce noise.
    if (m_nextChunkSize > 0)
        EXPECT_EQ(m_nextChunkSize, after - before) << "copyChunk must write exactly as much data as promised";

    // Need to call prepareNextChunk again before copying the next chunk
    m_nextChunkSize = 0;
}

// Verify that all chunks of the same payload unit have consistent metadata.
//
// This is intended for data generators, i.e., the earliest pipeline stages.
// Note that this is not applicable for some pipeline stages which return chunks
// out of order or combine multiple independent streams (like multiplexers).
//
//      CheckedGenerator<MyGeneratorStage> gen;
//      CheckedStage<MyPipelineStage1> pipe1;
//      CheckedStage<MyPipelineStage2> pipe2;
//      ...
//      InitMyGeneratorStage(&gen, ...);
//      InitMyPipelineStage1(&pipe1, &gen, ...);
//      InitMyPipelineStage1(&pipe1, &pipe2, ...);
//      ...
//
// A minor downside is that CheckedGenerator objects cannot be reused.
// Their fields will not be reset when calling init functions of the real
// pipeline stage, so they will get out of sync and have to be re-constructed.
template <typename PIPELINE_STAGE> struct CheckedGenerator : CheckedStage<PIPELINE_STAGE>
{
    CheckedGenerator()
    {
        m_prevChunkInfo.isPayloadUnitEnd = true;
        m_prevChunkInfo.sampleTimestamp = VIDEORTP_InvalidTimestamp;
    }

    size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData) override;
    void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer) override;

private:
    VIDEORTP_payloadChunkInfo_t m_prevChunkInfo = {}; // metadata of the most recently written chunk
    VIDEORTP_payloadChunkInfo_t m_nextChunkInfo = {}; // metadata of the next chunk to be written
    size_t m_totalWrittenSize = 0; // size of all chunks so far of the current payload unit
};

template <typename PIPELINE_STAGE>
size_t CheckedGenerator<PIPELINE_STAGE>::PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData)
{
    size_t nextChunkSize = CheckedStage<PIPELINE_STAGE>::PrepareNextChunk(maximumSize, metaData);

    if (nextChunkSize > 0)
    {
        m_nextChunkInfo = *metaData;

        // There must be no "gaps" between payload units
        EXPECT_EQ(m_prevChunkInfo.isPayloadUnitEnd, m_nextChunkInfo.isPayloadUnitStart);

        // All chunks must share the same payload unit metadata
        if (!m_prevChunkInfo.isPayloadUnitEnd)
        {
            EXPECT_EQ(m_prevChunkInfo.payloadUnitSize, m_nextChunkInfo.payloadUnitSize);
            EXPECT_EQ(m_prevChunkInfo.sampleTimestamp, m_nextChunkInfo.sampleTimestamp);
        }

        // Timestamps must be monotonically increasing
        if (m_prevChunkInfo.sampleTimestamp != VIDEORTP_InvalidTimestamp
            && m_nextChunkInfo.sampleTimestamp != VIDEORTP_InvalidTimestamp)
        {
            EXPECT_LE(m_nextChunkInfo.sampleTimestamp - m_prevChunkInfo.sampleTimestamp, 27000000);
        }
    }

    return nextChunkSize;
}

template <typename PIPELINE_STAGE> void CheckedGenerator<PIPELINE_STAGE>::CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer)
{
    size_t before = VIDEORTP_bufGetBytesWritten(payloadBuffer);
    CheckedStage<PIPELINE_STAGE>::CopyChunk(payloadBuffer);
    size_t after = VIDEORTP_bufGetBytesWritten(payloadBuffer);

    m_totalWrittenSize += after - before;
    EXPECT_LE(m_totalWrittenSize, m_nextChunkInfo.payloadUnitSize);

    // The whole payload unit must have been written (headers not included)
    if (m_nextChunkInfo.isPayloadUnitEnd)
    {
        EXPECT_EQ(m_totalWrittenSize, m_nextChunkInfo.payloadUnitSize);
        m_totalWrittenSize = 0;
    }

    m_prevChunkInfo = m_nextChunkInfo;
}

#endif
