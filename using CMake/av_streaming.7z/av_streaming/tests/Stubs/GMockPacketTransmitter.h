#ifndef GMOCK_PACKET_TRANSMITTER_H_INCLUDED
#define GMOCK_PACKET_TRANSMITTER_H_INCLUDED

#include <gmock/gmock.h>
#include <vector>

#include "PacketTransmitter.h"

namespace tests
{
struct MockPacketTransmitter : VIDEORTP_packetTransmitter_t
{
    MockPacketTransmitter();
    virtual ~MockPacketTransmitter()
    {
    }
    virtual VIDEORTP_bufferWriter_t* PrepareTransmissionBuffer();
    virtual VideoRTP_errorCode CommitTransmissionBuffer();
};

class GMockPacketTransmitter : public MockPacketTransmitter
{
public:
    MOCK_METHOD(VIDEORTP_bufferWriter_t*, PrepareTransmissionBuffer, (), (override));
    MOCK_METHOD(VideoRTP_errorCode, CommitTransmissionBuffer, (), (override));
};

struct DummyMockPacketTransmitter : public GMockPacketTransmitter
{
    DummyMockPacketTransmitter(const DummyMockPacketTransmitter& rhs) = delete;
    DummyMockPacketTransmitter& operator=(const DummyMockPacketTransmitter& rhs) = delete;

    std::vector<uint8_t> buffer {};
    VIDEORTP_bufferWriter_t writer {};

    explicit DummyMockPacketTransmitter(size_t bufferSize);
};
}

#endif
