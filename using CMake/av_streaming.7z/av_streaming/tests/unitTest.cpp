#include <gtest/gtest.h>

int main(int argc, char** argv)
{
    testing::InitGoogleTest(&argc, argv);
    int res = RUN_ALL_TESTS();

    std::cout << "result: " << res << std::endl;
    return res;
}

// https://google.github.io/googletest/advanced.html#sanitizer-integration
extern "C"
{
    void __wrap___ubsan_on_report()
    {
        FAIL() << "Encountered an undefined behavior sanitizer error";
    }

    void __wrap___asan_on_error()
    {
        FAIL() << "Encountered an address sanitizer error";
    }

    void __wrap___tsan_on_report()
    {
        FAIL() << "Encountered a thread sanitizer error";
    }
}
