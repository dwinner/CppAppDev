Misra coding rules (succinctly)
==================================

### In general
- Use english in comments;
- For reusable components like shared type definitions, defines etc. the file
  should be called someName_cfg.[h|c];
- One line has only one statement;
- Recursive functions are forbidden;
- Avoid implicit casting;
- One line has only one variable declaration;
- Avoid compiler warnings or supress them if you're sure of what you're doing; 

### Software Metrics
- No goto statements allowed;
- Max value for cyclomatic complexity = 15;
- Number of exit points = 1 (so had better declare return value once at the top);
- Maxumum number of function parameters = 5;
- Maximum number of statements in function = 100;
- Maximum nesting level in a function = 5;
- Maximum number of functions calling this function = 5;

### Style and Layout
- Tab and indentation are the 4 space characters;
- Maximum line width = 132;
- There is no space between unary operators (~byte, i++);
- There is a single space between binary operators (var1 = var2);
- File ends with an empty line;
- All operators with body must be surrounded by curly braces;
- Braces should always be on a separate line;
- Operators in a block have to be shifted by indentation;
- Use only C-style comments /**/;
- Comment must be placed on a separate line;

### Naming conventions
- Global function name must have a name <module_name>_<camelCase> (i.e. H264_createBitStream);
- Type definitions must have a name <module_name>_<camelCase>_t (i.e. H264_dataStream_t);
- Use cross platform data types (i.e. size_t instead of int);
- Global, static, volatile, constant variable must have a name <module_name>_<camelCase>
  (i.e. static int16_t CAN_missedMsgCnt);
- Local variables and parameters have camel case name (i.e. rawCount);
- Macros have a name like <MODULE_NAME>_UPPERCASE_WITH_UNDERSCORE (i.e. ADC_MAX_COUNT);
- enum, struct has a name like <MODULE_NAME>_camelCase, type def has _t suffix (CAN_errorTypes, CAN_errorTypes_t);
- enum constant has a name like <MODULE_NAME>_UPPERCASE_WITH_UNDERSCORE (CAN_ERROR_BUS_OFF);
- struct field has a name like camelCase (i.e. validData);