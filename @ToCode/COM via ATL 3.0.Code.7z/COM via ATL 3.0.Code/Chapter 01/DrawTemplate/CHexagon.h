// CHexagon.h: interface for the CHexagon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHEXAGON_H__B0CDED88_7C2B_11D3_A7DE_0000E885A202__INCLUDED_)
#define AFX_CHEXAGON_H__B0CDED88_7C2B_11D3_A7DE_0000E885A202__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CHexagon  
{
public:
	void Draw();
	CHexagon();
	virtual ~CHexagon();
};

#endif // !defined(AFX_CHEXAGON_H__B0CDED88_7C2B_11D3_A7DE_0000E885A202__INCLUDED_)
