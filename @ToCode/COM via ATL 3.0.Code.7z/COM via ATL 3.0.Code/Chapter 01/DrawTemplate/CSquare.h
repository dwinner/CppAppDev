// CSquare.h: interface for the CSquare class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CSQUARE_H__B0CDED87_7C2B_11D3_A7DE_0000E885A202__INCLUDED_)
#define AFX_CSQUARE_H__B0CDED87_7C2B_11D3_A7DE_0000E885A202__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSquare  
{
public:
	void Draw();
	CSquare();
	virtual ~CSquare();

};

#endif // !defined(AFX_CSQUARE_H__B0CDED87_7C2B_11D3_A7DE_0000E885A202__INCLUDED_)
