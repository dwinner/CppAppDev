// iids.cpp: implementation of the iids class.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <windows.h>
#include <initguid.h>
#include "iids.h"

