// iids.cpp: implementation of the iids class.
//
//////////////////////////////////////////////////////////////////////
#include <windows.h>
#include <initguid.h>
#include "iids.h"

