/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Oct 10 13:37:24 1999
 */
/* Compiler settings for C:\ATL\Labs\Chapter 12\ATL Events\ATLEvents.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IChild = {0xB2C94BC8,0xA582,0x11D2,{0xAA,0xD9,0x00,0xA0,0xC9,0x31,0x2D,0x57}};


const IID LIBID_ATLEVENTSLib = {0xB2C94BBC,0xA582,0x11D2,{0xAA,0xD9,0x00,0xA0,0xC9,0x31,0x2D,0x57}};


const IID DIID__IChildEvents = {0xB2C94BCA,0xA582,0x11D2,{0xAA,0xD9,0x00,0xA0,0xC9,0x31,0x2D,0x57}};


const CLSID CLSID_CoChild = {0xB2C94BC9,0xA582,0x11D2,{0xAA,0xD9,0x00,0xA0,0xC9,0x31,0x2D,0x57}};


#ifdef __cplusplus
}
#endif

