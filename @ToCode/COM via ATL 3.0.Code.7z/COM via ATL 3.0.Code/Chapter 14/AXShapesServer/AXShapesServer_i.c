/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Jan 02 21:44:06 2000
 */
/* Compiler settings for C:\My Documents\ATL\Labs\Chapter 14\AXShapesServer\AXShapesServer.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IShapesControl = {0x03FBA31F,0x71D1,0x11D3,{0xB9,0x2D,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID LIBID_AXSHAPESSERVERLib = {0x03FBA313,0x71D1,0x11D3,{0xB9,0x2D,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID DIID__IShapesControlEvents = {0x03FBA321,0x71D1,0x11D3,{0xB9,0x2D,0x00,0x20,0x78,0x12,0x38,0xD4}};


const CLSID CLSID_ShapesControl = {0x03FBA320,0x71D1,0x11D3,{0xB9,0x2D,0x00,0x20,0x78,0x12,0x38,0xD4}};


const CLSID CLSID_CoCusomPage = {0xC489E472,0x7391,0x11D3,{0xB9,0x2E,0x00,0x20,0x78,0x12,0x38,0xD4}};


#ifdef __cplusplus
}
#endif

