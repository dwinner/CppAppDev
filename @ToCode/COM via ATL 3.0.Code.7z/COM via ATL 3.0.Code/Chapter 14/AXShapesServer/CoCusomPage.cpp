// CoCusomPage.cpp : Implementation of CCoCusomPage
#include "stdafx.h"
#include "AXShapesServer.h"
#include "CoCusomPage.h"

/////////////////////////////////////////////////////////////////////////////
// CCoCusomPage

