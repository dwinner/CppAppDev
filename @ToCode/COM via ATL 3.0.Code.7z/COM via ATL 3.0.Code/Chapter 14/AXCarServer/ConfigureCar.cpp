// ConfigureCar.cpp : Implementation of CConfigureCar
#include "stdafx.h"
#include "AXCarServer.h"
#include "ConfigureCar.h"

/////////////////////////////////////////////////////////////////////////////
// CConfigureCar

