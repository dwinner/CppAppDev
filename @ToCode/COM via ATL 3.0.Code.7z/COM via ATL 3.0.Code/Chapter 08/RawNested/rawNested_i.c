/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Dec 28 21:41:59 1999
 */
/* Compiler settings for C:\My Documents\ATL\Labs\Chapter 08\RawNested\rawNested.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IDraw = {0xA533DA31,0xD372,0x11d2,{0xB8,0xCF,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID IID_IShapeID = {0xDD900363,0x2C02,0x11d3,{0xB9,0x01,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID LIBID_RawNested = {0xAD454EA3,0x2C15,0x11d3,{0xB9,0x01,0x00,0x20,0x78,0x12,0x38,0xD4}};


const CLSID CLSID_CoHexagon = {0xAD454EA0,0x2C15,0x11d3,{0xB9,0x01,0x00,0x20,0x78,0x12,0x38,0xD4}};


#ifdef __cplusplus
}
#endif

