/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Oct 03 12:10:24 1999
 */
/* Compiler settings for C:\Atl\Labs\Chapter 08\ATLTearOff\ATLTearOff.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICreateCar = {0xCDBDECB9,0x331E,0x11D3,{0xB9,0x04,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID IID_ICreate = {0x1FB21BF0,0x3CCE,0x11d3,{0xB9,0x10,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID IID_IStats = {0xA533DA31,0xD372,0x11d2,{0xB8,0xCF,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID IID_IEngine = {0xA533DA30,0xD372,0x11d2,{0xB8,0xCF,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID IID_IOwnerInfo = {0x530D7320,0x333E,0x11d3,{0xB9,0x04,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID LIBID_ATLTEAROFFLib = {0xD3DF9700,0x3676,0x11D3,{0xB9,0x05,0x00,0x20,0x78,0x12,0x38,0xD4}};


const CLSID CLSID_ATLCoCar = {0xE58B9C70,0x367D,0x11d3,{0xB9,0x05,0x00,0x20,0x78,0x12,0x38,0xD4}};


#ifdef __cplusplus
}
#endif

