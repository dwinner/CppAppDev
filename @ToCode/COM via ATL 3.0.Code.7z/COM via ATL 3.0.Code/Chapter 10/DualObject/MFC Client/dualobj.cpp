// Machine generated IDispatch wrapper class(es) created with ClassWizard

#include "stdafx.h"
#include "dualobj.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// ISquiggle properties

/////////////////////////////////////////////////////////////////////////////
// ISquiggle operations

void ISquiggle::DrawASquiggle()
{
	InvokeHelper(0x1, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void ISquiggle::FlipASquiggle()
{
	InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}

void ISquiggle::EraseASquiggle()
{
	InvokeHelper(0x3, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
}
