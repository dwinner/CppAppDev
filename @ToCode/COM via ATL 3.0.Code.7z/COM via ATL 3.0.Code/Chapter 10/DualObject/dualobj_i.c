/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Sun Nov 21 10:06:16 1999
 */
/* Compiler settings for C:\ATL\Labs\Chapter 10\DualObject\dualobj.idl:
    Os (OptLev=s), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ISquiggle = {0xBDFD41A0,0x580A,0x11d3,{0xB9,0x26,0x00,0x20,0x78,0x12,0x38,0xD4}};


const IID LIBID_DualObject = {0xBDFD41A1,0x580A,0x11d3,{0xB9,0x26,0x00,0x20,0x78,0x12,0x38,0xD4}};


const CLSID CLSID_CoDualSquiggle = {0xBDFD41A2,0x580A,0x11d3,{0xB9,0x26,0x00,0x20,0x78,0x12,0x38,0xD4}};


#ifdef __cplusplus
}
#endif

