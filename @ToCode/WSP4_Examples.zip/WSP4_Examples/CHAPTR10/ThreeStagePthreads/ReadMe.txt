This is the original version of ThreeStage, built to run using pthreads under 
UNIX. It has been run on several systems.

Suggestion: Try building and running with the Open Source pthreads Win32 library
mentioned in the text (You'll find it at the Red Hat web site).

The associated project is:

    WindowsSmpEd3\Projects6\ThreeStagePthreads

You can easily convert the project to Visual Studio 2005 or Visual Studio 7
-- Just use the Visual Studio's conversion feature.


