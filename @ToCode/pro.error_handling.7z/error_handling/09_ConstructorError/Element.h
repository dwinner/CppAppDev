#pragma once

class Element
{
private:
	int mValue;
};
