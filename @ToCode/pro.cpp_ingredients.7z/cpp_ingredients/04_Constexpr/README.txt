Compile each of the source files in this directory separately.


Microsoft Visual C++ 2013 does not yet support constexpr classes.