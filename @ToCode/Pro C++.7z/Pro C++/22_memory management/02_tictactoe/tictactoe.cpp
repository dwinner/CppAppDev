int main()
{
	char board[3][3];
	// Test code
	board[0][0] = 'X';   // X puts marker in position (0,0).
	board[2][1] = 'O';   // O puts marker in position (2,1).

	return 0;
}
