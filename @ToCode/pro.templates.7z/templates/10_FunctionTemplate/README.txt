Include the following combinations of files in your project:

FindTemplate.cpp and SpreadsheetCell.cpp
or
FindTemplateSpecialization.cpp
or
FindTemplateOverload.cpp
or
FindTemplateSpecialOverload.cpp
