# Assembly-Language-for-x86-processors---Kip-Irvine-solutions-for-parts-4-16-

This project contains solutions for the book of Kip Irvine (Parts 4 to 16).

All code was written and tested using VS2015 (thank you Microsoft), MASM32 and MASM16 (thank you Hutch, Iczelion and many many others).

OS: Win10, WinXP (DOS-emulation) and FreeDOS.

For the purpose of simplicity, if project contains several files (e.g. code written in C/C++ and code written in ASM), they all are combined in the same TXT file. 
