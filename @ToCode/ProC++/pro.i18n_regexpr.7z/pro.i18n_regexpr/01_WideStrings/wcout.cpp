#include <iostream>

using namespace std;

int main()
{
	wcout << L"I am wide-character aware." << endl;

	return 0;
}
