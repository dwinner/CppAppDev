Compile each of the source files in this directory separately.

Microsoft Visual C++ 2013 does not yet support equal() and mismatch() accepting four iterators.