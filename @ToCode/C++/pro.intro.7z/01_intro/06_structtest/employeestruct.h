#pragma once

struct Employee {
	char firstInitial;
	char lastInitial;
	int  employeeNumber;
	int  salary;
}; 
