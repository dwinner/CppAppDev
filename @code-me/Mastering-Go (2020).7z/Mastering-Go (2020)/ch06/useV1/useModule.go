package main

import (
	v1 "github.com/mactsouk/myModule"
)

func main() {
	v1.Version()
}

