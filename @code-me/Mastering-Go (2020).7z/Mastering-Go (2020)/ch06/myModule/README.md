# myModule
Sample Go module
