package main

import (
	v "github.com/mactsouk/myModule/v2"
)

func main() {
	v.Version()
}

