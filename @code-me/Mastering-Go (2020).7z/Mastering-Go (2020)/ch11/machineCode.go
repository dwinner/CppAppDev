package main

import (
	"fmt"
)

func hello() {
	fmt.Println("Hello!")
}

func main() {
	hello()
}
