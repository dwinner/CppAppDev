package main

import (
	"fmt"
)

func main() {
	fmt.Println("Creating WebAssembly code from Go!")
}
