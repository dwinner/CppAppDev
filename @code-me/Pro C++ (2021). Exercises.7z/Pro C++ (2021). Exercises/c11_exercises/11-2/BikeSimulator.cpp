module simulator;

import <iostream>;

using namespace Simulator;
using namespace std;

BikeSimulator::BikeSimulator()
{
	cout << "BikeSimulator::BikeSimulator()" << endl;
}
