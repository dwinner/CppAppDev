#include "StbM_stubs.h"
#include <map>
#include <utility>

namespace
{
std::map<StbM_SynchronizedTimeBaseType, std::pair<StbM_TimeStampType, StbM_UserDataType>> g_times;
}

void StbM_Reset(void)
{
    g_times.clear();
}

void StbM_SetCurrentTime(StbM_SynchronizedTimeBaseType timeBaseId, const StbM_TimeStampType* timeStamp,
                         const StbM_UserDataType* userData)
{
    if (timeStamp && userData)
        g_times[timeBaseId] = std::make_pair(*timeStamp, *userData);
    else
        g_times.erase(timeBaseId);
}

Std_ReturnType StbM_GetCurrentTime(StbM_SynchronizedTimeBaseType timeBaseId, StbM_TimeStampType* timeStamp,
                                   StbM_UserDataType* userData)
{
    auto i = g_times.find(timeBaseId);
    if (i == g_times.end())
        return E_NOT_OK;

    *timeStamp = i->second.first;
    *userData = i->second.second;
    return E_OK;
}
