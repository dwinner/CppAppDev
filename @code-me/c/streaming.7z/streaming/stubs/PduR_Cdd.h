#ifndef MAGNA_AUTOSAR_PDUR_CDD_H
#define MAGNA_AUTOSAR_PDUR_CDD_H

#include "ComStack_Types.h"

#ifdef __cplusplus
extern "C"
{
#endif

    Std_ReturnType PduR_CddTransmit(PduIdType TxPduId, const PduInfoType* PduInfoPtr);

#ifdef __cplusplus
}
#endif

#endif
