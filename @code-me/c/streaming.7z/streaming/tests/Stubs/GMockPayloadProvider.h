#ifndef GMOCK_PAYLOAD_PROVIDER_H_INCLUDED
#define GMOCK_PAYLOAD_PROVIDER_H_INCLUDED

#include <gmock/gmock.h>

#include "PayloadProvider.h"

namespace tests
{
struct MockPayloadProvider : VIDEORTP_payloadProvider_t
{
    MockPayloadProvider();
    virtual ~MockPayloadProvider()
    {
    }
    virtual size_t PrepareNextChunk(size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData);
    virtual void CopyChunk(VIDEORTP_bufferWriter_t* payloadBuffer);
};

class GMockPayloadProvider : public MockPayloadProvider
{
public:
    MOCK_METHOD(size_t, PrepareNextChunk, (size_t maximumSize, VIDEORTP_payloadChunkInfo_t* metaData), (override));
    MOCK_METHOD(void, CopyChunk, (VIDEORTP_bufferWriter_t * payloadBuffer), (override));
};
}

#endif
