#include "IpcCallbackMock.h"

IpcCallbackMock* IpcCallbackMock::mock = nullptr;

void ReleaseBufferCallback(void* buffer)
{
    ASSERT_NE(IpcCallbackMock::mock, nullptr);
    IpcCallbackMock::mock->ReleaseBuffer(buffer);
}

void InvalidReleaseBufferCallback(void*)
{
    ASSERT_TRUE(false);
}
