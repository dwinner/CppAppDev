#include "TestUtils.h"
#include "sysdef.h"
#include <gtest/gtest.h>

TEST(UtilTest, MinMax)
{
    TEST_DESCRIPTION("Test calculation of minimum and maximum values");

    EXPECT_EQ(VIDEORTP_sysGetMin(1, 2), 1);
    EXPECT_EQ(VIDEORTP_sysGetMax(1, 2), 2);

    EXPECT_EQ(VIDEORTP_sysGetMin(2, 1), 1);
    EXPECT_EQ(VIDEORTP_sysGetMax(2, 1), 2);

    EXPECT_EQ(VIDEORTP_sysGetMin(2, 2), 2);
    EXPECT_EQ(VIDEORTP_sysGetMax(2, 2), 2);
}

TEST(UtilTest, DivisionRoundingDown)
{
    TEST_DESCRIPTION("Test rounding down when dividing");

    EXPECT_EQ(VideoRTP_divideRoundDown(0, 2), 0);
    EXPECT_EQ(VideoRTP_divideRoundDown(1, 2), 0);
    EXPECT_EQ(VideoRTP_divideRoundDown(2, 2), 1);
    EXPECT_EQ(VideoRTP_divideRoundDown(3, 2), 1);
    EXPECT_EQ(VideoRTP_divideRoundDown(4, 2), 2);

    EXPECT_EQ(VideoRTP_divideRoundDown(999, 1000), 0);
    EXPECT_EQ(VideoRTP_divideRoundDown(1000, 1000), 1);
    EXPECT_EQ(VideoRTP_divideRoundDown(1001, 1000), 1);
}

TEST(UtilTest, DivisionRoundingUp)
{
    TEST_DESCRIPTION("Test rounding up when dividing");

    EXPECT_EQ(VideoRTP_divideRoundUp(0, 2), 0);
    EXPECT_EQ(VideoRTP_divideRoundUp(1, 2), 1);
    EXPECT_EQ(VideoRTP_divideRoundUp(2, 2), 1);
    EXPECT_EQ(VideoRTP_divideRoundUp(3, 2), 2);
    EXPECT_EQ(VideoRTP_divideRoundUp(4, 2), 2);

    EXPECT_EQ(VideoRTP_divideRoundUp(999, 1000), 1);
    EXPECT_EQ(VideoRTP_divideRoundUp(1000, 1000), 1);
    EXPECT_EQ(VideoRTP_divideRoundUp(1001, 1000), 2);
}
