#include <gtest/gtest.h>

#include "ConstantsMPEG.h"
#include "VideoRtpUtil.h"

#include "TestUtils.h"

TEST(StbmTest, ConvertsNanoseconds)
{
    TEST_DESCRIPTION("Check that nanoseconds from StbM timestamps can be converted to MPEG timestamps");

    StbM_TimeStampType ts = { 0, 0, 0, 0 };
    uint64_t mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, 0);

    // 1/27MHz = 37.037... ns

    ts.nanoseconds = 37;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, 0);

    ts.nanoseconds = 38;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, 1);

    // Test some fractions

    ts.nanoseconds = 200000000;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE / 5);

    ts.nanoseconds = 250000000;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE / 4);

    ts.nanoseconds = 500000000;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE / 2);

    ts.nanoseconds = 333333333;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE / 3 - 1);

    ts.nanoseconds = 666666666;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE * 2 / 3 - 1);

    ts.nanoseconds = 999999999;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE - 1);
}

TEST(StbmTest, ConvertsSeconds)
{
    TEST_DESCRIPTION("Check that seconds from StbM timestamps can be converted to MPEG timestamps");

    StbM_TimeStampType ts = { 0, 0, 0, 0 };
    uint64_t mpeg = 0;

    ts.seconds = 1;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE);

    ts.seconds = 100;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE * 100);

    ts.seconds = 10000;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE * 10000);

    // Test overflow of seconds

    ts.seconds = UINT32_C(0xFFFFFFFF);
    ts.secondsHi = 0;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE * UINT64_C(0xFFFFFFFF));

    ts.seconds = 0;
    ts.secondsHi = 1;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, VIDEORTP_CLOCK_RATE * UINT64_C(0x100000000));
}

TEST(StbmTest, DoesNotOverflow)
{
    TEST_DESCRIPTION("Check that MPEG timestamps cannot overflow StbM timestamps");

    uint64_t pcrMax = UINT64_C(300) << 33;
    StbM_TimeStampType ts = { 0 };
    ts.nanoseconds = (pcrMax % VIDEORTP_CLOCK_RATE) * 1000000000 / VIDEORTP_CLOCK_RATE;
    ts.seconds = pcrMax / VIDEORTP_CLOCK_RATE;
    ts.secondsHi = (pcrMax / VIDEORTP_CLOCK_RATE) >> 32;

    uint64_t mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, pcrMax - 1);
}

TEST(StbmTest, CheckOverflow)
{
    TEST_DESCRIPTION("Check overflow of MPEG timestamps");

    StbM_TimeStampType ts = { 0, 0, UINT32_MAX, UINT16_MAX };
    uint64_t mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_EQ(mpeg, (VIDEORTP_CLOCK_RATE * UINT64_C(0xFFFFFFFFFFFF)) & UINT64_MAX);

    ts.nanoseconds = 999999999;
    mpeg = VIDEORTP_convertTimestamp(&ts);
    EXPECT_NE(mpeg, VIDEORTP_InvalidTimestamp);
    EXPECT_EQ(mpeg, ((VIDEORTP_CLOCK_RATE << 48) - 1) & UINT64_MAX);
}
