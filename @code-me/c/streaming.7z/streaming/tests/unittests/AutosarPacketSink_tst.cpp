#include <gtest/gtest.h>
#include <vector>

#include "AutosarPacketSink.h"
#include "BufferWriter.h"
#include "PacketTransmitter.h"
#include "TestUtils.h"
#include <PduR_Cdd_stubs.h>

// Helper class which opens a PDU
class AutosarPacketSinkTest : public ::testing::Test
{
protected:
    VIDEORTP_asrPacketSink_t sock {};
    AutosarPdu pdu;
    std::string recvBuf;

    void SetUp() override
    {
        // initialize target PDU
        VIDEORTP_asrInitPacketSink(&sock, pdu.GetId());
    }

    // read a packet from the destination PDU
    int Receive()
    {
        auto buf = pdu.GetTransmittedPacket();
        EXPECT_FALSE(buf.empty());
        // Note: this adds a NUL terminator
        recvBuf = { buf.begin(), buf.end() };
        return (int) recvBuf.length();
    }
};

TEST_F(AutosarPacketSinkTest, ClearsNewTransmissionBuffers)
{
    TEST_DESCRIPTION("TEST for check clear buffer after prepare");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);

    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', 10));

    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);
}

TEST_F(AutosarPacketSinkTest, CanTransferSmallPackets)
{
    TEST_DESCRIPTION("TEST for check transmitting small data");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // send first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive first message
    EXPECT_EQ(Receive(), strlen(msg1));
    EXPECT_STREQ(msg1, recvBuf.data());

    // send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive second message
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf.data());
}

TEST_F(AutosarPacketSinkTest, DiscardsUncommittedBuffer)
{
    TEST_DESCRIPTION("TEST for check that preparing buffer discard old message");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // prepare first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    // don't send it

    // discard first message and send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive second message only
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf.data());
}

TEST_F(AutosarPacketSinkTest, SupportsMinimalMtu)
{
    TEST_DESCRIPTION("TEST for check size according mininum MTU");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);

    // maximum transfer size = minimum MTU size - UDP header - IPv6 header [IP_AVT_1562]
    EXPECT_LE(VIDEORTP_MAX_TX_PAYLOAD_SIZE, 1232);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(buffer), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
}

TEST_F(AutosarPacketSinkTest, CanTransferLargePackets)
{
    TEST_DESCRIPTION("TEST for check transmitting large data");
    // send packet
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive packet
    EXPECT_EQ(Receive(), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
    EXPECT_TRUE(ContainsPattern(recvBuf.data(), 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
}

TEST_F(AutosarPacketSinkTest, DoesNotCrashOnError)
{
    TEST_DESCRIPTION("Check that the transmitter doesn't crash after error");
    // Note: The stub returns an error for empty packets.
    PduInfoType data {};
    ASSERT_NE(PduR_CddTransmit(pdu.GetId(), &data), E_OK);

    VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_EQ(VideoRTP_networkError, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));
    EXPECT_TRUE(pdu.GetTransmittedPacket().empty());
}
