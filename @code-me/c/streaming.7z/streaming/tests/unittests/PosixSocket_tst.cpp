#include <gtest/gtest.h>

#include "BufferWriter.h"
#include "PacketTransmitter.h"
#include "PosixSocket.h"
#include "TestUtils.h"

// Helper class which opens a socket connection
class PosixSocketTransferTest : public ::testing::Test
{
    static constexpr const char* HOSTNAME = "localhost";

protected:
    VIDEORTP_posixSocket_t sock {};
    SOCKET recvSock { INVALID_SOCKET };
    char recvBuf[VIDEORTP_MAX_TX_PAYLOAD_SIZE + 1] {};

    PosixSocketTransferTest()
    {
        sock.m_socket = INVALID_SOCKET;
    }

    static void SetUpTestSuite()
    {
        WSAData ver;
        ASSERT_EQ(WSAStartup(MAKEWORD(2, 2), &ver), 0);
        ASSERT_EQ(ver.wVersion, MAKEWORD(2, 2));
    }

    static void TearDownTestSuite()
    {
        WSACleanup();
    }

    void SetUp() override
    {
        // Allow any protocol family
        addrinfo hints = { 0 };
        hints.ai_family = AF_UNSPEC;
        hints.ai_socktype = SOCK_DGRAM;
        hints.ai_protocol = IPPROTO_UDP;

        // Let the OS pick an unused port so that multiple tests can run in parallel
        addrinfo* ai = NULL;
        ASSERT_EQ(getaddrinfo(HOSTNAME, nullptr, &hints, &ai), 0) << "Could not resolve localhost";
        std::unique_ptr<addrinfo, void(WSAAPI*)(addrinfo*)> freeAddress(ai, freeaddrinfo);

        recvSock = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        ASSERT_NE(recvSock, INVALID_SOCKET) << "Could not create receiver socket";
        ASSERT_EQ(bind(recvSock, ai->ai_addr, ai->ai_addrlen), 0) << "Could not bind receiver socket";

        // Get the assigned port
        sockaddr addr;
        int addrlen = sizeof(addr);
        ASSERT_EQ(getsockname(recvSock, &addr, &addrlen), 0) << "Could not get receiver address";

        char port[NI_MAXSERV] = "";
        ASSERT_EQ(getnameinfo(&addr, addrlen, nullptr, 0, port, sizeof(port), NI_NUMERICSERV | NI_DGRAM), 0)
            << "Could not get receiver port";

        // Connect sender socket
        VIDEORTP_sockInit(&sock, HOSTNAME, strtoul(port, nullptr, 10));
        ASSERT_NE(sock.m_socket, INVALID_SOCKET) << "Could not create sender socket";
    }

    // read a packet from the destination socket
    int Receive()
    {
        memset(recvBuf, 0, sizeof(recvBuf));
        int len = recv(recvSock, recvBuf, VIDEORTP_MAX_TX_PAYLOAD_SIZE, 0);
        EXPECT_GT(len, 0);
        return len;
    }

    void TearDown() override
    {
        // close sockets
        closesocket(recvSock);
        VIDEORTP_sockDeinit(&sock);
    }
};

TEST_F(PosixSocketTransferTest, ClearsNewTransmissionBuffers)
{
    TEST_DESCRIPTION("TEST for check the clearing of new transfer buffers");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);

    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', 10));

    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(buffer), 0);
}

TEST_F(PosixSocketTransferTest, CanTransferSmallPackets)
{
    TEST_DESCRIPTION("TEST for check transmitting small data");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // send first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive first message
    EXPECT_EQ(Receive(), strlen(msg1));
    EXPECT_STREQ(msg1, recvBuf);

    // send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive second message
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf);
}

TEST_F(PosixSocketTransferTest, DiscardsUncommittedBuffer)
{
    TEST_DESCRIPTION("TEST for check that preparing buffer discard old message");
    char msg1[] = "Hello World";
    char msg2[] = "Lorem ipsum ...";

    // prepare first message
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg1, strlen(msg1)));
    // don't send it

    // discard first message and send second message
    buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWriteData(buffer, msg2, strlen(msg2)));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive second message only
    EXPECT_EQ(Receive(), strlen(msg2));
    EXPECT_STREQ(msg2, recvBuf);
}

TEST_F(PosixSocketTransferTest, SupportsMinimalMtu)
{
    TEST_DESCRIPTION("TEST for check size according mininum MTU");
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);

    // maximum transfer size = minimum MTU size - UDP header - IPv6 header [IP_AVT_1562]
    EXPECT_LE(VIDEORTP_MAX_TX_PAYLOAD_SIZE, 1232);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(buffer), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
}

TEST_F(PosixSocketTransferTest, CanTransferLargePackets)
{
    TEST_DESCRIPTION("TEST for check transmitting large data");
    // send packet
    VIDEORTP_bufferWriter_t* buffer = VIDEORTP_txPrepareTransmissionBuffer(&sock.vtable);
    ASSERT_NE(buffer, nullptr);
    EXPECT_TRUE(VIDEORTP_bufWritePattern(buffer, 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&sock.vtable));

    // receive packet
    EXPECT_EQ(Receive(), VIDEORTP_MAX_TX_PAYLOAD_SIZE);
    EXPECT_TRUE(ContainsPattern(recvBuf, 'x', VIDEORTP_MAX_TX_PAYLOAD_SIZE));
}
