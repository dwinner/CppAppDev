#include "DummyPacketMemoryWriter.h"
#include "TestUtils.h"
#include <gtest/gtest.h>

TEST(VIDEORTP_dummyPacketMemoryWriter_t, INIT)
{
    TEST_DESCRIPTION("TEST for check initialization of PacketTransmitter implementation example");
    VIDEORTP_dummyPacketMemoryWriter_t transmitter;
    VIDEORTP_dmwInit(&transmitter);
    VIDEORTP_bufferWriter_t* bw = VIDEORTP_txPrepareTransmissionBuffer(&(transmitter.vtable));
    size_t availableSpaceBefore = VIDEORTP_bufGetAvailableSpace(bw);
    EXPECT_EQ(availableSpaceBefore, VIDEORTP_MAX_TX_PAYLOAD_SIZE);
}

TEST(VIDEORTP_dummyPacketMemoryWriter_t, ERROR)
{
    TEST_DESCRIPTION("TEST for check wrong usage of PacketTransmitter");
    EXPECT_DEATH(VIDEORTP_txCommitTransmissionBuffer(nullptr), "");
}

TEST(VIDEORTP_dummyPacketMemoryWriter_t, COMMIT_BUFFER)
{
    TEST_DESCRIPTION("TEST for check transmission data from PacketTransmitter");
    VIDEORTP_dummyPacketMemoryWriter_t transmitter;
    VIDEORTP_dmwInit(&transmitter);

    VIDEORTP_bufferWriter_t* bw = VIDEORTP_txPrepareTransmissionBuffer(&(transmitter.vtable));
    EXPECT_TRUE(VIDEORTP_bufWritePattern(bw, 1, 200));
    EXPECT_TRUE(VIDEORTP_bufWritePattern(bw, 2, 300));
    EXPECT_TRUE(VIDEORTP_bufWritePattern(bw, 3, VIDEORTP_MAX_TX_PAYLOAD_SIZE - 500));

    ASSERT_EQ(VideoRTP_ok, VIDEORTP_txCommitTransmissionBuffer(&(transmitter.vtable)));
    uint8_t* loadBufer = VIDEORTP_dmwGetLoadBuffer(&transmitter);
    for (int i = 0; i < VIDEORTP_MAX_TX_PAYLOAD_SIZE; i++)
    {
        if (i < 200)
        {
            EXPECT_EQ(loadBufer[i], 1);
        }
        else if (i < 500)
        {
            EXPECT_EQ(loadBufer[i], 2);
        }
        else if (i < VIDEORTP_MAX_TX_PAYLOAD_SIZE)
        {
            EXPECT_EQ(loadBufer[i], 3);
        }
    }
}
