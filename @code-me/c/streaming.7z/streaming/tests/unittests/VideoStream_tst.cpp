#include "Stubs/IpcCallbackMock.h"
#include <AutosarPacketSink.h>
#include <PayloadUnitSequenceRepeater.h>
#include <PduR_Cdd_stubs.h>
#include <StbM_stubs.h>
#include <VideoStream.h>

#include "TestUtils.h"
#include <gtest/gtest.h>
#include <vector>

class VideoStreamTest : public ::testing::Test
{
protected:
    AutosarPdu pdu;
    VIDEORTP_asrPacketSink_t socket;
    std::vector<uint8_t> buf;

    VIDEORTP_payloadUnit_t testFrame1 = { "Hello, World!", 13 };
    VIDEORTP_payloadUnit_t testFrame2 = { "Lorem Ipsum", 11 };

    VIDEORTP_videoStream_t stream = {};
    VIDEORTP_videoStreamConfig_t config = {};

    VideoStreamTest()
    {
        config.cyclicInterval = 10;
        config.targetDataRate = 6000000;
        config.targetFrameRate = 30;
        config.tableConfig.interval = 100;
        config.ipcInputConfig.tsPid = 0x100;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
        config.staticInputConfig.tsPid = config.ipcInputConfig.tsPid;
        config.staticInputConfig.fps = 25;
#endif
        VIDEORTP_asrInitPacketSink(&socket, pdu.GetId());
    }

    void SetUp() override
    {
        // Set a timestamp to avoid an endless loop of dummy PCR packets
        StbM_TimeStampType timeStamp = { 0 };
        StbM_UserDataType userData = { 0 };
        StbM_SetCurrentTime(0, &timeStamp, &userData);
    }

    void TearDown() override
    {
        StbM_SetCurrentTime(0, nullptr, nullptr);
    }

    size_t Receive(bool mayFail = true)
    {
        buf = pdu.GetTransmittedPacket();
        if (buf.empty() && mayFail)
            return 0;
        EXPECT_FALSE(buf.empty());

        // Check RTP packet (12 bytes header + n * 188 bytes TS packet)
        EXPECT_GT(buf.size(), 12);
        EXPECT_EQ((buf.size() - 12) % 188, 0);
        EXPECT_EQ(buf.at(0), 0x80);
        // the rest should be checked in RTP the packetizer test

        return buf.size();
    }

    // Check that the packet contains an MPEG-TS packet with video data
    void CheckVideoPacket(const VIDEORTP_payloadUnit_t& expected)
    {
        VideoRTP_errorCode err = VIDEORTP_cyclicVideoStream(&stream);
        ASSERT_TRUE(err == VideoRTP_ok || err == VideoRTP_queueEmpty);

        while (Receive())
        {
            for (int i = 12; i + 188 <= buf.size(); i += 188)
            {
                ASSERT_EQ(buf.at(i + 0), 0x47) << "Invalid SYNC byte";

                // Payload unit start? (PID=0x0100)
                if (buf.at(i + 1) != 0x41 || buf.at(i + 2) != 0x00)
                    continue;

                // Verify payload
                // Skip TS header + PES header
                size_t header = 4 + 14;
                // Skip adaptation field with PCR and stuffing
                if (buf.at(i + 3) & 0x20)
                    header += 1 + buf.at(i + 4);
                ASSERT_EQ(0, memcmp(expected.buffer, buf.data() + i + header, expected.length));

                SUCCEED();
                return;
            }
        }

        FAIL() << "Video MPEG-TS packet not found";
    }

    void ReadFromIpc(const VIDEORTP_payloadUnit_t& expected)
    {
        IpcCallbackMock mockCallback;

        VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
        EXPECT_EQ(Receive(true), 0);

        VIDEORTP_timestamp timestamp = { 12345, 12345 };
        ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, expected.length, &timestamp));
        ASSERT_TRUE(VIDEORTP_appendFrameVideoStream(&stream, expected.buffer, expected.length, ReleaseBufferCallback));
        EXPECT_CALL(mockCallback, ReleaseBuffer).Times(1);
        CheckVideoPacket(testFrame1);

        VIDEORTP_timestamp timestamp2 = { 23456, 23456 };
        ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, expected.length, &timestamp2));
        ASSERT_TRUE(VIDEORTP_appendFrameVideoStream(&stream, expected.buffer, expected.length, ReleaseBufferCallback));
        EXPECT_CALL(mockCallback, ReleaseBuffer).Times(1);
        VIDEORTP_deinitVideoStream(&stream);
    }
};

TEST_F(VideoStreamTest, UsesIpcInput)
{
    TEST_DESCRIPTION("Check that a video can be read from IPC");

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputDisabled)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is disabled");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = false;
    config.staticInputConfig.payloadUnits = &testFrame2;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputMissing)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is missing");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = nullptr;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, FallsBackToIpcIfStaticInputEmpty)
{
    TEST_DESCRIPTION("Check that a video will be read from IPC if static input is disabled");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = &testFrame2;
    config.staticInputConfig.payloadUnitCount = 0;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    ReadFromIpc(testFrame1);
}

TEST_F(VideoStreamTest, UsesStaticInput)
{
    TEST_DESCRIPTION("Check that a video can be read via static input stream");

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    config.isStaticInputEnabled = true;
    config.staticInputConfig.payloadUnits = &testFrame1;
    config.staticInputConfig.payloadUnitCount = 1;
#else
    GTEST_SKIP() << "Static input is disabled";
#endif

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
    EXPECT_EQ(Receive(true), 0);

    CheckVideoPacket(testFrame1);

    IpcCallbackMock mockCallback;
    EXPECT_CALL(mockCallback, ReleaseBuffer).Times(0);

    // IPC is overridden by static input, so all data should be rejected.
    VIDEORTP_timestamp timestamp = { 12345 };
    ASSERT_FALSE(VIDEORTP_startFrameVideoStream(&stream, testFrame2.length, &timestamp));
    ASSERT_FALSE(VIDEORTP_appendFrameVideoStream(&stream, testFrame2.buffer, testFrame2.length, ReleaseBufferCallback));

    VIDEORTP_deinitVideoStream(&stream);
}

TEST_F(VideoStreamTest, LimitsPackets)
{
    TEST_DESCRIPTION("Check packet limits of RTP stream");

    struct LimitsPacketsTest
    {
        uint32_t cyclicInterval;
        uint32_t targetDataRate;
        uint32_t targetFrameRate;
        uint32_t packetsPerCycle;
    } tests[] = {
        // For 6mbit/s: Send 4.2 MPEG-TS packets per ms on average; max. 6 TS packets per RTP packet
        { 1, 6000000, 30, 1 },

        // Send more packets when called less often
        { 2, 6000000, 30, 2 },
        { 3, 6000000, 30, 3 },
        { 4, 6000000, 30, 3 },
        { 5, 6000000, 30, 4 },
        { 6, 6000000, 30, 5 },

        // Send more packets when bandwidth increases
        { 1, 12000000, 30, 2 },
        { 1, 18000000, 30, 3 },
        { 1, 24000000, 30, 3 },
        { 1, 30000000, 30, 4 },
        { 1, 36000000, 30, 5 },

        // Call less often and increase bandwidth
        { 2, 12000000, 30, 3 }, // 4x
        { 2, 18000000, 30, 5 }, // 6x
        { 3, 12000000, 30, 5 }, // 6x
        { 3, 18000000, 30, 7 }, // 9x

        // Send more packets when overhead increases
        { 1, 6000000 * 60 / 42, 15, 1 },
        { 1, 6000000 * 60 / 42, 60, 2 },
    };

    for (const auto& test : tests)
    {
        config.cyclicInterval = test.cyclicInterval;
        config.targetDataRate = test.targetDataRate;
        config.targetFrameRate = test.targetFrameRate;

        VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);

        EXPECT_EQ(stream.packetsPerCycle, test.packetsPerCycle) << "interval=" << test.cyclicInterval << ", "
                                                                << "bandwidth=" << test.targetDataRate << ", "
                                                                << "fps=" << test.targetFrameRate;
    }
}

TEST_F(VideoStreamTest, LimitsToOnePacket)
{
    TEST_DESCRIPTION("Check that a video stream limits RTP packets");

    config.cyclicInterval = 1;
    config.targetDataRate = 6000000;
    config.targetFrameRate = 15;

    std::vector<uint8_t> dummyData(1500, 0xAB);
    VIDEORTP_timestamp timestamp = { 10, 20, 30, 40 };

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);

    // Expect only one packet per call
    for (int i = 0; i < 1000; ++i)
    {
        VIDEORTP_startFrameVideoStream(&stream, dummyData.size(), &timestamp);
        VIDEORTP_appendFrameVideoStream(&stream, dummyData.data(), dummyData.size(), nullptr);
        VIDEORTP_cyclicVideoStream(&stream);
        EXPECT_TRUE(Receive());
        EXPECT_FALSE(Receive());
    }
}

TEST_F(VideoStreamTest, LimitsToTwoPacket)
{
    TEST_DESCRIPTION("Check that a video stream limits RTP packets");

    config.cyclicInterval = 1;
    config.targetDataRate = 6000000 * 2; // double the data rate
    config.targetFrameRate = 30;

    std::vector<uint8_t> dummyData(1500, 0xAB);
    VIDEORTP_timestamp timestamp = { 10, 20, 30, 40 };

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);

    // Expect two packet per call
    for (int i = 0; i < 1000; ++i)
    {
        VIDEORTP_startFrameVideoStream(&stream, dummyData.size(), &timestamp);
        VIDEORTP_appendFrameVideoStream(&stream, dummyData.data(), dummyData.size(), nullptr);
        VIDEORTP_cyclicVideoStream(&stream);
        EXPECT_TRUE(Receive());
        EXPECT_TRUE(Receive());
        EXPECT_FALSE(Receive());
    }
}

TEST_F(VideoStreamTest, HandlesBandwidth)
{
    TEST_DESCRIPTION("Check that the target bandwidth can be handled");

    config.cyclicInterval = 1;
    config.targetDataRate = 6000000;
    config.targetFrameRate = 15;
    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);

    // Expect that all frames have been processed by the end of this function
    IpcCallbackMock mockCallback;
    EXPECT_CALL(mockCallback, ReleaseBuffer).Times(config.targetFrameRate);

    // Add frames for 1 second
    std::vector<uint8_t> dummyData(config.targetDataRate / 8 / config.targetFrameRate);
    VIDEORTP_timestamp timestamp = { 10, 20, 30, 40 };
    for (int frame = 0; frame < config.targetFrameRate; ++frame)
    {
        VIDEORTP_startFrameVideoStream(&stream, dummyData.size(), &timestamp);
        VIDEORTP_appendFrameVideoStream(&stream, dummyData.data(), dummyData.size(), ReleaseBufferCallback);
    }

    // Let it run for 1 second
    int totalSize = 0;
    for (int i = 0; i < 1000 / config.cyclicInterval; ++i)
    {
        VIDEORTP_cyclicVideoStream(&stream);
        while (int size = Receive())
        {
            totalSize += size;
        }
    }

    ASSERT_GE(totalSize, config.targetDataRate / 8);
}

TEST_F(VideoStreamTest, DoesNotReturnErrorOnEmptyQueue)
{
    TEST_DESCRIPTION("Check that a video stream does not return errors if some packets could be transferred");

    config.cyclicInterval = 10;
    config.targetDataRate = 6000000;
    config.targetFrameRate = 15;

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
    ASSERT_GT(stream.packetsPerCycle, 5);

    // Send one packet (MPEG PAT/PMT)
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_TRUE(Receive());
    ASSERT_FALSE(Receive());

    // No more packets; no more video data available
    ASSERT_EQ(VideoRTP_queueEmpty, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_FALSE(Receive());

    // Add data for two RTP packets
    std::vector<uint8_t> dummyData(2000, 0xAB);
    VIDEORTP_timestamp timestamp = { 10, 20, 30, 40 };
    ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, dummyData.size(), &timestamp));
    ASSERT_TRUE(VIDEORTP_appendFrameVideoStream(&stream, dummyData.data(), dummyData.size(), nullptr));

    // Send packets, but do not return an error just because the queue is depleted
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_TRUE(Receive());
    ASSERT_TRUE(Receive());
    ASSERT_FALSE(Receive());

    // Return an error only if the queue is completely empty
    ASSERT_EQ(VideoRTP_queueEmpty, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_FALSE(Receive());
}

TEST_F(VideoStreamTest, ReturnsNetworkError)
{
    TEST_DESCRIPTION("Check that a video stream returns the real network error code even if some packets could be transferred");

    config.cyclicInterval = 10;
    config.targetDataRate = 6000000;
    config.targetFrameRate = 15;

    VIDEORTP_initVideoStream(&stream, &socket.vtable, nullptr, &config);
    ASSERT_GT(stream.packetsPerCycle, 5);

    // Add data for many RTP packets
    std::vector<uint8_t> dummyData(20000, 0xAB);
    VIDEORTP_timestamp timestamp = { 10, 20, 30, 40 };
    ASSERT_TRUE(VIDEORTP_startFrameVideoStream(&stream, dummyData.size(), &timestamp));
    ASSERT_TRUE(VIDEORTP_appendFrameVideoStream(&stream, dummyData.data(), dummyData.size(), nullptr));

    // Return an error immediately
    pdu.SetResult(E_NOT_OK, 0);
    ASSERT_EQ(VideoRTP_networkError, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_FALSE(Receive());

    // Fail when sending the fourth packet
    pdu.SetResult(E_NOT_OK, 3);
    ASSERT_EQ(VideoRTP_networkError, VIDEORTP_cyclicVideoStream(&stream));
    ASSERT_TRUE(Receive());
    ASSERT_TRUE(Receive());
    ASSERT_TRUE(Receive());
    ASSERT_FALSE(Receive());
}
