#include "../VideoStream/VideoTestStream.h"
#include "TestUtils.h"
#include "VideoStream.h"
#include <gtest/gtest.h>

// This transmitter can accumulate all packets
typedef struct
{
    // packet transmitter interface
    VIDEORTP_packetTransmitter_t vtable;
    // current packet buffer
    uint8_t buffer[1232];
    // current packet buffer
    VIDEORTP_bufferWriter_t bw;
    // accumulator of packets
    std::vector<std::vector<uint8_t>> dump;

} packetTransmitterDump_t;

static VIDEORTP_bufferWriter_t* dumpTXPrepareTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    packetTransmitterDump_t* self = (packetTransmitterDump_t*) ((void*) vtable);

    VIDEORTP_bufClear(&self->bw);
    return &self->bw;
}

static VideoRTP_errorCode dumpTXCommitTransmissionBuffer(VIDEORTP_packetTransmitter_t* vtable)
{
    packetTransmitterDump_t* self = (packetTransmitterDump_t*) ((void*) vtable);
    self->dump.push_back(std::vector<uint8_t>(VIDEORTP_bufGetBytesWritten(&self->bw)));
    memcpy(self->dump.back().data(), self->buffer, VIDEORTP_bufGetBytesWritten(&self->bw));
    return VideoRTP_ok;
}

static void dumpTXInit(packetTransmitterDump_t* self)
{
    self->vtable.prepareTransmissionBuffer = dumpTXPrepareTransmissionBuffer;
    self->vtable.commitTransmissionBuffer = dumpTXCommitTransmissionBuffer;

    VIDEORTP_bufInit(&self->bw, self->buffer, 1232);
}

static void checkNoPAT(const std::vector<uint8_t>& data)
{
    // TS header
    EXPECT_EQ(data.at(0), 0x47); // sync byte

    // Program Association Table
    uint8_t patSample[] = { VIDEORTP_DEFAULT_MPEGTS_PROGRAM, 0xC1, 0x00, 0x00 };
    EXPECT_NE(0, memcmp(patSample, data.data() + 9, sizeof(patSample)));
}

static void checkNoPMT(const std::vector<uint8_t>& data)
{
    // TS header
    EXPECT_EQ(data.at(0), 0x47); // sync byte

    // Program Map Table
    uint8_t pmtSample[]
        = { 0xC1, 0x00, 0x00, 0xE0 | (VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID >> 8), (uint8_t) VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID };

    EXPECT_NE(0, memcmp(pmtSample, data.data() + 10, sizeof(pmtSample)));
}

static void checkPAT(const std::vector<uint8_t>& data)
{
    // TS header
    EXPECT_EQ(data.at(0), 0x47); // sync byte
    EXPECT_EQ(data.at(1), 0x40); // PUSI flag + PID 0
    EXPECT_EQ(data.at(2), 0x00); // PID 0
    // EXPECT_EQ(data.at(3), 0x10); // payload only
    EXPECT_EQ(data.at(4), 0x00); // PAT 0

    // Program Association Table
    EXPECT_EQ(data.at(5), 0x00); // table id

    EXPECT_EQ(data.at(9), VIDEORTP_DEFAULT_MPEGTS_PROGRAM); // transport stream id
    EXPECT_EQ(data.at(10), 0xC1); // versionNumber
    EXPECT_EQ(data.at(11), 0x00); // sectionNumber
    EXPECT_EQ(data.at(12), 0x00); // lastSectionNumber
}

static void checkPMT(const std::vector<uint8_t>& data)
{
    // TS header
    EXPECT_EQ(data.at(0), 0x47); // sync byte
    EXPECT_EQ(data.at(1), 0x50); // PUSI flag + PID 0x1000
    EXPECT_EQ(data.at(2), 0x00); // PID 0x1000
    // EXPECT_EQ(data.at(3), 0x10); // payload only
    EXPECT_EQ(data.at(4), 0x00); // PMT 2

    // Program Map Table
    EXPECT_EQ(data.at(5), 0x02); // table id

    EXPECT_EQ(data.at(10), 0xC1); // version number
    EXPECT_EQ(data.at(11), 0x00); // section number
    EXPECT_EQ(data.at(12), 0x00); // last section number
    EXPECT_EQ(data.at(13), 0xE0 | (VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID >> 8)); // PCR PID
    EXPECT_EQ(data.at(14), (uint8_t) VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID); // PCR PID
}

static void checkNewTS(const std::vector<uint8_t>& data)
{
    // First video packet
    EXPECT_EQ(data.at(0), 0x47); // sync byte
    EXPECT_EQ(data.at(1), 0x41); // PUSI flag + PID 0x0100
    EXPECT_EQ(data.at(2), 0x00); // PID 0x0100
}

class PreGenVideoTest : public ::testing::Test
{
protected:
    std::vector<uint8_t> testData;
    std::vector<VIDEORTP_payloadUnit_t> testFrames;

    VIDEORTP_videoStream_t videoStream;
    VIDEORTP_videoStreamConfig_t videoConfig;

    packetTransmitterDump_t dump;
    std::vector<std::vector<uint8_t>> packets;

    uint64_t offset = 0;
    uint64_t unitCounter = 0;
    bool padding = false;
    uint64_t paddingCounter = 0;

    // Generate some random test data and some payload units with random sizes
    void initTestFrames()
    {
        testData.reserve(20000);
        for (int i = 0; i < 10000; ++i)
        {
            testData.push_back(i);
            testData.push_back(i >> 5);
        }
        for (int i = 0; i < 100; ++i)
        {
            size_t len = (i * 129) % (testData.size() / 10) + 10;
            ptrdiff_t start = (i * 59) % (testData.size() - len);
            testFrames.push_back({ testData.data() + start, len });
        }
    }

    void initConfig()
    {
        memset(&videoConfig, 0, sizeof(videoConfig));

        videoConfig.rtpConfig.payloadType = 33; /* for MPEG-TS (VIDEORTP_rtpStreamingMode_RFC2250) */
        videoConfig.rtpConfig.deliveryCompensationOffset = (uint32_t) VIDEORTP_DEFAULT_CLOCK_OFFSET;

        videoConfig.tableConfig.interval = (uint32_t) VIDEORTP_DEFAULT_MPEGTS_TABLES;
        videoConfig.tableConfig.program = VIDEORTP_DEFAULT_MPEGTS_PROGRAM;
        videoConfig.tableConfig.pmtPid = VIDEORTP_DEFAULT_MPEGTS_PMT_PID;
        videoConfig.tableConfig.videoPid = VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID;
        videoConfig.tableConfig.streamId = VIDEORTP_DEFAULT_MPEGTS_STREAM_ID;

        videoConfig.isStaticInputEnabled = true;
        videoConfig.staticInputConfig.payloadUnits = testFrames.data();
        videoConfig.staticInputConfig.payloadUnitCount = testFrames.size();
        videoConfig.staticInputConfig.fps = VIDEORTP_DEFAULT_FRAME_RATE;
        videoConfig.staticInputConfig.tsPid = VIDEORTP_DEFAULT_MPEGTS_VIDEO_PID;
        videoConfig.staticInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;

        videoConfig.cyclicInterval = 1;
        videoConfig.targetDataRate = 6000000;
        videoConfig.targetFrameRate = 30;
    }

    void SetUp() override
    {
        dumpTXInit(&dump);

        initTestFrames();
        initConfig();
        VIDEORTP_initVideoStream(&videoStream, &dump.vtable, NULL, &videoConfig);
    }

    void GetAllTsPackets()
    {
        packets.clear();
        for (const std::vector<uint8_t>& data : dump.dump)
        {
            EXPECT_EQ(data.size() % 188, 12);
            for (int i = 0; i < data.size() / 188; i++)
            {
                const uint8_t* packetStart = data.data() + i * 188 + 12;

                packets.push_back(std::vector<uint8_t>(188));
                memcpy(packets.back().data(), packetStart, 188);
            }
        }
    }

    void CheckData(const std::vector<uint8_t>& TSpacket)
    {
        // Minimal TS header
        size_t headerLength = 4;

        // Skip adaptation field if present (contains PCR or stuffing)
        if (TSpacket.at(3) & 0x20)
        {
            headerLength += 1 + TSpacket.at(4);
        }

        // Payload unit start? (PID=0x0100)
        if (TSpacket.at(1) == 0x41 && TSpacket.at(2) == 0x00)
        {
            // PES packet header (with PTS)
            headerLength += 14;
            checkNewTS(TSpacket);
        }
        else if (padding)
        {
            // PES padding packet header
            headerLength += 6;
            EXPECT_TRUE(ContainsPattern(TSpacket.data() + headerLength, 255, 188 - headerLength));
            paddingCounter++;
        }

        ASSERT_LT(headerLength, 188);
        uint64_t remainingPayloadSize = testFrames.at(unitCounter).length - offset;
        ASSERT_GE(remainingPayloadSize, 188 - headerLength);

        int cmp = memcmp(TSpacket.data() + headerLength, static_cast<const uint8_t*>(testFrames.at(unitCounter).buffer) + offset,
                         188 - headerLength);
        EXPECT_EQ(0, cmp);

        offset += 188 - headerLength;
    }

    void ParseData(const std::vector<uint8_t>& TSpacket)
    {
        if (padding)
        {
            // Check padding
            size_t headerLength = 10;
            EXPECT_TRUE(ContainsPattern(TSpacket.data() + headerLength, 255, 188 - headerLength));
            paddingCounter++;
        }
        else
        {
            // Check that transmitted data equals pregenerated video
            CheckData(TSpacket);

            // Check data end
            if (offset >= testFrames.at(unitCounter).length)
            {
                unitCounter = (unitCounter + 1) % testFrames.size();
                offset = 0;
                // if data end must adding paddings
                padding = true;
            }
        }
    }

    void CheckPackets(int startIndex = 0)
    {
        for (int i = startIndex; i < packets.size(); i++)
        {
            ParseData(packets.at(i));
        }
        dump.dump.clear();
        padding = false;
    }

    void CyclicReceiveHelper(int interval)
    {
        for (int t = 0; t < (interval + videoStream.cyclicInterval - 1) / videoStream.cyclicInterval; t++)
            VIDEORTP_cyclicVideoStream(&videoStream);
    }

    void CyclicReceivePacket(int interval)
    {
        CyclicReceiveHelper(interval);
        auto dmp = dump.dump.at(dump.dump.size() - 1);
        dump.dump.clear();
        dump.dump.push_back(dmp);
    }
};

TEST_F(PreGenVideoTest, TABLES_IN_FIRST_PACKET)
{
    TEST_DESCRIPTION("TEST for check that first packet contains PMT and PAT");

    CyclicReceiveHelper(1);
    GetAllTsPackets();
    checkPAT(packets.at(0));
    checkPMT(packets.at(1));
    dump.dump.clear();
}

TEST_F(PreGenVideoTest, TABLES_CHECK)
{
    TEST_DESCRIPTION("TEST for check that PMT and PAT repeats every 250 ms");

    for (int i = 0; i < 10; ++i)
    {
        // check that every 250 ms pmt is included
        for (int i = 0; i < 4; i++)
        {
            CyclicReceivePacket(250);
            GetAllTsPackets();
            checkPAT(packets.at(0));
            checkPMT(packets.at(1));
            dump.dump.clear();
        }

        // check that pmt not included
        for (int i = 0; i < 4; i++)
        {
            CyclicReceivePacket(50);
            GetAllTsPackets();
            checkNoPAT(packets.at(0));
            checkNoPMT(packets.at(1));
            dump.dump.clear();
        }
        // totaly +200 ms

        // extend last
        CyclicReceivePacket(50);
        GetAllTsPackets();
        checkPAT(packets.at(0));
        checkPMT(packets.at(1));
        dump.dump.clear();
    }
}

TEST_F(PreGenVideoTest, CYCLIC_PROCESSING)
{
    TEST_DESCRIPTION("TEST for check that TS packet has correct header and payload according with pregenerated video");
    videoStream.cyclicInterval = 1;
    ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&videoStream));
    // 1 ms
    GetAllTsPackets();

    // repeats == 36 - full video transmitted
    for (int repeats = 0; repeats < 500; repeats++)
    {
        // first RTP packet and every 250 ms must include PAT and PMT
        checkPAT(packets.at(0));
        checkPMT(packets.at(1));

        // check remaining packets with data
        CheckPackets(2);

        // TODO Test fail if we use CyclicReceiveHelper
        videoStream.packetsPerCycle = videoStream.cyclicInterval = 100;
        ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&videoStream));
        // 100 ms
        // All TS packets only with data or padding
        GetAllTsPackets();
        CheckPackets();

        // TODO Test fail if we use CyclicReceiveHelper
        videoStream.packetsPerCycle = videoStream.cyclicInterval = 100;
        ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&videoStream));
        // 200 ms
        // All TS packets only with data or padding
        GetAllTsPackets();
        CheckPackets();

        // TODO Test fail if we use CyclicReceiveHelper
        // Note: No timers expired, so no new packets will be generated.
        videoStream.packetsPerCycle = videoStream.cyclicInterval = 25;
        ASSERT_EQ(VideoRTP_queueEmpty, VIDEORTP_cyclicVideoStream(&videoStream));
        // 225 ms
        ASSERT_TRUE(dump.dump.empty());

        // 250 ms
        // Must contains PAT, PMT and data
        videoStream.packetsPerCycle = videoStream.cyclicInterval = 25;
        ASSERT_EQ(VideoRTP_ok, VIDEORTP_cyclicVideoStream(&videoStream));
        GetAllTsPackets();
    }
    EXPECT_GE(paddingCounter, unitCounter);
}
