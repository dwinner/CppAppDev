#include "PayloadGate.h"
#include "PayloadUnitRepeater.h"
#include "Stubs/CheckedStage.h"
#include "TestUtils.h"
#include "TransportStreamMultiplexer.h"
#include <gtest/gtest.h>

// A simple test pipeline for multiplexer input
struct PatternRepeaterWithGate
{
    // raw buffer for test pattern
    std::vector<uint8_t> buffer;
    VIDEORTP_bufferWriter_t writer;

    // pipeline stages
    CheckedGenerator<VIDEORTP_payloadUnitRepeater_t> rep;
    CheckedStage<VIDEORTP_payloadGate_t> gate;

    PatternRepeaterWithGate(size_t bufferSize, uint8_t pattern)
        : buffer(bufferSize)
    {
        VIDEORTP_bufInit(&writer, buffer.data(), buffer.size());
        VIDEORTP_bufWritePattern(&writer, pattern, VIDEORTP_bufGetAvailableSpace(&writer));
        VIDEORTP_repInitRaw(&rep, VIDEORTP_bufGetBasePointer(&writer), VIDEORTP_bufGetBytesWritten(&writer));
        VIDEORTP_gateInit(&gate, &rep, 1);
    }

    // Cannot copy or move this around because pipeline stages store pointers to each other
    PatternRepeaterWithGate(const PatternRepeaterWithGate&) = delete;
    PatternRepeaterWithGate& operator=(const PatternRepeaterWithGate&) = delete;
};

// This shall call mux functions and check result
void muxProcessing(CheckedStage<VIDEORTP_transportStreamMultiplexer_t>* mux, const std::vector<uint8_t>& expected,
                   size_t expectChunkSize)
{
    std::vector<uint8_t> buffer(expected.size());
    VIDEORTP_bufferWriter_t destBW;
    VIDEORTP_bufInit(&destBW, buffer.data(), buffer.size());

    VIDEORTP_payloadChunkInfo_t metadata;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(mux, VIDEORTP_bufGetAvailableSpace(&destBW), &metadata);
    EXPECT_EQ(expectChunkSize, nextChunkSize);

    VIDEORTP_pipeCopyChunk(mux, &destBW);
    ASSERT_EQ(expectChunkSize, VIDEORTP_bufGetBytesWritten(&destBW));
    EXPECT_EQ(expected, buffer);
}

std::vector<uint8_t> getExpectedWithPattern(uint8_t pattern, size_t dataSize, size_t destSize)
{
    std::vector<uint8_t> expected(destSize);
    size_t patternSize = dataSize > destSize ? destSize : dataSize;
    std::fill(expected.begin(), expected.begin() + patternSize, pattern);
    return expected;
}

TEST(TransportStreamMultiplexer, EMPTY_MULTIPLEXER)
{
    TEST_DESCRIPTION("Check that an empty multiplexer always returns empty chunks");

    CheckedStage<VIDEORTP_transportStreamMultiplexer_t> mux;
    VIDEORTP_muxInit(&mux);

    VIDEORTP_payloadChunkInfo_t metadata;
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, 188, &metadata);
    ASSERT_EQ(0, nextChunkSize);
}

TEST(TransportStreamMultiplexer, SINGLE_GATE_ENABLED)
{
    TEST_DESCRIPTION("TEST for check one enabled gate");

    CheckedStage<VIDEORTP_transportStreamMultiplexer_t> mux;
    VIDEORTP_muxInit(&mux);

    const uint8_t gates_count = 5;
    size_t sizes[] = { 32, 64, 128, 256, 512 };
    uint8_t patterns[] = { 1, 2, 3, 4, 5 };
    std::vector<std::unique_ptr<PatternRepeaterWithGate>> sources;

    // Create repeaters and add them to the mux
    for (int i = 0; i < gates_count; i++)
    {
        sources.push_back(std::make_unique<PatternRepeaterWithGate>(sizes[i], patterns[i]));
        VIDEORTP_pipeAddMultiplePredecessor(&static_cast<VIDEORTP_transportStreamMultiplexer_t&>(mux).base, &sources[i]->gate);
    }

    const size_t destSize = 256;
    // Generate expected buffer and run mux processing
    // Activate only one gate
    for (int i = 0; i < gates_count; i++)
    {
        VIDEORTP_gateEnable(&sources[i]->gate);
        auto expected = getExpectedWithPattern(patterns[i], sizes[i], destSize);
        size_t expectChunkSize = destSize < sizes[i] ? destSize : sizes[i];
        muxProcessing(&mux, expected, expectChunkSize);

        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(destSize < sizes[i] ? destSize : 0, nextChunkSize);
    }
}

TEST(TransportStreamMultiplexer, TWO_GATES_ENABLED)
{
    TEST_DESCRIPTION("TEST for check two enabled gate together");
    CheckedStage<VIDEORTP_transportStreamMultiplexer_t> mux;
    VIDEORTP_muxInit(&mux);

    const uint8_t gates_count = 5;
    size_t sizes[] = { 32, 64, 128, 256, 512 };
    uint8_t patterns[] = { 1, 2, 3, 4, 5 };
    std::vector<std::unique_ptr<PatternRepeaterWithGate>> sources;

    // Create repeaters and add them to the mux
    for (int i = 0; i < gates_count; i++)
    {
        sources.push_back(std::make_unique<PatternRepeaterWithGate>(sizes[i], patterns[i]));
        VIDEORTP_pipeAddMultiplePredecessor(&static_cast<VIDEORTP_transportStreamMultiplexer_t&>(mux).base, &sources[i]->gate);
    }

    const size_t destSize = 512;

    // Activate two gates
    size_t first = 1;
    size_t second = 4;
    VIDEORTP_gateEnable(&sources[second]->gate);
    VIDEORTP_gateEnable(&sources[first]->gate);

    // Expect data to be copied from first gate
    auto expected = getExpectedWithPattern(patterns[first], sizes[first], destSize);
    muxProcessing(&mux, expected, sizes[first]);
    VIDEORTP_payloadChunkInfo_t metadata;
    // The size of the next chunk must be equal to the data size of the second gateway.
    size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
    EXPECT_EQ(sizes[second], nextChunkSize);

    // Expect data to be copied from second gate
    expected = getExpectedWithPattern(patterns[second], sizes[second], destSize);
    muxProcessing(&mux, expected, sizes[second]);
    // The next chunk size should be 0 because all data  copied and gateways are disabled
    nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
    EXPECT_EQ(nextChunkSize, 0);
}

TEST(TransportStreamMultiplexer, INTERLEAVED_COPY)
{
    TEST_DESCRIPTION(
        "TEST for check switch multiplexer between two gates in process by enabling/disabling according with priority");
    CheckedStage<VIDEORTP_transportStreamMultiplexer_t> mux;
    VIDEORTP_muxInit(&mux);

    const uint8_t gates_count = 5;
    size_t sizes[] = { 32, 64, 128, 256, 512 };
    uint8_t patterns[] = { 1, 2, 3, 4, 5 };
    std::vector<std::unique_ptr<PatternRepeaterWithGate>> sources;

    // Create repeaters and add them to the mux
    for (int i = 0; i < gates_count; i++)
    {
        sources.push_back(std::make_unique<PatternRepeaterWithGate>(sizes[i], patterns[i]));
        VIDEORTP_pipeAddMultiplePredecessor(&static_cast<VIDEORTP_transportStreamMultiplexer_t&>(mux).base, &sources[i]->gate);
    }

    // Activate two gates
    size_t first = 4;
    size_t second = 0;
    // We need to copy the data from 2nd gate to one step
    const size_t destSize = sizes[second];
    // But the data from 1st gate needs to be copied in several steps
    size_t count = sizes[first] / destSize;
    VIDEORTP_gateEnable(&sources[first]->gate);
    for (size_t i = 0; i < count; i++)
    {
        VIDEORTP_payloadChunkInfo_t metadata;

        // must copied chunk of first gate
        auto expected = getExpectedWithPattern(patterns[first], sizes[first], destSize);
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(destSize, nextChunkSize);
        muxProcessing(&mux, expected, destSize);

        // when all data is copied from the 2nd gate, should return 0
        // because 2nd gate is disable
        size_t expectedNextChunkSize = i == (count - 1) ? 0 : destSize;
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(expectedNextChunkSize, nextChunkSize);

        // must copy all data from 2nd gate because 2nd index < 1st index
        VIDEORTP_gateEnable(&sources[second]->gate);
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(destSize, nextChunkSize);

        expected = getExpectedWithPattern(patterns[second], sizes[second], destSize);
        muxProcessing(&mux, expected, destSize);

        // data from 2nd gate was copied; resume copy from 1st gate
        nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(nextChunkSize, expectedNextChunkSize);
    }
}

TEST(TransportStreamMultiplexer, ALL_GATES_ENABLED)
{
    TEST_DESCRIPTION("TEST for check switch multiplexer between several gates if all gates is enabled");

    CheckedStage<VIDEORTP_transportStreamMultiplexer_t> mux;
    VIDEORTP_muxInit(&mux);

    const uint8_t gates_count = 5;
    size_t sizes[] = { 32, 64, 128, 256, 512 };
    uint8_t patterns[] = { 1, 2, 3, 4, 5 };
    std::vector<std::unique_ptr<PatternRepeaterWithGate>> sources;

    // Enable all gates
    for (int i = 0; i < gates_count; i++)
    {
        sources.push_back(std::make_unique<PatternRepeaterWithGate>(sizes[i], patterns[i]));
        VIDEORTP_pipeAddMultiplePredecessor(&static_cast<VIDEORTP_transportStreamMultiplexer_t&>(mux).base, &sources[i]->gate);
        VIDEORTP_gateEnable(&sources[i]->gate);
    }

    const size_t destSize = 512;
    // Expect data order to match gate order
    for (size_t first = 0; first < gates_count - 1; first++)
    {
        size_t second = first + 1;
        auto expected = getExpectedWithPattern(patterns[first], sizes[first], destSize);
        muxProcessing(&mux, expected, sizes[first]);
        VIDEORTP_payloadChunkInfo_t metadata;
        size_t nextChunkSize = VIDEORTP_pipePrepareNextChunk(&mux, destSize, &metadata);
        EXPECT_EQ(sizes[second], nextChunkSize);
    }
}
