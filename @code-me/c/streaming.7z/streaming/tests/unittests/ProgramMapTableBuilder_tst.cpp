#include "ProgramMapTableBuilder.h"
#include "TestUtils.h"
#include "crc32_mpeg2.h"
#include <gtest/gtest.h>

#define TEST_DESCRIPTION(desc) RecordProperty("description", desc)

const uint8_t pmt_header_size = 10;

void checkEmptyHeaderPMT(uint8_t data[], uint16_t pcrPid)
{
    uint16_t pcr = 0xE000 | (0x1FFF & pcrPid);
    // sizeof = pmt_header_size
    uint8_t buffer_template_res[] = {
        VIDEORTP_PMT_TABLE_ID,
        0, // section_syntax_indicator, zero, reserved
        0, // reserved and section_length
        0, // programNumber 1st half
        0, // programNumber 2nd half
        0xC1, // reserved, versionNumber, and current_next_indicator
        0, // section_number
        0, // last_section_number
        (uint8_t) (pcr >> 8), // PCR_PID
        (uint8_t) pcr // PCR_PID
    };

    int mem_eq = memcmp(data, buffer_template_res, pmt_header_size);
    EXPECT_EQ(mem_eq, 0);

    // Check reserved bits
    uint8_t reserved = 0xE0 & data[8];
    EXPECT_EQ(reserved, 0xE0);
    // Check actual PCR
    uint16_t actualPcr = (0x1FFF & ((uint16_t) (data[8] << 8))) | (uint16_t) data[9];
    ASSERT_LE(actualPcr, 0x1FFF);
    if (pcrPid > 0x1FFF)
    {
        EXPECT_EQ(actualPcr, 0x1FFF & pcrPid);
    }
    else
    {
        EXPECT_EQ(actualPcr, pcrPid);
    }
}

TEST(ProgramMapTableBuilderModule, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor PMT builder");
    for (uint16_t pcrPid = 0; pcrPid < 0xFFFF; pcrPid++)
    {
        uint16_t id = 0;
        const size_t bufferSize = VIDEORTP_PMT_MAX_SIZE;
        uint8_t buffer[bufferSize] = {};
        VIDEORTP_bufferWriter_t bw;
        VIDEORTP_bufInit(&bw, buffer, bufferSize);
        VIDEORTP_programMapTableBuilder_t programMapTableBuilder;
        VIDEORTP_pmtInit(&programMapTableBuilder, id, pcrPid, &bw);

        checkEmptyHeaderPMT(buffer, pcrPid);
    }
}

TEST(ProgramMapTableBuilderModule, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all PMT builder functions");
    uint16_t id = 0;
    uint16_t pcrPid = VIDEORTP_PCR_PID_PMT;
    const size_t bufferSize = VIDEORTP_PMT_MAX_SIZE;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_programMapTableBuilder_t programMapTableBuilder;
    VIDEORTP_pmtInit(&programMapTableBuilder, id, pcrPid, &bw);

    EXPECT_EXIT(VIDEORTP_pmtInit(NULL, id, pcrPid, NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_pmtInit(NULL, id, pcrPid, &bw), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_pmtInit(&programMapTableBuilder, id, pcrPid, NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_pmtAddElementaryStreamPid(NULL, 0x01, 0x1b), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_pmtFinalize(NULL), testing::ExitedWithCode(3), "");
}

TEST(ProgramMapTableBuilderModule, addEmptyElementaryStreamPid)
{
    TEST_DESCRIPTION("TEST for check adding several ES PID to PMT builder and builded PMT");
    uint16_t id = 0;
    uint16_t pcrPid = 0x0100;
    const size_t bufferSize = VIDEORTP_PMT_MAX_SIZE;
    uint8_t buffer[bufferSize] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_programMapTableBuilder_t programMapTableBuilder;
    VIDEORTP_pmtInit(&programMapTableBuilder, id, pcrPid, &bw);

    checkEmptyHeaderPMT(buffer, pcrPid);

    uint16_t es_pid1 = 0x1FFF; // max possible value for 13 bits
    VIDEORTP_pmtAddElementaryStreamPid(&programMapTableBuilder, es_pid1, VIDEORTP_STREAM_TYPE_STUB);
    uint16_t es_pid2 = 0x10FF;
    VIDEORTP_pmtAddElementaryStreamPid(&programMapTableBuilder, es_pid2, VIDEORTP_STREAM_TYPE_STUB);

    // The third stream must be ignored (see VIDEORTP_PMT_MAX_STREAMS_NUMBER)
    uint16_t es_pid3 = 0x18FF;
    VIDEORTP_pmtAddElementaryStreamPid(&programMapTableBuilder, es_pid3, VIDEORTP_STREAM_TYPE_STUB);

    uint8_t body_res[] = {
        0xF0, // reserved and 1st part of program_info_length
        0x00, // part of 2nd program_info_length

        // 1st stream
        VIDEORTP_STREAM_TYPE_STUB, // streamType
        (uint8_t) (0xE0 | ((es_pid1 & 0x1F00) >> 8)), // 3 bits reserved and es_pid 5 bits
        (uint8_t) (es_pid1 | 0x1F), // es_pid 8 bit
        0xF0, // 4 bits reserved and infoLength 4 bits (now es_info_length == 0)
        0, // infoLength 8 bits

        // 2nd stream
        VIDEORTP_STREAM_TYPE_STUB, // streamType
        (uint8_t) (0xE0 | ((es_pid2 & 0x1F00) >> 8)), // 3 bits reserved and es_pid 5 bits
        (uint8_t) (es_pid2 | 0x1F), // es_pid 8 bit
        0xF0, // 4 bits reserved and infoLength 4 bits (now es_info_length == 0)
        0, // infoLength 8 bits
    };
    VIDEORTP_pmtFinalize(&programMapTableBuilder);

    int body_eq = memcmp(buffer + pmt_header_size, body_res, sizeof(body_res));
    EXPECT_EQ(body_eq, 0);

    uint32_t CRC_32 = 0;
    memcpy(&CRC_32, &buffer[pmt_header_size + sizeof(body_res)], sizeof(uint32_t));
    EXPECT_NE(CRC_32, 0);
}

TEST(ProgramMapTableBuilderModule, PROTOTYPE)
{
    TEST_DESCRIPTION("TEST for check PMT originally generated by prototype and decoded by Wireshark");
    // PMT originally created by prototype/FFmpeg and decoded by Wireshark
    const unsigned char expected[] = {
        // Table ID: Program Map Table (PMT) (0x02)
        0x02,
        // 1... .... .... .... = Syntax indicator: 1
        // .011 .... .... .... = Reserved: 0x3
        // .... 0000 0001 0010 = Length: 18
        0xb0,
        0x12,
        // Program Number: 0x0001
        0x00,
        0x01,
        // 11.. .... = Reserved: 0x3
        // ..00 000. = Version Number: 0x00
        // .... ...1 = Current/Next Indicator: Currently applicable (0x1)
        0xc1,
        // Section Number: 0
        0x00,
        // Last Section Number: 0
        0x00,
        // 111. .... .... .... = Reserved: 0x7
        // ...0 0001 0000 0000 = PCR PID: 0x0100
        0xe1,
        0x00,
        // 1111 .... .... .... = Reserved: 0xf
        // .... 0000 0000 0000 = Program Info Length: 0x000
        0xf0,
        0x00,
        // Stream PID=0x0100
        //     Stream type: AVC video stream as defined in ITU-T Rec. H.264 | ISO/IEC 14496-10 Video (0x1b)
        0x1b,
        //     111. .... .... .... = Reserved: 0x7
        //     ...0 0001 0000 0000 = Elementary PID: 0x0100
        0xe1,
        0x00,
        //     1111 .... .... .... = Reserved: 0xf
        //     .... 0000 0000 0000 = ES Info Length: 0x000
        0xf0,
        0x00,
        // CRC 32: 0x15bd4d56 [correct]
        0x15,
        0xbd,
        0x4d,
        0x56,
    };

    uint8_t buffer[30] = {};
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, sizeof(buffer));

    VIDEORTP_programMapTableBuilder_t builder;
    VIDEORTP_pmtInit(&builder, 0x0001, 0x0100, &bw);
    VIDEORTP_pmtAddElementaryStreamPid(&builder, 0x0100, 0x1b);
    VIDEORTP_pmtFinalize(&builder);

    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), sizeof(expected));
    EXPECT_EQ(memcmp(expected, VIDEORTP_bufGetBasePointer(&bw), sizeof(expected)), 0);
}
