#include "TestUtils.h"
#include "ipcFrame.h"
#include "ipcFrameFactory.h"
#include <gtest/gtest.h>
#include <set>

class FrameFactoryTest : public ::testing::Test
{
protected:
    VIDEORTP_timestamp timestamp = { 123 };
    VIDEORTP_ipcFrameFactory_t factory;
    VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;

    FrameFactoryTest()
    {
        VIDEORTP_frameFactoryInit(&factory);
        VIDEORTP_payloadChunkFactoryInit(&chunkFactory);
    }
};

TEST_F(FrameFactoryTest, RejectsEmptyFrames)
{
    TEST_DESCRIPTION("Tests that empty frames are ignored");
    VIDEORTP_ipcFrame_t* frame = VIDEORTP_frameFactoryCreate(&factory, &chunkFactory, 0, &timestamp);
    ASSERT_EQ(frame, nullptr);
}

TEST_F(FrameFactoryTest, CanReuseFrameBuffers)
{
    TEST_DESCRIPTION("Tests that destroyed/freed frames can be reused");

    // We check that factory can create more than VIDEORTP_FACTORY_FRAME_MAX_COUNT
    for (int i = 0; i < VIDEORTP_FACTORY_FRAME_MAX_COUNT * 3; i++)
    {
        VIDEORTP_ipcFrame_t* frame = VIDEORTP_frameFactoryCreate(&factory, &chunkFactory, 123, &timestamp);
        EXPECT_TRUE(frame != NULL);
        VIDEORTP_frameFactoryDestroy(&factory, frame);
    }
}

TEST_F(FrameFactoryTest, CanUseFrameBuffersInAnyOrder)
{
    TEST_DESCRIPTION("Test that the order of frame buffers does not matter");

    size_t frameSize = 128;

    for (int repeats = 0; repeats < 3; repeats++)
    {
        std::vector<VIDEORTP_ipcFrame_t*> frames;

        // Check that the factory returns each frame exactly once (no duplicates; order does not matter)
        for (int i = 0; i < VIDEORTP_FACTORY_FRAME_MAX_COUNT; i++)
        {
            VIDEORTP_ipcFrame_t* frame = VIDEORTP_frameFactoryCreate(&factory, &chunkFactory, frameSize, &timestamp);
            frames.push_back(frame);
        }
        std::set<VIDEORTP_ipcFrame_t*> uniqueFrames(frames.begin(), frames.end());
        EXPECT_EQ(frames.size(), uniqueFrames.size());

        // The factory must return null if no more frames are available.
        VIDEORTP_ipcFrame_t* frame = VIDEORTP_frameFactoryCreate(&factory, &chunkFactory, frameSize, &timestamp);
        EXPECT_EQ(frame, nullptr);

        // Destroy all frames in reverse. Their order should not matter.
        for (auto i = frames.rbegin(); i != frames.rend(); ++i)
        {
            VIDEORTP_frameFactoryDestroy(&factory, *i);
        }
    }
}
