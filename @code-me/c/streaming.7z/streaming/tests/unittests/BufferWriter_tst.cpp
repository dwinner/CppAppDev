#include "BufferWriter.h"
#include "TestUtils.h"
#include "sysdef.h"
#include <gtest/gtest.h>

void show_mem_rep(char* start, int n)
{
    int i;
    for (i = 0; i < n; i++)
        printf(" %.2x", start[i]);
    printf("\n");
}

TEST(BufferWriterModule, CONSTRUCTOR)
{
    TEST_DESCRIPTION("TEST for check constructor buffer writer");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    EXPECT_EQ(VIDEORTP_bufGetBasePointer(&bw), buffer) << "base pointer not equals buffer pointer";
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize) << "available space not equals buffer capacity";
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0) << "written bytes not 0";
}

TEST(BufferWriterModule, EMPTY)
{
    TEST_DESCRIPTION("TEST for check make empty buffer");
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, NULL, 5);

    EXPECT_EQ(VIDEORTP_bufGetBasePointer(&bw), nullptr);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);

    EXPECT_EQ(VIDEORTP_bufGetWritableChunk(&bw, 0), nullptr);
    EXPECT_EQ(VIDEORTP_bufGetWritableChunk(&bw, 1), nullptr);
}

TEST(BufferWriterModule, ASSERTS)
{
    TEST_DESCRIPTION("TEST for check assert all  buffer writer functions");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize] = { 0 };

    EXPECT_EXIT(VIDEORTP_bufInit(NULL, NULL, NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufClear(NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufGetAvailableSpace(NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufGetBasePointer(NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufGetBytesWritten(NULL), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufGetWritableChunk(NULL, 1), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufWriteInteger(NULL, 0xFFFF, sizeof(uint16_t)), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufWriteData(NULL, buffer, bufferSize), testing::ExitedWithCode(3), "");
    EXPECT_EXIT(VIDEORTP_bufWritePattern(NULL, 1, bufferSize), testing::ExitedWithCode(3), "");
}

TEST(BufferWriterModule, WRITE_DATA_VALID)
{
    TEST_DESCRIPTION("TEST check write valid data");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize + 1] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xEE };

    const uint8_t dataSize = 5;
    uint8_t data[dataSize] = { 0, 1, 2, 3, 4 };

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    EXPECT_TRUE(VIDEORTP_bufWriteData(&bw, data, dataSize));
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 5);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 5);

    EXPECT_TRUE(VIDEORTP_bufWriteData(&bw, data, dataSize));
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 10);

    uint8_t expected[sizeof(buffer)] = { 0, 1, 2, 3, 4, 0, 1, 2, 3, 4, 0xEE };
    int compare = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(compare, 0);
}

TEST(BufferWriterModule, WRITE_DATA_AS_STRUCT)
{
    TEST_DESCRIPTION("TEST check write valid data structure");
    struct BufferWriter_tst_struct
    {
        uint8_t data0;
        uint8_t data1;
    };

    const uint8_t bufferSize = 16;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    BufferWriter_tst_struct data = { 1, 2 };
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    bool res = VIDEORTP_bufWriteData(&bw, &data, sizeof(data));
    EXPECT_TRUE(res);

    EXPECT_EQ(buffer[0], data.data0);
    EXPECT_EQ(buffer[1], data.data1);
    for (int i = 2; i < bufferSize; i++)
    {
        EXPECT_EQ(buffer[i], 0);
    }
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize - sizeof(data));
}

TEST(BufferWriterModule, WRITE_DATA_INVALID)
{
    TEST_DESCRIPTION("TEST check write invalid data");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize + 1] = { 0, 0, 0, 0, 0, 0xEE };

    const uint8_t dataSize = 10;
    uint8_t data[dataSize] = "123456789";

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    bool res = VIDEORTP_bufWriteData(&bw, data, dataSize);
    EXPECT_FALSE(res);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);

    uint8_t expected[sizeof(buffer)] = { 0, 0, 0, 0, 0, 0xEE };
    int cmp = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(cmp, 0);
}

TEST(BufferWriterModule, WRITE_INTEGER_LONG)
{
    TEST_DESCRIPTION("TEST check write integer long buffer");
    uint8_t buffer[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xEE };
    uint64_t data = 0x0123456789abcdefull;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, 16);
    bool res = VIDEORTP_bufWriteInteger(&bw, data, 8);

    EXPECT_TRUE(res);

    uint8_t expected[sizeof(buffer)] = { 0x01, 0x23, 0x45, 0x67, 0x89, 0xab, 0xcd, 0xef, 0, 0, 0, 0, 0, 0, 0, 0, 0xEE };
    int cmp = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(cmp, 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 8);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 8);
}

TEST(BufferWriterModule, WRITE_INTEGER_SHORT)
{
    TEST_DESCRIPTION("TEST check write integer short buffer");
    uint8_t buffer[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xEE };
    uint64_t data = 0x0123456789abcdefull;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, 16);
    bool res = VIDEORTP_bufWriteInteger(&bw, data, 5);

    EXPECT_TRUE(res);

    uint8_t expected[sizeof(buffer)] = { 0x67, 0x89, 0xab, 0xcd, 0xef, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0xEE };
    int cmp = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(cmp, 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 11);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 5);
}

TEST(BufferWriterModule, WRITE_INTEGER_INVALID)
{
    TEST_DESCRIPTION("TEST check write integer invalid buffer");
    uint8_t buffer[5 + 1] = { 0, 0, 0, 0, 0, 0xEE };
    uint64_t data = INT64_MAX;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, 5);
    bool res = VIDEORTP_bufWriteInteger(&bw, data, 10);

    EXPECT_FALSE(res);

    uint8_t expected[sizeof(buffer)] = { 0, 0, 0, 0, 0, 0xEE };
    int cmp = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(cmp, 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 5);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);
}

TEST(BufferWriterModule, WRITE_PATTERN_VALID)
{
    TEST_DESCRIPTION("TEST check write pattern valid ");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize + 1] = { 0, 0, 0, 0, 0, 0xEE };
    uint8_t pattern = 2;
    uint8_t writeLength = 2;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    bool res = VIDEORTP_bufWritePattern(&bw, pattern, writeLength);

    EXPECT_TRUE(res);
    uint8_t expected[sizeof(buffer)] = { 2, 2, 0, 0, 0, 0xEE };
    int compare = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(compare, 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), writeLength);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 2);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 3);
}

TEST(BufferWriterModule, WRITE_PATTERN_INVALID)
{
    TEST_DESCRIPTION("TEST check write pattern INvalid ");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize + 1] = { 0, 0, 0, 0, 0, 0xEE };
    uint8_t pattern = 2;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    bool res = VIDEORTP_bufWritePattern(&bw, pattern, bufferSize * 2);

    EXPECT_FALSE(res);
    uint8_t expected[sizeof(buffer)] = { 0, 0, 0, 0, 0, 0xEE };
    int compare = memcmp(buffer, expected, sizeof(expected));
    EXPECT_EQ(compare, 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
}

TEST(BufferWriterModule, CHILD_WRITER)
{
    TEST_DESCRIPTION("TEST check write valid CHILD_WRITER");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    uint8_t pattern = 2;
    uint8_t writeLength = 2;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_bufWritePattern(&bw, pattern, writeLength);

    uint8_t childSize = 3;
    uint8_t childPattern = 3;
    uint8_t* expectChildBasePointer = (uint8_t*) VIDEORTP_bufGetBasePointer(&bw) + VIDEORTP_bufGetBytesWritten(&bw);
    VIDEORTP_bufferWriter_t child = VIDEORTP_bufSpawnChildWriter(&bw, childSize);
    EXPECT_EQ(expectChildBasePointer, VIDEORTP_bufGetBasePointer(&child));
    EXPECT_EQ(childSize, VIDEORTP_bufGetAvailableSpace(&child));
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), writeLength + childSize);

    bool res = VIDEORTP_bufWritePattern(&child, childPattern, childSize);
    res &= VIDEORTP_bufWritePattern(&bw, pattern, writeLength);
    EXPECT_TRUE(res);

    uint8_t expectBuffer[bufferSize] = { pattern, pattern, childPattern, childPattern, childPattern, pattern, pattern, 0, 0, 0 };

    int compare = memcmp(buffer, expectBuffer, bufferSize);

    EXPECT_EQ(compare, 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&child), 0);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 3);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 7);
}

TEST(BufferWriterModule, CHILD_WRITER_INVALID)
{
    TEST_DESCRIPTION("TEST check write invalid CHILD_WRITER");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    uint8_t childSize = bufferSize * 2;

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    VIDEORTP_bufferWriter_t child = VIDEORTP_bufSpawnChildWriter(&bw, childSize);

    EXPECT_EQ(VIDEORTP_bufGetBasePointer(&child), nullptr);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);
}

TEST(BufferWriterModule, CLEAR)
{
    TEST_DESCRIPTION("TEST clear");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);
    EXPECT_TRUE(VIDEORTP_bufWritePattern(&bw, 5, bufferSize));
    VIDEORTP_bufClear(&bw);
    for (int i = 0; i < bufferSize; i++)
    {
        // "Clear" does not erase the buffer
        EXPECT_NE(buffer[0], 0);
    }
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);
}

TEST(BufferWriterModule, GET_VALID_WRITABLE_CHUNK)
{
    TEST_DESCRIPTION("TEST GET_VALID_WRITABLE_CHUNK");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);

    uint8_t chunkLength = bufferSize / 2;
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    // Allocate small chunk of memory
    uint8_t* writableChunk = VIDEORTP_bufGetWritableChunk(&bw, chunkLength);
    EXPECT_EQ(writableChunk, buffer);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize - chunkLength);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), chunkLength);

    // Allocate another chunk
    writableChunk = VIDEORTP_bufGetWritableChunk(&bw, chunkLength);
    EXPECT_EQ(writableChunk, buffer + chunkLength);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize - chunkLength * 2);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), chunkLength * 2);

    // No more space left
    writableChunk = VIDEORTP_bufGetWritableChunk(&bw, chunkLength);
    EXPECT_EQ(writableChunk, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetBasePointer(&bw), buffer);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), chunkLength * 2);
}

TEST(BufferWriterModule, GET_NULL_WRITABLE_CHUNK)
{
    TEST_DESCRIPTION("TEST GET_NULL_WRITABLE_CHUNK");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    // If not enough space is left, the buffer writer does not change.
    uint8_t* writableChunk = VIDEORTP_bufGetWritableChunk(&bw, bufferSize * 2);
    EXPECT_EQ(writableChunk, nullptr);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);
}

TEST(BufferWriterModule, GET_EMPTY_WRITABLE_CHUNK)
{
    TEST_DESCRIPTION("TEST GET_EMPTY_WRITABLE_CHUNK");
    const uint8_t bufferSize = 5;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);

    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, 5);

    uint8_t* writableChunk = VIDEORTP_bufGetWritableChunk(&bw, 0);
    EXPECT_EQ(writableChunk, buffer);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 0);

    // Fill buffer
    writableChunk = VIDEORTP_bufGetWritableChunk(&bw, bufferSize);
    EXPECT_EQ(writableChunk, buffer);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), bufferSize);

    // Requesting 0 bytes never fails (although nothing can be written)
    writableChunk = VIDEORTP_bufGetWritableChunk(&bw, 0);
    EXPECT_EQ(writableChunk, buffer + bufferSize);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), bufferSize);
}

TEST(BufferWriterModule, CHILD_WRITER_WITH_CHUNK)
{
    TEST_DESCRIPTION("TEST CHILD_WRITER_WITH_CHUNK");
    const uint8_t bufferSize = 10;
    uint8_t buffer[bufferSize];
    memset(buffer, 0, bufferSize);
    VIDEORTP_bufferWriter_t bw;
    VIDEORTP_bufInit(&bw, buffer, bufferSize);

    uint8_t childSize = bufferSize / 2;
    uint8_t childPattern = 3;
    uint8_t chunkSize = 5;
    uint8_t* chunk = VIDEORTP_bufGetWritableChunk(&bw, chunkSize);

    EXPECT_NE(chunk, nullptr) << "chunk must be not equal nullptr";

    VIDEORTP_bufferWriter_t child = VIDEORTP_bufSpawnChildWriter(&bw, childSize);
    bool res = VIDEORTP_bufWritePattern(&child, childPattern, childSize);

    EXPECT_TRUE(res);
    uint8_t expectBuffer[bufferSize] = { 0, 0, 0, 0, 0, childPattern, childPattern, childPattern, childPattern, childPattern };
    int compare = memcmp(buffer, expectBuffer, bufferSize);
    EXPECT_EQ(compare, 0);

    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&bw), bufferSize - chunkSize - childSize);
    EXPECT_EQ(VIDEORTP_bufGetAvailableSpace(&child), 0);
    EXPECT_EQ(VIDEORTP_bufGetBytesWritten(&bw), 10);
}
