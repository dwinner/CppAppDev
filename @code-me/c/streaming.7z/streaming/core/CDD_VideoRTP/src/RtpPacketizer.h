#ifndef RTP_PACKETIZER_H
#define RTP_PACKETIZER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "AvbRtcpPacketBuilder.h"
#include "BufferWriter.h"
#include "PayloadProvider.h"
#include <stdbool.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

    /* ===========================================================================
     *
     *   Public Definitions
     *
     * ========================================================================= */

/** @brief Maximum size of RTP header */
#define VIDEORTP_RTP_HEADER_SIZE 12

    /**
     * \defgroup RtpPacketizer
     * @{
     * @brief Wraps MPEG-TS packets into RTP packets.
     *
     * This packetizer builds RTP packets by aggregating MPEG-TS packets according to
     * [RFC 3550](https://www.rfc-editor.org/rfc/rfc3550.html) and [RFC 3551](https://www.rfc-editor.org/rfc/rfc3551.html).
     *
     * Some data fields in the RTP header are "constant" for the duration of an RTP connection (e.g., various IDs of the peers
     * involved). These fields can be pre-configured in a @ref VIDEORTP_rtcpSessionConfiguration_t "session configuration"
     * structure, which can be shared with a @ref VIDEORTP_avbRtcpPacketBuilder_t "RTCP packet builder".
     *
     * @startuml rtp_packetizer
     *  hide empty members
     *
     *  class PipelineStageWithSinglePredecessor
     *
     *  class RtpPacketizer {
     *      - headerBuilder : RtpHeaderBuilder
     *      + buildPacket(packetBuffer : BufferWriter*) : bool
     *  }
     *  PipelineStageWithSinglePredecessor <|-- RtpPacketizer
     *
     *  class RawRtpHeader <<struct>> {
     *      + version : uint8_t : 2
     *      + padding : uint8_t : 1
     *      + extension : uint8_t : 1
     *      + csrcCount : uint8_t : 4
     *      + marker : uint8_t : 1
     *      + type : uint8_t : 7
     *      + sequenceNumber : uint16_t
     *      + timestamp : uint32_t
     *      + ssrc : uint32_t
     *  }
     *
     *  note right of RtpPacketizer
     *  Forwards RtcpSessionConfiguration to RtpHeaderBuilder
     *  end note
     *
     *  note bottom of RawRtpHeader
     *  This data type is just for illustration.
     *  See RFC 3550, section 5.1 for details.
     *  end note
     *
     *  Class RtpHeaderBuilder {
     *      + addPacketMetaData(metaData : PayloadChunkInfo*) : void
     *      + getPacketTimestamp() : uint64_t
     *      + buildHeader(buffer : BufferWriter*) : void
     *      - nextSequenceNumber : uint16_t
     *      - config : const RtcpSessionConfiguration*
     *      - metaDataAccumulator : PayloadChunkInfo
     *      - lastValidTimestamp : uint64_t
     *  }
     *  RtpPacketizer *-- RtpHeaderBuilder
     *  RtpHeaderBuilder . RawRtpHeader : <<serialize>>
     *  RtpHeaderBuilder o-- RtcpSessionConfiguration
     *
     *  class RtcpSessionConfiguration <<struct>>
     * @enduml
     *
     * Note that this packetizer does not implement the @ref VIDEORTP_payloadProvider_t "PayloadProvider" interface. It merges
     * packets from different transport streams, so "payload unit" would not have a well-defined meaning in this use case.
     *
     * The number of TS packets in a RTP packet is determined by the size of the destination buffer. For example, if the destination
     * buffer is limited to 1280 bytes (the minimum MTU for IPv6), an RTP packet can carry up to 6 MPEG-TS packets:
     *
     *     IPv6-Header + UDP-Header + RTP-Header + 6 * MPEG-TS-Packet = 40 + 8 + 12 + 6 * 188 = 1188
     *
     * The actual number of TS packets may be less if not enough data is available.
     *
     * @startuml rtp_packetizer_sequence
     *  hide footbox
     *
     *  actor MainFunction
     *  participant "RTP Packetizer" as rtppack
     *  participant packetBuffer
     *  participant predecessor
     *  participant headerBuilder
     *  participant headerWriter
     *
     *  MainFunction -> rtppack++ : buildPacket(packetBuffer : BufferWriter*)
     *      rtppack -> rtppack++ : getPredecessor()
     *          return predecessor =
     *      alt predecessor != nullptr
     *          rtppack -> packetBuffer++ : spawnChildWriter(rtpHeaderSize)
     *              packetBuffer -> headerWriter**
     *              return
     *          rtppack -> packetBuffer++ : getAvailableSpace()
     *              return availableSpace =
     *          rtppack -> predecessor++ : prepareNextChunk(availableSpace)
     *              return chunkSize =
     *          alt chunkSize > 0
     *              loop chunkSize > 0
     *                  rtppack -> headerBuilder++ : addPacketMetaData()
     *                      return
     *                  rtppack -> predecessor++ : copyChunk(packetBuffer)
     *                      return
     *                  rtppack -> packetBuffer++ : getAvailableSpace()
     *                      return availableSpace =
     *                  rtppack -> predecessor++ : prepareNextChunk(availableSpace)
     *                      return chunkSize =
     *                  end
     *              rtppack -> headerBuilder++ : buildHeader(headerWriter)
     *                  loop
     *                      headerBuilder -> headerWriter++ : writeInteger() etc.
     *                          return
     *                  end
     *                  return
     *              rtppack --> MainFunction : true
     *          else
     *              rtppack --> MainFunction : false
     *          end
     *          rtppack -> headerWriter!!
     *      else
     *          rtppack --> MainFunction : false
     *      end
     *      deactivate rtppack
     * @enduml
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Contains data for RTP header preparation
     *
     * This struct implements of rtpHeaderBuilder.
     * The purpose of structure is to accumulate metadata.
     *
     * @see rtpHeaderBuilder
     */
    typedef struct VIDEORTP_rtpHeaderBuilder_t
    {
        /** @privatesection @{ */
        /**
         * @brief Sequence number of RTP packets.
         * @note May overflow.
         */
        uint16_t nextSequenceNumber;
        /**
         * @brief The session configuration contains some IDs which are needed for the RTP header.
         */
        const VIDEORTP_rtcpSessionConfiguration_t* config;
        /**
         * @brief Collects a "summary" of metadata from all TS packets so certain fields in the RTP header can be set correctly.
         */
        VIDEORTP_payloadChunkInfo_t metaDataAccumulator;
        /**
         * @brief The last known valid timestamp as a fallback because not all TS packets contain a valid timestamp.
         */
        VIDEORTP_timestamp lastValidTimestamp;

        /**
         * @brief A flag to change the way the marker bit is determined
         *
         * In mode VIDEORTP_rtpStreamingMode_RFC2250: set marker bit on timestamp discontinuity => set marker bit = 1 on first RTP
         * packet only
         *
         * In mode VW LAH IP_AVT: set marker bit on fragmented packets => cannot happen with MPEG-TS payload → set marker bit = 0
         * always
         */
        bool markerBitFlag;
        /** @} */
    } VIDEORTP_rtpHeaderBuilder_t;

    /**
     * @brief Contains data for RTP packetizer
     * @implements VIDEORTP_payloadProvider_t
     *
     * @see rtpPaketizer
     */
    typedef struct VIDEORTP_rtpPaketizer_t
    {
        /** @privatesection @{ */
        /**
         * @brief Source of TS packets
         * @invariant not @c NULL
         */
        VIDEORTP_payloadProvider_t* predecessor;
        /**
         * @brief Manages counters etc. needed for the RTP header
         */
        VIDEORTP_rtpHeaderBuilder_t headerBuilder;
        /** @} */
    } VIDEORTP_rtpPaketizer_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief It shall initialize headerBuilder
     * @public @memberof VIDEORTP_rtpHeaderBuilder_t
     *
     * @param self VIDEORTP_rtpHeaderBuilder_t instance to be initialized
     * @param config initialize RTCP session config fields
     * @param sequenceNumber counted internally with wrap around
     */
    void VIDEORTP_rtpHeaderBuilderInit(VIDEORTP_rtpHeaderBuilder_t* self, const VIDEORTP_rtcpSessionConfiguration_t* config);

    /**
     * @brief Return the RTP timestamp of the last RTP packet header
     * @public @memberof VIDEORTP_rtpHeaderBuilder_t
     *
     * @param self Header builder used to create the RTP header
     * @return MPEG and RTCP timestamps
     */
    VIDEORTP_timestamp VIDEORTP_rtpGetPacketTimestamp(VIDEORTP_rtpHeaderBuilder_t* self);

    /**
     * @brief It shall initialize RTP Packetizer
     * @public @memberof VIDEORTP_rtpPaketizer_t
     *
     * @param self VIDEORTP_rtpPaketizer_t instance to be initialized
     * @param predecessor VIDEORTP_payloadProvider_t contains previous data
     * @param config VIDEORTP_rtcpSessionConfiguration_t contains RTCP data
     * @param sequenceNumber counted internally with wrap around
     */
    void VIDEORTP_rtpPacketizerInit(VIDEORTP_rtpPaketizer_t* self, VIDEORTP_payloadProvider_t* predecessor,
                                    const VIDEORTP_rtcpSessionConfiguration_t* config);

    /**
     * @brief Combination of accumulator and new meta data
     * @public @memberof VIDEORTP_rtpHeaderBuilder_t
     *
     * @param self This instance
     * @param chunkInfo VIDEORTP_payloadChunkInfo_t contains metadata information
     */
    void VIDEORTP_rtpAddPacketMetaData(VIDEORTP_rtpHeaderBuilder_t* self, const VIDEORTP_payloadChunkInfo_t* tempMetaData);

    /**
     * @brief Write RTP header into BufferWriter
     * @public @memberof VIDEORTP_rtpHeaderBuilder_t
     *
     * @param self This instance
     * @param buffer buffer where provided BufferWriter
     */
    void VIDEORTP_rtpBuildHeader(VIDEORTP_rtpHeaderBuilder_t* self, VIDEORTP_bufferWriter_t* buffer);

    /**
     * @brief prepare and write RTP packet into BufferWriter
     * @public @memberof VIDEORTP_rtpPaketizer_t
     *
     * @param self This instance
     * @param packetBuffer buffer where provided BufferWriter
     * @return VideoRTP_errorCode error code
     */
    VideoRTP_errorCode VIDEORTP_rtpBuildPacket(VIDEORTP_rtpPaketizer_t* self, VIDEORTP_bufferWriter_t* packetBuffer);

    /**@} RtpPacketizer global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* RTP_PACKETIZER_H */
