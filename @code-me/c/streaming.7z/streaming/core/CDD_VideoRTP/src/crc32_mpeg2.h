#ifndef CRC32_MPEG_2_H
#define CRC32_MPEG_2_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "ConstantsMPEG.h"
#include "sysdef.h"


#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup CRC CRC32/MPEG2
     * @{
     * @brief CRC calculation
     */

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Calculate CRC32/MPEG2 checksum
     *
     * @note Calculates a CRC32/MPEG2 checksum using a pregenerated table. The table will be generated automatically on the first
     * call. This is not reentrant/thread-safe until the first call has completed.
     *
     * @param buf data for which to calculate crc
     * @param len size of data
     * @return CRC32 of the input buffer.
     */
    uint32_t VIDEORTP_CRC32calculate(const void* buf, size_t len);

/**@} */
#ifdef __cplusplus
}
#endif
#endif /* CRC32_MPEG_2_H */
