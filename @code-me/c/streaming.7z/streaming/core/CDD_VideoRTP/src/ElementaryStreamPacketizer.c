/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */
/* ===========================================================================
 *
 *   Description about this module
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "ElementaryStreamPacketizer.h"
#include "sysdef.h"

/* ===========================================================================
 *
 *   Private Function (static)
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_needDts
 *
 *   Function:   Returns the size of the data
 *
 *   Inputs:
 *               VIDEORTP_pesStreamPacketizer_t* self: VIDEORTP_pesStreamPacketizer_t instance that the function works on
 *
 *   Outputs:
 *               bool
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static bool VIDEORTP_needDts(VIDEORTP_pesStreamPacketizer_t* self)
{
    return self->timeDTS != self->timePTS;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesGetHeaderSize
 *
 *   Function:   Returns the size of the data
 *
 *   Inputs:
 *               VIDEORTP_pesInitPacketizer* self: VIDEORTP_pesInitPacketizer instance that the function works on
 *
 *   Outputs:
 *               size_t: size of data
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static size_t VIDEORTP_pesGetHeaderSize(VIDEORTP_pesStreamPacketizer_t* self)
{
    assert(self);

    size_t headerSize = 0;
    if (VIDEORTP_needDts(self))
    {
        headerSize = VIDEORTP_PES_HEADER_SIZE_WITH_DTS;
    }
    else
    {
        headerSize = VIDEORTP_PES_HEADER_SIZE_WITHOUT_DTS;
    }

    return headerSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesSetPacketMetaData
 *
 *   Function:   Initialize fields of self
 *
 *   Inputs:
 *               VIDEORTP_pesInitPacketizer* self: VIDEORTP_pesInitPacketizer instance that the function works on
 *               VIDEORTP_payloadChunkInfo_t* metaData: VIDEORTP_payloadChunkInfo_t instance that the function works on
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static void VIDEORTP_pesSetPacketMetaData(VIDEORTP_pesStreamPacketizer_t* self, VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(self);
    assert(metaData);

    /* All timestamps must be valid. Streams without timestamps are not supported. */
    assert(metaData->sampleTimestamp.mpegPresentationTimestamp != VIDEORTP_InvalidTimestamp);
    assert(metaData->sampleTimestamp.mpegDecodingTimestamp != VIDEORTP_InvalidTimestamp);

    /* MPEG uses a 27MHz system clock, but PES timestamps use a 90kHz clock so 300 is the natural divisor */
    self->timePTS = metaData->sampleTimestamp.mpegPresentationTimestamp / 300;
    self->timeDTS = metaData->sampleTimestamp.mpegDecodingTimestamp / 300;
    self->pesSize = metaData->payloadUnitSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesWriteTimestamp
 *
 *   Function:   Write Timestamp
 *
 *   Inputs:
 *               VIDEORTP_bufferWriter_t* bufferWriter: VIDEORTP_bufferWriter_t instance that the function works on
 *               uint64_t* timeTS: timestamp PTS/DTS
 *               uint8_t timestampType: the first byte mask
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static void VIDEORTP_pesWriteTimestamp(VIDEORTP_bufferWriter_t* bufferWriter, uint64_t timeTS, uint8_t timestampType)
{
    uint8_t* dest = VIDEORTP_bufGetWritableChunk(bufferWriter, 5);
    if (dest != NULL)
    {
        dest[0] = ((timeTS >> 29) & VIDEORTP_PES_TIMESTAMP_BIT_MASK_0) | VIDEORTP_PES_TIMESTAMP_MARKER_BIT | timestampType;
        dest[1] = ((timeTS >> 22) & VIDEORTP_PES_TIMESTAMP_BIT_MASK_1);
        dest[2] = ((timeTS >> 14) & VIDEORTP_PES_TIMESTAMP_BIT_MASK_2) | VIDEORTP_PES_TIMESTAMP_MARKER_BIT;
        dest[3] = ((timeTS >> 7) & VIDEORTP_PES_TIMESTAMP_BIT_MASK_3);
        dest[4] = ((timeTS << 1) & VIDEORTP_PES_TIMESTAMP_BIT_MASK_4) | VIDEORTP_PES_TIMESTAMP_MARKER_BIT;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesBuildHeader
 *
 *   Function:   Write PES header
 *
 *   Inputs:
 *               VIDEORTP_pesInitPacketizer* self: VIDEORTP_pesInitPacketizer instance that the function works on
 *               VIDEORTP_bufferWriter_t* bufferWriter: Destination buffer (must be large enough for the PES header)
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *               packet_start_code_prefix : 24 bits
 *               stream_id : 8 bits
 *
 *               PES_packet_length : 16 bits
 *
 *               '10' : 2 bits
 *               PES_scrambling_control : 2 bits
 *               PES_priority : 1 bits
 *               data_alignment_indicator : 1 bits
 *               copyright : 1 bits
 *               original_or_copy : 1 bits
 *
 *               PTS_DTS_flags : 2 bits
 *               ESCR_flag : 1 bits
 *               ES_rate_flag : 1 bits
 *               DSM_trick_mode_flag : 1 bits
 *               additional_copy_info_flag : 1 bits
 *               PES_CRC_flag : 1 bits
 *               PES_extension_flag : 1 bits
 *
 *               PES_header_data_length : 16 bits
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static void VIDEORTP_pesBuildHeader(VIDEORTP_pesStreamPacketizer_t* self, VIDEORTP_bufferWriter_t* bufferWriter)
{
    assert(self);
    assert(bufferWriter);

    /*
     * The PES packet size may be 0 for video streams only (types 0xE0 ... 0xEF).
     * If the size fits into the 16 bit PES_packet_length field, we should include it in the header.
     * For all other stream types (including audio), the length must be nonzero always
     */

    size_t pesLength = VIDEORTP_pesGetHeaderSize(self);
    /* number of bytes from start of packet until end of pes_packet_length field */
    pesLength -= VIDEORTP_PES_PACKET_LEN;
    pesLength += self->pesSize;

    if ((pesLength > (size_t) UINT16_MAX)
        && ((self->streamID & (uint8_t) VIDEORTP_PES_VIDEO_STREAM_0) == (uint8_t) VIDEORTP_PES_VIDEO_STREAM_0))
    {
        pesLength = 0;
    }

    /* packet_start_code_prefix */
    VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_START_CODE_PREFIX, VIDEORTP_PES_START_CODE_PREFIX_SIZE);
    /* stream_id */
    VIDEORTP_bufWriteInteger(bufferWriter, self->streamID, sizeof(self->streamID));
    /* PES_packet_length */
    VIDEORTP_bufWriteInteger(bufferWriter, pesLength, sizeof(uint16_t));
    /* '10', PES_scrambling_control, PES_priority, data_alignment_inicator, original_or_copy*/
    VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_FLAGS, sizeof(uint8_t));

    if (VIDEORTP_needDts(self))
    {
        /* PTS_DTS_flags..PES_extension_flag */
        VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_FLAGS_WITH_DTS, sizeof(uint8_t));
        /* PES_header_data_length */
        VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_TIME_SIZE + VIDEORTP_PES_TIME_SIZE, sizeof(uint8_t));

        /* According to MPEG 2.4.3.6 */
        VIDEORTP_pesWriteTimestamp(bufferWriter, self->timePTS, VIDEORTP_TS_TIMESTAMP_TAG_PTSDTS);
        VIDEORTP_pesWriteTimestamp(bufferWriter, self->timeDTS, VIDEORTP_TS_TIMESTAMP_TAG_DTS);
    }
    else
    {
        /* PTS_DTS_flags..PES_extension_flag */
        VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_FLAGS_WITHOUT_DTS, sizeof(uint8_t));
        /* PES_header_data_length */
        VIDEORTP_bufWriteInteger(bufferWriter, VIDEORTP_PES_TIME_SIZE, sizeof(uint8_t));

        VIDEORTP_pesWriteTimestamp(bufferWriter, self->timePTS, VIDEORTP_TS_TIMESTAMP_TAG_PTS);
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesPrepareNextChunk
 *
 *   Function:   Set prepare next chunk
 *
 *   Inputs:
 *               VIDEORTP_pesStreamPacketizer_t* self: VIDEORTP_pesStreamPacketizer_t instance that the function works on
 *               size_t maximumSize: a pointer to predecessor stage
 *               VIDEORTP_payloadChunkInfo_t* metaData: a pointer to predecessor stage
 *
 *   Outputs:
 *               The remaining length of the data
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static size_t VIDEORTP_pesPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);
    VIDEORTP_pesStreamPacketizer_t* self = (void*) vtable;

    size_t nextChunkSize = 0;
    self->needHeader = false;
    nextChunkSize = VIDEORTP_pipePrepareNextChunk(self->base, maximumSize, metaData);
    if (nextChunkSize > (size_t) 0)
    {
        VIDEORTP_pesSetPacketMetaData(self, metaData);
        if (metaData->isPayloadUnitStart)
        {
            /* Need to include the PES header in the first chunk. Double-check that enough space is left for header and payload. */
            size_t headerSize = VIDEORTP_pesGetHeaderSize(self);
            if (maximumSize > headerSize)
            {
                nextChunkSize = VIDEORTP_pipePrepareNextChunk(self->base, maximumSize - headerSize, metaData);
                if (nextChunkSize > (size_t) 0)
                {
                    VIDEORTP_pesSetPacketMetaData(self, metaData);
                    nextChunkSize += headerSize;
                    self->needHeader = metaData->isPayloadUnitStart;
                }
            }
            else
            {
                /* Not enough space for header and at least 1 byte payload */
                nextChunkSize = 0;
            }
        }
    }

    return nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesCopyChunk
 *
 *   Function:   Copy chunk
 *
 *   Inputs:
 *               VIDEORTP_pesStreamPacketizer_t* self: VIDEORTP_pesStreamPacketizer_t instance that the function works on
 *               VIDEORTP_bufferWriter_t* payloadBuffer: a pointer to buffer stage
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-23, MAGAVSTR-843
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_pesStreamPacketizer_t */
static void VIDEORTP_pesCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_pesStreamPacketizer_t* self = (void*) vtable;
    if (self->needHeader)
    {
        VIDEORTP_pesBuildHeader(self, payloadBuffer);
    }
    VIDEORTP_pipeCopyChunk(self->base, payloadBuffer);
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_pesInitPacketizer
 *
 *   Function:   Initialize VIDEORTP_pesInitPacketizer
 *
 *   Inputs:
 *               VIDEORTP_pesInitPacketizer* self: instance that the function works on
 *               VIDEORTP_payloadProvider_t* predecessor: previous pipeline stage
 *               uint8_t streamId: stream id according to H.222.0 2.4.3.7 Table 2-22
 *               - Audio stream IDs = 0xC0 .. 0xDF
 *               - Video stream IDs = 0xE0 .. 0xEF
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-25
 *
 *   Traceability to SW Req: 16805908, 16805944
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_pesInitPacketizer(VIDEORTP_pesStreamPacketizer_t* self, VIDEORTP_payloadProvider_t* predecessor, uint8_t streamId)
{
    assert(self);
    assert(predecessor);

    self->vtable.copyChunk = VIDEORTP_pesCopyChunk;
    self->vtable.prepareNextChunk = VIDEORTP_pesPrepareNextChunk;
    self->streamID = streamId;
    self->timePTS = VIDEORTP_InvalidTimestamp;
    self->timeDTS = VIDEORTP_InvalidTimestamp;
    self->pesSize = 0;
    self->needHeader = false;

    self->base = predecessor;
}
