#ifndef PAYLOAD_PROVIDER_H
#define PAYLOAD_PROVIDER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "sysdef.h"
#include <stdbool.h>
#include <stdint.h>

#include "BufferWriter.h"

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup PayloadProvider
     * @{
     * @brief Main interface of the video pipeline
     *
     * @ref VIDEORTP_payloadProvider_t "PayloadProvider" is the central interface which connects all pipeline stages. Every
     * component which produces or filters data in the pipeline implements this interface.
     *
     * This interface has been designed in a way that allows building packets incrementally without intermediate copies. For
     * example, to wrap an H.264 video stream in RTP packets, it is necessary to
     *
     * - add MPEG-PES headers,
     * - split the frames into smaller chunks,
     * - add MPEG-TS headers,
     * - and finally add RTP headers.
     *
     * Using the @ref VIDEORTP_payloadProvider_t "PayloadProvider" interface, all headers can be added "on the fly" when building an
     * RTP packet. The user only needs to provide a destination buffer (a @ref VIDEORTP_bufferWriter_t "BufferWriter") to the first
     * pipeline stage. Each pipeline stage will in turn write a few bytes of header data and then delegate to the next pipeline
     * stage. This process continues recursively, until the final pipeline stage eventually copies the H.264 video data into the
     * destination buffer. The result is a complete RTP packet in the destination buffer with a minimum amount of @c memcpy calls.
     *
     * @note On one hand, there is some overhead due to the nature of the pipeline (recursive function calls etc.); but on the other
     * hand, the headers and video data can be written directly to the correct position in the destination buffer *without*
     * temporary copies. We believe that avoiding @c memcpy calls to conserve system memory bandwidth justifies the the pipeline
     * design.
     *
     * The base classes PipelineStageWithMultiplePredecessors and PipelineStageWithSinglePredecessor are
     * mainly for convenience. They encapsulate access to the previous stages (producers) of a pipeline
     * stage.
     *
     * @startuml pipeline_interface
     * hide empty members
     *
     * interface PayloadProvider {
     *     + prepareNextChunk(maximumSize : size_t, metaData : PayloadChunkInfo*) : size_t
     *     + copyChunk(payloadBuffer : BufferWriter*) : void
     * }
     *
     * class PayloadChunkInfo <<struct>> {
     *     + sampleTimestamp : Timestamp
     *     + payloadUnitSize : size_t
     *     + isPayloadUnitStart : bool
     *     + isPayloadUnitEnd : bool
     * }
     * PayloadProvider .> PayloadChunkInfo : <<initialize>>
     *
     * class Timestamp <<struct>> {
     *     + mpegPresentationTimestamp : uint64_t
     *     + mpegDecodingTimestamp : uint64_t
     *     + gptpTimestamp : uint32_t
     *     + gptpTimeBaseIndicator : uint16_t
     * }
     * Timestamp --* PayloadChunkInfo
     *
     * class BufferWriter
     * BufferWriter <.. PayloadProvider : <<fill>>
     *
     * class PipelineStageWithSinglePredecessor
     * PayloadProvider "1" --o PipelineStageWithSinglePredecessor
     *
     * class PipelineStageWithMultiplePredecessors
     * PayloadProvider "*" --o PipelineStageWithMultiplePredecessors
     * @enduml
     *
     * @see @ref BufferWriter, @ref PipelineStageWithMultiplePredecessors, @ref PipelineStageWithSinglePredecessor.
     */

    /**
     * @brief Meta data about a payload unit.
     *
     * This struct contains all meta data which are needed to create packet headers
     * outside of the pipeline stage where the information originates.
     */
    typedef struct VIDEORTP_payloadChunkInfo_t
    {
        /** @publicsection @{ */
        /**
         * @brief Sampling timestamp of a video frame.
         */
        VIDEORTP_timestamp sampleTimestamp;

        /**
         * @brief Total size of the whole payload unit in bytes (sum of all chunks).
         */
        size_t payloadUnitSize;

        /**
         * @brief Whether this chunk is the first chunk of a payload unit.
         *
         * This flag is set if and only if the first byte of the current chunk is
         * the first byte of the whole payload unit.
         */
        bool isPayloadUnitStart;

        /**
         * @brief Whether this chunk is the last chunk of a payload unit.
         *
         * This flag is set if and only if the last byte of the current chunk is
         * the last byte of the whole payload unit.
         */
        bool isPayloadUnitEnd;
        /** @} */
    } VIDEORTP_payloadChunkInfo_t;

    /**
     * @brief Initializes a payload chunk info structure.
     * @public @memberof VIDEORTP_payloadChunkInfo_t
     *
     * The flags will be initialized according to the arguments.
     * The timestamps will be initialized to invalid/empty values.
     *
     * @param chunkInfo Structure to initialize
     * @param readPosition current read position within the current frame (payload unit)
     * @param chunkSize size of the next chunk to be returned by the calling pipeline stage
     * @param payloadUnitSize total size of the current frame (payload unit)
     */
    void VIDEORTP_initPayloadChunkInfo(VIDEORTP_payloadChunkInfo_t* chunkInfo, size_t readPosition, size_t chunkSize,
                                       size_t payloadUnitSize);

    /**
     * @brief Pipeline output interface.
     *
     * This is the output interface of a pipeline intended to (re-)packetize data.
     * Pipeline stages usually add headers or other pieces information on the fly.
     *
     * The initial input to a pipeline is a sequence of "payload units".
     * Each payload unit represents one self-contained "unit" of data.
     * For instance, this could be one (encoded) frame of a video (MPEG).
     * Payload units do not overlap. Every byte belongs to exactly one payload unit.
     *
     * Pipeline stages generally implement one of the following operations:
     *
     * - Generate/provide data: The first pipeline stage provides payload units to
     *   subsequent stages. This data could be read from a different system (e.g.,
     *   via network or from a file) or it could be completely synthetic (generated
     *   on demand). This stage defines where payload units start and end.
     *
     * - Packetize data: Some pipeline stages split their input into smaller
     *   packets, or they merge smaller packets into bigger packets.
     *   Usually these pipeline stages also add a header to the data.
     *
     * - Insert data: A common use case is to add protocol headers to some chunk of
     *   data. Those pipeline stages usually add/generate a few bytes on their own;
     *   then they delegate the call to their respective predecessor which provides
     *   the remaining data.
     *
     * - Modify (meta) data: Some pipeline stages modify their input data. Usually,
     *   they only modify meta data (such as timestamps or flags), although they
     *   could overwrite the whole payload.
     *
     * - Analyze (meta) data: Some pipeline stages analyze data passed through,
     *   e.g., to measure bandwidth and throughput. This information can be useful
     *   for controlling other pipeline stages.
     *
     * - Control data flow: Some pipeline stages control the flow between other
     *   pipeline stages. For instance, they merge multiple (sub-) pipelines
     *   like a multiplexer; or they delay some packets to throttle bandwidth.
     *
     * Usually payload units are not processed as a whole but in smaller chunks.
     * The actual chunk size is determined by several factors:
     *
     * - The size of the output buffer provided to the last pipeline stage; This
     *   size may be limited by external constraints, such as the maximum record
     *   size in a file or the maximum packet size of a network protocol.
     *   For example, network packets often are limited to 1500 bytes or less.
     *
     * - The allowed packet or chunk size of intermediate pipeline stages; This
     *   depends on the protocol specifications of the pipeline.
     *   For example, the size of MPEG-TS packets is fixed to 188 bytes.
     *
     * - The size of additional protocol headers inserted by intermediate stages,
     *   since each header effectively reduces the available buffer size.
     *
     * Most pipeline stages, however, do not care about the size of a chunk.
     *
     * Note that chunks, as provided by the initial pipeline stage, never span
     * multiple payload units. There may be pipeline stages which merge chunks of
     * different payload units, however (e.g., MPEG-TS multiplexer or RTP packetizer).
     *
     * The pipeline has been designed in a way to defer the actual data copy or
     * generation operation as long as possible in order to save memory bandwidth.
     *
     * The user of a pipeline provides a destination buffer to the last pipeline stage.
     * This buffer is forwarded among intermediate pipeline stages until the first
     * stage; that stage eventually copies (or generates) a chunk of the original
     * payload unit into the destination buffer. Ideally, the payload unit will be
     * copied only once, directly to the correct location in the destination buffer.
     * The other pipeline stages merely add their headers to the destination buffer.
     *
     * For this purpose, the "copy" operation is split into two phases:
     *
     * - The preparation step (see @ref VIDEORTP_payloadProvider_t#prepareNextChunk
     *   "prepareNextChunk"), where the pipeline user (or a "successor" pipeline stage)
     *   and the last pipeline stage (or a "predecessor" pipeline stage, respectively)
     *   determine the size of the next payload chunk.
     *
     * - The writing step (see @ref VIDEORTP_payloadProvider_t#copyChunk "copyChunk"),
     *   where a pipeline stage actually writes data into the provided destination buffer.
     *
     * The user must call @ref VIDEORTP_payloadProvider_t#prepareNextChunk
     * "prepareNextChunk" at least once so the pipeline stage can
     * determine how big the destination buffer (and therefore the payload chunk)
     * will be. It also reports (via VIDEORTP_payloadChunkInfo_t) whether the next
     * chunk is the very first or last chunk of the current payload unit.
     * @ref VIDEORTP_payloadProvider_t#copyChunk "copyChunk" eventually writes
     * that exact chunk into the destination buffer.
     *
     * @startuml pipeline_interface_sequence
     * hide footbox
     *
     * loop while prepareNextChunk() returns 0, but at least once
     *   Consumer -> Producer++ : prepareNextChunk()
     *   note right
     *   Only the last call is binding.
     *   end note
     *   return
     * end
     *
     * Consumer -> Producer++ : copyChunk()
     * note right
     * Actual copying or generation of data
     * end note
     * return
     * @enduml
     *
     * If the destination buffer is not suitable, or not enough data is available,
     * @ref VIDEORTP_payloadProvider_t#prepareNextChunk "prepareNextChunk"
     * returns 0. The user should then try again later with a
     * bigger buffer, or when more data is available, respectively.
     *
     * @note To implement this interface, add a VIDEORTP_payloadProvider_t
     * field at the beginning of your struct and set its function pointers to
     * functions in your module. Use @ref VIDEORTP_pipePrepareNextChunk
     * and @ref VIDEORTP_pipeCopyChunk to call its methods.
     * See @ref id_ood for further details.
     */
    typedef struct VIDEORTP_payloadProvider_t
    {
        /** @protectedsection @{ */
        /**
         * @brief Negotiate the size of the next data chunk.
         *
         * The **maximum buffer size** is provided by the caller and defines the
         * maximum number of bytes that the caller can accept from the callee.
         * It is specified as argument so that the callee can decide how much of it
         * can be used.
         *
         * The **maximum chunk size** is the amount of available data. The callee
         * returns the smaller value of both sizes (which is the amount of data it
         * would like to copy), which then becomes the **minimum buffer size** it
         * expects for the copyChunk call.
         *
         * If the amount of available data is smaller than the **minimum chunk size**
         * (a number only known internally by the callee), the copy action is refused
         * by returning 0.
         *
         * The user of this interface must provide a buffer that is large enough for
         * the negotiated chunk size. The buffer may be larger.
         * The implementation of this interface must write exactly the amount of
         * data that has been negotiated.
         *
         * #copyChunk must write the exact amount of data into the provided buffer;
         * because otherwise the flags announced in VIDEORTP_payloadChunkInfo_t might be wrong.
         *
         * prepareNextChunk must be called at least once before calling #copyChunk.
         * Calling prepareNextChunk multiple times is allowed. No data will be copied
         * or modified unless #copyChunk is actually called. Only the last call
         * determines the effects of #copyChunk.
         *
         * The negotiated result remains valid until a call to copyChunk has occurred
         * or the involved objects have been altered otherwise.
         *
         * @param self Points to the vtable of an instance implementing this interface.
         * @param maximumSize specifies the maximum buffer size provided by the caller.
         * @param metaData specifies the chunk that will be returned if copyChunk
         * is called and filled by the callee (output parameter); if the return value
         * is 0 the contents is undefined.
         *
         * @return Returns the negotiated buffer size. If the negotiation failed
         * (e.g., because only an unsuitable buffer size was offered), 0 will be returned.
         */
        /* Traceability to SW Req: 16813256 */
        size_t (*prepareNextChunk)(struct VIDEORTP_payloadProvider_t* self, size_t maximumSize,
                                   VIDEORTP_payloadChunkInfo_t* metaData);

        /**
         * @brief Copy the next chunk of the current payload unit.
         *
         * Copy data (as determined by the most recent #prepareNextChunk call) from
         * this pipeline stage into the provided buffer. If the most recent call to
         * #prepareNextChunk returned 0, copyChunk must not be called. After
         * copyChunk has been called, it must not be called again until
         * #prepareNextChunk was called again.
         *
         * For example, the provided data may be raw data, generated data, or
         * possibly some header and payload provided by another pipeline stage.
         *
         * @param self Points to the vtable of an instance implementing this interface.
         * @param payloadBuffer The destination buffer which receives the next chunk of data.
         */
        /* Traceability to SW Req: 16813256 */
        void (*copyChunk)(struct VIDEORTP_payloadProvider_t* self, VIDEORTP_bufferWriter_t* payloadBuffer);
        /** @} */
    } VIDEORTP_payloadProvider_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /** @copydoc VIDEORTP_payloadProvider_t::prepareNextChunk
     * @public @memberof VIDEORTP_payloadProvider_t */
    static inline size_t VIDEORTP_pipePrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                                       VIDEORTP_payloadChunkInfo_t* metaData)
    {
        return (*vtable->prepareNextChunk)(vtable, maximumSize, metaData);
    }

    /** @copydoc VIDEORTP_payloadProvider_t::copyChunk
     * @public @memberof VIDEORTP_payloadProvider_t */
    static inline void VIDEORTP_pipeCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
    {
        (*vtable->copyChunk)(vtable, payloadBuffer);
    }

    /**@} PayloadProvider global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
