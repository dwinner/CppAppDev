/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "AvbRtcpPacketBuilder.h"
#include <assert.h>
#include <string.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtcpInitConfig
 *
 *   Function:   Initialize VIDEORTP_avbRtcpPacketBuilder_t instance
 *
 *   Inputs:
 *               VIDEORTP_rtcpSessionConfiguration_t* configuration: The instance of VIDEORTP_rtcpSessionConfiguration_t
 *               VIDEORTP_rtpStreamingMode_t streamingMode: Controls rtp header setting switcher
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-125
 *
 *   Traceability to SW Req: 16802568, 16802570, 16805562, 16805566, 16805588, 16805593, 16805598, 16805694, 16805822, 16805842
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_rtcpInitConfig(VIDEORTP_rtcpSessionConfiguration_t* configuration, VIDEORTP_rtpStreamingMode_t streamingMode)
{
    /* IP_AVT mode uses by default */
    configuration->streamingMode = streamingMode;
    switch (configuration->streamingMode)
    {
        case VIDEORTP_rtpStreamingMode_IP_AVT_ISOCHRONOUS:
            configuration->payloadType = VIDEORTP_RTCP_IP_AVT_ISO_PAYLOAD_TYPE;
            break;
        case VIDEORTP_rtpStreamingMode_IP_AVT_SYNCHRONOUS:
            configuration->payloadType = VIDEORTP_RTCP_IP_AVT_SYN_PAYLOAD_TYPE;
            break;
        /* case VIDEORTP_rtpStreamingMode_RFC2250: */
        default:
            configuration->payloadType = VIDEORTP_RTCP_RFC2250_PAYLOAD_TYPE;
            break;
    }
    memset(configuration->ssrc, 0, VIDEORTP_RTCP_SSRC_SIZE);
    memset(configuration->rtcpName, 0, VIDEORTP_RTCP_NAME_SIZE);
    memset(configuration->gmIdentity, 0, VIDEORTP_RTCP_GM_IDENTITY_SIZE);
    memset(configuration->streamId, 0, VIDEORTP_RTCP_STREAM_ID_SIZE);
    configuration->deliveryCompensationOffset = 0;
    configuration->initialSequenceCounter = 1;
    configuration->initialTimestamp = 0;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtcpInit
 *
 *   Function:   Initialize VIDEORTP_avbRtcpPacketBuilder_t instance
 *
 *   Inputs:
 *               VIDEORTP_avbRtcpPacketBuilder_t* self: The instance of VIDEORTP_avbRtcpPacketBuilder_t
 *               const VIDEORTP_rtcpSessionConfiguration_t* configuration: Pointer to session configuration
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-125
 *
 *   Traceability to SW Req: 16802568, 16802570, 16805562, 16805566, 16805588, 16805593, 16805598, 16805694, 16805822
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_rtcpInit(VIDEORTP_avbRtcpPacketBuilder_t* self, const VIDEORTP_rtcpSessionConfiguration_t* configuration)
{
    assert(self);
    assert(configuration);

    self->configuration = configuration;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_rtcpBuildPacket
 *
 *   Function:   Writes an AVB RTCP packet to the destination buffer.
 *
 *   Inputs:
 *               VIDEORTP_avbRtcpPacketBuilder_t* self: The instance of VIDEORTP_avbRtcpPacketBuilder_t
 *               uint32_t rtpTimestamp: RTP timestamp/counter of previous RTP packet [IP_AVT_1537]
 *               uint32_t ieeeTimestamp: IEEE 802.1AS timestamp of the same RTP packet [IP_AVT_1786]
 *               uint32_t ieeeTimeBaseIndicator: IEEE 802.1AS time base indicator of the timestamp [IP_AVT_1786]
 *               VIDEORTP_bufferWriter_t* packetBuffer: Destination buffer for RTCP packet
 *
 *   Outputs:
 *              bool true: if VIDEORTP_bufGetAvailableSpace(packetBuffer) >= VIDEORTP_RTCP_PACKET_SIZE
 *              bool false: VIDEORTP_bufGetAvailableSpace(packetBuffer) < VIDEORTP_RTCP_PACKET_SIZE
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-125
 *
 *   Traceability to SW Req: 16802568, 16802570, 16805562, 16805566, 16805588, 16805593, 16805598, 16805694, 16805822, 16805894,
 * 16805952
 *
 *   Remarks:   According with IEEE 1733:
 *              - 2 bits version : always 2
 *              - 1 bit padding : always 0
 *              - 5 bits reportCount : always 0
 *
 *              - 8 bits packetType : always 208 (AVB RTCP)
 *              - 16 bits length : always 9
 *              - 32 bits bits SSRC :  from configuration
 *              - 32 bits name : from configuration
 *
 *              - 16 bits gmTimeBaseIndicator: parameter
 *              - 80 bits gmIdentity : from configuration
 *
 *              - 64 bits streamId : from configuration
 *              - 32 bits asTimestamp : taken in the function
 *              - 32 bits rtpTimestamp : taken in the function
 *
 *              In result: 320 bits = 40 bytes => length = 40/4 - 1 = 9 (according with IEEE 1733)
 *
 * ========================================================================= */
bool VIDEORTP_rtcpBuildPacket(VIDEORTP_avbRtcpPacketBuilder_t* self, uint32_t rtpTimestamp, uint32_t ieeeTimestamp,
                              uint16_t ieeeTimeBaseIndicator, VIDEORTP_bufferWriter_t* packetBuffer)
{
    assert(self);
    assert(packetBuffer);

    bool res = VIDEORTP_bufGetAvailableSpace(packetBuffer) >= (uint32_t) VIDEORTP_RTCP_PACKET_SIZE;

    if (res)
    {
        /* version number, padding and report counter */
        VIDEORTP_bufWriteInteger(packetBuffer, VIDEORTP_RTCP_HEADER_START, sizeof(uint8_t));

        /* packet type */
        VIDEORTP_bufWriteInteger(packetBuffer, VIDEORTP_RTCP_AVB_PACKET_TYPE, sizeof(uint8_t));

        /* length */
        VIDEORTP_bufWriteInteger(packetBuffer, VIDEORTP_RTCP_LENGTH_VALUE, sizeof(uint16_t));

        /* write ssrc */
        VIDEORTP_bufWriteData(packetBuffer, self->configuration->ssrc, VIDEORTP_RTCP_SSRC_SIZE);

        /* write name */
        VIDEORTP_bufWriteData(packetBuffer, self->configuration->rtcpName, VIDEORTP_RTCP_NAME_SIZE);

        /* gmTimeBaseIndicator */
        VIDEORTP_bufWriteInteger(packetBuffer, ieeeTimeBaseIndicator, sizeof(ieeeTimeBaseIndicator));

        /* gmIdentity */
        VIDEORTP_bufWriteData(packetBuffer, self->configuration->gmIdentity, VIDEORTP_RTCP_GM_IDENTITY_SIZE);

        /* streamId */
        VIDEORTP_bufWriteData(packetBuffer, self->configuration->streamId, VIDEORTP_RTCP_STREAM_ID_SIZE);

        /* timestamps */
        VIDEORTP_bufWriteInteger(packetBuffer, ieeeTimestamp, sizeof(ieeeTimestamp));
        VIDEORTP_bufWriteInteger(packetBuffer, rtpTimestamp, sizeof(rtpTimestamp));
    }

    return res;
}
