#ifndef BUFFER_WRITER_H
#define BUFFER_WRITER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup BufferWriter
     * @{
     *
     * @brief The BufferWriter class encapsulates a piece of memory for writing into.
     *
     * The memory can be of any type (e.g. stack, heap), it just needs to stay
     * valid as long as the BufferWrite instance uses it. The memory's address
     * and size are passed to the @ref VIDEORTP_bufInit "init" method.
     *
     * As the name sugests, the BufferWriter focuses on *writing* data into the
     * buffer using the methods @ref VIDEORTP_bufWriteData "writeData",
     * @ref VIDEORTP_bufWriteInteger "writeInteger" and
     * @ref VIDEORTP_bufWritePattern "writePattern". To obtain the result of all
     * subsequent writing actions the method @ref VIDEORTP_bufGetBasePointer
     * "getBasePointer" should be used (rather then remembering the original
     * pointer that was passed).
     *
     * The BufferWriter keeps track of the current write position (where new
     * data are inserted) and the total amount of memory which is managed. By
     * this it prevents any write attempts that go beyond the buffer's end.
     * To obtain a piece of memory for writing into directly the method
     * @ref VIDEORTP_bufGetWritableChunk "getWritableChunk" can be used.
     *
     * Another feature of the BufferWriter is to spawn child writers by using
     * @ref VIDEORTP_bufSpawnChildWriter "spawnChildWriter". A child writer
     * uses the same piece of memory as its parent writer, but the parent
     * writer's write position is moved beyond the end of the child writer's
     * share. This allows out-of-order writing (e.g. the child writer can be
     * used in parallel or after the parent writer received new data) without
     * running into the danger of overwriting data.
     *
     * Beware: The whole buffer of the child writer must be written. Otherwise
     * there will be a "gap" of uninitialized garbage between the last written
     * byte of the child writer and the next piece of data in the parent writer.
     */

    /**
     * @brief Structure holding the data specific to a @ref BufferWriter instance.
     */
    typedef struct
    {
        /** @privatesection @{ */
        /**
         * @brief buffer start pointer
         * @invariant if #capacity > 0 then #basePointer != NULL
         */
        uint8_t* basePointer;
        /**
         * @brief current write position
         * @invariant 0 <= #writePosition <= #capacity
         */
        size_t writePosition;
        /**
         * @brief buffer capacity available to write for this BufferWriter
         * @invariant #basePointer[0] ... #basePointer[capacity - 1] is valid memory
         */
        size_t capacity;
        /** @} */
    } VIDEORTP_bufferWriter_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief init VIDEORTP_bufferWriter_t instance
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param buffer buffer where VIDEORTP_bufferWriter_t must write
     * @param capacity buffer capacity
     */
    void VIDEORTP_bufInit(VIDEORTP_bufferWriter_t* self, void* buffer, const size_t capacity);

    /**
     * @brief write data to buffer by length
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param data must be copied data
     * @param length length of must be copied data
     * @return true if data copied successful
     * @return false if data copied fail
     */
    bool VIDEORTP_bufWriteData(VIDEORTP_bufferWriter_t* self, const void* data, const size_t length);

    /**
     * @brief It shall copy bytes from data by length as big endian
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param data must be copied data
     * @param typeSize length of must be copied data
     * @return true if data copied successful
     * @return false if data copied fail
     */
    bool VIDEORTP_bufWriteInteger(VIDEORTP_bufferWriter_t* self, const uint64_t data, const uint8_t typeSize);

    /**
     * @brief Fill the buffer with a pattern.
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param pattern recordable sample
     * @param length length of must be filled by pattern
     * @return true if pattern success wrote
     * @return false if pattern fail wrote
     */
    bool VIDEORTP_bufWritePattern(VIDEORTP_bufferWriter_t* self, const uint8_t pattern, const size_t length);

    /**
     * @brief It shall create child VIDEORTP_bufferWriter_t whom can write chunk buffer
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @note Create child VIDEORTP_bufferWriter_t and set self.writePosition after child.basePointer
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param length child buffer length from current writer position
     * @return VIDEORTP_bufferWriter_t
     * @return nullptr if child create invalid child.basePointer == nullptr && childLength == 0
     */
    VIDEORTP_bufferWriter_t VIDEORTP_bufSpawnChildWriter(VIDEORTP_bufferWriter_t* self, const size_t length);

    /**
     * @brief It shall return buffer base pointer
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     *
     * @return void*
     */
    void* VIDEORTP_bufGetBasePointer(const VIDEORTP_bufferWriter_t* self);

    /**
     * @brief It shall return current buffer write position
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     *
     * @return size_t writePosition
     */
    size_t VIDEORTP_bufGetBytesWritten(const VIDEORTP_bufferWriter_t* self);

    /**
     * @brief It shall return buffer available space
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     *
     * @return size_t available space in buffer
     */
    size_t VIDEORTP_bufGetAvailableSpace(const VIDEORTP_bufferWriter_t* self);

    /**
     * @brief It shall set writePosition to 0
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     *
     */
    void VIDEORTP_bufClear(VIDEORTP_bufferWriter_t* self);

    /**
     * @brief Check if the requested amount memory is available and return a pointer to that.
     * @public @memberof VIDEORTP_bufferWriter_t
     *
     * @param self VIDEORTP_bufferWriter_t instance
     * @param length length writable chunk
     * @return uint8_t* next pointer after chunk length
     * @return uint8_t* nullptr if chunk out of range buffer
     *
     */
    uint8_t* VIDEORTP_bufGetWritableChunk(VIDEORTP_bufferWriter_t* self, const size_t length);

    /**@} BufferWriter global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* BUFFER_WRITER_H */
