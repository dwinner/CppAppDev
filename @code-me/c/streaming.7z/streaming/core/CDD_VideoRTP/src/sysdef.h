#if !defined(SYS_DEF_H)
#define SYS_DEF_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif
/**
 * \defgroup util Utilities
 * @{
 * @brief Helper functions and macros
 */

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */

/**
 * @brief Declare that some parameters or variables may be unused (e.g., in release builds)
 */
#define VIDEORTP_unused(x) (void) (x)

/**
 * @brief Invalid value for timestamp
 *
 */
#define VIDEORTP_InvalidTimestamp UINT64_MAX

/** @brief Returns the lesser value */
#define VIDEORTP_sysGetMin(x, y) (((x) < (y)) ? (x) : (y))
/** @brief Returns the greater value */
#define VIDEORTP_sysGetMax(x, y) (((x) > (y)) ? (x) : (y))

/** @brief Normal unsigned integer division, rounding down */
#define VideoRTP_divideRoundDown(n, d) ((n) / (d))
/** @brief Unsigned integer division, but rounding up */
#define VideoRTP_divideRoundUp(n, d) (((d) - (1) + (n)) / (d))

    /**
     * @brief Lists possible errors of the public VideoRTP API
     */
    typedef enum VideoRTP_errorCode
    {
        VideoRTP_ok = 0, /* success; no error occurred */
        VideoRTP_error = 1, /* generic error; unspecified reason */
        VideoRTP_queueEmpty, /* the IPC queue is empty; nothing to send at the moment */
        VideoRTP_queueFull, /* the IPC queue is full; cannot store more data (congestion) */
        VideoRTP_networkError, /* PduR_CddTransmit returned an error; packets were discarded */
        VideoRTP_invalidCall, /* the interface is used incorrectly (e.g., call deinit before init, etc.) */
        VideoRTP_invalidParameter, /* an invalid parameter was passed to a function (NULL pointer, etc.) */
    } VideoRTP_errorCode;

    /**
     * @brief Sampling timestamp of a video frame in different time bases (for MPEG, RTP and RTCP)
     */
    typedef struct VIDEORTP_timestamp
    {
        /**
         * @brief Presentation timestamp from Media Clock (27MHz MPEG System Clock)
         * @note This timestamp should never overflow in practice.
         * @note This timestamp is to be derived from the Media Clock which must not jump!
         * @note Set this to VIDEORTP_InvalidTimestamp if unused or not applicable.
         */
        uint64_t mpegPresentationTimestamp;

        /**
         * @brief Decoding timestamp from Media Clock (27MHz MPEG System Clock)
         * @invariant Must be equal to VIDEORTP_InvalidTimestamp if and only if mpegPresentationTimestamp is invalid.
         * @invariant Must be less than or equal to mpegPresentationTimestamp otherwise.
         */
        uint64_t mpegDecodingTimestamp;

        /**
         * @brief Presentation timestamp in IEEE 802.1AS clock for IEEE 802.1 AVB (RTCP).
         * @note This timestamp is derived from a wall clock, so it might jump.
         */
        uint32_t gptpTimestamp;

        /**
         * @brief Source (or "version number") of the IEEE802.1AS time.
         * @note gmIdentity must be provided separately.
         */
        uint16_t gptpTimeBaseIndicator;
    } VIDEORTP_timestamp;

/**@} */
#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* SYS_DEF_H */
