#ifndef PIPE_LINE_STAGE_WITH_MULTIPLE_PREDECESSORS_H
#define PIPE_LINE_STAGE_WITH_MULTIPLE_PREDECESSORS_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "PayloadProvider.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * \defgroup PipelineStageWithMultiplePredecessors
 * @{
 *
 * @brief Helper class to handle multiple predecessor pipeline stages
 *
 * The PipelineStageWithMultiplePredecessors class holds a list of pipeline stages that
 * can be addressed by index. Since use of dynamic memory is not allowed, a worst-case
 * assumption of the number of possible predecessors must be made (@ref VIDEORTP_MAX_PREDECESSOR_COUNT).
 *
 * When initialized the instance doesn't know any predecessors. They need to be added by a call to
 * the @ref VIDEORTP_pipeAddMultiplePredecessor "addPredecessor" method.
 *
 * For iterating over the predecessors the methods @ref VIDEORTP_pipeGetMultiplePredecessorCount
 * "getPredecessorCount" and @ref VIDEORTP_pipeGetMultiplePredecessor "getPredecessor" exist.
 *
 * @note In the original concept this was a base class to derive from; with the concept converted to
 * ANSI-C an instance of this class should be aggregated to achieve the same functionality.
 */

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */

/**
 * @brief Maximum number of predecessors to store
 *
 */
#define VIDEORTP_MAX_PREDECESSOR_COUNT (5)

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Helper class for pipeline stage which should have multiple predecessor
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct
    {
        /** @privatesection @{ */
        /**
         * @brief Pointer to predecessor
         *
         */
        VIDEORTP_payloadProvider_t* predecessor[VIDEORTP_MAX_PREDECESSOR_COUNT];

        /**
         * @brief Number of elements in the array
         *
         */
        size_t count;
        /** @} */
    } VIDEORTP_pipelineStageWithMultiplePredecessors_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize fields of self
     * @public @memberof VIDEORTP_pipelineStageWithMultiplePredecessors_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_pipeInitStageWithMultiplePredecessors(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self);

    /**
     * @brief Add predecessor stage
     * @public @memberof VIDEORTP_pipelineStageWithMultiplePredecessors_t
     *
     * @param self instance that the function works on
     * @param predecessor pointer to predecessor stage
     */
    void VIDEORTP_pipeAddMultiplePredecessor(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self,
                                             VIDEORTP_payloadProvider_t* predecessor);

    /**
     * @brief Get predecessor stage
     * @public @memberof VIDEORTP_pipelineStageWithMultiplePredecessors_t
     *
     * @param self instance that the function works on
     * @param index the position of the requested predecessors
     * @return VIDEORTP_payloadProvider_t* pointer to predecessor stage
     */
    VIDEORTP_payloadProvider_t* VIDEORTP_pipeGetMultiplePredecessor(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self,
                                                                    const size_t index);

    /**
     * @brief Returns the number of predecessors
     * @public @memberof VIDEORTP_pipelineStageWithMultiplePredecessors_t
     *
     * @param self instance that the function works on
     * @return count to predecessor stage
     */
    size_t VIDEORTP_pipeGetMultiplePredecessorCount(VIDEORTP_pipelineStageWithMultiplePredecessors_t* self);

    /**@} PipelineStageWithMultiplePredecessors global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PIPE_LINE_STAGE_WITH_MULTIPLE_PREDECESSORS_H */
