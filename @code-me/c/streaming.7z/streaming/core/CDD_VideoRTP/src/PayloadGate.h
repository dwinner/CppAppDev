#ifndef PayloadGate_H_INCLUDED
#define PayloadGate_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */
#include "PipelineStageWithSinglePredecessor.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * \defgroup PayloadGate
     * @{
     *
     * @brief Pipeline stage that lets pass exactly one payload unit after being enabled.
     *
     * @startuml PayloadGate
     * hide empty members
     * interface "PayloadProvider" as p1
     * interface "PayloadProvider" as p2
     * class PayloadGate {
     *   enable() : void
     * }
     * p1 <|.. PayloadGate : <<implement>>
     * PayloadGate o- p2
     * @enduml
     *
     * The PayloadGate returns "no data" unless it is explicitly enabled by a call
     * to the @ref VIDEORTP_gateEnable "enable" method. After that calls to retrieve
     * data are directly forwarded to the gate's predecessor stage.
     * After the last piece of the current payload unit has passed, the gate
     * disables itself again and stays shut until the next call to
     * @ref VIDEORTP_gateEnable "enable" occurs.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Structure holding the data specific to a @ref PayloadGate instance.
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct
    {
        /** @privatesection @{ */
        /**
         * @brief Allocation of base class
         *
         */
        VIDEORTP_payloadProvider_t base;
        /**
         * @brief Predecessor stage
         *
         */
        VIDEORTP_pipelineStageWithSinglePredecessor_t predecessor;
        /**
         * @brief Counts how many payload units may pass (how often this gate was @ref VIDEORTP_gateEnable "enabled")
         *
         */
        uint32_t enabled;
        /**
         * @brief How many @ref VIDEORTP_gateEnable "enable" calls may be accumulated.
         * Additional requests will be ignored.
         *
         */
        uint32_t maximum;
        /**
         * @brief Flag that last chunk of data is prepared (default = false)
         *
         */
        bool lastChunk;
        /** @} */
    } VIDEORTP_payloadGate_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize fields of self
     * @public @memberof VIDEORTP_payloadGate_t
     *
     * @param self pointer to instance
     * @param maximum maximum number of @ref VIDEORTP_gateEnable "enable" calls that can be accumulated
     */
    void VIDEORTP_gateInit(VIDEORTP_payloadGate_t* self, VIDEORTP_payloadProvider_t* predecessor, uint32_t maximum);

    /**
     * @brief Enable gate stage of pipeline to let one additional frame pass through (up to the configured maximum)
     * @public @memberof VIDEORTP_payloadGate_t
     *
     * @param self pointer to instance
     */
    void VIDEORTP_gateEnable(VIDEORTP_payloadGate_t* self);

    /**@} PayloadGate global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif
