/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "PayloadUnitSequenceRepeater.h"
#include <assert.h>
#include <stddef.h>

/* ===========================================================================
 *
 *   Name:       VIDEORTP_seqPrepareNextChunk
 *
 *   Function:   It shall return the minimum of maximumSize and content length
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               size_t maximumSize: maximum available space of destination buffer
 *               VIDEORTP_PayloadChunkInfo_t* metaData: meta data of next chunk
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-132, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks: Implementation of VIDEORTP_PayloadProvider_t
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadUnitSequenceRepeater_t */
static size_t VIDEORTP_seqPrepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                           VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    VIDEORTP_payloadUnitSequenceRepeater_t* self = (VIDEORTP_payloadUnitSequenceRepeater_t*) ((void*) vtable);
    size_t bufferLength = self->payloadUnitArray[self->payloadUnitArrayPosition].length;
    self->nextChunkSize = VIDEORTP_sysGetMin(bufferLength - self->readPosition, maximumSize);
    VIDEORTP_initPayloadChunkInfo(metaData, self->readPosition, self->nextChunkSize, bufferLength);

    return self->nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_seqCopyChunk
 *
 *   Function:   Copy as much data into payloadBuffer as promissed in last call VIDEORTP_seqPrepareNextChunk
 *
 *   Inputs:
 *               PayloadProvider* vtable: PayloadProvider instance that the function works on
 *               VIDEORTP_BufferWriter_t* payloadBuffer: destination VIDEORTP_BufferWriter_t
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-132, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_payloadUnitSequenceRepeater_t */
static void VIDEORTP_seqCopyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    VIDEORTP_payloadUnitSequenceRepeater_t* self = (VIDEORTP_payloadUnitSequenceRepeater_t*) ((void*) vtable);

    /* Copy the next chunk of the current payload unit */
    const uint8_t* chunkStartPointer
        = (const uint8_t*) self->payloadUnitArray[self->payloadUnitArrayPosition].buffer + self->readPosition;
    VIDEORTP_bufWriteData(payloadBuffer, chunkStartPointer, self->nextChunkSize);
    self->readPosition += self->nextChunkSize;

    /* Go to the next payload unit if the end of the current payload unit was reached. */
    if (self->readPosition == self->payloadUnitArray[self->payloadUnitArrayPosition].length)
    {
        self->readPosition = 0;
        self->payloadUnitArrayPosition = self->payloadUnitArrayPosition + (size_t) 1;

        /* Restart if all payload units were copied. */
        if (self->payloadUnitArraySize == self->payloadUnitArrayPosition)
        {
            self->payloadUnitArrayPosition = 0;
        }
    }
}

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_repInit
 *
 *   Function:   Initialize VIDEORTP_PayloadUnitSequnceRepeater_t
 *
 *   Inputs:
 *               VIDEORTP_PayloadUnitRepeater_t* self: Instance to initialize
 *               const VIDEORTP_payloadUnit_t* unitArray: Array of payload units to read from
 *               const size_t arraySize: Count of payload units in array
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-132, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks: The provided array must remain valid throughout the lifetime of the payload unit sequence repeater.
 *
 * ========================================================================= */

void VIDEORTP_seqInit(VIDEORTP_payloadUnitSequenceRepeater_t* self, const VIDEORTP_payloadUnit_t* unitArray, const size_t arraySize)
{
    assert(self);
    assert(unitArray);
    assert(arraySize);

    self->vtable.prepareNextChunk = VIDEORTP_seqPrepareNextChunk;
    self->vtable.copyChunk = VIDEORTP_seqCopyChunk;

    self->payloadUnitArray = unitArray;
    self->payloadUnitArraySize = arraySize;

    self->readPosition = 0;
    self->nextChunkSize = 0;
    self->payloadUnitArrayPosition = 0;
}
