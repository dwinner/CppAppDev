/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "PaddingStream.h"
#include "VideoRtpUtil.h"
#include <assert.h>

#define VIDEORTP_PADDING_PID 0x0200
#define VIDEORTP_PADDING_UPDATE_INTERVAL 100 /* ms */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_initPaddingStream
 *
 *   Function:   The function initializes a padding stream to increase the used bandwidth for testing
 *
 *   Inputs:
 *               VIDEORTP_paddingStream_t* stream: VIDEORTP_paddingStream_t instance that the function works on
 *               uint32_t targetDataRate: Desired target bandwidth (bytes per second)
 *               const VIDEORTP_initConfiguration_t* config: Counter pipeline stage which measures video bandwidth
 *
 *   Outputs:
 *               Pointer to the output pipeline stage which should be connected to the next stage.
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
VIDEORTP_payloadProvider_t* VIDEORTP_initPaddingStream(VIDEORTP_paddingStream_t* stream, uint32_t targetDataRate,
                                                       VIDEORTP_payloadDataCounter_t* counter)
{
    assert(targetDataRate > 0);

    stream->counter = counter;

    /* Update padding as soon as possible */
    stream->timer = VIDEORTP_PADDING_UPDATE_INTERVAL;

    VIDEORTP_padCalcInit(&stream->calculator, targetDataRate);
    VIDEORTP_padInit(&stream->generator);
    VIDEORTP_tsInitPacketizer(&stream->tsPacketizer, &stream->generator.base, VIDEORTP_PADDING_PID, NULL, NULL);

    return &stream->tsPacketizer.vtable;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_cyclicPaddingStream
 *
 *   Function:   Cyclically updates the amount of padding
 *
 *   Inputs:
 *               VIDEORTP_paddingStream_t* stream: VIDEORTP_paddingStream_t instance that the function works on
 *               uint32_t timeSinceLastCall: Time since the last call of this function
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-662
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_cyclicPaddingStream(VIDEORTP_paddingStream_t* stream, uint32_t timeSinceLastCall)
{
    /* Update amount of padding */
    if (VIDEORTP_timerTick(&stream->timer, timeSinceLastCall, VIDEORTP_PADDING_UPDATE_INTERVAL))
    {
        stream->generator.padding = VIDEORTP_padCalcPadding(&stream->calculator, VIDEORTP_cntGetCounter(stream->counter),
                                                            VIDEORTP_PADDING_UPDATE_INTERVAL);
        VIDEORTP_cntResetCounter(stream->counter);
    }
}
