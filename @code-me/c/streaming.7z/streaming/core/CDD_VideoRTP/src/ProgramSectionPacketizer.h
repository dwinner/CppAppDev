#ifndef PROGRAM_SECTION_PACKETIZER_H
#define PROGRAM_SECTION_PACKETIZER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "PayloadProvider.h"
#include "PipelineStageWithSinglePredecessor.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
/**
 * \defgroup ProgramSectionPacketizer
 * @{
 * @brief Adds a pointer field to MPEG program table sections so they can be wrapped in TS packets.
 *
 * A TS packet can contain multiple program sections (or parts thereof); Furthermore, a section can span multiple TS packets.
 * Nevertheless, a receiver/decoder can easily find the beginning of a section by following the pointer field at the beginning of a
 * TS packet. This pointer field specifies the offset from the beginning of the TS packet to the beginning of the next section. A
 * pointer field is only present if a new section starts in a TS packet; this is indicated by the payload unit start bit in the TS
 * header. The position of following sections can then be calculated using the length fields in the section headers. This format
 * allows for a very compact and efficient transmission of MPEG program sections because very small sections can be aggregated and
 * do not waste a whole TS packet.
 *
 * See H.222.0 2.4.4.2 or ["Typical section packetization"](https://tsduck.io/download/docs/mpegts-introduction.pdf) for details.
 *
 * A fully generic implementation needs to:
 *
 * - Add pointer fields if there is more than one section in the next payload chunk.
 *
 * - Add padding bytes in the end if payload is shorter than requested read.
 *
 * - Add meta data about new section start so that next stage can set payload unit start indicator bit in the TS header.
 *
 * This can be tricky to implement, however:
 *
 * - Multiple sections (payload units) need to be merged, but the pipeline interface does not support that very well. For example,
 * if @ref VIDEORTP_pipePrepareNextChunk "prepareNextChunk" indicates that the next chunk is the end of a section, but there is
 * still some space left in the TS packet, there is no obvious way to query whether *another* section is pending and whether it
 * could still be included in the next chunk.
 *
 * - The presence of pointer fields depends on the start of a new section which depends on the remaining chunk size which depends on
 * the presence of a pointer field again. There are some edge cases where this loop does not terminate.
 *
 * Fortunately, the format is very flexible and allows significant simplifications in this application.
 *
 * Since only one program with only one elementary stream is currently required, only two tables are actually needed in this
 * application: The program association table and one program map table. These tables must be transferred in streams with different
 * PIDs, so they cannot be aggregated. They are also very small because they both contain only a single entry, so a single TS packet
 * will be sufficient for each table.
 *
 * For these reasons, the ProgramSectionPacketizer features a very naive implementation, which is similar to the PES packetizer: TS
 * packets can only contain (parts of) a single section. Therefore, the pointer field is always zero and it is only needed for the
 * first TS packet. The last TS packet will be filled with padding.
 *
 * Typically, the predecessor stage will be a PayloadUnitRepeater which generates program table sections. The following pipeline
 * stage should be a TS packetizer so the pointer field will be placed at the beginning of the MPEG TS packet payload.
 *
 * @startuml section_packetizer
 *  hide empty members
 *
 *  interface PayloadProvider
 *  class PipelineStageWithSinglePredecessor
 *
 *  class ProgramSectionPacketizer {
 *      + prepareNextChunk(maximumSize : size_t, metaData : PayloadChunkInfo*) : size_t
 *      + copyChunk(payloadBuffer : BufferWriter*) : void
 *  }
 *  PayloadProvider <|.. ProgramSectionPacketizer
 *  PayloadProvider *.. ProgramSectionPacketizer
 *  PipelineStageWithSinglePredecessor <|-- ProgramSectionPacketizer
 * @enduml
 */

/* ===========================================================================
 *
 *  Public Macros
 *
 * ========================================================================= */
/** This is the number of bytes after the pointer until the payload */
#define VIDEORTP_SECT_DEFAULT_POINTER 0x00
/** sizeof pointer */
#define VIDEORTP_SECT_POINTER_SIZE 1
/** This is pattern for padding */
#define VIDEORTP_SECT_PADDING 0xFF

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief This struct contains data for adding pointer in TS header
     * @implements VIDEORTP_payloadProvider_t
     *
     * This structure is used to add a pointer to the TS header.
     * It also adds padding at the end if necessary.
     *
     * @see ProgramSectionPacketizer
     */
    typedef struct VIDEORTP_programSectionPacketizer_t
    {
        /** @privatesection @{ */
        /**
         * @brief Instance of the VIDEORTP_payloadProvider_t
         *
         * @see VIDEORTP_payloadProvider_t
         */
        VIDEORTP_payloadProvider_t vtable;
        /**
         * @brief Previous pipeline stage
         *
         */
        VIDEORTP_pipelineStageWithSinglePredecessor_t predecessor;
        /**
         * @brief Flag to add padding
         *
         * This set to true if the data size is less than the buffer size and the end of the buffer needs to be filled.
         */
        bool needPointer;
        /**
         * @brief The size of the next fragment to be copied
         *
         */
        size_t nextChunkSize;
        /** @} */
    } VIDEORTP_programSectionPacketizer_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief It shall initialize self
     * @public @memberof VIDEORTP_programSectionPacketizer_t
     *
     * @param self VIDEORTP_programSectionPacketizer_t instance to be initialized
     * @param predecessor previous stage of the pipeline
     */
    void VIDEORTP_sectInit(VIDEORTP_programSectionPacketizer_t* self, VIDEORTP_payloadProvider_t* predecessor);

    /**@} ProgramSectionPacketizer global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* PROGRAM_SECTION_PACKETIZER_H */
