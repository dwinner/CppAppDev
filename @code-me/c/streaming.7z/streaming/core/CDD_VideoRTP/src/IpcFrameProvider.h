#ifndef IPC_FRAME_PROVIDER_H
#define IPC_FRAME_PROVIDER_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "PayloadProvider.h"
#include "ipcFrame.h"
#include "ipcFrameFactory.h"
#include "ipcPayloadChunkFactory.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup IpcFrameProvider
     * @{
     *
     * @brief Pipeline stage that provides access to frames received via IPC.
     *
     * @startuml
     * hide empty members
     * interface ElementaryStreamProvider #LightGrey {
     *   OnBufferRelease(void*) : void
     * }
     * interface PayloadProvider
     * ElementaryStreamProvider . IpcFrameProvider : IPC interface
     * class IpcFrameProvider {
     *   + StartFrame(frameSize : size_t, samplingTime : uint64_t, bufferPayload : void*, bufferSize : size_t) : bool
     *   + AppendFrame(bufferPayload : void*, bufferSize : size_t) : bool
     * }
     * PayloadProvider <|.. IpcFrameProvider : <<implement>>
     * @enduml
     *
     * The IpcFrameProvider exports methods being called by the IPC subsystem when a new frame
     * is started or more data is added. The data are stored as @ref Frame "Frames" and offered
     * to the pipeline for further processing. Frames are stored inside a queue, where new frames
     * are added in the end. Incoming data are wrapped in @ref PayloadChunk instances which are
     * passed to the newest frame that has been started successfully.
     *
     * For data handling an IpcFrameProvider instance hosts its own @ref VIDEORTP_ipcFrameFactory_t
     * "FrameFactory" and @ref VIDEORTP_ipcPayloadChunkFactory_t "PayloadChunkFactory".
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Structure holding the data specific to an @ref IpcFrameProvider instance.
     *
     */
    typedef struct VIDEORTP_ipcFrameProvider_t
    {
        /** @privatesection @{ */
        /** PayloadProvider instance */
        VIDEORTP_payloadProvider_t vtable;
        /** Queue of frames */
        VIDEORTP_ipcFrameQueue_t frameQueue;
        /** Size of frame that will be copied to next pipeline stage */
        size_t nextChunkSize;
        /** Allocator of frame chunks */
        VIDEORTP_ipcPayloadChunkFactory_t chunkFactory;
        /** Allocator of frames */
        VIDEORTP_ipcFrameFactory_t frameFactory;
        /** Pointer to current frame */
        VIDEORTP_ipcFrame_t* newestFrame;
        /** @} */
    } VIDEORTP_ipcFrameProvider_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_ipcFrameProvider_t
     * @public @memberof VIDEORTP_ipcFrameProvider_t
     *
     * @param self VIDEORTP_ipcFrameProvider_t instance that the function works on
     */
    void VIDEORTP_ipcInit(VIDEORTP_ipcFrameProvider_t* self);

    /**
     * @brief Deinitialize VIDEORTP_ipcFrameProvider_t
     * @public @memberof VIDEORTP_ipcFrameProvider_t
     *
     * @param self VIDEORTP_ipcFrameProvider_t instance that the function works on
     */
    void VIDEORTP_ipcDeinit(VIDEORTP_ipcFrameProvider_t* self);

    /**
     * @brief Creates frame
     * @public @memberof VIDEORTP_ipcFrameProvider_t
     *
     * @param self VIDEORTP_ipcFrameProvider_t instance that the function works on
     * @param frameSize frame full size
     * @param timestamp Sampling timestamp of this frame
     * @return true if start frame successful
     * @return false if start frame unsuccessful
     */
    bool VIDEORTP_ipcStartFrame(VIDEORTP_ipcFrameProvider_t* self, const size_t frameSize, const VIDEORTP_timestamp* timestamp);

    /**
     * @brief Appends payload chunk to frame
     * @public @memberof VIDEORTP_ipcFrameProvider_t
     *
     * @param self VIDEORTP_ipcFrameProvider_t instance that the function works on
     * @param bufferPayload payload chunk
     * @param bufferSize size of payload chunk
     * @param bufferReleaseCallback release buffer callback
     * @return true if append chunk successful
     * @return false if append chunk unsuccessful
     */
    bool VIDEORTP_ipcAppendFrame(VIDEORTP_ipcFrameProvider_t* self, const void* bufferPayload, const size_t bufferSize,
                                 VIDEORTP_releaseBufferCb_t bufferReleaseCallback);

    /**@} IpcFrameProvider global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* IPC_FRAME_PROVIDER_H */
