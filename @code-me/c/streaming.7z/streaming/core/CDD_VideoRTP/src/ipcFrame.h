#ifndef FRAME_H
#define FRAME_H

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "ipcFramePayloadChunk.h"
#include "ipcPayloadChunkFactory.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup IpcFrame
     * @{
     *
     * @brief Represents a video frame that has been passed for transmission.
     *
     * The Frame class provides a frontend to deal with a video frame that is
     * internally stored as a series of data chunks. After creation, a frame
     * knows about the meta data (here: the sampling time) and its total size,
     * but does not yet contain any data.
     * Later data chunks can be added until the total size has been reached.
     *
     * The frame instance keeps track of the number of bytes that have been
     * added so far ("bytes in") and the number of bytes that have been
     * consumed by later stages ("bytes out"). By this the frame can always
     * compute the **number of remaining bytes** which can be retrieved via
     * @ref VIDEORTP_ipcFrameGetRemainingBytes "getRemainingBytes". This is the
     * number of bytes of the whole frame which have not been read yet.
     *
     * This is in contrast to the **number of currently available bytes** which
     * can be retrieved via @ref VIDEORTP_ipcFrameGetAvailableBytes
     * "getAvailableBytes". This returns the number of bytes that are already
     * stored inside the frame and are ready for being read immediately. Note
     * that the number of available bytes will be less than the number of
     * remaining bytes until all data chunks have been added.
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Structure holding the data specific to a @ref Frame instance.
     *
     */
    typedef struct VIDEORTP_ipcFrame_t
    {
        /** @privatesection @{ */
        /** Sampling timestamp of this frame */
        VIDEORTP_timestamp timestamp;
        /** Total frame size */
        size_t totalSize;
        /** Bytes wthich got from Perfomance controller */
        size_t bytesIn;
        /** Bytes which given to pipeline */
        size_t bytesOut;
        /** Queue of frame chunks */
        VIDEORTP_ipcPayloadChunkQueue_t payloadChunkQueue;
        /** Pointer to allocator of frame chunks */
        VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory;
        /** Pointer to next frame in queue */
        struct VIDEORTP_ipcFrame_t* next;
        /** @} */
    } VIDEORTP_ipcFrame_t;

    /**
     * @brief Queue of VIDEORTP_ipcFrame_t instances
     *
     * @note Works only with two frame instances
     *
     * @see VIDEORTP_ipcFrame_t
     */
    typedef struct VIDEORTP_ipcFrameQueue_t
    {
        /** @privatesection @{ */
        /** First element of queue */
        VIDEORTP_ipcFrame_t* head;
        /** Last element of queue */
        VIDEORTP_ipcFrame_t* tail;
        /** @} */
    } VIDEORTP_ipcFrameQueue_t;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief Initialize VIDEORTP_ipcFrame_t
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @param chunkFactory Pointer to frame chunk factory
     * @param frameSize Total frame size
     * @param timestamp Sampling timestamp of this frame
     */
    void VIDEORTP_ipcFrameInit(VIDEORTP_ipcFrame_t* self, VIDEORTP_ipcPayloadChunkFactory_t* chunkFactory, const size_t frameSize,
                               const VIDEORTP_timestamp* timestamp);

    /**
     * @brief Deinitialize VIDEORTP_ipcFrame_t
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     */
    void VIDEORTP_ipcFrameDeinit(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Return frame samplingTime
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @return uint64_t
     */
    uint64_t VIDEORTP_ipcFrameGetSamplingTime(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Return frame decoding time
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @return uint64_t
     */
    uint64_t VIDEORTP_ipcFrameGetDecodingTime(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Return frame total size
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameGetTotalSize(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Return remaining size of frame
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @note remaining size = self->totalSize - self->bytesOut
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameGetRemainingBytes(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Return available to send bytes
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @note available bytes = self->bytesIn - self->bytesOut
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameGetAvailableBytes(VIDEORTP_ipcFrame_t* self);

    /**
     * @brief Copies data to a buffer and returns the size of the copied data
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @param buffer Destination buffer
     * @param max Buffer available space
     * @return size_t
     */
    size_t VIDEORTP_ipcFrameGetData(VIDEORTP_ipcFrame_t* self, void* buffer, const size_t max);

    /**
     * @brief Adds chunk to frame
     * @public @memberof VIDEORTP_ipcFrame_t
     *
     * Add chunk to payloadChunkQueue and increase bytesIn
     *
     * @param self VIDEORTP_ipcFrame_t instance that the function works on
     * @param chunkBuffer payload chunk (optional)
     * @param chunkSize size of payload chunk
     * @param releaseCb release buffer callback (optional)
     * @return true if successful
     * @return false if unsuccessful
     */
    bool VIDEORTP_ipcFrameAddPayloadChunk(VIDEORTP_ipcFrame_t* self, const void* chunkBuffer, size_t chunkSize,
                                          VIDEORTP_releaseBufferCb_t releaseCb);

    /**@} Frame global */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* FRAME_H */
