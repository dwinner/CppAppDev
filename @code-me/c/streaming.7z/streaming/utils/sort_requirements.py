# Format a list of PTC requirement IDs and remove duplicates

import sys, os, re

REQ_LINE = re.compile(
    r"(.*Traceability to SW Req:\s*)((\d+[ ,]*)+)(.*)", re.IGNORECASE | re.DOTALL)
REQ_NUMS = re.compile("\d+")

# Sort a list of requirement IDs
def filter_reqs(reqs):
    return sorted(set(reqs), key=int)

# Format a single line
def process(line):
    m = REQ_LINE.match(line)
    if not m:
        return line

    reqs = REQ_NUMS.findall(m.group(2))
    if not reqs:
        return line

    reqs = filter_reqs(reqs)
    return m.group(1) + ", ".join(reqs) + m.group(4)

# Read a whole file and check all lines
def parse_file(filename):
    with open(filename, "r+", encoding="UTF-8") as f:
        contents = []
        modified = False

        for line in f:
            new_line = process(line)
            if new_line != line:
                modified = True
            contents.append(new_line)

        if modified:
            print(f"Updating {filename}")
            f.seek(0)
            f.writelines(contents)
            f.truncate()

# Root directory
top = sys.argv[1] if len(sys.argv) > 1 else "."

for root, dirs, files in os.walk(top):
    # Find all C and C++ files
    for file in files:
        name, ext = os.path.splitext(file)
        if ext.lower() in (".c", ".h", ".cpp", ".hpp"):
            path = os.path.join(root, file)
            parse_file(path)
    # ignore .git etc.
    dirs[:] = [d for d in dirs if not d.startswith(".")]
