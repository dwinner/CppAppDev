import sys
def check():

    found = False
    datafile = open(str(sys.argv[1]))
    for line in datafile:
        if "AVC video (640x480, baseline profile, level 3.0, 4:2" in line:
           found = True           
           break
        if "PCR OK" in line:
           found = True           
           break

    return found

if check():
    print("found")
    sys.exit(0)
else:
    print("Nfound")
    sys.exit(1)