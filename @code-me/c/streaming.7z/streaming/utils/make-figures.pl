#!/usr/bin/perl

################################################################################
#
# Draw.IO file generator
#
# Features
# - Creates output directory (if it does not exist already)
# - Discovers all *.drawio files in current working directory
# - Generates diagrams (only if source is newer than target)
#
# Notes
# - Sorts files lexically to achieve stable behavior
# - Does work with spaces in file names, but that's pure luck
# - Output format can be configured in $format
# - Takes path to Draw.IO from environment variable LOCAL_DRAWIO_PATH
# - Does not delete files; output directory will collect garbage
#
################################################################################

use strict;
use File::stat;
use Env;

################################################################################
# Global variables and constants
my $outdir     = 'gen';
my $format     = 'png';  # 'png' or 'svg'
my @files;

################################################################################
# Verify that environment variable exists
if (not exists $ENV{LOCAL_DRAWIO_PATH})
{
	print "ERROR: environment variable LOCAL_DRAWIO_PATH not set!";
	exit;
}

################################################################################
# Helper functions
sub get_file_mtime {
	my $stat = stat($_[0]);
	return defined $stat ? $stat->mtime : 0;
}

################################################################################
# Create output directory if needed
if (not -d $outdir) {
	print "create output directory $outdir\n";
	mkdir $outdir or die "$!";
}

################################################################################
# Get names of all .drawio files
opendir (DIR, ".");
foreach (readdir DIR) {
	push @files, $_ if (m/^([^\.]+)\.drawio$/);
}
closedir DIR;

################################################################################
# Generate figures for each diagram
foreach (sort @files) {
	print "generate diagram \"$_\"...";
	if (get_file_mtime($_) <= get_file_mtime("$outdir/$_.$format")) {
		print " skipped.\n";
		next;
	}
	system ("\"$ENV{LOCAL_DRAWIO_PATH}\" -x \"$_\" -o \"$outdir/$_.$format\"") == 0 or die "$!";
	print " ok.\n";
}
