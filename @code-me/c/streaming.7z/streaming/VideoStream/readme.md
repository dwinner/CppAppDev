# VideoRTP Streaming Test Application

This is a standalone streaming application which streams a video on the net.

The main goal of this application is testing streaming without real target
hardware. Testing with real hardware might not be feasible, for example, if
the system is not readily available or it might be too complex to set up a
testbench.

## Features

This application can stream a pre-generated test video or a carefully prepared
H.264 video file (see below). The video will be wrapped in MPEG-TS and RTP
packets which can be transmitted via UDP or written to a Wireshark PCAP file.

Padding can be added to the input stream to simulate a full HD video.
The target input bandwidth with padding is approximately 6 Mbit/s.
Depending on the actual MPEG and RTP protocol overhead, the output bandwidth
may range from approximately 6.5 Mbit/s to approximately 8 Mbit/s.

## Usage Examples

### Send test video with padding

    VideoStream
        --host 127.0.0.1 --port 5004
        --loop 1 --generate 10000
        --input testvideo.h264 --fps 25
        --test-stream 1

Press *Ctrl + C* to terminate the application.
Note that only IPv4 addresses are supported.

Also note that the streaming mode defaults to RFC2250, so the stream will be
compatible with tools like VLC or FFmpeg.

    vlc rtp://@:5004
    ffplay -i rtp://@127.0.0.1:5004

### Send IP AVT Synchronous Stream

    VideoStream
        --host 127.0.0.1 --port 5004
        --loop 1 --generate 10000
        --input testvideo.h264 --fps 15
        --cycle 1 --data-rate 6000000
        --rtcp 1
        --ip-avt 2

This mode simulates streaming on the target system as accurately as possible.
VW LAH IP_AVT defines different payload types than RFC2250 for RTP streams.
Since the types are non-standard, the encoding must be defined in an SDP file:

    v=0
    o=- 0 0 IN IP4 127.0.0.1
    s=IP_AVT Synchronous Stream
    c=IN IP4 127.0.0.1
    t=0 0
    m=video 5004 RTP/AVP 122
    a=rtpmap:122 MP2T/90000

Note that `122` corresponds to payload type `0x7A` for MPEG-TS video without
content protection. Save this as ip_avt_sync.sdp and launch a video player:

    vlc ip_avt_sync.sdp

### Write packets to PCAP file

    VideoStream
        --output dump.pcap
        --loop 1 --generate 10000
        --input testvideo.h264 --fps 25
        --rtcp 1
        --ip-avt 2

This would write all packets to a PCAP file for analysis with Wireshark.
Note that the streaming mode has been changed to IP AVT synchronous streaming.

## Limitations

At its core, this streaming application only supports video streaming.
It can wrap a single H.264 video in MPEG-TS and RTP packets, but not much more.

In particular, negotiation and connection setup is not supported.
That would require some logic to determine when to start and stop streaming;
perhaps even communication (possibly via CAN) with an A/V streaming master.
This is out of the scope of the VideoRTP module.
This application starts streaming immediately and continues until terminated.

Note that this application does not support a globally synchronized IEEE 802.1AS
clock. Therefore, even though IEEE 1733 AVB RTCP packets can be enabled by
setting `--rtcp` to `1`, the timestamps in these packets are not meaningful.

Please note that no other RFC 3350 RTCP packets are supported.

## Command Line Parameters

### Input

- `--input`: H.264 input file (see below)
- `--generate`: How many frames to generate.
- `--loop`: Set to `1` to repeat the video indefinitely
- `--cycle`: Average cycle time (ms)
- `--fps`: Target video frame rate (Hz)
- `--data-rate`: Estimated maximum data rate (bit/s)

### Output

- `--host`: UDP destination address (IPv4)
- `--port`: UDP destination port
- `--output`: PCAP output file name

### MPEG settings

- `--mpegts-tables`: Interval between resending MPEG program tables
- `--mpegts-program`: ID of MPEG program
- `--mpegts-pmt-pid`: PID of MPEG program map table
- `--mpegts-video-pid`: PID of MPEG video stream table
- `--mpegts-stream-id`: ID of MPEG transport stream

### RTP settings

- `--ip-avt`: Streaming mode
    * 0 for RFC2250 compliant stream (default)
    * 1 for IP AVT isochronous streaming
    * 2 for IP AVT synchronous streaming
- `--clock-offset`: *Delivery Compensation Offset* to be added to timestamps
- `--rtcp`: Set to 1 to enable RTCP packets

### Miscellaneous

- `--test-stream`: Use a special pipeline configuration for testing.
    This includes extra padding to simulate higher bandwith requirements.
- `--estimate-stack`: Determine the amount of stack space used by the streaming
    pipeline. All output will be discarded. Note that this estimation heavily
    depends on the selected compiler and optimization level.

## Preparing H.264 input video

MPEG (H.222.0, section 2.14) imposes certain constraints on an embedded H.264
stream. In particular, the stream must conform to the format specified in H.264
Annex B and it must contain Access Unit Delimiters (AUD NALUs). In a nutshell,
this means that video frames must be separated by a very specific byte sequence.

While H.264 files usually already conform to H.264 Annex B, often they do not
contain Access Unit Delimiters. The obvious way to generate such a file is to
configure an encoder to output Access Unit Delimiters in the encoded stream;
if this is not possible, as a workaround, a H.264 video stream can be streamed
using a different application (like FFmpeg) which adds Access Unit Delimiters.
The H.264 stream can then be extracted from the MPEG stream.

    ffmpeg -i testvideo.mp4 -c copy temp.ts
    ffmpeg -i temp.ts -c copy -an testvideo_with_aud.h264
