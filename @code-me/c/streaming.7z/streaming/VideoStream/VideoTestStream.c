/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

#include "VideoTestStream.h"

#include <malloc.h>
#include <stdio.h>

#include <DummyPacketMemoryWriter.h>
#include <PCAPWriter.h>
#include <PosixSocket.h>

#include "FrameStream.h"
#include "H264Wrapper.h"
#include <VideoStream.h>

#include <StbM_stubs.h>
#ifdef VIDEORTP_ENABLE_TEST_VIDEO
#include <test_noloop.h264_bin.h>
#endif

#define STBM_TIME_BASE_TYPE 42

#ifdef _MSC_VER
#define NOINLINE __declspec(noinline)
#else
#define NOINLINE __attribute__((noinline))
#endif

typedef struct
{
    /* Convert video stream to IPC interface */
    VIDEORTP_frameStream_t frameStream;
    /* H264 file reader */
    VIDEORTP_H264Wrapper_t fileReader;
    /* MPEG/RTP processing */
    VIDEORTP_videoStream_t videoStream;
    /* Posix socket output (Windows, etc.) */
    VIDEORTP_posixSocket_t m_socket;
    VIDEORTP_posixSocket_t m_rtcpSocket;
    /* Write Wireshark PCAP file */
    VIDEORTP_pcapWriter_t m_filePCAP;
    /* Dummy output */
    VIDEORTP_dummyPacketMemoryWriter_t m_dummyRtpWriter;
    VIDEORTP_dummyPacketMemoryWriter_t m_dummyRtcpWriter;
} VIDEORTP_videoTestStream_t;

#define STACK_PATTERN (~0x12345678)
#define STACK_CHECK_SIZE (100 << 10)

/* Location of test pattern on the stack. Only for estimating stack space.
 * BEWARE! These pointers are DANGLING! This is UNDEFINED BEHAVIOR! */
void* volatile stackLow;
void* volatile stackHigh;

/* Fill some range on the stack with a fixed pattern */
NOINLINE void FillStackPattern(void)
{
    int* mem = alloca(sizeof(int) * STACK_CHECK_SIZE);
    stackLow = mem;
    for (int i = 0; i < STACK_CHECK_SIZE; ++i)
        *mem++ = STACK_PATTERN;
    stackHigh = mem;
}

/* Try to find the first word on the stack which was modified. */
void EstimateStackUsage(void)
{
    int* p = stackLow;
    while (p != stackHigh && *p == STACK_PATTERN)
        ++p;
    printf("Approximately %zu bytes used on stack\n", (size_t) stackHigh - (size_t) p);
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_mainVideoStream
 *
 *   Function:   The main function that runs the pipeline
 *
 *   Inputs:
 *               const VIDEORTP_initConfiguration_t* config: command line parameters
 *
 *   Outputs:
 *               None
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-407, MAGAVSTR-815
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks:
 *
 * ========================================================================= */
void VIDEORTP_mainVideoStream(const VIDEORTP_initConfiguration_t* config)
{
    VIDEORTP_videoTestStream_t stream;

    /* Define video source */
    VIDEORTP_payloadUnit_t* payloadUnits = NULL;
    size_t payloadUnitCount = 0;

#ifdef VIDEORTP_ENABLE_TEST_VIDEO
    /* Default to pre-compiled video */
    payloadUnits = VIDEORTP_payloadUnits;
    payloadUnitCount = VIDEORTP_PAYLOAD_UNIT_COUNT;
#endif

    /* Stream pre-compiled video by default unless an input file was specified */
    if (config->fileNameH264 != NULL)
    {
        VIDEORTP_frInitFileRead(&stream.fileReader, config->fileNameH264);
        payloadUnitCount = VIDEORTP_frInitSequenceRepeator(&stream.fileReader, &payloadUnits);
    }

    if (payloadUnits == NULL || payloadUnitCount == 0)
    {
        // No video specified!
        // TODO: Print error message?
        return;
    }

    /* Initialize stream output */
    VIDEORTP_packetTransmitter_t* transmitter = NULL;
    VIDEORTP_packetTransmitter_t* rtcpTransmitter = NULL;
    if (config->estimateStack)
    {
        VIDEORTP_dmwInit(&stream.m_dummyRtpWriter);
        transmitter = &stream.m_dummyRtpWriter.vtable;
        if (config->rtcp)
        {
            VIDEORTP_dmwInit(&stream.m_dummyRtcpWriter);
            rtcpTransmitter = &stream.m_dummyRtcpWriter.vtable;
        }
    }
    else if (config->address != NULL && config->port != 0)
    {
        VIDEORTP_sockInit(&stream.m_socket, config->address, config->port);
        transmitter = &stream.m_socket.vtable;
        if (config->rtcp)
        {
            VIDEORTP_sockInit(&stream.m_rtcpSocket, config->address, config->port + 1);
            rtcpTransmitter = &stream.m_rtcpSocket.vtable;
        }
    }
    else if (config->fileNamePCAP != NULL)
    {
        VIDEORTP_pcapInit(&stream.m_filePCAP, config->fileNamePCAP);
        transmitter = &stream.m_filePCAP.vtable;
        // TODO: RTCP is not supported (yet?)
    }
    else
    {
        // TODO: Print error message?
        return;
    }

    // Select IPC or static input. Prefer IPC.
    bool testStream = false;
#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    testStream = config->testStream;
#endif

    VIDEORTP_videoStreamConfig_t videoConfig = { 0 };

    /* Initialize pipeline */
    VIDEORTP_rtcpInitConfig(&videoConfig.rtpConfig, config->IPAvt);
    videoConfig.rtpConfig.deliveryCompensationOffset = (uint32_t) config->clockOffset;
    videoConfig.tableConfig.interval = (uint32_t) config->mpegTSTables;
    videoConfig.tableConfig.program = config->mpegTSProgram;
    videoConfig.tableConfig.pmtPid = config->mpegTSPmtPid;
    videoConfig.tableConfig.videoPid = config->mpegTSVideoPid;
    videoConfig.tableConfig.streamId = (uint32_t) config->mpegTSStreamId;

    videoConfig.ipcInputConfig.tsPid = config->mpegTSVideoPid;
    videoConfig.ipcInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
    videoConfig.ipcInputConfig.timeBaseId = STBM_TIME_BASE_TYPE;

#ifdef VIDEORTP_ENABLE_STATIC_INPUT
    videoConfig.isStaticInputEnabled = testStream;
    videoConfig.staticInputConfig.fps = (uint32_t) config->fps;
    videoConfig.staticInputConfig.tsPid = config->mpegTSVideoPid;
    videoConfig.staticInputConfig.streamId = VIDEORTP_PES_VIDEO_STREAM_0;
    videoConfig.staticInputConfig.payloadUnits = payloadUnits;
    videoConfig.staticInputConfig.payloadUnitCount = payloadUnitCount;
#endif /* VIDEORTP_ENABLE_STATIC_INPUT */

    videoConfig.cyclicInterval = config->cycle;
    videoConfig.targetDataRate = config->dataRate;
    videoConfig.targetFrameRate = config->fps;

    if (!testStream)
    {
        /* Use IPC input */
        VIDEORTP_frStreamInit(&stream.frameStream, &stream.videoStream, 1000 / config->fps);
        VIDEORTP_frSetPayload(&stream.frameStream, payloadUnits, payloadUnitCount);
    }

    if (config->estimateStack)
        FillStackPattern();

    VIDEORTP_initVideoStream(&stream.videoStream, transmitter, rtcpTransmitter, &videoConfig);

    DWORD lastCycle = GetTickCount();
    for (uint32_t it = 0; config->loop || it < config->generate; it++)
    {
        /* Catch up and run cyclic calls (should usually only be one or two iterations) */
        for (DWORD now = GetTickCount(); now - lastCycle < -videoConfig.cyclicInterval; lastCycle += videoConfig.cyclicInterval)
        {
            if (!testStream)
            {
                /* Manually copy frames to IPC input */
                VIDEORTP_frStreamCyclic(&stream.frameStream, videoConfig.cyclicInterval);

                /* Set MPEG PCR for IPC input */
                uint32_t pcr = stream.frameStream.timestamp;
                StbM_UserDataType user = { 0 };
                StbM_TimeStampType time = { 0 };
                time.nanoseconds = (pcr % 1000) * 1000000;
                time.seconds = (pcr / 1000);
                StbM_SetCurrentTime(STBM_TIME_BASE_TYPE, &time, &user);
            }

            /* Send packets */
            VIDEORTP_cyclicVideoStream(&stream.videoStream);
        }

        /* Wait for next cyclic call */
        Sleep(videoConfig.cyclicInterval);
    }

    if (config->estimateStack)
        EstimateStackUsage();

    if (config->estimateStack)
    {
        /* nothing to do */
    }
    else if (config->address != NULL && config->port != 0)
    {
        VIDEORTP_sockDeinit(&stream.m_socket);
        if (config->rtcp)
            VIDEORTP_sockDeinit(&stream.m_rtcpSocket);
    }
    else if (config->fileNamePCAP != NULL)
    {
        VIDEORTP_pcapDeinit(&stream.m_filePCAP);
    }

    if (config->fileNameH264 != NULL)
    {
        VIDEORTP_frDeinitFileRead(&stream.fileReader);
    }
}
