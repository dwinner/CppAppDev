# Magna VW A/V Streaming, implementation

## Overview
Add a few nice words here

## Build Configurations

The following build configurations are supported (`cmake --config`):

* **Debug**: Default configuration for development. Assertions are enabled.

* **Sanitize**: Like the *Debug* configuration, but with extra instrumentation
    to detect certain errors at runtime (buffer overflows and other undefined
    behavior). Note that some debugging features might not be available due to
    limitations of the current compiler or operating system.

* **RelWithDebInfo**: Optimized build. Assertions are disabled.

## Build Options

Certain features can be enabled or disabled.

* **Source code coverage**: If enabled, source code coverage information will be
    collected for the *core* modules. Run `build/tests/generate_coverage_report.bat`
    to run unit tests and automatically generate a test report.

* **Static input**: If enabled, a second parallel input interface (along with IPC)
    is supported. This is only used for reading files or streaming a pre-generated
    test video. The input interface can be selected at runtime when initializing
    the VideoRTP module. If disabled, only the IPC interface is supported.

* **Pre-generated test video**: If enabled, a pre-generated test video will be
    included in the application. The test video consumes approximately 100kb ROM.

Select the desired combination in Visual Studio Code.

## Folder structure

Generated files like Doxygen output, object files, binary files from libraries which are distributed
as source code, etc. should not be checked in. If uncertain, please put this item to discussion
before adding such files to the repository.

```
root
+---core
|   +---src                             Target code that is delivered to Magna
|   +---doc                             Doxyfile, *.dox files, etc.
|   +---Makefile                        Placeholder project/build files
|   \---lib
|       \---core.a                      Static library for use in test system/unit test (do not check in!)
+---libs
|   +---lib-with-source                 3rd party library with source code
|   |   +---bin                         Executables (if any)
|   |   +---include                     Include files for user
|   |   +---lib                         Library binary for user
|   |   +---src                         Library source code
|   |   +---Makefile                    Placeholder for project/build files
|   |   \---readme.md                   Information about origin/license/reasons to use, etc.
|   \---binary-only-lib                 3rd party library without source code
|       +---bin                         Executables (if any)
|       +---include                     Include files for user
|       +---lib                         Library binary for user
|       \---readme.md                   Information about origin/license/reasons to use, etc.
+---misc                                Miscellaneous helper files that cannot be turned into a library
|   +---great_helper_class.cpp
|   +---pattern_generator_stage.cpp
|   \---useful_template.h
+---res                                 Resources for testing, checking, etc.
|   +---finger.asc
|   \---test-pattern.mp4
+---tests
|   +---testsystem                      Acceptance test system, linking against core.a
|   \---unittests                       Unit tests, linking against core.a
+---utils                               Standalone utilities
|   +---readme.md
|   +---stream_test.py
|   +---ts_extract.py
|   \---cpp_stream_test
\---readme.md                           This file
```
