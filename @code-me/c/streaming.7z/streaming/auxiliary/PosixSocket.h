#ifndef _POSIXSOCKET_H_
#define _POSIXSOCKET_H_

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include <stdint.h>

#include <WS2tcpip.h>
#include <WinSock2.h>

#include "BufferWriter.h"
#include "PacketTransmitter.h"

/**
 * \defgroup PosixSocket
 * @{
 * @brief Sends packets via UDP to an arbitrary IP address and port.
 *
 * @startuml posix_socket
 *  hide empty members
 *
 *  class BufferWriter
 *
 *  interface PacketTransmitter {
 *      {abstract} + getBuffer() : BufferWriter*
 *      {abstract} + commitBuffer() : void
 *  }
 *
 *  PacketTransmitter ...> BufferWriter : <<use>>
 *
 *  class PosixSocketSender {
 *      - payloadBuffer : uint8_t[MAX_PAYLOAD_SIZE]
 *      - payloadWriter : BufferWriter
 *      - posixSocket : int
 *      + getBuffer() : BufferWriter*
 *      + commitBuffer() : void
 *  }
 *
 *  PacketTransmitter <|.. PosixSocketSender : <<implement>>
 *
 *  BufferWriter -* PosixSocketSender
 * @enduml
 */

/* ===========================================================================
 *
 *  Public Typedefs
 *
 * ========================================================================= */

/**
 * @brief This interface specifies a way to output packets
 * @implements VIDEORTP_packetTransmitter_t
 */
typedef struct
{
    /** @privatesection @{ */
    /**
     * @brief Allocation of base class
     *
     */
    VIDEORTP_packetTransmitter_t vtable;
    /**
     * @brief Buffer for transmitted data
     *
     */
    VIDEORTP_buffer_t m_payloadBuffer;
    /**
     * @brief Allocation of BufferWriter class
     *
     */
    VIDEORTP_bufferWriter_t m_payloadWriter;
    /**
     * @brief Socket connection to destination
     *
     */
    SOCKET m_socket;
    /** @} */
} VIDEORTP_posixSocket_t;

/* ===========================================================================
 *
 *  Public Function Prototypes
 *
 * ========================================================================= */

#ifdef __cplusplus
extern "C"
{
#endif // _cplusplus

    /**
     * @brief Initialize fields of self
     * @public @memberof VIDEORTP_posixSocket_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_sockInit(VIDEORTP_posixSocket_t* self, const char* address, const uint16_t port);

    /**
     * @brief Deinitialize fields of self
     * @public @memberof VIDEORTP_posixSocket_t
     *
     * @param self instance that the function works on
     */
    void VIDEORTP_sockDeinit(VIDEORTP_posixSocket_t* self);

    /**@} PosixSocket global */

#ifdef __cplusplus
}
#endif // _cplusplus

#endif /* _POSIXSOCKET_H_ */
