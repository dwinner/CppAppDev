/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Include Files
 *
 * ========================================================================= */

#include "TestPatternGenerator.h"
#include <assert.h>

/* ===========================================================================
 *
 *   Public Function
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *   Name:       VIDEORTP_testPatternGen_prepareNextChunk
 *
 *   Function:   It shall prepare information for chunk handling
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: It contains the start point of VIDEORTP_testPatternGenerator
 *               size_t maximumChuckSize: The maximum allowed size for one chunk
 *               VIDEORTP_payloadChunkInfo_t* metaData: VIDEORTP_payloadChunkInfo_t contained information for chunk handling
 *
 *
 *   Outputs:
 *               size_t
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-99, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks: For test geneartor pattern vtable is VIDEORTP_testPatternGenerator->predecessor
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_testPatternGenerator */
static size_t VIDEORTP_testPatternGen_prepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumChunkSize,
                                                       VIDEORTP_payloadChunkInfo_t* metaData)
{
    assert(vtable);
    assert(metaData);

    /* vtable must be the first struct member. */
    VIDEORTP_testPatternGenerator* self = (void*) vtable;

    /* The maximum payload size is unlimited, but copyChunk may only write as much as requested in this function. */
    self->nextChunkSize = VIDEORTP_sysGetMin(self->payloadUnitSize - self->writePosition, maximumChunkSize);

    /* A payload unit may span multiple chunks. */
    VIDEORTP_initPayloadChunkInfo(metaData, self->writePosition, self->nextChunkSize, self->payloadUnitSize);

    return self->nextChunkSize;
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_testPatternGen_copyChunk
 *
 *   Function:   It shall write data to payloadBuffer according the pattern
 *
 *   Inputs:
 *               VIDEORTP_payloadProvider_t* vtable: It contains the start point of VIDEORTP_testPatternGenerator
 *               VIDEORTP_bufferWriter_t* payloadBuffer: VIDEORTP_bufferWriter_t contained data buffer which will be repeat
 *
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-99, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks: For test geneartor pattern vtable is VIDEORTP_testPatternGenerator->predecessor
 *
 * ========================================================================= */
/** @private @memberof VIDEORTP_testPatternGenerator */
static void VIDEORTP_testPatternGen_copyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    assert(vtable);
    assert(payloadBuffer);

    /* vtable must be the first struct member. */
    VIDEORTP_testPatternGenerator* self = (void*) vtable;
    VIDEORTP_bufWritePattern(payloadBuffer, self->currentPattern, self->nextChunkSize);

    self->writePosition += self->nextChunkSize;
    if (self->writePosition == self->payloadUnitSize)
    {
        /* When the payload unit is complete, change the pattern and restart. */
        self->writePosition = 0;
        self->currentPattern += 1;
    }
}

/* ===========================================================================
 *
 *   Name:       VIDEORTP_testPatternGenInit
 *
 *   Function:   It shall initialize VIDEORTP_testPatternGenerator
 *
 *   Inputs:
 *               VIDEORTP_testPatternGenerator* self: It contains all support information like metadata, virtual methods, etc
 *               size_t payloadLength: It contains the length of all expected chunks
 *
 *
 *   Outputs:
 *
 *   Side Effects:
 *
 *   Traceability to SDD: MAGAVSTR-99, <further tickets, or if bug tickets exists and fix something here>
 *
 *   Traceability to SW Req: 16813298
 *
 *   Remarks: For test geneartor pattern vtable is VIDEORTP_testPatternGenerator->predecessor
 *
 * ========================================================================= */
void VIDEORTP_testPatternGenInit(VIDEORTP_testPatternGenerator* self, size_t payloadLength)
{
    assert(self);

    self->vTable.prepareNextChunk = VIDEORTP_testPatternGen_prepareNextChunk;
    self->vTable.copyChunk = VIDEORTP_testPatternGen_copyChunk;
    self->payloadUnitSize = payloadLength;
    self->currentPattern = 0;
    self->nextChunkSize = 0;
    self->writePosition = 0;
}
