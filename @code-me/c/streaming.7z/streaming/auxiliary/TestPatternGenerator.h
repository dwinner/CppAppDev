#ifndef TESTPATTERNGENERATOR_H_INCLUDED
#define TESTPATTERNGENERATOR_H_INCLUDED

/* ===========================================================================
 *
 *                   CONFIDENTIAL MAGNA ELECTRONICS
 *
 *   This is an unpublished work of authorship, which contains
 *   trade secrets, created in 2022.  Magna Electronics owns all
 *   rights to this work and intends to maintain it in confidence
 *   to preserve its trade secret status.  Magna Electronics
 *   reserves the right, under the copyright laws of the United
 *   States or those of any other country that may have jurisdiction,
 *   to protect this work as an unpublished work, in the event of
 *   an inadvertent or deliberate unauthorized publication.
 *   Magna Electronics also reserves its rights under all copyright
 *   laws to protect this work as a published work, when appropriate.
 *   Those having access to this work may not copy it, use it,
 *   modify it, or disclose the information contained in it without
 *   the written authorization of Magna Electronics.
 *
 * ========================================================================= */

/* ===========================================================================
 *
 *  Include Files
 *
 * ========================================================================= */

#include "BufferWriter.h"
#include "PayloadProvider.h"
#include "sysdef.h"

#ifdef __cplusplus
extern "C"
{
#endif
    /**
     * \defgroup TestPatternGenerator
     * @{
     */

    /* ===========================================================================
     *
     *  Public Typedefs
     *
     * ========================================================================= */

    /**
     * @brief Meta data about a generation data unit.
     * @implements VIDEORTP_payloadProvider_t
     */
    typedef struct VIDEORTP_testPatternGenerator
    {
        /** @privatesection @{ */
        /**
         * @brief "Virtual methods" of this class
         *
         */
        VIDEORTP_payloadProvider_t vTable;

        /**
         * @brief The summary size of all chunks
         *
         */
        size_t payloadUnitSize;

        /**
         * @brief The pattern of a data for the data generation.
         *
         * In the default test pattern, all bytes (of all chunks) of a
         * payload unit shall be set to the same value (i.e., use memset).
         *
         */
        uint8_t currentPattern;

        /**
         * @brief The chunk size for a next copyChunk operation
         *
         */
        size_t nextChunkSize;

        /**
         * @brief How much of the test pattern has already been written
         *
         */
        size_t writePosition;
        /** @} */
    } VIDEORTP_testPatternGenerator;

    /* ===========================================================================
     *
     *  Public Function Prototypes
     *
     * ========================================================================= */

    /**
     * @brief init VIDEORTP_testPatternGenerator instance
     * @public @memberof VIDEORTP_testPatternGenerator
     *
     * @param self VIDEORTP_testPatternGenerator instance
     * @param payloadLength the length of all chunks
     */
    void VIDEORTP_testPatternGenInit(VIDEORTP_testPatternGenerator* self, size_t payloadLength);

    /**@} TestPatternGenerator */

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* TESTPATTERNGENERATOR_H_INCLUDED */
