#include "DemoHeaderPipelineStage.h"

#define HEADER_SIZE 8

static size_t DemoHeaderPipelineStage_prepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                                       VIDEORTP_payloadChunkInfo_t* metaData)
{
    /* vtable must be the first struct member */
    DemoHeaderPipelineStage* self = (void*) vtable;
    size_t res = 0;

    // Reserve space for our header
    if (maximumSize >= HEADER_SIZE)
    {
        // Let the next pipeline stage decide if there is still enough room left for its payload
        res = VIDEORTP_pipePrepareNextChunk(self->predecessor, maximumSize - HEADER_SIZE, metaData);

        // If there is enough space for the payload, remember to include space for the header
        if (res > 0)
        {
            res += HEADER_SIZE;
        }
    }

    return res;
}

static void DemoHeaderPipelineStage_copyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    /* vtable must be the first struct member */
    DemoHeaderPipelineStage* self = (void*) vtable;

    // Reserve space to write header later
    VIDEORTP_bufferWriter_t headerWriter = VIDEORTP_bufSpawnChildWriter(payloadBuffer, 8);

    // Write actual payload
    size_t before = VIDEORTP_bufGetBytesWritten(payloadBuffer);
    VIDEORTP_pipeCopyChunk(self->predecessor, payloadBuffer);
    size_t after = VIDEORTP_bufGetBytesWritten(payloadBuffer);

    // Add header
    VIDEORTP_bufWriteInteger(&headerWriter, self->magic, 4);
    VIDEORTP_bufWriteInteger(&headerWriter, after - before, 4);
}

void DemoHeaderPipelineStage_init(DemoHeaderPipelineStage* obj, VIDEORTP_payloadProvider_t* predecessor, uint32_t magic)
{
    obj->vtable.prepareNextChunk = DemoHeaderPipelineStage_prepareNextChunk;
    obj->vtable.copyChunk = DemoHeaderPipelineStage_copyChunk;
    obj->predecessor = predecessor;
    obj->magic = magic;
}
