#include "DemoGeneratorPipelineStage.h"

static size_t DemoGeneratorPipelineStage_prepareNextChunk(VIDEORTP_payloadProvider_t* vtable, size_t maximumSize,
                                                          VIDEORTP_payloadChunkInfo_t* metaData)
{
    /* vtable must be the first struct member */
    DemoGeneratorPipelineStage* self = (void*) vtable;

    // The maximum payload size is unlimited, but copyChunk may only write as much as requested in this function.
    self->nextChunkSize = maximumSize;

    // Assume each payload unit is small enough to fit in one buffer.
    VIDEORTP_initPayloadChunkInfo(metaData, 0, maximumSize, maximumSize);

    return maximumSize;
}

static void DemoGeneratorPipelineStage_copyChunk(VIDEORTP_payloadProvider_t* vtable, VIDEORTP_bufferWriter_t* payloadBuffer)
{
    /* vtable must be the first struct member */
    DemoGeneratorPipelineStage* self = (void*) vtable;
    VIDEORTP_bufWritePattern(payloadBuffer, self->pattern, self->nextChunkSize);
}

void DemoGeneratorPipelineStage_init(DemoGeneratorPipelineStage* self, uint8_t pattern)
{
    self->vtable.prepareNextChunk = DemoGeneratorPipelineStage_prepareNextChunk;
    self->vtable.copyChunk = DemoGeneratorPipelineStage_copyChunk;
    self->pattern = pattern;
    self->nextChunkSize = 0;
}
