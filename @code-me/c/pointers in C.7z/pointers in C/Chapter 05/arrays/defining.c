int main(int argc, char **argv)
{
  int a1[5];
  int a2[5] = { 1, 2, 3 }; // only init first three
  int a3[] = { 1, 2, 3, 4, 5 };
  return 0;
}
