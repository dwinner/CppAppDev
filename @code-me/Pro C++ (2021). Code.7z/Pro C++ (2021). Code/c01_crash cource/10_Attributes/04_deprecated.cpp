[[deprecated("Unsafe method, please use xyz")]] void func() {}

int main()
{
	func();
}