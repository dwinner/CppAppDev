import <iostream>;

using namespace std;

int main()
{
	int* ptr{ nullptr };
	cout << "ptr size is " << sizeof(ptr) << " bytes" << endl;
}
