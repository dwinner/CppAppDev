import simple;
import derived_simple;

int main()
{
	Simple mySimple;
	DerivedSimple derived;
}
