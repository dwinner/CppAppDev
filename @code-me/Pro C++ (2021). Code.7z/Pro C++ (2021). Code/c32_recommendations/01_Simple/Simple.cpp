module simple;

Simple::Simple() : m_publicInteger{ 40 }
{
	// Implementation of constructor
}

void Simple::publicMethod() { /* Implementation of public method */ }

void Simple::protectedMethod() { /* Implementation of protected method */ }

void Simple::privateMethod() { /* Implementation of private method */ }
