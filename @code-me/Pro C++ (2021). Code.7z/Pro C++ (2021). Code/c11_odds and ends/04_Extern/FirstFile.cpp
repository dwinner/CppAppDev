import <iostream>;

extern int x;

int main()
{
	std::cout << x << std::endl;
}
