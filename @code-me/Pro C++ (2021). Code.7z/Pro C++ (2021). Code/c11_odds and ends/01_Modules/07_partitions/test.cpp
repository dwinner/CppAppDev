import datamodel;

int main()
{
	DataModel::Address a;
}
