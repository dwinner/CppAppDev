import math;

int main()
{
	auto a{ Math::lerchZeta(1, 2, 3) };
	auto b{ Math::superLog(1, 2) };
}
