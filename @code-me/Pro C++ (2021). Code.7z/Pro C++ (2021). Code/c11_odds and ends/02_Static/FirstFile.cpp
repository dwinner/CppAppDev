void f();

int main()
{
	f();
}
