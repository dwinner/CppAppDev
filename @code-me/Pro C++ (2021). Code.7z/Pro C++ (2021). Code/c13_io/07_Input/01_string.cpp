import <iostream>;
import <string>;

using namespace std;

int main()
{
	string userInput;
	cin >> userInput;
	cout << "User input was " << userInput << endl;
}
