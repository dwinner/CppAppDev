package main

func main() {
	var n int
}
