#include "EfficientCarMilesEstimator.h"

int EfficientCarMilesEstimator::getMilesPerGallon() const
{
	return 35;
}
