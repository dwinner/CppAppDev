There are two source files in this directory that define main(). Include
SpreadsheetCell.cpp and one of GridTest.cpp, or GridTestRefNonType.cpp,
in your project.