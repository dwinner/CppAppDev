SpreadsheetTest.cpp does not compile.
