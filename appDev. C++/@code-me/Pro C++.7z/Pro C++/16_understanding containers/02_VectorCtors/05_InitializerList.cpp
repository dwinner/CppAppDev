#include <vector>
using namespace std;

int main()
{
	vector<int> intVector({ 1, 2, 3, 4, 5, 6 });  // Uses C++11 initializer_list
	return 0;
}
