#include "Matrix.h"
#include <iostream>

using namespace std;

int main()
{
	Matrix m(10, 10);
	return 0;
}
