Two source files in this directory include a main() function. Your project
should include SpreadsheetCell.cpp and one of DestructorExamples.cpp or
DestructorHeapExamples.cpp.


