int main() {
  int a[5];
  int index = 6;
  int retval = a[index];
  return retval;
}
