int func() {
  int a = 0;
  int b = 1 / a;
  return b;
}
