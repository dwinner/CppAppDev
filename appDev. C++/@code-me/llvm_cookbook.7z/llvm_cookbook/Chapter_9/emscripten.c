#include <stdio.h>

int main() {
  printf("hi, user!\n");
  return 0;
}
