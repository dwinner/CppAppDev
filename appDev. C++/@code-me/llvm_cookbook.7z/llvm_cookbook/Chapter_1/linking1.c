int func(int a) {
  a = a * 2;
  return a;
}
