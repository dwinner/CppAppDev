#define MAX 100
void func() { int a[MAX]; }
