1. Unzip the folder

2. Go into this folder

$ cd ch4_using_another_pass

3. make opt tool inside the folder as executable

$ chmod +x ./opt

4. Run the opt tool with funcblockcount pass on test4.ll

$ ./opt -funcblockcount ./test4.ll

5. For reference, attached test4.c as example. 
